---
name: Feature request
about: Suggest an idea
title: ''
labels: ''
assignees: ''

---

**Describe the feature you'd like to see added to the app**
A clear and concise description of what you want to happen.
