---
name: Other
about: For other issues, please email support@dev47apps.com first.
title: ''
labels: ''
assignees: ''

---


