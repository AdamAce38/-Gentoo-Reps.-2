===============
whipper-accurip
===============

------------------------------
Handle AccurateRip information
------------------------------

:Author: Louis-Philippe Véronneau
:Date: 2020
:Manual section: 1

Synopsis
========

| whipper accurip **show** *<URL>*
| whipper accurip **-h**

Arguments
=========

| **show** *<URL>*  Show AccurateRip data for the given URL

Options
=======

| **-h** | **--help**
|     Show this help message and exit

See Also
========

whipper(1)
