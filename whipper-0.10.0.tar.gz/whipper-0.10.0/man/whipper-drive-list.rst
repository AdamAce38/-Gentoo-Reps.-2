=====================
whipper-drive-analyze
=====================

---------------------------
List available CD-DA drives
---------------------------

:Author: Louis-Philippe Véronneau
:Date: 2020
:Manual section: 1

Synopsis
========

| whipper drive list [**-h**]

Options
=======

| **-h** | **--help**
|     Show this help message and exit

See Also
========

whipper(1), whipper-drive(1), whipper-drive-analyze(1)
