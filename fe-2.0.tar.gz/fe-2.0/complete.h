#ifndef COMPLETE_H
#define COMPLETE_H

/* Return malloc()ed completion of passed prefix */
char *completefile(const char *path);

#endif
