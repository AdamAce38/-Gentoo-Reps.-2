#ifndef LIBFE_H
#define LIBFE_H

#include "config.h"

#ifdef DMALLOC
#include "dmalloc.h"
#endif

#ifdef HAVE_GETTEXT
#include <libintl.h>
#define _(String) gettext(String)
#else
#define _(String) String
#endif

#include "getopt.h"

#include "buffer.h"
#include "display.h"
#include "macro.h"
#include "misc.h"
#include "msgline.h"

#endif
