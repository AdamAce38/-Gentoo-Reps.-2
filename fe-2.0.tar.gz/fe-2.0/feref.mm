.\"{{{roff}}}\"{{{ strings
.\" variable
.ds V \fI
.ds v \fP
.\" code
.ds C \fB
.ds c \fP
.\" anchor
.ds A \fI
.ds a \fP
.\" emphasize
.ds E \fI
.ds e \fP
.\" keyboard
.ds K \fB
.ds k \fP
.\"}}}
.PH "''\s+4Fe reference card of common commands\s0''"
.nf
.ta 0.3i 0.9i
.sp
.\".S 9 11
.2C
.H 1 "First things first"
\*KM-x\*k		main menu
\*KM-z\*k		save and exit
\*KC-x C-c\*k		exit
\*KM-C-l\*k		redraw screen
.H 1 "Files and Buffers"
\*KC-x C-b\*k		name buffer
\*KC-x C-i\*k		insert file
\*KC-x C-r\*k		load buffer from file
\*KC-x C-s\*k		save buffer to file
\*KC-x C-w\*k		save buffer to new file
.H 1 "Arguments"
\*KM--\*k		set negative argument
\*KM-\*k\*Vdigit\*v		set argument
.H 1 "Moving the cursor"
\*KC-p\*k		previous line
\*KC-n\*k		next line
\*KC-b\*k		backward character
\*KC-f\*k		forward character
\*KC-a\*k		beginning of line
\*KC-e\*k		end of line
\*KC-v\*k		next page
\*KM-v\*k		previous page
\*KM-<\*k		beginning of buffer
\*KM->\*k		end of buffer
\*KM-g\*k		Go to line
\*KC-l\*k		center display
\*KM-#\*k		go to matching fence
.H 1 "Editing"
\*KC-d\*k		delete character under cursor
\*KC-h\*k		delete previous character
\*KC-q\*k		quote character
\*KC-t\*k		transpose character
\*KC-x =\*k		describe line
.H 1 "Regions and the kill ring"
\*KC-@\*k		set mark
\*KC-k\*k		kill to end of line
\*KC-w\*k		kill region
\*KM-w\*k		copy region
\*KC-y\*k		yank current kill ring element back
\*KM-y\*k		move backward in kill ring
\*KC-x C-f\*k		filter region
.H 1 "Folding"
\*KM-C-@\*k		fold region
\*KC-u\*k		unfold
\*KC-o\*k		open fold
\*KC-c\*k		close fold
.H 1 "Search and replace"
\*KC-s\*k		incremental search
\*KC-r\*k		reverse incremental search
	\*KC-h\*k	delete last character
	\*KC-s\*k	next occurence
	\*KC-r\*k	previous occurence
	\*KC-p\*k	previous search string
	\*KC-n\*k	next search string
	\*KC-g\*k	abort searching
	\*KEnter\*k	quit searching
	\*Vother\*v	append character to search string
\*KM-C-r\*k		search backward
\*KM-C-s\*k		search forward
\*KM-R\*k		Search and replace
\*KM-r\*k		Query search and replace
.H 1 "Modes and variables"
\*KC-x m\*k \*Vmode\*v		add (enable) mode
\*KC-x C-m\*k \*Vmode\*v		delete (disable) mode
	\*Ki\*k	auto indent
	\*Ko\*k	overwrite
	\*Kp\*k	show cursor position
\*KC-x :\*k \*Vvariable\*v		set variable
	\*Kd\*k	display/window size
	\*Kl\*k	folding language
	\*Kt\*k	tab width
.H 1 "Macros"
\*KC-x (\*k		start recording macro
\*KC-x )\*k		stop recording macro
\*KC-x e\*k		execute recorded macro
.H 1 "Windows"
\*KC-x 2\*k		split window
\*KC-x 0\*k		delete window
\*KC-x o\*k		switch to next window
.H 1 "Shell commands"
\*KC-x c\*k		start sub shell
\*KC-x !\*k		start shell command
\*KC-z\*k		suspend fe
