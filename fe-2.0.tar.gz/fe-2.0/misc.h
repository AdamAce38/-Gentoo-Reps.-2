#ifndef MISC_H
#define MISC_H

#include "config.h"

/*@null@*/ char *mymemmem(const char *hay, size_t haysize, const char *needle, size_t needlesize);
/*@null@*/ char *myrmemmem(const char *hay, size_t haysize, const char *needle, size_t needlesize);
#ifndef HAVE_STRDUP
/*@null@*/ char *strdup(const char *str);
#endif
#ifndef HAVE_STRNDUP
/*@null@*/ char *strndup(const char *str, size_t len);
#endif
/*@null@*/ const char *getshell(void);
/*@null@*/ char *mytmpnam(char *buf);

#define elementsof(array) ((int)(sizeof(array)/sizeof(array[0])))

#endif
