.. _api:

=========================
 oslo.i18n API Reference
=========================

.. toctree::

   api/modules
