=========================
 oslo.i18n Release Notes
=========================

.. toctree::
   :maxdepth: 1

   unreleased
   2023.2
   2023.1
   victoria
   ussuri
   train
   stein
   rocky
   queens
   pike
   ocata
