### What is the expected behavior
-

### What actually happens
-

### How to reproduce
-

### Environment
| Hardware | description |
|-----|-----|
| GPU | device string |
| CPU | device string |

| Software | version |
|-----|-----|
| ROCK | v0.0 |
| ROCR | v0.0 |
| HCC | v0.0 |
| Library | v0.0 |
