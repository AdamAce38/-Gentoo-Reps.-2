// *************************************************************************
//
// Simple test for compilation issues.
//
// *************************************************************************

#include <mmtf.hpp>
#include <string>

void read_check_file(mmtf::StructureData& data, const std::string& filename);
