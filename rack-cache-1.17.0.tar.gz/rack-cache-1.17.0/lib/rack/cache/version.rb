module Rack
  module Cache
    VERSION = '1.17.0'
  end
end
