warn "use require 'rack/cache/entity_store'"
require 'rack/cache/entity_store'
