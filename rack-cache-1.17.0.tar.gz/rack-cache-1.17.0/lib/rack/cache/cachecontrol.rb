warn "use require 'rack/cache/cache_control'"
require 'rack/cache/cache_control'
