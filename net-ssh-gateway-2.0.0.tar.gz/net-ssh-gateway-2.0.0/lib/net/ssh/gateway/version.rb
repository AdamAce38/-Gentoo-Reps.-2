module Net
  module SSH
    class Gateway
      VERSION = "2.0.0"
    end
  end
end
