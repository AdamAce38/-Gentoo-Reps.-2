#!/usr/bin/env ruby
# frozen_string_literal: true

$:.unshift '../../lib'
require 'rack'
Rack::Server.start
