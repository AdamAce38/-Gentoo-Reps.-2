# -*- test-case-name: tubes.test -*-
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
L{tubes} offers an abstraction of data flow and backpressure for event-driven
applications.

@see: L{tubes.tube}
"""
