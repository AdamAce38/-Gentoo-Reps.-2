print("I'm the result!")
