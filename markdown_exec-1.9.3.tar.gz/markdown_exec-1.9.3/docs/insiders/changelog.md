# Changelog

## Markdown Exec Insiders

### 1.0.1 <small>June 15, 2023</small> { id="1.0.1" }

- Support HTML minification by wrapping code in pre tags
- Catch JS error on pages without Pyodide fences

### 1.0.0 <small>April 26, 2023</small> { id="1.0.0" }

- Add a [`pyodide` fence](../usage/pyodide.md)
