#ifndef __BTFSSTAT_H__
#define __BTFSSTAT_H__

#define XATTR_FILE_INDEX "user.btfs.file_index"
#define XATTR_IS_BTFS_ROOT "user.btfs.is_btfs_root"
#define XATTR_IS_BTFS "user.btfs.is_btfs"

namespace btfs
{
}

#endif
