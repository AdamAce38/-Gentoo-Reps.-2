# frozen_string_literal: true

require "rqrcode/qrcode/qrcode"
