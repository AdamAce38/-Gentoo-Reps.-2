#!/bin/bash

autoreconf -f -i

echo "You may now run ./configure"
