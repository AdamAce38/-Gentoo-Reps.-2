/* @(#) $Id: util.h 1506 2019-11-30 18:39:08Z leres $ (LBL) */

void	dosyslog(int, const char *, u_int32_t, const u_char *, const u_char *);
int	dump(void);
void	dumpone(u_int32_t, const u_char *, time_t, const char *);
char	*intoa(u_int32_t);
/* Note: different implementations in arpwatch and arpsnmp */
void	lg(int, const char *, ...) __attribute__ ((format (printf, 2, 3)));
int	readdata(void);
char	*savestr(const char *);

extern char *arpdir;
extern char *arpfile;
extern char *ethercodes;

extern u_char zero[6];
extern u_char allones[6];
extern u_char vrrp_prefix[5];

extern int debug;
extern int vrrpflag;
extern int zeroflag;
extern int zeropad;
extern int initializing;
