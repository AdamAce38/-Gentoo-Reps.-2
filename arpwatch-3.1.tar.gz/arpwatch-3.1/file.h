/* @(#) $Id: file.h 1008 2009-07-16 03:11:36Z leres $ (LBL) */

typedef int (*file_process)(u_int32_t, const u_char *, time_t, const char *);

int file_loop(FILE *, file_process, const char *);
