/* @(#) $Id: report.h 1008 2009-07-16 03:11:36Z leres $ (LBL) */

void report(const char *, u_int32_t, const u_char *, const u_char *,
    const time_t *, const time_t *);
