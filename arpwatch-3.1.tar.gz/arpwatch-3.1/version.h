/* @(#) $Id: version.h 1001 2009-07-13 07:32:35Z leres $ (XSE) */

#ifndef _version_h
#define _version_h
extern char version[];
#endif
