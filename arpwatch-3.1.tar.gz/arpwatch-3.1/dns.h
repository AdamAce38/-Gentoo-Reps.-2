/* @(#) $Id: dns.h 1000 2009-07-13 06:50:05Z leres $ (LBL) */

int	gethinfo(char *, char *, int, char *, int);
char	*gethname(u_int32_t);
char	*getsname(u_int32_t);
