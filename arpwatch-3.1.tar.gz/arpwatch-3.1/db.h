/* @(#) $Id: db.h 1008 2009-07-16 03:11:36Z leres $ (LBL) */

typedef void (*ent_process)(u_int32_t, const u_char *, time_t, const char *);

#ifdef	DEBUG
void	debugdump(void);
#endif
int	ent_add(u_int32_t, const u_char *, time_t, const char *);
int	ent_loop(ent_process);
void	sorteinfo(void);
