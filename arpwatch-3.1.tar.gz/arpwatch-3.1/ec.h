/* @(#) $Id: ec.h 1008 2009-07-16 03:11:36Z leres $ (LBL) */

typedef int (*ec_process)(u_int32_t, const char *);

char	*e2str(const u_char *);
int	ec_add(u_int32_t, const char *);
char	*ec_find(const u_char *);
int	ec_loop(FILE *, ec_process, const char *);
int	isdecnet(const u_char *);
int	str2e(const char *, u_char *);
