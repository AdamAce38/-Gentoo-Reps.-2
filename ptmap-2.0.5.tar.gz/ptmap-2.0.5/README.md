Integer map implementation using Patricia trees

Follows "Fast Mergeable Integer Maps" by Chris Okasaki and Andrew Gill
(Workshop on ML, 1998)

Note: In 2017, a bug was found in the paper above, which is described
in "QuickChecking Patricia Trees" by Jan Midtgaard. This is fixed in
the present OCaml code.
