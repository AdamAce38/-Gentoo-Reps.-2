
# 2.0.5
  - switch from obuild to dune and to opam 2.0
  - fixed compilation with old versions of OCaml
  - document the difference wrt `Map.S` specs (issue #11)
  - more efficient implementation of `union` (issue #7)
  - add `update` (Andy Li)
  - add `filter_map` (rwmjones)
  - no more use of qtest, move tests from ptmap.ml to test.ml

# 2.0.0
  - added missing functions to conform to `Map.S` (Francois Berenger)
  - unit tests (Francois Berenger)

# 1.0.0
  - first opam package
