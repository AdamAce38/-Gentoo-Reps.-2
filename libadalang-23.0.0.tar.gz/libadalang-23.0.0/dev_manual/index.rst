Welcome to the Libadalang Developer Manual!
===========================================

Contents:

.. toctree::
   :numbered:
   :maxdepth: 2

   testsuite
   dev_doc
   design_documents/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
