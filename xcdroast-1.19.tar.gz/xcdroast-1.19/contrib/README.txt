
X-CD-Roast 1.17 contrib
------------------------------

The files in the directory may be useful for the work
with X-CD-Roast. 
Please refer to the comments within the files for instructions.

I do not know if these work - everything here is just for 
your evaluation, no guarantees at all. 
Use at own risk.

If you also have useful scripts, you want to have included here,
please send them to me.


27.10.2003 Thomas Niederreiter (tn@xcdroast.org)

