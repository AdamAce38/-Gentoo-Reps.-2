#include    <stdio.h>  		/* standard I/O library 	*/
#include    <string.h>          /* standard library             */
#include    <fcntl.h> 	        /* definition of symbols 	*/
#include <sys/types.h>
#include <unistd.h>


/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                  H A U P T P R O G R A M M 			             */
/*                                                                           */
/* (from: Reinhard Drube <drube@ipp.mpg.de>)                                 */
/*---------------------------------------------------------------------------*/

main(int argc,char *argv[])
{
    (void) setuid((uid_t)0);
    (void) seteuid((uid_t)0);

    system("/usr/sbin/vold >/dev/msglog 2>&1 &");

    /* if (argc == 1) {
	if(execl("/usr/sbin/vold",
		 "/usr/sbin/vold",
		 NULL))
	   {  
	      perror("execl"); exit(0);
	   }
	else exit(0);
   }	 */
}
