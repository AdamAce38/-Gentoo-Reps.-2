
This little files are helpful on Solaris machines. There you have
to stop the volume-daemon before you can burn CDs. 

Compile the scripts, chown them to root, give them the SUID-bit.
Now make a wrapper for xcdroast so that the volume-daemon is stopped
at the start of X-CD-Roast and started again when you quit it.

Thanks to Reinhard Drube <drube@ipp.mpg.de>
