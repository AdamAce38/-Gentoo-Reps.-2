/*
 *	main.h
 *
 *	external-function-definitions
 *	21.10.02 tn@xcdroast.org
 *
 *
 *  Copyright (C) 1995, 1996, 1997 Free Software Foundation, Inc.
 *
 *  This file is part of xcdroast.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


gint check_screensize(gint bigfonts);
gint tbf(gint koord);

void my_center_dialog(GtkWidget *dialog);
gint show_dialog(gchar *icon_file, gchar *text, gchar *btn1, gchar *btn2, gchar *btn3, gint defbutton); 
void show_about_dialog();
gint show_fancy_dialog(gchar *htext, gchar *ttext, gchar *btn1, gchar *btn2, gint defbutton);
void define_tooltip(GtkWidget *widget, gchar *text);
void clear_sidespace();
void clear_workspace();
void clear_actionspace();
void set_sidebar_width();
gboolean logo_on_expose(GtkWidget *widget, GdkEventExpose *event, cairo_surface_t *img);
GtkWidget *display_logo(cairo_surface_t *logo, gchar *logo_text);
gint init(gint argc, gchar *argv[], gint *altdevscan);
void create_main(gint confignotloaded);
void create_setup();
void create_duplicate();
void create_create();
void set_font_and_color(GtkWidget *widget, gchar *font, gchar *color);
void set_font_and_color_frame(GtkWidget *widget, gchar *font, gchar *color);
void set_labelcolor(GtkWidget *widget, gchar *color);
void set_clist_row_font(GtkCList *clist, gint row, gchar *ffont);
void set_clist_row_color(GtkCList *clist, gint row, gchar *color);
void free_glist(GList **list);
void copy_glist(GList **dst, GList *src);
void del_glist_link(GList **list, gchar *str);
gint check_in_glist(GList **list, gchar *str);
gint check_in_mstr_glist(GList **list, gchar *str);
void del_mstr_glist_link(GList **list, gchar *str, gint del_both);
void add_redir_mstr_glist(GList **list, gchar *str, gchar *new);
void extract_mstr_path_from_clist(gchar *in, gchar *out);
void get_redir_path_from_mstr_glist(GList **list, gchar *str, gchar *ret);
void get_spawn_path(gchar *app, gchar *ret);

void get_scsi_type_string(gchar *str, gint type, gint removeable);
void scanbus(gint altdevscan);
void scandrivers();
void scancharsets();
void scanoptions(gint write_devnr);
GList *get_dsp_devices();
gchar *gen_mix_from_dspdev(gchar *dsp, gchar *ret);
gchar *get_uname_info(gchar *str);
gint save_setup_config(gchar *confdir, gchar *fname);
gint load_setup_config(gchar *fname, gint rootconf);
void get_cd_toc(gint devnr);
void get_cd_toc_and_volid(gint devnr);
pid_t full_dpl_pipe_shell(gint *out, gint *in, gchar *cmd);
gint query_mixer();
gint set_mixer(gint val);
void kill_readcdda();
gint read_audio_track(gint devnr, gint starttrack, gint endtrack, gint kbyte,
                      gchar *fname, gint startoffset, gint endoffset,
                      gint nrtracks, gfloat percent, gfloat percent_done,
		      gint viewtrack);
gint read_data_track(gint devnr, gint starttrack, gint kbyte,                               	      gchar *fname, gint startoffset, gint endoffset,
                      gint nrtracks, gfloat percent, gfloat percent_done,
		      gint viewtrack);
gint verify_audio_track(gint devnr, gint starttrack, gint endtrack, gint kbyte,
                      gchar *fname, gint startoffset, gint endoffset,
                      gint nrtracks, gfloat percent, gfloat percent_done,
		      gint viewtrack);
gint verify_data_track(gint devnr, gint starttrack, gint kbyte,                               	      gchar *fname, gint startoffset, gint endoffset,
                      gint nrtracks, gfloat percent, gfloat percent_done,
		      gint viewtrack);

void ctree_change_viewmode(gint showfiles, gint showhidden);
void ctree_unselect_all();
void ctree_get_selected(GList **retsel);
void ctree_expand_manualpath(GtkWidget* entry, gchar *altstring);
GtkCTree *create_directory_ctree(gchar *basedir,gchar *title, GtkWidget *win, GtkWidget *entry, gint showfiles, gint showhidden, gint mastermenu);
gint check_iso_file(gint devnr, gchar *isoname, gchar *volid, gint startsec);
gint save_text2file(char *fname, GtkWidget *txt);
gint write_copy_cd_toc_file(gchar *tocfile);
gint read_copy_cd_toc_file(gchar *tocfile);
gint write_inf_file(track_read_param_t *trackparam);
gint get_inf_tracktitle(gchar *path, image_files_t *entry);
void fill_device_info(gint devnr, GtkWidget *txt);
void eject_cd(gint devnr);
void load_cd(gint devnr);
void get_atip_info(gint devnr, GtkWidget *txt);
void get_msinfo_info(gint devnr, gint *nr1, gint *nr2);
void scanblankmodes();
gint read_info_sector_from_file(gchar *isoname, gchar *buf, gint bsize);
gint read_info_sector_from_dev(gint devnr, gchar *buf, gint bsize, gint startsector);
gint start_blanking_process(gint devnr, GtkWidget *text_window);
gint start_bulk_read_action(gint devnr, gfloat percent_done, gint startnr);
gint start_write_action(gint devnr);
gint start_write_onthefly_action(gint read_devnr, gint write_devnr);
gint start_write_fixate_only(gint devnr);
gint start_delete_action(GList *delfiles);
gint start_cddb_lookup_action(gint mode);
gint continue_cddb_lookup_action(gint match);
void test_dspdevice_play();
gint save_isooptions_file(gchar *confdir, gchar *fname);
gint load_isooptions_file(gchar *fname);
gint save_isoheaders_file(gchar *confdir, gchar *fname);
gint load_isoheaders_file(gchar *fname);
gint save_writeoptions_file(gchar *confdir, gchar *fname);
gint load_writeoptions_file(gchar *fname);

gint get_free_space(gchar *path, gchar *filesystem);
gint convert_devnr2devstring(gint devnr, gchar *str);
gint convert_devnr2vendor(gint devnr, gchar *str);
gint convert_devnr2model(gint devnr, gchar *str);
gint convert_devnr2busid(gint devnr, gchar *str);
gint convert_devnr2busid_dev(gint devnr, gchar *str);
void convert_kbytes2mbminstring(gint kbytes, gchar *str);
void convert_kbytes2mbcorrectminstring(gint kbytes, gchar *str);
void convert_kbytes2mbstring(gint kbytes, gchar *str);
void convert_frames2mbminstring(gint frames, gchar *str);
void convert_sectors2mbminstring(gint frames, gchar *str);
void convert_frames2mbstring(gint frames, gchar *str);
void convert_frames2minstring(gint frames, gchar *str);
gint is_directory(gchar *path);
gint is_not_directory(gchar *path);
gint is_file(gchar *path);
gchar *get_basedir(gchar *dir);
gint is_subdirs(gchar *path);
gint is_subfiles(gchar *path);
void show_dir_tree(gchar *retvalue);
GtkWidget *rightjust_gtk_label_new(gchar *txt);
GtkWidget *leftjust_gtk_label_new(gchar *txt);
void show_file_selector(gchar *title, gint mode, gchar *defname, gchar *retvalue);
gchar *strip_string(gchar *str);
gchar *escape_parse(gchar *str);
gchar *convert_escape(gchar *str);
gchar *convert_escape2(gchar *str);
gchar *convert_escape3(gchar *str);
gint remove_illegal_chars(gchar *str);
void remove_illegal_chars_iconv(gchar *str);
gint decode_title_artist(gchar *str, gchar *title, gchar *artist);
gint show_cddb_query(GtkWidget *cdtext_parent, gint onthefly);
gint scan_imagedirs();
gint determine_disc_type(gchar *type_name, gint mode);
gint determine_free_space(gint *biggestfree);
gint read_line(gint fd, gchar *ptr, gint maxlen);
gint read_io_channel_all(GIOChannel *channel, gchar *ptr, gint maxlen);
gint read_io_channel(GIOChannel *channel, gchar *ptr, gint maxlen);
gint read_line_wait(gint fd, gchar *ptr, gint maxlen);
gint allocate_track_filenames(gint *overwrite, gint *overwritebiggest);
gint scan_for_toc_files();
void print_trackreadset();
gint show_mstr_redir(gchar *dir, gchar *ret);
gint show_and_do_read_tracks(gint devnr, gint bulk);
void show_device_detail(gint devnr);
void display_atip_info(gint devnr);
void wait_and_process_events();
void display_blank_cdrw(gint devnr);
void display_advwriteoptions(gint devnr);
gint check_write_files(gint nosizecheck);
gint show_and_do_write_tracks(gint devnr, gint read_devnr, gint onthefly);
off_t get_size_from_imagelist(gchar *tname);
gint get_type_from_imagelist(gchar *tname);
gint get_tracknr_from_imagelist(gchar *tname);
gint get_discid_from_imagelist(gchar *tname, gchar *ret);
gint get_volname_from_imagelist(gchar *tname, gchar *ret);
image_files_t *get_entry_from_imagelist(gchar *tname);
gint show_and_do_delete(GList *delfiles);
gint show_and_do_verify_tracks(gint devnr);
void show_setup_dsptest();
gint extract_quoted(gchar *str);
gint read_line2(gint fd, gchar *ptr, gint maxlen, gint timeout);
gint writen(gint fd, gchar *ptr, gint nbytes, gint newline);
gint check_wav_file(gchar *wavname);
gchar *check_tilde(gchar *str);
gchar *get_pw_home(gint uid);
gint parse_config_line(gchar *iline, gchar *id, gchar *value);
gint parse_config_line2(gchar *iline, gchar *id, gchar *value, gchar *value2);
gint allocate_master_filename(gint size, gint nr, gchar **return_fname,
        gint *overwrite, gint *overwritebiggest);
void sort_glist(GList *filelist);
void sort_int_glist(GList *intlist);
gint show_request_redirect_path(gchar *path, gchar *ret);
gint show_request_redirect_path_multiple(gchar *commonstr, gint nrpaths, gchar *ret);
void wavplay_frontend(GtkWidget *widget);
void wavplay_dodouble();

off_t is_std_wav_file(int f, off_t *offset);

void dodebug(gint debuglevel, gchar *fmt, ...);
void dolog(gint loglevel, gchar *fmt, ...);
void dobeep(gint type);
gint verify_loaded_config();
gint check_vrfy_track(gchar *fname);
void assign_trackname(gchar *titlestr, image_files_t *entry);
gint is_on_writelist(gchar *file);
void clear_trackreadset();

void show_mkisofs_check_output(gint automode,  gint *timeout);
gint fill_mkisofs_check_info(GtkWidget *text_window);
gint show_and_start_master();
gint start_master_action();
gint start_onthefly_master_action(gint write_devnr);

gint check_version_cdrecord(gchar *match, gchar *found, gint *isProDVD);
gint check_version_mkisofs(gchar *match, gchar *found);
gint check_version_cdda2wav(gchar *match, gchar *found);
gint check_version_readcd(gchar *match, gchar *found);
gint check_version_shell();
gint check_version_wrapper(gchar *tmp);

gint stat_file(gchar *file);
gint does_support_burnproof(gint devnr);
gint does_support_varirec(gint devnr);
gint does_support_audiomaster(gint devnr);
gint does_support_forcespeed(gint devnr);
gint isroot();
gint check_pw_user(gchar *name);
gint get_file_owner(gchar *path);
gint match_group_name(gid_t gid, gchar *group);
void return_group_name(gid_t gid, gchar *ret);
void return_user_name(uid_t uid, gchar *ret);
gint check_group_exists(gchar *name);
void parse_alt_devs(gchar *str);
gchar *get_wrap_path(gchar *cmd, gchar *ret);
gint get_gracetime();
gint is_dir_writeable(gchar *dir);
gint extract_singlequoted(gchar *str);
void set_sectorsize(gint devnr, gint size);
gint get_sectorsize(gint devnr);
void get_chown_cmd(gchar *cmd);
void get_chgrp_cmd(gchar *cmd);
void get_chmod_cmd(gchar *cmd);

gint simple_exec(gchar *line);
void add_to_nonrootvalues(GList **list, gchar *path, gint uid, gint gid, gint mode);
void free_nonrootvalues(GList **list);

void edit_cdtext_clicked(GtkWidget *widget, gpointer data);
void switch_artist_title(gchar *dtitle);
void get_artist_and_title_from_cddb(gchar *dtitle, gchar *artist, gchar *title);
void get_title_artist_from_xinf(gchar *file, gchar *artist, gchar *title);
void fill_cdlist();
gint show_edit_cdtext(gint mode, GtkWidget *writetoc_menu);
void cdtext_set_dtitle(gchar *dtitle);
void cdtext_set_ttitle(gchar *ttitle, gint nr);
void edit_xinf_for_cd_text(gchar *trackfile, gchar *tocfile);
gint move_textfile(gchar *src, gchar *target);
void edit_title_artist_in_toc_file(gchar *tocfile, gchar *title, gchar *artist);
void edit_title_artist_in_xinf_file(gchar *trackfile, gchar *title, gchar *artist);
gint create_tmp_writetracks_tocfile(gchar *tocfile);
void generate_tmp_tocfile_name(gchar *tocfile);
void get_cdtitle_from_tmp_tocfile(gchar *tocfile, gchar *cdtitle);
void fill_write_tracks();
void fill_writelist2(GtkCList *llist, GtkWidget *lentry);
void redraw_writelist(GtkCList *llist, GtkWidget *lentry);
void clear_mstr_glist(GList **list);
gint save_master_list(gchar *fname);
gint load_master_list(gchar *fname);
void generate_tmp_file_name(gchar *ext, gchar *file1);
gint write_empty_file(gchar *fname);
gint write_inf_file_for_master(gchar *fname, gint tracknr);
void get_msinfo_from_imagelist(gchar *tname, gint *nr1, gint *nr2);
gint is_a_sony(gint devnr);
gint check_islink(gchar *file, gchar *link);
gint compare_versions(gchar *gotversion, gchar *minimal_version);
void get_common_path_component(GList *dirs, gchar *common);
gint show_mstr_redir_multi(gchar *commondir, gint nrpaths, gchar *ret);
void get_subheader(gchar *buf, gchar *text, gint start, gint end);
gint do_driveropts(gchar *out, gint devnr);
void remove_tmp_xcdr_files();
void remove_master_dir_by_drag(GList *sel);
gchar *url_encode(gchar *s, gint len, gint *new_length);
gint extract_single_drag_filename(gchar *dragtext, gint draglen, gchar *rettext);
gint extract_glist_drag_filenames(gchar *dragtext, gint draglen, gchar *match, GList **dst);
gint create_device_scanning(gint scanparam, gint manual, gint withlogo, gchar *devicestr);
void scanbus_new(GtkWidget *txt, gint scanparam);
void scanbus_new_single(gchar *devstr, GtkWidget *txt);
gint get_writerreaderdevs_index(gint devnr);
gint writemode_supported(gint mode, gint devnr);
void free_writerreader_data();
void preselect_write_mode_menu(GtkWidget *omenu, gint devnr);
gint show_add_manual_device(gchar *newdev);
void remove_from_writerreader_data(gint devnr);
gint get_last_writerreaderdevs_index();
void store_win_geometry(GtkWidget *win);
gint set_win_geometry(GtkWidget *win);
void set_xcdr_title(GtkWidget *dialog, GtkWidget *dialog2, gint val);
gint run_sudo_command(gchar *cmd);
void scanbus_rscsi(gchar *devstr, GtkWidget *txt);
gint get_writerreaderdevs_index_from_devstr(gchar *devstr);
gint check_valid_isrc_mcn(gchar *tname);
gint verify_mcn(gchar *mcn);
gint verify_isrc(gchar *isrc);
gint clear_isrc_mcn_from_tracks();
gint clear_isrc_mcn_from_inffile(gchar *tname);
gchar *get_reducedpath(gchar *dir, gchar *out);
gint charset_convert_to_latin1(gchar *str, gchar *out);
gint charset_convert_to_utf8(gchar *str, gchar *out);
gchar *get_purefile(gchar *dir, gchar *out);
gchar *return_media_type(gint devnr);
void getmodesflags(gchar *dev, gchar *drvflags, gchar *drvmodes);
void generate_tmp_prefix_name(gchar *tmpprefix); 
gchar *pleaseinsertmedia();
gint is_dvdwriter(gint devnr);
GtkWidget *show_dialog_wait(gchar *icon_file, gchar *ttext);
void show_dialog_wait_remove(GtkWidget *dialog);
GtkWidget *my_gtk_dialog_new();
gchar *convert_for_gtk2(gchar *str);
gchar *convert_for_gtk2_filename(gchar *str);
gchar *lookup_stock_icon(gchar *icon);
gint exec_sudo(gchar *cmd);
void append_to_text_view(GtkWidget *txt, gchar *tmp);
void append_to_text_view_bold(GtkWidget *txt, gchar *tmp);
void append_to_text_view_color(GtkWidget *txt, gchar *tmp, gchar *color);
void set_dialog_disallow_delete();
void set_dialog_allow_delete();
gboolean get_dialog_delete_pressed();
void clear_dialog_delete_pressed();
void cancel_show_dialog();
void set_wm_icon();
void append_multiline_to_textview(gchar *str, gchar *trimstr, GtkWidget *txt, gchar *debugcmd);
