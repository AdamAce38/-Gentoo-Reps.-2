/*
 *	language.h
 *
 *	the list of installed language catalogs
 *	needs to be up-to-date to switch languages on-the-fly in setup.
 *	21.10.02 tn@xcdroast.org
 *
 *
 *  Copyright (C) 1995, 1996, 1997 Free Software Foundation, Inc.
 *
 *  This file is part of xcdroast.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define AVAIL_LANG { \
	"English", "C", \
	"German", "de_DE", \
	"French", "fr_FR", \
	"Italian", "it_IT", \
	"Spanish", "es_ES", \
	"Catalan", "ca_ES", \
	"Galician", "gl_ES", \
	"Brasilian Portuguese", "pt_BR", \
	"Dutch", "nl_NL", \
	"Danish", "da_DK", \
	"Norwegian", "nb_NO", \
	"Swedish", "sv_SE", \
	"Finnish", "fi_FI", \
	"Estonian", "et_EE", \
	"Latvian", "lv_LV", \
	"Russian", "ru_RU", \
	"Ukrainian", "uk_UA", \
	"Polish", "pl_PL", \
	"Czech", "cs_CZ", \
	"Slovak", "sk_SK", \
	"Hungarian", "hu_HU", \
	"Romanian", "ro_RO", \
	"Bulgarian", "bg_BG", \
	"Croatian", "hr_HR", \
	"Albanian", "sq_AL", \
	"Greek", "el_GR", \
	"Turkish", "tr_TR", \
	"Simplified Chinese", "zh_CN", \
	"Traditional Chinese", "zh_TW", \
	"Indonesian", "id_ID", \
	"Japanese", "ja_JP", \
	NULL, NULL }
