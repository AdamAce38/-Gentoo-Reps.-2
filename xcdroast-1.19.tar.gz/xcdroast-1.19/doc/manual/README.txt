
Manual/tutorial for X-CD-Roast 0.98alpha14/15
---------------------------------------------
28.05.2003 by Thorsten Staerk 
              (http://www.staerk.de/thorsten)


This manual outlines the most common usage steps for X-CD-Roast.
Please read this if you have any problems and also check the
FAQ for more detailed problem descriptions.

Many thanks to Thorsten Staerk for his great work!

This manual is mirrored on  

	http://www.xcdroast.org/manual


The original work and the most current version can be
found here: 

	http://www.staerk.de/xcdroast/


The PDF-version of that manual was created by James C. Geneva 
<jimgeneva@earthlink.net>.

27.10.2003 Thomas Niederreiter (tn@xcdroast.org)

