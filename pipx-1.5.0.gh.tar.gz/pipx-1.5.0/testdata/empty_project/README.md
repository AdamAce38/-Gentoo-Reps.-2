Empty project used for testing only
