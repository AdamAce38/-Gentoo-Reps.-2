---
name: Feature request
about: Suggest an idea or new feature for this project
---

**How would this feature be useful?**

<!-- Describe any use cases this solves or frustrations it alleviates.   -->

**Describe the solution you'd like**

<!-- If you have an idea of how to do this, write it here! -->

**Describe alternatives you've considered**

<!-- If there's some workaround or alternative solutions, let us know. -->
