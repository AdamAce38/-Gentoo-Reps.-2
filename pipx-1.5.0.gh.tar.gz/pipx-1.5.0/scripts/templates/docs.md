{{ usage }}

### pipx install

{{ install }}

### pipx run

{{run}}

### pipx upgrade

{{upgrade}}

### pipx upgrade-all

{{upgradeall}}

### pipx inject

{{inject}}

### pipx uninstall

{{uninstall}}

### pipx uninstall-all

{{uninstallall}}

### pipx reinstall-all

{{reinstallall}}

### pipx list

{{list}}

### pipx runpip

{{runpip}}
