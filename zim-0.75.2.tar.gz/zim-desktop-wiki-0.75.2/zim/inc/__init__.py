
'''This package contains third party libraries to be packaged
with zim. See the respective files for the copyright and license
notices.
'''
