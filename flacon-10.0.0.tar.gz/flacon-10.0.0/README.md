Flacon      &nbsp;   ![Release](http://flacon.github.io/badge_release.svg)      &nbsp;  ![Build Status](https://github.com/flacon/flacon/actions/workflows/test-linux.yml/badge.svg)      &nbsp;  [![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=XVRVWTQL5WERG)
======

Audio File Encoder.

Flacon extracts individual tracks from one big audio file containing the entire album of music and saves them as separate audio files. To do this, it uses information from the appropriate CUE file.
Besides, Flacon makes it possible to conveniently revise or specify tags both for all tracks at once or for each tag separately.


Get started
-----------
* [Official site](https://flacon.github.io)
* [Get Flacon](https://flacon.github.io/download/)
* [Installation guides](https://github.com/flacon/flacon/wiki/How-to-build)


Documentation
-------------
The Flacon documentation is available at [WIKI](https://github.com/flacon/flacon/wiki)
