#!/bin/sh

tx pull --all --force
