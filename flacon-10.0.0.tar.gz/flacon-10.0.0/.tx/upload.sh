#!/bin/sh

./updateSrc.sh && tx push --source

