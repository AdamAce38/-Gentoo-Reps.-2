#!/bin/bash

iconutil --convert icns --output Flacon.icns Flacon.iconset
