icons8.com
==========
Use for Free, but Please Set a Link

The icons, sounds, and photos are free for personal use and also free for commercial use,
but we require linking to our web site. We distribute them under the license called
**Creative Commons Attribution-NoDerivs 3.0 Unported**.
Alternatively, you could buy a license that doesn't require any linking.

https://icons8.com/license/

-----------------------

Preferneces icons - https://icons8.com/icon/set/popular/ios
* preferences-audio.svg    Music
* preferences-general.svg  Settings
* preferences-programs.svg Puzzle
* preferences-update.svg   Download from the Cloud