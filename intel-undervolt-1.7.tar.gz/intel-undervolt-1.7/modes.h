#ifndef __MODES_H__
#define __MODES_H__

#include <stdbool.h>

bool read_apply_mode(bool write, bool trigger);
int daemon_mode();

#endif
