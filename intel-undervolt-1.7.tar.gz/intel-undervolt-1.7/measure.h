#ifndef __MEASURE_H__
#define __MEASURE_H__

#include <stdbool.h>

bool measure_mode(bool csv, float sleep);

#endif
