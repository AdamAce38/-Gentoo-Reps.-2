# Security Disclosures

To report a security vulnerability, please use the [GitHub private vulnerabilities disclosure](https://github.com/sethmlarson/truststore/security/advisories/new) workflow.
The draft advisory will be used to coordinate the fix and disclosure.
