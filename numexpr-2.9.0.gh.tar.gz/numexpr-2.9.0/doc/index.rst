.. numexpr documentation master file, created by
   sphinx-quickstart on Sat Feb  4 17:19:36 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

NumExpr Documentation Reference
=================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   user_guide
   vm2
   mkl
   api
   release_notes


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

