line\_profiler.timers module
============================

.. automodule:: line_profiler.timers
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
