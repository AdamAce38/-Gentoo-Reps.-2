.. .. manually created (not sure how to get automodule to do it)

kernprof module
===============

.. automodule:: kernprof
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
