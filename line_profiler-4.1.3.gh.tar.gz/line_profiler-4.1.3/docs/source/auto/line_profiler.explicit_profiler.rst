line\_profiler.explicit\_profiler module
========================================

.. automodule:: line_profiler.explicit_profiler
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
