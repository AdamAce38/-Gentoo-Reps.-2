line\_profiler.ipython\_extension module
========================================

.. automodule:: line_profiler.ipython_extension
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
