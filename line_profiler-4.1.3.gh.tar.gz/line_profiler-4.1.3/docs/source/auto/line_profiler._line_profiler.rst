line\_profiler.\_line\_profiler module
======================================

.. automodule:: line_profiler._line_profiler
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
