line\_profiler package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   line_profiler.autoprofile

Submodules
----------

.. toctree::
   :maxdepth: 4

   line_profiler.__main__
   line_profiler._line_profiler
   line_profiler.explicit_profiler
   line_profiler.ipython_extension
   line_profiler.line_profiler

Module contents
---------------

.. automodule:: line_profiler
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
