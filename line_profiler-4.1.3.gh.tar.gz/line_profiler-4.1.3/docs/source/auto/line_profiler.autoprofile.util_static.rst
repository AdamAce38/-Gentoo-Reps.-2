line\_profiler.autoprofile.util\_static module
==============================================

.. automodule:: line_profiler.autoprofile.util_static
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
