line\_profiler.autoprofile.autoprofile module
=============================================

.. automodule:: line_profiler.autoprofile.autoprofile
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
