line\_profiler.\_\_main\_\_ module
==================================

.. automodule:: line_profiler.__main__
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
