line\_profiler.line\_profiler module
====================================

.. automodule:: line_profiler.line_profiler
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
