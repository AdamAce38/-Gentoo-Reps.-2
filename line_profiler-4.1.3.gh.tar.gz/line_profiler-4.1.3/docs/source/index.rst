.. The __init__ files contains the top-level documentation overview
.. automodule:: line_profiler.__init__
   :show-inheritance:

.. toctree::
   :maxdepth: 8
   :caption: Package Layout

   auto/line_profiler
   auto/line_profiler.autoprofile
   auto/line_profiler.explicit_profiler
   auto/kernprof


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
