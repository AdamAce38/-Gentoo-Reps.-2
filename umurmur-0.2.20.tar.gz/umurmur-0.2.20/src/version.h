#ifndef VERSION_H_989876
#define VERSION_H_989876

#define UMURMUR_VERSION "0.2.20"
#define UMURMUR_CODENAME "Bonkers"

#endif

