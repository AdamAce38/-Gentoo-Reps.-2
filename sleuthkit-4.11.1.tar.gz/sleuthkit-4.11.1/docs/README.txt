The docs that used to live in this directory now exist on the wiki:

http://wiki.sleuthkit.org/

