#ifndef WMENU_RENDER_H
#define WMENU_RENDER_H

#include "menu.h"

void calc_widths(struct menu *menu);
void render_menu(struct menu *menu);

#endif
