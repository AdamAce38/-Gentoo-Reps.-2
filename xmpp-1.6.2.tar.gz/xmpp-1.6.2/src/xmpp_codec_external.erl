%% Created automatically by XML generator (fxml_gen.erl)
%% Source: xmpp_codec.spec

-module(xmpp_codec_external).

-compile(export_all).

modules() -> [].

lookup(_, _) -> undefined.

lookup(Term) -> erlang:error(badarg, [Term]).
