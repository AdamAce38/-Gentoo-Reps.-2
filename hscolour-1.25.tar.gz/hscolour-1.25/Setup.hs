#!/usr/bin/env runghc

import Distribution.Simple
main = defaultMain
