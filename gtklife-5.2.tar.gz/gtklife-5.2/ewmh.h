#ifndef EWMH_H
#define EWMH_H

#include <gtk/gtk.h>

void ewmh_toggle_fullscreen(GtkWidget* win);

#endif
