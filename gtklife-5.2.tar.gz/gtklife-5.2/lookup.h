#ifndef LOOKUP_H
#define LOOKUP_H

extern uint8   ul_lookup[0x10000];
extern uint8   ur_lookup[0x10000];
extern uint16  ll_lookup[0x10000];
extern uint16  lr_lookup[0x10000];

#endif
