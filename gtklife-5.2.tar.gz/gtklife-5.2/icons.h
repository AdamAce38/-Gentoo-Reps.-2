#ifndef ICONS_H
#define ICONS_H

/* Defines */

#define ICON_WIDTH   24
#define ICON_HEIGHT  24

/* Externs */

extern uint8  copy_icon[];
extern uint8  cut_icon[];
extern uint8  description_icon[];
extern uint8  draw_icon[];
extern uint8  error_icon[];
extern uint8  new_icon[];
extern uint8  open_icon[];
extern uint8  paste_icon[];
extern uint8  reopen_icon[];
extern uint8  save_icon[];
extern uint8  select_icon[];
extern uint8  start_icon[];
extern uint8  step_icon[];
extern uint8  stop_icon[];
extern uint8  zoom_1_icon[];
extern uint8  zoom_16_icon[];
extern uint8  zoom_in_icon[];
extern uint8  zoom_out_icon[];

#endif
