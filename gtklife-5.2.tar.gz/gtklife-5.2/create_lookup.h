#ifndef CREATE_LOOKUP_H
#define CREATE_LOOKUP_H

#define PROG "create_lookup"

enum {NW, NE, SW, SE, NUM_TEMPLATES};

typedef struct template_struct {
    const char*  name;
    int          shiftage;
    int          bits[4][4];
} template_type;

void process(const char* name, template_type* template);
void usage_abort(void);

#endif
