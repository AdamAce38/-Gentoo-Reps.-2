# x2goserver-extensions
This folder contains the entry-points for server extensions. This is the namespace in which you'll write your server side contributions.

 * bin

   contains the extensions running script. This is the script that starts the extension if provided.

 * lib

   contains the different entry-points for extensions in order to start have entry points to different scripts running on one of these points in time. these folders will contain your extensions scripts.

 * man

   man page documentation

 * share

   feature starting daemon script
