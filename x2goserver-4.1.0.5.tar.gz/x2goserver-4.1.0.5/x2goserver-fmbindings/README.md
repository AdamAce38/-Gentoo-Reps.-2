# x2goserver-fmbindings
This folder contains all scripts and helpers for the ssh mounted Shared Folders in x2go

 * bin

   contains the script to open a shared folder with x2go

 * man

   man page documentation

 * share

   contains the mime type definition as well as a german translation of the binding and the feature script itself.
