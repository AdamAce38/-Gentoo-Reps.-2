# x2goserver-printing
This folder contains the x2go printing service feature.

 * bin

   contains the script that lets you run the print job remotely at your client side.

 * man

   man page documentations

 * share

   contains the feature definition itself.

