# x2goserver-xsession
This folder contains the scripts to enable you to use your own Xsession file instead of the system ones.

 * doc

   documentation folder

 * etc

   contains the default Xsession file

 * share

   contains the feature itself
