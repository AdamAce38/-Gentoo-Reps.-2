#!/bin/bash -ex

apt-get update
