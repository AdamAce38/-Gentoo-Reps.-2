---
name: ❓ Support
about: Questions and requests for support
title: 
labels: support
assignees: ''

---

<!-- Note, that you can also join our community chat, either via Telegram (https://t.me/joinchat/AMhHjj9Txhkhn8JM5_LeMg) or via Matrix (https://matrix.to/#/#openrazer:matrix.org) for questions -->

### Distribution

<!-- Name and version -->

### Support

- [ ] Have you tried rebooting?
- [ ] Have you looked at the [Troubleshooting](https://github.com/openrazer/openrazer/wiki/Troubleshooting) page?

<!-- Please describe your issue here -->

