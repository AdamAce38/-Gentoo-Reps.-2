#include "pinyin_internal.h"


/* deprecated headers:
 * ChewingLargeTable and PhraseLargeTable2.
 * just keep it here for compiling and compatibility. */
#include "chewing_large_table.h"
#include "phrase_large_table2.h"
#include "facade_chewing_table.h"
#include "facade_phrase_table2.h"
#include "pinyin_lookup2.h"

/* Place holder for pinyin internal library. */
