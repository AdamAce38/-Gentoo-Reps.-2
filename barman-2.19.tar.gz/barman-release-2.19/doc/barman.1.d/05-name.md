# NAME

barman - Backup and Recovery Manager for PostgreSQL
