# DESCRIPTION

Barman is an administration tool for disaster recovery of PostgreSQL
servers written in Python and maintained by EnterpriseDB.
Barman can perform remote backups of multiple servers in business critical
environments and helps DBAs during the recovery phase.
