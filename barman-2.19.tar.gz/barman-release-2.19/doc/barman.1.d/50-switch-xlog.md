switch-xlog *SERVER_NAME*
:   Alias for switch-wal (kept for back-compatibility)
