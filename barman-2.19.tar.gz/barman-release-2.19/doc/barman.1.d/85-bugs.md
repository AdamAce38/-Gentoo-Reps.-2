# BUGS

Barman has been extensively tested, and is currently being used in several
production environments. However, we cannot exclude the presence of bugs.

Any bug can be reported via the Github bug tracker. Along with the bug
submission, users can provide developers with diagnostics information
obtained through the `barman diagnose` command.
