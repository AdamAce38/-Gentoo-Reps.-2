check_timeout
:   Maximum execution time, in seconds per server, for a barman check
    command. Set to 0 to disable the timeout.
    Positive integer, default 30. Global/Server.
