barman_lock_directory
:   Directory for locks. Default: `%(barman_home)s`. Global.
