description
:   A human readable description of a server. Server.
