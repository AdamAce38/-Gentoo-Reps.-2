streaming_archiver_name
:   Identifier to be used as `application_name` by the `receive-wal` command.
    Only available with `pg_receivewal` (or `pg_receivexlog` >= 9.3).
    By default it is set to `barman_receive_wal`. Global/Server.
