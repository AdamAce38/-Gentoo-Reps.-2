basebackup_retry_sleep
:   Number of seconds of wait after a failed copy, before retrying
    Used during both backup and recovery operations.
    Positive integer, default 30. Global/Server.
