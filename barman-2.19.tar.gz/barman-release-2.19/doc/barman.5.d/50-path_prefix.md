path_prefix
:   One or more absolute paths, separated by colon, where Barman looks for
    executable files. The paths specified in `path_prefix` are tried before
    the ones specified in `PATH` environment variable. Global/server.
