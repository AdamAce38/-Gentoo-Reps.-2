log_file
:   Location of Barman's log file. Global.
