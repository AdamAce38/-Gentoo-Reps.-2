wals_directory
:   Directory which contains WAL files. Server.
