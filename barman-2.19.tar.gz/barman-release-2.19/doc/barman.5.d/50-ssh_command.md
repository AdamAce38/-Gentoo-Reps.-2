ssh_command
:   Command used by Barman to login to the Postgres server via ssh. Server.
