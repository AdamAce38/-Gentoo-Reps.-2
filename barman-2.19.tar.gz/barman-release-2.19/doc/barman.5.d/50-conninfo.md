conninfo
:   Connection string used by Barman to connect to the Postgres server.
    This is a libpq connection string, consult the
    [PostgreSQL manual][conninfo] for more information. Commonly used
    keys are: host, hostaddr, port, dbname, user, password. Server.

[conninfo]: https://www.postgresql.org/docs/current/static/libpq-connect.html#LIBPQ-CONNSTRING
