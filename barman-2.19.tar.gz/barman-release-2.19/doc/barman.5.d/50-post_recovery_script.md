post_recovery_script
:   Hook script launched after a recovery, after 'post_recovery_retry_script'.
    Global/Server.
