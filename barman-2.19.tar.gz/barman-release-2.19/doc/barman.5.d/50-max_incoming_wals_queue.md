max_incoming_wals_queue
:   Maximum number of WAL files in the incoming queue (in both streaming and
    archiving pools) that are allowed before barman check returns an error
    (that does not block backups). Global/Server. Default: None (disabled).
