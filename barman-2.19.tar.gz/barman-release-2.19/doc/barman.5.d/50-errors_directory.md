errors_directory
:   Directory that contains WAL files that contain an error; usually
    this is related to a conflict with an existing WAL file (e.g. a WAL
    file that has been archived after a streamed one).
