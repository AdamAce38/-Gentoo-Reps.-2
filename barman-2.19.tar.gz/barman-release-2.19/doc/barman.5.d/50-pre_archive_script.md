pre_archive_script
:   Hook script launched before a WAL file is archived by maintenance.
    Global/Server.
