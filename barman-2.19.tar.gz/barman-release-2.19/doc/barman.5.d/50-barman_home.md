barman_home
:   Main data directory for Barman. Global.
