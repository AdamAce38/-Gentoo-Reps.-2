basebackups_directory
:   Directory where base backups will be placed. Server.
