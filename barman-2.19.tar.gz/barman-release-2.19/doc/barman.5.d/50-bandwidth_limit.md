bandwidth_limit
:   This  option  allows  you  to specify a maximum transfer rate in
    kilobytes per second. A value of zero specifies no limit (default).
    Global/Server.
