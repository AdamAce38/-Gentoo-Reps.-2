streaming_wals_directory
:   Directory where WAL files are streamed from the PostgreSQL server
    to Barman. Requires `streaming_archiver` to be enabled. Server.
