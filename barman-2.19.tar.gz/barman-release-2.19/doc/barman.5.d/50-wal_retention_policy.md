wal_retention_policy
:   Policy for retention of archive logs (WAL files). Currently only "MAIN"
    is available. Global/Server.
