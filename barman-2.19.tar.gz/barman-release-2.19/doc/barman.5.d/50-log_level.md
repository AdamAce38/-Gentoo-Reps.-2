log_level
:   Level of logging (DEBUG, INFO, WARNING, ERROR, CRITICAL). Global.
