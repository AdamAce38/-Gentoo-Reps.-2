basebackup_retry_times
:   Number of retries of base backup copy, after an error.
    Used during both backup and recovery operations.
    Positive integer, default 0. Global/Server.
