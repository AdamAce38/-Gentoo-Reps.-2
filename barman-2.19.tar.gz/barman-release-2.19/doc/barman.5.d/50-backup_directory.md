backup_directory
:   Directory where backup data for a server will be placed. Server.
