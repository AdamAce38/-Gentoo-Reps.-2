slot_name
:   Physical replication slot to be used by the `receive-wal`
    command when `streaming_archiver` is set to `on`. Requires
    PostgreSQL >= 9.4. Global/Server. Default: None (disabled).
