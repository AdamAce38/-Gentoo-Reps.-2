pre_recovery_script
:   Hook script launched before a recovery. Global/Server.
