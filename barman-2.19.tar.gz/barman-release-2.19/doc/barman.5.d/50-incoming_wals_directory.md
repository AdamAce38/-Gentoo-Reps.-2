incoming_wals_directory
:   Directory where incoming WAL files are archived into.
    Requires `archiver` to be enabled. Server.
