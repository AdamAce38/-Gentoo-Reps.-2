## Barman INSTALL instructions

For further information, see the "Installation" section in the official manual of Barman or the Markdown source file: [doc/manual/16-installation.en.md](https://github.com/EnterpriseDB/barman/blob/master/doc/manual/16-installation.en.md).
