package internal

// note: do not change this
const ApplicationName = "grype"
const DBUpdateURL = "https://toolbox-data.anchore.io/grype/databases/listing.json"
