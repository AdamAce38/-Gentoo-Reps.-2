package config

type CliOnlyOptions struct {
	ConfigPath string
	Verbosity  int
}
