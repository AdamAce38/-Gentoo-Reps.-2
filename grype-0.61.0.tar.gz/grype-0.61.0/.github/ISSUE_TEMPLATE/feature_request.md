---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**What would you like to be added**:

**Why is this needed**:

**Additional context**:
<!-- Add any other context or screenshots about the feature request here. -->
