package main

import (
	"github.com/anchore/grype/cmd"
)

func main() {
	cmd.Execute()
}
