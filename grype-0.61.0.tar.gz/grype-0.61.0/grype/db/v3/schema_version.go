package v3

const SchemaVersion = 3
