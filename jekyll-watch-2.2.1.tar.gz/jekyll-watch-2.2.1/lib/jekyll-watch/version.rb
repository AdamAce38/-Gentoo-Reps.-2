# frozen_string_literal: true

module Jekyll
  module Watch
    VERSION = "2.2.1"
  end
end
