# frozen_string_literal: true

require "jekyll-watch/version"
require_relative "jekyll/watcher"
require_relative "jekyll/commands/watch"
