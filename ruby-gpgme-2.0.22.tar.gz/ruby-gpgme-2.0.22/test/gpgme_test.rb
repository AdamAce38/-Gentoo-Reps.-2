# -*- encoding: utf-8 -*-
require 'test_helper'

describe GPGME do
  it "should pass" do
    assert true
  end

  it "should also pass" do
    assert true
  end
end
