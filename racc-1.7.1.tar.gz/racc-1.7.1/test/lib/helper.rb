require_relative '../case'
require 'core_assertions'

Racc::TestCase.include Test::Unit::CoreAssertions
