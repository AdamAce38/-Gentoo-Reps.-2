module ROTP
  VERSION = '6.2.2'.freeze
end
