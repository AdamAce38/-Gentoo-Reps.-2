
-- | Extra functions for "System.Environment".
--
--   Currently this module has no functionality beyond "System.Environment".
module System.Environment.Extra  {-# DEPRECATED "Use System.Environment directly" #-} (
    module System.Environment,
    ) where

import System.Environment
