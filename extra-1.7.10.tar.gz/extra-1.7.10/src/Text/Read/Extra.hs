
-- | This module provides "Text.Read" with functions added in later versions.
--
--   Currently this module has no functionality beyond "Text.Read".
module Text.Read.Extra {-# DEPRECATED "Use Text.Read directly" #-} (
    module Text.Read,
    ) where

import Text.Read
