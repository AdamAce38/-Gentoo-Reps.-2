int GetGlVal (Tcl_Interp *interp, int argc, char* argv []);


