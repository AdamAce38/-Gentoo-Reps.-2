# frozen_string_literal: true

module X25519
  VERSION = "1.0.10"
end
