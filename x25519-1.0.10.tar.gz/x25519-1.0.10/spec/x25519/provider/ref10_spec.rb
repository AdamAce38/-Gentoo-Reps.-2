# frozen_string_literal: true

RSpec.describe X25519::Provider::Ref10 do
  include_examples "X25519::Provider"
end
