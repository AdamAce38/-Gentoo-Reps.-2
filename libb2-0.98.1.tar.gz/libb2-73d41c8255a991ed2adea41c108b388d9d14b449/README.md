# libb2

C library providing BLAKE2b, BLAKE2s, BLAKE2bp, BLAKE2sp

Installation:

```
$ ./autogen.sh
$ ./configure
$ make
$ sudo make install
```

Contact: contact@blake2.net
