make maintainer-clean
rm -rf Makefile.in\
       aclocal.m4\
       config.guess\
       config.sub\
       configure\
       depcomp\
       install-sh\
       ltmain.sh\
       missing\
       src/Makefile.in\
       src/config.h.in

