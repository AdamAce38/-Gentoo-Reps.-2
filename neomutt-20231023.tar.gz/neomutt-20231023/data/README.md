## NeoMutt data files

This directory contains examples, scripts, and helpers that we maintain.
