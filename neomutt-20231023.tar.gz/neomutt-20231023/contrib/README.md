## NeoMutt contrib files

This directory contains examples, scripts, and helpers that we do *not* maintain.
