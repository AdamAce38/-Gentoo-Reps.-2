## Security Policy

If you believe you have found a security vulnerability in NeoMutt,
please **don't** open a GitHub Issue.

Please contact the maintainer by email:

[<img align="left" src="https://avatars3.githubusercontent.com/u/76760?s=60">](https://github.com/flatcap)

- Richard Russon ([@flatcap](https://github.com/flatcap)) \<rich@flatcap.org\>  
  `69AD 1D63 6AC2 92E8 2065 8C16 EBC1 50E4 B5DA 63DF`

Thank you :heart:
