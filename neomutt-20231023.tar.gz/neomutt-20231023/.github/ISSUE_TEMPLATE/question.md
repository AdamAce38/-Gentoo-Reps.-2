---
name: "❓ Question"
about: "Ask a question about NeoMutt"
labels: "type:question"

---

<!--
Sometimes NeoMutt can be quite confusing.
We're working on making it easier to understand.
-->

Before asking a question, please check:

- NeoMutt Guide: https://neomutt.org/guide/
- Google:        https://www.google.com/

