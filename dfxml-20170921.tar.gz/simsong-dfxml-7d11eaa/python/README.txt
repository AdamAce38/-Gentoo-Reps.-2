The following DFXML tools are provided:


deidentify.py - Removes PII from filenames in a DFXML file

dfxinfo.py - Print information about a DFXML file
  - Prints a summary about all of the files, duplicate files, histograms of file types.

iredact.py - Image redaction tool using the langauge described in the file.

iverify:   - Reads an XML file and image and verifies that the files are present.
