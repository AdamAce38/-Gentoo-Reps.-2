/*
 * first line
 *
 * second line
 * third line
 */

// and this text also

/*
this type of block comment also
*/

/* this one line comment also */

package testdata
