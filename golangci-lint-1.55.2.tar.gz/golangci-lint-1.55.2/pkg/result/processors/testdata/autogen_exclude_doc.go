package testdata

// DO NOT EDIT

import "fmt"

//nolint:all
func PrintString(s string) {
	fmt.Printf("%s", s)
}
