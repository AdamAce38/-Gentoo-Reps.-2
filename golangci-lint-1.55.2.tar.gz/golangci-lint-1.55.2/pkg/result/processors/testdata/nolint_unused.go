package testdata

var nolintVarcheck int //nolint:varcheck

var nolintVarcheckUnusedOK int //nolint:varcheck,nolintlint
