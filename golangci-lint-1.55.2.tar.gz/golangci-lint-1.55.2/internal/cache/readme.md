# cache

Extracted from go/src/cmd/go/internal/cache/
I don't know what version of Go this package was pulled from.

Adapted for golangci-lint:
- https://github.com/golangci/golangci-lint/pull/699
- https://github.com/golangci/golangci-lint/pull/779
- https://github.com/golangci/golangci-lint/pull/788
- https://github.com/golangci/golangci-lint/pull/808
- https://github.com/golangci/golangci-lint/pull/1063
- https://github.com/golangci/golangci-lint/pull/1070
- https://github.com/golangci/golangci-lint/pull/1162
- https://github.com/golangci/golangci-lint/pull/2318
- https://github.com/golangci/golangci-lint/pull/2352
- https://github.com/golangci/golangci-lint/pull/3012
- https://github.com/golangci/golangci-lint/pull/3096
- https://github.com/golangci/golangci-lint/pull/3204
