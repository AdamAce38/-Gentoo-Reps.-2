export default {
  colors: {
    primary: '#7159c1',
    background: '#fff',
    sidebar: {
      background: '#ffffff',
      link: '#999',
      heading: '#aaa',
      linkActive: '#13131A',
      itemActive: '#F5F5FA',
      footer: '#A8A8B3',
    },
  },
};
