Changes are maintained under [Releases](https://github.com/brianmario/mysql2/releases)
