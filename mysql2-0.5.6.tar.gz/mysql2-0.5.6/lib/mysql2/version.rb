module Mysql2
  VERSION = "0.5.6".freeze
end
