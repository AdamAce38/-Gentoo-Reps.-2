module Mysql2
  Field = Struct.new(:name, :type)
end
