void mysql2_set_local_infile(MYSQL *mysql, void *userdata);
