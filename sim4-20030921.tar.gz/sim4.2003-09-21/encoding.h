/* mechanically generated; do not edit. Mon Jan 24 17:08:16 EST 2000 */
extern const unsigned char nfasta_ctype[256];
extern const unsigned char dna_complement[256];
enum { Nfasta_bad=0, Nfasta_nt=1, Nfasta_ws=2, Nfasta_amb=3 };
