#ifndef SIM_DISCRIM_H
#define SIM_DISCRIM_H
/* $Id: discrim.h,v 1.1 2000/06/05 22:23:15 florea Exp $ */

bool is_DNA(uchar *s, int len);

#endif
