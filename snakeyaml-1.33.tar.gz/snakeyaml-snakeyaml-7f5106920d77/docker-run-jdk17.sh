#!/usr/bin/env bash
./run-in-docker.sh openjdk:17-alpine -Pwith-java11-tests $@
