#!/usr/bin/env bash
./run-in-docker.sh openjdk:11 -Pwith-java11-tests $@
