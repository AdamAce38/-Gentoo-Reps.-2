#!/usr/bin/env bash
./run-in-docker.sh openjdk:8-alpine -Pwith-java8-tests $@
