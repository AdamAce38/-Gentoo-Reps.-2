void generateDefaultMenus();
void refreshMenuLabels();
void unloadMenuLabels();
void show_file_find(bool charcase, bool useLast);
int show_file_find_case_input();
void show_file_position_input(int currentpos);
void show_file_inputs();
void show_file_file_input();
