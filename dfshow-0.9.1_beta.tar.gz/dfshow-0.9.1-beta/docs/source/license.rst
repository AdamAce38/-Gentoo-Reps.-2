License and Credits
===================

DF-SHOW is licensed under the `GNU General Public License v3.0
<https://github.com/roberthawdon/dfshow/blob/master/LICENSE>`_.

Authors
-------

* `Robert Ian Hawdon <https://github.com/roberthawdon>`_

Contributors
------------

* `List of contributors
  <https://github.com/roberthawdon/dfshow/graphs/contributors>`_
