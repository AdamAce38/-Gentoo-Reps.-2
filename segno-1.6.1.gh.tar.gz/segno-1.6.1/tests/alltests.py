# -*- coding: utf-8 -*-
#
# Copyright (c) 2016 - 2024 -- Lars Heuer
# All rights reserved.
#
# License: BSD License
#
"""\
Executes all tests.
"""
if __name__ == '__main__':
    import pytest
    pytest.main()
