This directory contains matrices in the following format:

    0 = white module
    1 = dark module

Example finder pattern:

    1111111
    1000001
    1011101
    1011101
    1011101
    1000001
    1111111

No border / quiet zone should be defined, just the pure matrix.
