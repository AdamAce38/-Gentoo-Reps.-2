Man pages
=========

Documentation of the command line interface.

.. toctree::
   :maxdepth: 3

   segno
