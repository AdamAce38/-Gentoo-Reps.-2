API
===

Module contents
---------------

.. automodule:: segno
    :member-order: bysource
    :members:


High level QR Code factories
----------------------------

.. automodule:: segno.helpers
    :members:
