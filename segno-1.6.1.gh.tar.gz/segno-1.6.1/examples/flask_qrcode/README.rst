Example how to use Segno with `Flask <https://pypi.org/project/Flask/>`_

See https://segno.readthedocs.io/en/latest/web-development.html#flask for
a detailed description.
