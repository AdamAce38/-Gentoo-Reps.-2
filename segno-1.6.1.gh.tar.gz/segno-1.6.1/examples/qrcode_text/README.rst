Examples to add additional text to the generated QR code.

Inspired by https://github.com/lincolnloop/python-qrcode/issues/199

``png_text.py`` requires `Pillow <https://pypi.org/project/Pillow/>`_.
