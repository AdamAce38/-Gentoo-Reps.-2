Example to add an image to a QR code.

See https://github.com/heuer/segno/issues/116

``add_logo.py`` requires `Pillow <https://pypi.org/project/Pillow/>`_.

blackbird.jpg
-------------

* LICENSE `CC0 1.0 Universal Public Domain Dedication <https://creativecommons.org/publicdomain/zero/1.0/deed.en>`_
* CREATOR `Bernard Spragg, NZ <https://www.flickr.com/people/88123769@N02>`_
* SOURCE https://commons.wikimedia.org/wiki/File:Blackbird._(Turdus_merula)_(9513269847).jpg
