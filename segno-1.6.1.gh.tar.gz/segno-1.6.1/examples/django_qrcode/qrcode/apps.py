from django.apps import AppConfig


class QrcodeConfig(AppConfig):
    name = 'qrcode'
