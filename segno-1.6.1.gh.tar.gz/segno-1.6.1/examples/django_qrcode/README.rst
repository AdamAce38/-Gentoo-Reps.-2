Example how to use Segno with `Django <https://pypi.org/project/Django/>`_

See https://segno.readthedocs.io/en/latest/web-development.html#django for
a detailed description.
