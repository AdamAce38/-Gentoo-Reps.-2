require 'busted.modules.luacov'()

