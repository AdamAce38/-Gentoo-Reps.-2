-- supporting testfile; belongs to 'cl_spec.lua'

nothing here, it should just fail when it is being compiled.
