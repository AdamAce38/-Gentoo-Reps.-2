require 'spec.strict'

describe('runs a single successful test with strict', function()

  it('is a succesful test with strict', function()
    -- nothing here, makes it succeed
  end)

end)
