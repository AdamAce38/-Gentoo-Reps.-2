#!/usr/bin/env lua
local exit = require 'busted.compatibility'.exit
print(table.concat(arg, ' '))
exit(0)
