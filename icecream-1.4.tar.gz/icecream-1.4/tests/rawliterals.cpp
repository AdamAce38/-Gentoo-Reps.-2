int main()
{
    const auto vert = R"(
#hello)";
    (void)vert;
    return 0;
}
