#ifndef ICECREAM_TEST_DEFINE
#error Failed.
#endif

// this should expand to test()
void ICECREAM_TEST_DEFINE();

void test2()
    {
    test();
    }
