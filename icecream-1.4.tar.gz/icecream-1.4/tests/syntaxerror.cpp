void f()
    {
    catch throw break auto;
    nonsense;
    }
