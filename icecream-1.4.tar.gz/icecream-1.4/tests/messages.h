#ifndef MESSAGES_H
#define MESSAGES_H

void g()
    {
    int unused; // this should also give a warning about being unused
    }

#endif
