/*
*
*       config.h 
*
* $Id$
*/

#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

/* not much here for now */

#endif /* CONFIG_H_INCLUDED */
