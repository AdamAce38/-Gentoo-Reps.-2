/*
*
*       config.h - describes abilities (desired or actual) of soundcard fd
*
* $NCDId: @(#)config.h,v 1.1 1996/04/24 17:00:31 greg Exp $
*/

#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

/* not much here for now */

#endif /* CONFIG_H_INCLUDED */
