/* emacs buffer mode hint -*- objc -*- */

#import <Foundation/Foundation.h>

@interface HourFormatter : NSFormatter
+ (NSString *)stringForObjectValue:(id)anObject;
@end
