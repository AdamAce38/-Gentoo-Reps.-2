/* emacs buffer mode hint -*- objc -*- */

#import <Foundation/Foundation.h>

@interface NSString(SimpleAgenda)
+ (NSString *)uuid;
- (BOOL)isValidURL;
@end
