#! /usr/bin/env python
"""Setup file for easy installation."""

from setuptools import setup

setup()
