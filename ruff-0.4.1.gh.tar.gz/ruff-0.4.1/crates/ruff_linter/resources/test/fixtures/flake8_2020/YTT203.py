import sys
from sys import version_info

sys.version_info[1] >= 5
version_info[1] < 6
