import sys
from sys import version

py_minor = sys.version[2]
py_minor = version[2]
