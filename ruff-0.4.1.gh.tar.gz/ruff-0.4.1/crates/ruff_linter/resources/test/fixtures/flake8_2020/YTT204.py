import sys
from sys import version_info

sys.version_info.minor <= 7
version_info.minor > 8
