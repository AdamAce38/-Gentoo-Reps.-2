import sys
from sys import version

py_major = sys.version[0]
py_major = version[0]
