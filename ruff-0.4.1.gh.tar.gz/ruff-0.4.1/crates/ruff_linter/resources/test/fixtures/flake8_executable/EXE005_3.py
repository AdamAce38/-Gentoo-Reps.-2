"""
With a docstring
print("commented out code")
"""
# A python comment
#!/usr/bin/python
