print("  #!/usr/bin/python")
# shebang outside of comments should be ignored
