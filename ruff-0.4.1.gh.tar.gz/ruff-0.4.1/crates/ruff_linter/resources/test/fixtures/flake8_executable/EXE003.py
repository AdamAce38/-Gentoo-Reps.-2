#!/usr/bin/bash
print("hello world")
