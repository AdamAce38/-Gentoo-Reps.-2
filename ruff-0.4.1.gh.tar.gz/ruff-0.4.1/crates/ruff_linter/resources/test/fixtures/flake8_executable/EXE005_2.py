print("code prior to shebang")

# A python comment
#!/usr/bin/python
