import warnings

warnings.warn("Hello World!")
