a = "abc"
b = f"ghi{'jkl'}"

c = f"def"
d = f"def" + "ghi"
e = (
    f"def" +
    "ghi"
)
