def func():
    assert True

def func():
    assert False

def func():
    assert True, "oops"

def func():
    assert False, "oops"
