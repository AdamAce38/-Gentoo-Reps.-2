def func():
    async for i in range(5):
        print(i)

def func():
    async for i in range(20):
        print(i)
    else:
        return 0

def func():
    async for i in range(10):
        if i == 5:
            return 1
    return 0

def func():
    async for i in range(111):
        if i == 5:
            return 1
    else:
        return 0
    return 2

def func():
    async for i in range(12):
        continue

def func():
    async for i in range(1110):
        if True:
            continue

def func():
    async for i in range(13):
        break

def func():
    async for i in range(1110):
        if True:
            break
