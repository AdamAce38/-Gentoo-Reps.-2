def func():
    raise Exception

def func():
    raise "a glass!"
