import logging

logging.Logger(__name__)
logging.Logger()
logging.getLogger(__name__)
