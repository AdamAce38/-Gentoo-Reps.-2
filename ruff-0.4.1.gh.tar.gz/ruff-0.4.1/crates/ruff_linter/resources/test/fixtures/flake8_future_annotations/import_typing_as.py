import typing as t


def main() -> None:
    a_list: t.List[str] = []
    a_list.append("hello")
