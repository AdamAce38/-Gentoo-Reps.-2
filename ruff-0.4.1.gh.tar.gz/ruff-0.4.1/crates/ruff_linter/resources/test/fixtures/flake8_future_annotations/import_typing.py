import typing


def main() -> None:
    a_list: typing.List[str] = []
    a_list.append("hello")
