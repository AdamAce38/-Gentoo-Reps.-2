from typing import List
import typing as t


def main(_: List[int]) -> None:
    a_list: t.List[str] = []
    a_list.append("hello")
