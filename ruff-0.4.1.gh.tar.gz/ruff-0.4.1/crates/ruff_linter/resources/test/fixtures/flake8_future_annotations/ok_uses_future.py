from __future__ import annotations


def main() -> None:
    a_list: list[str] = []
    a_list.append("hello")
