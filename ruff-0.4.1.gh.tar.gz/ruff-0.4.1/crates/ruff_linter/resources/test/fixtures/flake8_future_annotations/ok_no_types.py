def main() -> str:
    a_str = "hello"
    return a_str
