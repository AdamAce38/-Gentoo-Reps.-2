from typing import List


def main() -> None:
    a_list: List[str] = []
    a_list.append("hello")
