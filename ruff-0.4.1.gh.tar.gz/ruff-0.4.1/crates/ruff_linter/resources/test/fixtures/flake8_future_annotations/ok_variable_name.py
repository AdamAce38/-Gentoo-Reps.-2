import typing

IRRELEVANT = typing.TypeVar


def main() -> None:
    List: list[str] = []
    List.append("hello")
