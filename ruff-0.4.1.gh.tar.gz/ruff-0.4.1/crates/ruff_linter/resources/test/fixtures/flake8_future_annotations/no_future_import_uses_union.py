def main() -> None:
    a_list: list[str] | None = []
    a_list.append("hello")


def hello(y: dict[str, int] | None) -> None:
    del y
