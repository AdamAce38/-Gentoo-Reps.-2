import datetime

# qualified
datetime.date.fromtimestamp(1234)

from datetime import date

# unqualified
date.fromtimestamp(1234)
