import datetime

# qualified
datetime.date.today()

from datetime import date

# unqualified
date.today()
