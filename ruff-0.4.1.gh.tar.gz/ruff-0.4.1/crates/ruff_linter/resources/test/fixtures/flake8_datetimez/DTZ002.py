import datetime

# qualified
datetime.datetime.today()

from datetime import datetime

# unqualified
datetime.today()

# uses `astimezone` method
datetime.today().astimezone()
