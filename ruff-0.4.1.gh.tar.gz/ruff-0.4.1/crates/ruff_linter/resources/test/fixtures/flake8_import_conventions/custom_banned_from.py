from logging.config import BaseConfigurator  # banned
from typing import Any, Dict  # banned
from typing import *  # banned

from pandas import DataFrame  # banned
from pandas import *  # banned

import logging.config  # ok
import typing  # ok
import pandas  # ok
