import typing as t  # banned
import typing as ty  # banned

import numpy as nmp  # banned
import numpy as npy  # banned
import tensorflow.keras.backend as K  # banned
import torch.nn.functional as F  # banned
from tensorflow.keras import backend as K  # banned
from torch.nn import functional as F  # banned

from typing import Any  # ok

import numpy as np  # ok
import tensorflow as tf  # ok
import torch.nn as nn  # ok
from tensorflow.keras import backend  # ok
