import math  # not checked

import altair  # unconventional
import matplotlib.pyplot  # unconventional
import numpy  # not checked
import pandas  # unconventional
import seaborn  # unconventional

import altair as altr  # unconventional
import matplotlib.pyplot as plot  # unconventional
import numpy as nmp  # not checked
import pandas as pdas  # unconventional
import seaborn as sbrn  # unconventional

import altair as alt  # conventional
import matplotlib.pyplot as plt  # conventional
import numpy as np  # not checked
import pandas as pd  # conventional
import seaborn as sns  # conventional
