import os


async def foo():
    os.popen()


async def foo():
    os.spawnl()


async def foo():
    os.fspath("foo")
