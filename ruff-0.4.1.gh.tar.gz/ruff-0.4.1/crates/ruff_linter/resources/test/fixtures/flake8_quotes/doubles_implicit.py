x = (
    "This"
    "is"
    "not"
)

x = (
    "This" \
    "is" \
    "not"
)

x = (
    "This"
    "is 'actually'"
    "fine"
)

x = (
    "This" \
    "is 'actually'" \
    "fine"
)

if True:
    "This can use 'double' quotes"
"But this needs to be changed"
