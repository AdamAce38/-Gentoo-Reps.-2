"""This is a docstring."""

this_is_an_inline_string = "double quote string"

this_is_a_multiline_string = """
double quote string
"""
