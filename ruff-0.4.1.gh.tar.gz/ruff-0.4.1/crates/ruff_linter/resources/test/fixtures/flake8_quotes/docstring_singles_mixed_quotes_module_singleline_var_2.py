'Do not'" start with empty string" ' and lint docstring safely'

def foo():
    pass
""" this is not a docstring """
