def func1(str, /, type, *complex, Exception, **getattr):
    pass


async def func2(bytes):
    pass

async def func3(id, dir):
    pass

map([], lambda float: ...)
