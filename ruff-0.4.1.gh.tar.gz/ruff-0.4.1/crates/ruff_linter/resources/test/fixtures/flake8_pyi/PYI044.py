# Bad import.
from __future__ import annotations # Not PYI044 (not a stubfile).

# Good imports.
from __future__ import Something
import sys
from socket import AF_INET
