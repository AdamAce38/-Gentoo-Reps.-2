from telnetlib import Telnet

Telnet("localhost", 23)
