def fn():
    # Error
    exec('x = 2')

exec('y = 3')
