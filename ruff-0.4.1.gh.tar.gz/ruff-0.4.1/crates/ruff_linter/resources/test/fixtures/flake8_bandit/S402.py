import ftplib  # S402
from ftplib import FTP  # S402
