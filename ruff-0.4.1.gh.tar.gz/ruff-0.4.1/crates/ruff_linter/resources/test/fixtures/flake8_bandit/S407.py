from xml.dom import expatbuilder  # S407
import xml.dom.expatbuilder  # S407
