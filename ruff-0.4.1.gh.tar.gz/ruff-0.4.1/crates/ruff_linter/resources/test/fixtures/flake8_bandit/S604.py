def foo(shell):
    pass


foo(shell=True)
