import pickle

pickle.loads()
