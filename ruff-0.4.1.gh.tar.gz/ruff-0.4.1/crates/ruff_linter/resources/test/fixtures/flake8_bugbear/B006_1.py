# Docstring followed by a newline

def foobar(foor, bar={}):    
    """
    """
