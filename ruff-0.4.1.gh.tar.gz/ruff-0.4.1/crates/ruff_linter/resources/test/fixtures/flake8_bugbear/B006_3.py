# Docstring with no newline


def foobar(foor, bar={}):    
    """
    """