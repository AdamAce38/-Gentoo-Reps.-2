sum([x.val for x in bar])
min([x.val for x in bar])
max([x.val for x in bar])

# Ok
sum(x.val for x in bar)
min(x.val for x in bar)
max(x.val for x in bar)
