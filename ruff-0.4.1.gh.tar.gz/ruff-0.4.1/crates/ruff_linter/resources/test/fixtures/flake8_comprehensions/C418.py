dict({})
dict({'a': 1})
dict({'x': 1 for x in range(10)})
dict(
    {'x': 1 for x in range(10)}
)

dict({}, a=1)
dict({x: 1 for x in range(1)}, a=1)

