x = [1, 2, 3]
list([i for i in x])
