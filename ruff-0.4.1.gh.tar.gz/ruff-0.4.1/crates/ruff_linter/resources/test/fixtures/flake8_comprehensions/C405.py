set([1, 2])
set((1, 2))
set([])
set(())
set()
set((1,))
set((
    1,
))
set([
    1,
])
set(
    (1,)
)
set(
    [1,]
)
f"{set([1,2,3])}"
f"{set(['a', 'b'])}"
f'{set(["a", "b"])}'

f"{set(['a', 'b']) - set(['a'])}"
f"{ set(['a', 'b']) - set(['a']) }"
f"a {set(['a', 'b']) - set(['a'])} b"
f"a { set(['a', 'b']) - set(['a']) } b"
