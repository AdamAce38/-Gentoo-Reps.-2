from pprint import pprint

pprint("Hello, world!")  # T203

import pprint

pprint.pprint("Hello, world!")  # T203

pprint.pformat("Hello, world!")
