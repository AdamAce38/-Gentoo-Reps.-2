# NOTE: sync with cache::invalidation test
a = 1

__all__ = list(["a", "b"])
