Myspell hyphenation
-------------------

Language: Norwegian Nynorsk (nn NO)
Langauge: Norwegian Bokm�l (nb NO)
Origin:   Generated from the spell-norwegian source v2.0.7
License:  GNU General Public license
Author:   The spell-norwegian project, <URL:https://alioth.debian.org/projects/spell-norwegian/>

HYPH nn NO nn_NO
HYPH nb NO nb_NO

