_______________________________________________________________________________

	DICCIONARI DE PARTICIÓ DE MOTS
	versió 1.5

	Copyright (C) 2013-2023 Jaume Ortolà <jaumeortola@gmail.com> --- Riurau Editors 
	
	Llicència (a la vostra elecció):
		LGPL v. 3.0 o superior --  http://www.gnu.org/licenses/lgpl-3.0.html
		GPL v.3.0 o superior --  http://www.gnu.org/licenses/gpl-3.0.html

	Aquests patrons funcionen amb el LibreOffice i OpenOffice.org 3.2+
	
	Més informació:
		https://www.softcatala.org/programes/diccionari-catala-de-particio-de-mots/
_______________________________________________________________________________
