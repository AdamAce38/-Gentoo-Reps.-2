This Swedish Hyphenation Dictionary is maintained by
Niklas Johansson <sleeping.pillow@gmail.com>.
The most recent version should be available through 
the libreoffice extensions respiratory at:
extensions.libreoffice.org/extension-center
or
http://extensions.services.openoffice.org/

If you find a Swedish word that is hyphenated incorrectly 
please send me a mail at sleeping.pillow@gmail.com

*********************************
* Copyright			*
*********************************

Copyright © 2013 Niklas Johansson <sleeping.pillow@gmail.com>

******* BEGIN LICENSE BLOCK *******
* 
* MPL/LGPLv3+ dual license
* 

******* END LICENSE BLOCK *******
