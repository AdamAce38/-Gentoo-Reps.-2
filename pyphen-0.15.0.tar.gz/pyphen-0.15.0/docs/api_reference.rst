API Reference
=============

.. module:: pyphen

.. autoclass:: Pyphen
   :members:

.. autofunction:: language_fallback

.. autodata:: LANGUAGES
   :annotation:
