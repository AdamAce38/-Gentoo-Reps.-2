Support
=======


Sponsorship
-----------

With `donations and sponsorship`_, you help the projects to be
better. Donations allow the CourtBouillon team to have more time dedicated to
add new features, fix bugs, and improve documentation.

.. _donations and sponsorship: https://opencollective.com/courtbouillon


Professionnal Support
---------------------

You can improve your experience with CourtBouillon’s tools thanks to our
professional support. You want bugs fixed as soon as possible? You projects
would highly benefit from some new features? You or your team would like to get
new skills with one of the technologies we master?

Please contact us by mail_, by chat_ or by tweet_ to get in touch and find the
best way we can help you.

.. _mail: mailto:contact@courtbouillon.org
.. _chat: https://matrix.to/#/#CourtBouillon_community:gitter.im
.. _tweet: https://twitter.com/BouillonCourt
