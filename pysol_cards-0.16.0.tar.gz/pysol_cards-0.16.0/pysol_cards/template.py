# -*- encoding: utf-8 -*-
# pysol_cards v0.16.0
# Deal PySol FC Cards
# Copyright © 2020, Shlomi Fish.
# See /LICENSE for licensing information.

"""
INSERT MODULE DESCRIPTION HERE.

:Copyright: © 2020, Shlomi Fish.
:License: BSD (see /LICENSE).
"""

__all__ = ()
