---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: acrisci

---

The player I am using is [PLAYER].
