#ifndef NCURSES_CONVENIENCE_H
#define NCURSES_CONVENIENCE_H

#include <menu.h>

void clear_body(void);

#endif // NCURSES_CONVENIENCE_H
