#ifndef UI_MUTUAL_H
#define UI_MUTUAL_H

#include "objects_def.h"
#include "device.h"

void ui_dev_descr_format(char *buf, int bufsize, DC_Dev *dev);

#endif  // UI_MUTUAL_H
