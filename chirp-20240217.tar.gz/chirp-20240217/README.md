# CHIRP Project

This is the official git repository for the
__[CHIRP](https://chirp.danplanet.com)__ project.

When submitting PRs, please squash commits into logical units in a fashion
similar to what is currently expected by the project on the mailing list.

For Python3 driver testing status, see [this file](tests/Python3_Driver_Testing.md).
