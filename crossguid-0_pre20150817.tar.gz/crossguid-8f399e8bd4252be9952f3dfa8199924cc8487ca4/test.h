#pragma once

#include "guid.h"
#include <iostream>

int test(GuidGenerator generator, std::ostream &outStream);
