require 'puppet/indirector_testing'
require 'puppet/indirector/msgpack'

class Puppet::IndirectorTesting::Msgpack < Puppet::Indirector::Msgpack
  desc "Testing the MessagePack indirector"
end
