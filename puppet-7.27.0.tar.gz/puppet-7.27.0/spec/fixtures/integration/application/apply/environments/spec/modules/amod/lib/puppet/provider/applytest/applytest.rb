Puppet::Type.type(:applytest).provide(:applytest) do
end
