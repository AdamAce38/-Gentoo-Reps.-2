Puppet::Functions.create_function(:'usee::usee_ruby') do
  def usee_ruby()
    "I'm the function usee::usee_ruby()"
  end
end

