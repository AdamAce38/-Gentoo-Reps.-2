.. _examples:

========
Examples
========
Here are some things you could do with Tekore, enjoy!

.. toctree::
   :maxdepth: 3
   :caption: Index
   :glob:

   examples/*
