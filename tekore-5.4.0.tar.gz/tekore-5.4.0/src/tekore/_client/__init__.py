from .full import Spotify
from .short_link import is_short_link
