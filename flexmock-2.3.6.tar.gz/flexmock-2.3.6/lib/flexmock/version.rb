class FlexMock
    VERSION = "2.3.6"
end
