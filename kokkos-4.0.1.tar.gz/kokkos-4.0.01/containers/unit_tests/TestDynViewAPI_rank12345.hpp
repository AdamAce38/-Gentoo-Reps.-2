//@HEADER
// ************************************************************************
//
//                        Kokkos v. 4.0
//       Copyright (2022) National Technology & Engineering
//               Solutions of Sandia, LLC (NTESS).
//
// Under the terms of Contract DE-NA0003525 with NTESS,
// the U.S. Government retains certain rights in this software.
//
// Part of Kokkos, under the Apache License v2.0 with LLVM Exceptions.
// See https://kokkos.org/LICENSE for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//@HEADER

#include <TestDynViewAPI.hpp>

namespace Test {
TEST(TEST_CATEGORY, dyn_rank_view_api_operator_rank12345) {
  TestDynViewAPI<double, TEST_EXECSPACE>::run_operator_test_rank12345();
}
}  // namespace Test
