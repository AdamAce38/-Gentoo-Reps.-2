#!/bin/env bash

rm -rf /usr/share/doc/cdm
rm -f /etc/cdmrc
rm -f /usr/bin/{cdm,cdm-xlaunch}
