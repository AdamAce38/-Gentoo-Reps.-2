# encoding: utf-8

module Plist
  VERSION = '3.7.0'.freeze
end
