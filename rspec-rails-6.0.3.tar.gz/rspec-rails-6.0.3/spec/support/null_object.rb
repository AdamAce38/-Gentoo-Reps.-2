class NullObject
  private

  def method_missing(method, *args, &blk)
  end
end
