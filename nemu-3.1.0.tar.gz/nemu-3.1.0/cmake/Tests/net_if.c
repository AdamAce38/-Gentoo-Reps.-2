#include <net/if.h>
#include <linux/if.h>

int main()
{
    if_nametoindex("");
    return 0;
}
