# Contributing

If you have a feature request or found a bug - open an issue, and describe it there.

If you want to implement a feature or fix a bug - pull-requests are welcomed.
