#ifndef NM_EASTER_EGG_H_
#define NM_EASTER_EGG_H_

void nm_print_nemu(void);

#endif /* NM_EASTER_EGG_H_ */
/* vim:set ts=4 sw=4: */
