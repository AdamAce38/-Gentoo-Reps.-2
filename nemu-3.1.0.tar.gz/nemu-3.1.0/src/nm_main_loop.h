#ifndef NM_MAIN_LOOP_H_
#define NM_MAIN_LOOP_H_

void nm_start_main_loop(void);

#endif /* NM_MAIN_LOOP_H_ */
/* vim:set ts=4 sw=4: */
