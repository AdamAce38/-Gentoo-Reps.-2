#ifndef NM_RENAME_VM_H_
#define NM_RENAME_VM_H_

#include <nm_string.h>

void nm_rename_vm(const nm_str_t *name);

#endif /*NM_RENAME_VM_H_ */
