#ifndef NM_9P_SHARE_H_
#define NM_9P_SHARE_H_

#include <nm_string.h>

void nm_9p_share(const nm_str_t *name);

#endif /* NM_9P_SHARE_H_ */
/* vim:set ts=4 sw=4: */
