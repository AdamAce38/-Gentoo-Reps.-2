#ifndef NM_VIEWER_H_
#define NM_VIEWER_H_

void nm_viewer(const nm_str_t *name);

#endif /* NM_VIEWER_H_ */
/* vim:set ts=4 sw=4: */
