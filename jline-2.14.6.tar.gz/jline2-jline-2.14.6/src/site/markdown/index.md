<!--

    Copyright (c) 2002-2016, the original author or authors.

    This software is distributable under the BSD license. See the terms of the
    BSD license in the documentation provided with this software.

    http://www.opensource.org/licenses/bsd-license.php

-->
# Jline v2

JLine is a Java library for handling console input.

It is similar in functionality to BSD editline and GNU readline.

People familiar with the readline/editline capabilities for modern shells (such as bash and tcsh)
will find most of the command editing features of JLine to be familiar.