﻿namespace Mond.Compiler.Expressions
{
    interface IStatementExpression
    {
        bool HasChildren { get; }
    }
}
