﻿namespace Mond.Compiler.Expressions
{
    interface IBlockExpression
    {

    }
}
