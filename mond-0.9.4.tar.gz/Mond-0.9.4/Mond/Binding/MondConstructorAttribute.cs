﻿using System;

namespace Mond.Binding
{
    [AttributeUsage(AttributeTargets.Constructor)]
    public class MondConstructorAttribute : Attribute
    {

    }
}
