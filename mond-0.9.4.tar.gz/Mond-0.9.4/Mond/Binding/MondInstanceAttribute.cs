﻿using System;

namespace Mond.Binding
{
    [AttributeUsage(AttributeTargets.Parameter, AllowMultiple = false)]
    public class MondInstanceAttribute : Attribute
    {

    }
}
