/*
 * Ninja IRC update checkign code..
 * 
 * written by Joshua J. Drake
 * 
 */

#ifndef __nchk_up_h_
#define __nchk_up_h_

#include "defs.h"

/* these are strings so i don't have to convert them */
#define NINJA_SERVER_HOST "1070614641"
#define NINJA_SERVER_PORT 3546
#define NINJA_DCC_SERVER_PORT "3547"

#ifdef NON_BLOCKING_CONNECTS
# define NINJA_UPDATE_TIMEOUT 120
#else
# define NINJA_UPDATE_TIMEOUT 30
#endif

/* global prototype... */
	void	ninja_check_update(int);
#ifdef NON_BLOCKING_CONNECTS
	void	ninja_update_chk_connect(void);
#endif

/* vars */
extern	int	update_check_finished;

#endif
