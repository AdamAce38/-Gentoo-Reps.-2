/*
 * includes pertaining to SSL support and ninjassl.c
 *
 * written by Joshua J. Drake <jdrake@qoop.org> jduck@EFNet
 *
 * Distributed under GPL.  For the newest ware, please check out
 * http://ninja.qoop.org/       or      ftp://ninja.qoop.org/
 * 
 */
#ifndef __NSSL_H_
#define __NSSL_H_
#include "defs.h"
#ifdef HAVE_SSL

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/rand.h>

	void	ninja_ssl_init(void);
	void	ninja_ssl_show_errors(void);

#endif /* HAVE_SSL */
#endif /* __NSSL_H_ */
