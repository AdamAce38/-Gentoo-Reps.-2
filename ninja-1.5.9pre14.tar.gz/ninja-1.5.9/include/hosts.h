/*
 * hosts.h
 * 
 * This file describes the the functions used to deal with hostnames and sockets.
 *
 * Functions include:  ones to get sockets, ones to resolve hosts, and ones to connect sockets.
 *
 * written by Joshua J. Drake <jduck@EFNet>
 *
 */

#ifndef __hosts_h_
#define __hosts_h_

#include "irc.h"

/* function prototypes */
	int    	getTCPSock(void);
	/* int    	getUDPSock(void)); */
	int    	resolve_host(struct in_addr *, u_char *);
	int    	tcpConnect(int, struct in_addr, struct sockaddr_in, int);
	/* int    	udpConnect(int, struct sockaddr_in, int)); */

#endif
