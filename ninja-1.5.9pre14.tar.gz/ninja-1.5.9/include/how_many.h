/*
 * how_many.h: header file for how_many.c
 * 
 * how_many() counts the # of characters in a string
 * 
 * written by Joshua J. Drake <jduck@EFNet>
 */

#ifndef __how_many_h
#define __how_many_h

#include "irc.h"

/* function prototypes */
	int	how_many(u_char *, u_char);

#endif
