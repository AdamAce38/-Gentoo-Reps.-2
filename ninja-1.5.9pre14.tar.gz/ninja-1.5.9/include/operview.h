/*
 * operver.h: header file for operview.c
 * 
 * written by Joshua J. Drake and Kraig Amador
 */

#ifndef __operview_h_
# define __operview_h_

#include "irc.h"

/* prototypes */
	void	toggle_operview(u_int, u_char *);

/* vars */
extern	int	oper_view;

#endif /* __ninja_h_ */
