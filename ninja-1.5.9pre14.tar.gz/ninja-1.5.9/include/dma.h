/*
 * dma.h
 * 
 * This file contains prototypes for the dynamically allocated memory functions in dma.c
 *
 * written by Joshua J. Drake
 * copyright (c) 1998-2005
 */

#ifndef __dma_h_
#define __dma_h_

#include "irc.h"

#ifndef IN_IRCIO
/* aliases */
# define new_malloc	dma_Malloc
# define dma_malloc	dma_Malloc

# define new_free	dma_Free
# define dma_free	dma_Free

# define new_realloc	dma_ReAlloc
# define dma_realloc	dma_ReAlloc

# define malloc_strcpy	dma_strcpy
# define malloc_strcat	dma_strcat
# define malloc_strcat_ue	dma_strcat_ue

# define really_free	dma_ReallyFree
# define wait_new_free	dma_WaitFree
#endif

/* function prototypes */
	void	dma_Free(void *);
	void	dma_WaitFree(u_char **);
	void	dma_ReallyFree(int);
	u_char	*dma_ReAlloc(u_char *, int);
	u_char	*dma_Malloc(int);
	int	dma_strcpy(u_char **, u_char *);
	void	dma_strcat(u_char **, u_char *);
	void	dma_strcat_ue(u_char **, u_char *);
#ifdef DMA_DEBUG_INT
	void	save_dma_list(void);
#endif

#endif
