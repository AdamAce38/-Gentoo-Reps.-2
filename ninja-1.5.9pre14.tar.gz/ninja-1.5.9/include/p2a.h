/*
 * pipe to ansi .h
 * 
 * written by Joshua J. Drake and Kraig Amador
 */

#ifndef __p2a_h_
# define __p2a_h_

/* proto types */
	u_char	*pipe_to_ansi(u_char *);

#endif
