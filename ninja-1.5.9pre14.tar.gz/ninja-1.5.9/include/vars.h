/*
 * vars.h: header for vars.c
 *
 * Generated from vars.h.proto automatically by the Makefile
 *
 * Copyright (c) 1990 Michael Sandrof.
 * Copyright (c) 1991, 1992 Troy Rollo.
 * Copyright (c) 1992-2004 Matthew R. Green.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/*
 * NOTE: This file is automatically created!
 *
 * from: @(#) eterna: vars.h.proto,v 1.50 2004/01/06 06:04:59 mrg Exp 
 * @(#)$eterna: vars.h.proto,v 1.50 2004/01/06 06:04:59 mrg Exp $
 */

#ifndef __vars_h_
#define __vars_h_

	int	do_boolean(u_char *, int *);
	void	set_variable(u_char *, u_char *, u_char *);
	int	get_int_var(int);
	u_char	*get_string_var(int);
	void	set_int_var(int, unsigned int);
	void	set_string_var(int, u_char *);
	void	init_variables(void);
	u_char	*make_string_var(u_char *);
	void	set_highlight_char(u_char *);
	int	charset_size(void);
	int	save_variables(FILE *, int);
	void	set_var_value(int, u_char *);

extern	char	*var_settings[];
extern	int	loading_global;

/* var_settings indexes ... also used in display.c for highlights */
#define OFF 0
#define ON 1
#define TOGGLE 2

#define DEBUG_COMMANDS		0x0001
#define DEBUG_EXPANSIONS	0x0002
#define DEBUG_FUNCTIONS		0x0004

/* indexes for the irc_variable array */
#define ALWAYS_SPLIT_BIGGEST_VAR 0
#define ANSI_COLOR_VAR 1
#define ANTI_IDLE_VAR 2
#define AUTO_RECONNECT_VAR 3
#define AUTO_REJOIN_VAR 4
#define AUTO_UNMARK_AWAY_VAR 5
#define AUTO_WHOIS_NICK_IN_USE_VAR 6
#define AUTO_WHOWAS_VAR  7
#define BACKGROUND_COLOUR_VAR 8
#define BACKGROUND_COLOR_VAR BACKGROUND_COLOUR_VAR
#define BEEP_VAR 9
#define BEEP_MAX_VAR 10
#define BEEP_ON_MSG_VAR 11
#define BEEP_WHEN_AWAY_VAR 12
#define	BOLD_VIDEO_VAR 13
#define CHANNEL_NAME_WIDTH_VAR 14
#define CLIENTINFO_VAR 15
#define CLOAK_VAR 16
#define CLOCK_VAR 17
#define CLOCK_24HOUR_VAR 18
#define CLOCK_ALARM_VAR 19
#define CMDCHARS_VAR 20
#define COMMAND_MODE_VAR 21
#define CONTINUED_LINE_VAR 22
#define CTCP_REPLY_BACKLOG_SECONDS_VAR 23
#define CTCP_REPLY_FLOOD_SIZE_VAR 24
#define CTCP_REPLY_IGNORE_SECONDS_VAR 25
#define DCCHOST_VAR 26
#define DCCPORT_VAR 27
#define DCC_AUTOGET_VAR 28
#define DCC_BLOCK_SIZE_VAR 29
#define DCC_IDLE_LIMIT_VAR 30
#define	DEBUG_VAR 31
#define DECRYPT_PROGRAM_VAR 32
#define DEFAULT_AWAY_MSG_VAR 33
#define DEFAULT_BACK_MSG_VAR 34
#define DISPLAY_VAR 35
#define DOUBLE_CHECK_ADDRESSES_VAR 36
#define EIGHT_BIT_CHARACTERS_VAR 37
#define EMAIL_ADDRESS_VAR 38
#define ENCRYPT_PROGRAM_VAR 39
#define EXEC_PROTECTION_VAR 40
#define EXTENDED_CACHE_VAR 41
#define FLOOD_AFTER_VAR 42
#define FLOOD_IGNORE_TIME_VAR 43
#define FLOOD_PROTECTION_VAR 44
#define FLOOD_RATE_VAR 45
#define FLOOD_USERS_VAR 46
#define FLOOD_WARNING_VAR 47
#define FOREGROUND_COLOUR_VAR 48
#define FOREGROUND_COLOR_VAR FOREGROUND_COLOUR_VAR
#define FULL_STATUS_LINE_VAR 49
#define HACKED_IDENTD_VAR 50
#define HELP_PAGER_VAR 51
#define HELP_PATH_VAR 52
#define HELP_PROMPT_VAR 53
#define HELP_WINDOW_VAR 54
#define HIDE_CHANNEL_KEYS_VAR 55
#define HIDE_PRIVATE_CHANNELS_VAR 56
#define HIGHLIGHT_CHAR_VAR 57
#define HISTORY_VAR 58
#define HISTORY_FILE_VAR 59
#define HOLD_MODE_VAR 60
#define HOLD_MODE_MAX_VAR 61
#define IDLE_LIMIT_VAR 62
#define INDENT_VAR 63
#define INPUT_ALIASES_VAR 64
#define INPUT_PROMPT_VAR 65
#define INPUT_PROTECTION_VAR 66
#define INSERT_MODE_VAR 67
#define INVERSE_VIDEO_VAR 68
#define IRCHOST_VAR 69
#define ISO2022_SUPPORT_VAR 70
#define LAG_LIMIT_VAR 71
#define LASTLOG_VAR 72
#define LASTLOG_LEVEL_VAR 73
#define LEADER_VAR 74
#define	LOAD_PATH_VAR 75
#define LOG_VAR 76
#define LOGFILE_VAR 77
#define MAIL_VAR 78
#define MAKE_NOTICE_MSG_VAR 79
#define MAX_RECURSIONS_VAR 80
#define	MENU_VAR 81
#define MINIMUM_SERVERS_VAR 82
#define MINIMUM_USERS_VAR 83
#define MIRC_COLOR_VAR 84
#define NDCC_INTERVAL_VAR 85
#define NDCC_OFFERING_VAR 86
#define NDCC_PUBLIC_VAR 87
#define NDCC_SECURE_VAR 88
#define NO_ASK_NICKNAME_VAR 89
#define NO_CTCP_FLOOD_VAR 90
#define NOTIFY_HANDLER_VAR 91
#define NOTIFY_LEVEL_VAR 92
#define NOTIFY_ON_TERMINATION_VAR 93
#define NOVICE_VAR 94
#define OLD_ENCRYPT_PROGRAM_VAR 95
#define REALNAME_VAR 96
#define RESOLVE_VAR 97
#define SAME_WINDOW_ONLY_VAR 98
#define SCREEN_OPTIONS_VAR 99
#define SCROLL_VAR 100
#define SCROLL_LINES_VAR 101
#define SEND_IGNORE_MSG_VAR 102
#define SHELL_VAR 103
#define SHELL_FLAGS_VAR 104
#define SHELL_LIMIT_VAR 105
#define SHOW_AWAY_ONCE_VAR 106
#define SHOW_CHANNEL_NAMES_VAR 107
#define SHOW_END_OF_MSGS_VAR 108
#define SHOW_NUMERICS_VAR 109
#define SHOW_STARS_VAR $ /* not supported, set -leader if you dont want anything */
#define SHOW_STATUS_ALL_VAR 110
#define SHOW_WHO_HOPCOUNT_VAR 111
#define SILENT_AWAY_VAR 112
#define SOCKS_PROXY_VAR 113
#define SOCKS_USERNAME_VAR 114
#define SOCKS_PASSWORD_VAR 115
#define STAR_PREFIX_VAR 116
#define STATUS_AWAY_VAR 117
#define STATUS_CHANNEL_VAR 118
#define	STATUS_CHANOP_VAR 119
#define STATUS_CLOCK_VAR 120
#define STATUS_FORMAT_VAR 121
#define STATUS_FORMAT1_VAR 122
#define STATUS_FORMAT2_VAR 123
#define STATUS_GROUP_VAR 124
#define STATUS_HOLD_VAR 125
#define STATUS_HOLD_LINES_VAR 126
#define STATUS_INSERT_VAR 127
#define STATUS_LAG_VAR 128
#define STATUS_MAIL_VAR 129
#define STATUS_MODE_VAR 130
#define STATUS_NOTIFY_VAR 131
#define STATUS_OPER_VAR 132
#define STATUS_OVERWRITE_VAR 133
#define STATUS_QUERY_VAR 134
#define STATUS_SERVER_VAR 135
#define	STATUS_UMODE_VAR 136
#define STATUS_USER_VAR 137
#define STATUS_USER1_VAR 138
#define STATUS_USER2_VAR 139
#define STATUS_USER3_VAR 140
#define STATUS_USERS_VAR 141
#define STATUS_VOICE_VAR 142
#define STATUS_WINDOW_VAR 143
#define STRIP_LOG_ANSI_VAR 144
#define STRIP_REDIRECT_ANSI_VAR 145
#define SUPPRESS_SERVER_MOTD_VAR 146
#define SWITCH_TO_QUIET_CHANNELS 147
#define TAB_VAR 148
#define	TAB_MAX_VAR 149
#define TRANSLATION_VAR 150
#define UNDERLINE_VIDEO_VAR 151
#define USE_OLD_MSG_VAR 152
#define USER_INFO_VAR 153
#define	USER_WALLOPS_VAR 154
#define VERBOSE_CTCP_VAR 155
#define WARN_OF_IGNORES_VAR 156
#define XTERM_GEOMOPTSTR_VAR 157
#define XTERM_OPTIONS_VAR 158
#define XTERM_PATH_VAR 159
#define NUMBER_OF_VARIABLES 160

#endif /* __vars_h_ */
