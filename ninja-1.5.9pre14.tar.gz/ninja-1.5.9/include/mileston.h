#ifndef __milestone_h
#define __milestone_h

extern char ninja_release[];
extern unsigned long ninja_internal;

#endif
