/*
 * prototype declarations for nicks.c
 *
 * written by Joshua J. Drake <jdrake@qoop.org> jduck@EFNet
 *
 * Distributed under GPL.  For the newest ware, please check out
 * http://ninja.qoop.org/       or      ftp://ninja.qoop.org/
 * 
 */

#ifndef __NICKS_H_
#define __NICKS_H_

#include "irc.h"

	u_char	*check_nick(u_char *);
	void	free_nick(Nick **);
	Nick	*find_nick(u_char *, u_char *, int, Channel *);
	void	rotate_nick(u_char *);

#endif
