
#ifndef __ninja_redir_h
#define __ninja_redir_h


	void	addredirect(int, u_char *, ...);

#define REDIRECT_MSG		1
#define REDIRECT_SENT_MSG	2
#define REDIRECT_NOTICE		3
#define REDIRECT_SENT_NOTICE	4


#endif
