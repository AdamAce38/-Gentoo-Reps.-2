/*
 * enemies.h: header file for enemies.c
 * 
 * this file contains stuff that supports Ninja IRC's
 * enemy list.
 * 
 * originally by Kraig Amador 
 * mostly re-written by Joshua J. Drake
 */
#ifndef __enemies_h
#define __enemies_h

/* the values must match up */
#define EL_CMODE_STRING		"bkp"
#define EL_CMODE_AUTO_BAN      	0x0001
#define EL_CMODE_AUTO_KICK     	0x0002
#define EL_CMODE_PERMBAN       	0x0004

/* enemy structures */
typedef struct	echanlist_stru
{
	struct	echanlist_stru	*next;
	u_char	*channel;
	u_long	modes;
	time_t	date;
	u_char	*reason;
}	EChan;

/* reuse FHost if possible */
#ifdef FHost
# define EHost FHost
#else
typedef struct	ehostlist_stru
{
	struct	ehostlist_stru  *next;
	u_char	*host;
}	EHost;
#endif

typedef struct	enemylist_stru
{
	struct	enemylist_stru	*next;
   	u_char	*nick;		/* the bad boy's name */
	EHost	*hosts;		/* hosts to recognize them on */
	EChan	*channels;
}	Enemy;

/* enemy list head */
extern	Enemy	*enemy_list;

/* function prototypes */
	u_char	*recreate_ecmode(EChan *);
	u_char	*recreate_eumode(Enemy *);
	EChan	*get_echan(Enemy *, u_char *, int);
	Enemy	*get_enemy(u_char *);
	EHost	*get_ehost(Enemy *, u_char *);
	Enemy	*get_enemy_by_nuh(u_char *, u_char *, u_char *);
	Enemy	*get_enemy_by_mask(u_char *, EHost **);

/* routine prototypes */
	void	enemy_channel_sync(Channel *);
	/* checking for when things happen */
	void	check_enemy_join(Channel *, u_char *, u_char *, u_char *);
	/* loading/saving them */
	int	load_enemies(int);
	int	save_enemies(int);
	/* /commands */
	void	enemy_cmd(u_char *, u_char *, u_char *);

	/* sub command called externally (whois.c) */
	void	ecmd_add_host(u_char *);

#endif
