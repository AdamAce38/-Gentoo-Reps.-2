/*
 * info.h: header for info about who compiled this version.
 */

#ifndef __info_h
#define __info_h

#include "config.h"

extern char *compile_user;
extern char *compile_host;
extern char *compile_time;
extern char *compile_num;
extern char *compile_info;

#endif
