/*
 * nincache.h: header file for nincache.c
 * 
 * prototype for cache parsing code
 * 
 * written by Joshua J. Drake
 */

#ifndef __nincache_h_
# define __nincache_h_

/* procedure prototypes */
	int	parse_into_cache_pre(u_char *, int *);
	int	parse_into_cache_post(u_char *, int *);

#endif /* __grep_h_ */
