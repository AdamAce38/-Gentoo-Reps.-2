/*
 * tabkey.h: header for tabkey.c
 *
 * written by Joshua J. Drake and Kraig Amador
 *
 */

#ifndef __tabkey_h
#define __tabkey_h

#include "irc.h"

typedef struct	nicktab_stru
{
	struct	nicktab_stru	*next;
	u_char	*prompt;
	u_char	*nick;
	int	times;
	time_t	last_used;
   	int 	server;
}	Reply;

	void	tab_reply(u_int, u_char *);
	u_char	*get_tab_key(void);
	void	nchk_tabkeys(time_t);
	void	add_tab_key(int, u_char *, u_char *);

#endif /* __keys_h */
