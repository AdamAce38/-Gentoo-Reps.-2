/*
 * prototype declarations for bans.c
 *
 * written by Joshua J. Drake <jdrake@qoop.org> jduck@EFNet
 *
 * Distributed under GPL.  For the newest ware, please check out
 * http://ninja.qoop.org/       or      ftp://ninja.qoop.org/
 * 
 */

#ifndef __BANS_H_
#define __BANS_H_

#include "irc.h"

/* functions */
	u_char	*cluster(u_char *);

/* procedures */
	void   	add_ban(Channel *, u_char *, u_char *, u_char *);
	void   	ban_queue(WhoisStuff *, u_char *, u_char *);
	void   	unban_queue(WhoisStuff *, u_char *, u_char *);
	void   	remove_matching_bans(u_char *, u_char *, u_char *, u_char *, int);

#endif
