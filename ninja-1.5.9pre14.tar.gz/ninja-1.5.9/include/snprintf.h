/*
 * prototype declarations for snprintf.c
 *
 * written by Joshua J. Drake <jdrake@qoop.org> jduck@EFNet
 *
 * Distributed under GPL.  For the newest ware, please check out
 * http://ninja.qoop.org/       or      ftp://ninja.qoop.org/
 * 
 */

#ifndef __SNPRINTF_H
#define __SNPRINTF_H

#include "defs.h"

#ifndef HAVE_SNPRINTF
int snprintf(char *s, size_t z, const char *f, ...);
#endif

#ifndef HAVE_VSNPRINTF
int vsnprintf(char *s, size_t z, const char *f, va_list vl);
#endif

#endif
