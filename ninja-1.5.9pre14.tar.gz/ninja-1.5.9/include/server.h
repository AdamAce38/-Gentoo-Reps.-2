/*
 * server.h: header for server.c 
 *
 * Written By Michael Sandrof
 *
 * Copyright (c) 1990 Michael Sandrof.
 * Copyright (c) 1991, 1992 Troy Rollo.
 * Copyright (c) 1992-2005 Matthew R. Green.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)$eterna: server.h,v 1.69 2005/04/03 02:35:07 mrg Exp $
 *
 * addition/modifications written by Joshua J. Drake
 */

#ifndef __server_h_
#define __server_h_

#include "ninjassl.h"

/*
 * type definition to distinguish different
 * server versions
 */
#ifdef SUPPORT_ICB
# define ServerICB	-5
#endif
#define Server2_5	0
#define Server2_6	1
#define Server2_7	2
#define Server2_8	3
#define Server2_8_hyb	5
#define Server2_9	6
#define Server2_10	7
#define Server2_11	8

/*
 * Server
 * a type definition for the structured linked list data.
 *
 */
typedef	struct
{
	u_char	*name;			/* the name of the server */
	u_char	*itsname;		/* the server's idea of its name */
	u_char	*password;		/* password for that server */
	int	port;			/* port number on that server */
	u_char	*nickname;		/* nickname for this server */
   /* extra from information */
   u_char	*username;		/* the username the server sees */
   u_char	*hostname;		/* the hostname the server sees */
   u_char	*usermode;		/* the usermode to set on the server */
   /* away stuff */
	u_char	*away;			/* away message for this server */
	time_t	away_set;		/* time that the person was set away */
	u_long	away_count;		/* count of away messages logged */

	int	operator;		/* true if operator */
	int	version;		/* the version of the server -
					 * defined above */
	u_char	*version_string;	/* what is says */
	int	whois;			/* true if server sends numeric 318 */
	u_long	flags;			/* Various flags */
	int	connected;		/* true if connection is assured */
	int	write;			/* write descriptor */
	int	read;			/* read descriptior */
	pid_t	pid;			/* process id of server */
	int	eof;			/* eof flag for server */
	int	motd;			/* motd flag (used in notice.c) */
	int	sent;			/* set if something has been sent,
					 * used for redirect */
   /* these are used for lag checking */
	int	lag;			/* lag in seconds */
	time_t	lag_time;		/* last lag check time */
	int	in_ping;		/* if we're ping'n */
   
	u_char	*buffer;		/* buffer of what dgets() doesn't get */
	WhoisQueue	*WQ_head;	/* WHOIS Queue head */
	WhoisQueue	*WQ_tail;	/* WHOIS Queue tail */
	WhoisStuff	whois_stuff;	/* Whois Queue current collection buf */
	int	close_serv;		/* Server to close when LOGGED_IN */
        time_t	ctcp_last_reply_time;   /* used to limit flooding */
        time_t	ctcp_flood_time;
        int	ctcp_backlog_size;
        int	*ctcp_send_size;
	struct in_addr local_addr;	/* ip address of this connection */
        u_char	*group;			/* ICB group */
#ifdef SUPPORT_ICB   
        u_char	*icbmode;	       	/* ICB initial mode */
#endif
        Channel	*chan_list;		/* list of channels for this server */
					/* pointer to parser for this server */
	void	(*parse_server)(u_char *);
	int	server_group;		/* group this server belongs to */
	int	attempting_to_connect;	/* are we trying to connect this server? */
	struct	addrinfo *res, *res0;	/* current lookup; for non blocking support */
	SOCKADDR_STORAGE *localaddr;	/* currently bound local port */
	int 	localaddrlen;		/* length of above */
   
   /* what channel/usermode the server allows obtained from #004 */
   	u_char	*cmodes;		/* the server's allowed channel modes */
   	u_char	*umodes;		/* the server's allowed user modes */
   /* this is used to keep track of who we've done a /who on when they joined
    * a channel...  sloppy i know..
    */
   	u_char	*who_nicks;
   /* ssl support */
#ifdef HAVE_SSL
   	SSL_CTX *ctx;
   	SSL 	*ssl;
   	u_char 	*cert;
   	int 	sslerr;
#endif /* HAVE_SSL */
}	Server;

/* SGroup: a structure for server groups. */
typedef struct ser_group_list
{
	struct ser_group_list	*next;
	u_char	*name;
	int	number;
}	SGroup;

typedef	unsigned	short	ServerType;

	int	find_server_group(u_char *, int);
	u_char *	find_server_group_name(int);
	void	add_to_server_list(u_char *, int, u_char *, u_char *,
				   int, int, int, u_char *, u_char *);
/* flags for add_to_server_list() */
#define SL_ADD_OVERWRITE	0x1
#define SL_ADD_SSL		0x2
	void	build_server_list(u_char *);
	int	connect_to_server(u_char *, int, u_char *, int);
	void	get_connected(int);
	int	read_server_file(void);
	void	display_server_list(void);
	void	do_server(fd_set *, fd_set *);
	void	send_to_server(char *, ...);
	int	get_server_whois(int);

	WhoisStuff	*get_server_whois_stuff(int);
	WhoisQueue	*get_server_qhead(int);
	WhoisQueue	*get_server_qtail(int);

extern	int	save_chan_from;	/* to keep the channel list if all servers
				 * are lost */

extern	int	number_of_servers;
extern	int	connected_to_server;
extern	int	never_connected;
extern	int	using_server_process;
extern	int	primary_server;
/*
 * server we're currently interested in; set for window operations or
 * pretending to be on another server.
 */
extern	int	from_server;
/* set to the server we last got a message from */
extern	int	parsing_server_index;
extern	SGroup	*server_group_list;

	void	add_server_to_server_group(int, u_char *);
	void	servercmd(u_char *, u_char *, u_char *);
	u_char	*get_server_nickname(int);
	u_char	*get_server_name(int);
	u_char	*get_server_itsname(int);
	void	set_server_flag(int, int, int);
	int	find_in_server_list(u_char *, int, u_char *);
	u_char	*create_server_list(void);
	void	remove_from_server_list(int);
	void	set_server_motd(int, int);
	int	get_server_motd(int);
	int	get_server_operator(int);
	int	get_server_2_6_2(int);
	int	get_server_version(int);
	u_char	*get_server_password(int);
#ifdef SUPPORT_ICB
	u_char	*get_server_icbgroup(int);
	u_char	*get_server_icbmode(int);
#endif
	void	close_server(int, u_char *);
	void	MarkAllAway(u_char *, u_char *);
	int	is_server_connected(int);
	void	flush_server(void);
	int	get_server_flag(int, int);
	void	set_server_operator(int, int);
	void	server_is_connected(int, int);
	int	parse_server_index(u_char *);
	void	parse_server_info(u_char **, u_char **, u_char **,
				  u_char **, u_char **, u_char **, 
				  int *, u_char **, u_char **);
	void	set_server_bits(fd_set *, fd_set *);
	void	set_server_itsname(int, u_char *);
	void	set_server_version(int, int);
	int	is_server_open(int);
	int	get_server_port(int);
	u_char	*set_server_password(int, u_char *);
	void	set_server_nickname(int, u_char *);
	void	set_server_2_6_2(int, int);
	void	set_server_qhead(int, WhoisQueue *);
	void	set_server_qtail(int, WhoisQueue *);
	void	set_server_whois(int, int);
#ifdef SUPPORT_ICB
	void	set_server_icbgroup(int, u_char *);
	void	set_server_icbmode(int, u_char *);
#endif
	void	set_server_server_group(int, int);
	void	close_all_server(void);
	void	disconnectcmd(u_char *, u_char *, u_char *);
	void	ctcp_reply_backlog_change(int);
	SOCKADDR_STORAGE *get_server_localaddr(int);
	int	get_server_localaddrlen(int);
	int	 active_server_group(int sgroup);

/* ninja extensions */
	int	get_server_lag(int);
	void	set_server_lag(int);
#ifdef HAVE_SSL
	int	get_server_ssl(int);
	void	set_server_ssl(int, int);
#endif

	/* server_list: the list of servers that the user can connect to,etc */
	extern	Server	*server_list;

/*
 * valid server flags..
 */

#define	SERVER_2_6_2	0x00000001

#define UNUSED_1	0x00000002
#define UNUSED_2	0x00000004
#define UNUSED_3	0x00000008

#define PROXY_CONNECTED		0x00000010
#define PROXY_AUTH_SENT 	0x00000020
#define PROXY_AUTH_OK		0x00000040
#define PROXY_LOGIN_SENT 	0x00000080
#define PROXY_LOGIN_OK		0x00000100
#define PROXY_CONNECT_SENT 	0x00000200
#define PROXY_CONNECT_OK 	0x00000400
#define PROXY_ALL_OK		(PROXY_CONNECTED|PROXY_AUTH_SENT|PROXY_AUTH_OK|PROXY_LOGIN_SENT|PROXY_LOGIN_OK|PROXY_CONNECT_SENT|PROXY_CONNECT_OK)

#ifdef HAVE_SSL
#define SSL_ENABLED    	0x00000800
#else
#define UNUSED_4	0x00000800
#endif

#define SRV_CONNECTED	0x00001000
#define LOGGED_IN	0x00002000
#define CLEAR_PENDING	0x00004000	/* set for servers whose channels are to be
					 * removed when a connect has been established. */
#define CLOSE_PENDING	0x00008000	/* set for servers who are being switched
					 * away from, but have not yet connected. */
#define SERVER_FAKE	0x00010000	/* server is fake entry; not connected to yet.
					 * will be GCed after connect_to_server_*(). */
#define UNUSED_5	0x00020000
#define UNUSED_6	0x00040000
#define UNUSED_7	0x00080000

#define	USER_MODE_I	0x00100000
#define	USER_MODE_W	0x00200000
#define	USER_MODE_S	0x00400000	/* obsolete */
#define USER_MODE_Z	0x00800000
#define USER_MODE_C	0x01000000
#define USER_MODE_R	0x02000000
#define USER_MODE_K	0x04000000
#define USER_MODE_F	0x08000000
#define USER_MODE_Y	0x10000000
#define USER_MODE_D	0x20000000
#define USER_MODE_N	0x40000000
#define USER_MODE_A	0x80000000 	/* away status, not really used */

#ifdef SUPPORT_ICB
/* pick the default port if none is given. */
# define	CHOOSE_PORT(type) \
	(((type) == ServerICB || ((type) == -1 && client_default_icb)) \
		? icb_port : irc_port)
#else
# define	CHOOSE_PORT(type)	irc_port
#endif

#endif /* __server_h_ */
