/*
 * Main include file for Ninja IRC additions to ircII
 * 
 * written by Joshua J. Drake and Kraig Amador
 */

#ifndef __ninja_h_
# define __ninja_h_

#include "list.h"
#include "channels.h"
#include "nicks.h"
#include "window.h"

#ifdef __MSDOS__
#define NINJA_DIR		"ninja"
#else
#define NINJA_DIR_1		"/.ninja"
#define NINJA_DIR		"~" NINJA_DIR_1
#endif
#define NINJA_AWAY_FILE		NINJA_DIR "/away"
#define NINJA_FRIEND_FILE      	NINJA_DIR "/friends"
#define NINJA_ENEMY_FILE	NINJA_DIR "/enemies"
#define NINJA_SAVE_FILE		NINJA_DIR "/save"
#define NINJA_CKEY_FILE		NINJA_DIR "/ckeys"
#define NINJA_HISTORY_FILE	NINJA_DIR "/history"
#define NINJA_RC_FILE		NINJA_DIR_1 "/rc"
#define NINJA_QUICK_FILE       	NINJA_DIR_1 "/quick"

#define NINJA_EMAIL		"ninja@qoop.org"
#define NINJA_AUTHOR		"Joshua J. Drake <jduck@EFNet> and Kraig Amador."

	u_char	*ninja_size(unsigned long);
	u_char	*ninja_etime(unsigned long);
	u_char	*ninja_host(struct in_addr);

	u_char	*ninja_strftime(time_t *, u_char *);
	u_char	*ninja_date(time_t *);
	u_char	*ninja_ctime(time_t *);

	int	ninja_parse_mode(u_char *, u_long *, const u_char *);
	int	ninja_recreate_mode(u_long, const u_char *, u_char *, size_t);

	void	ninja_load_saves(void);
	void	ninja_check_update(int);

	void	usage(u_char *, u_char *);

	void	do_server_lag_check(int, time_t);

	u_char	*ninja_make_nuh(u_char *, u_char *, u_char *);

extern	u_char *leader;


extern void add_to_awaylog(char *, ...);
extern void close_away_log(u_char *);
extern void open_away_log(u_char *);
extern void load_userlist(void);
extern void save_userlist(int);
extern void wrong(char *);
extern char *make_nice(char *);
extern char *un_nice(char *);
extern char *strip_8bit(char *);
/* extern void strip_mean_ansi(char *); */
extern char *strip_ansi(char *);
extern char *strip_path(char *);
extern void add_to_bans();
extern int checkgrep();
extern char *strfill(char c, int num);
extern void ninja_check();
extern	void	check_idleaway();
extern void adddelayop();

extern	int	ninja_chkfiles(char **, char *, unsigned long *);

extern char ansi_stripped[BIG_BUFFER_SIZE + 1];
extern char bit_stripped[BIG_BUFFER_SIZE + 1];

typedef struct delayop_stru
{
   struct delayop_stru *next;
   u_char *nick;
   u_char *channel;
   int server;
   int delay;
   time_t time;
} DelayOp;

#endif /* __ninja_h_ */
