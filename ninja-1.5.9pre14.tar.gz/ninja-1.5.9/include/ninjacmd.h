/*
 * ninjacmd.h:
 * 
 * this file contains code declaring routines dealing 
 * with /commands for ninja irc
 * 
 * written by Kraig Amador and Joshua J. Drake
 *
 */

#ifndef __ninja_cmd_h
#define __ninja_cmd_h

#include "defs.h"

/* general commands */
	void	whois2(u_char *, u_char *, u_char *);

/* name/host commands */
	void	chhost(u_char *, u_char *, u_char *);
	void	chuname(u_char *, u_char *, u_char *);

/* internal information commands */
	void	ninja_about(u_char *, u_char *, u_char *);
	void	uptime(u_char *, u_char *, u_char *);
	void	update_cmd(u_char *, u_char *, u_char *);

/* channel commands */
#ifdef ALLOW_RESYNC
	void	resync(u_char *, u_char *, u_char *);
#endif
	void	ninja_scan(u_char *, u_char *, u_char *);
	void	users(u_char *, u_char *, u_char *);
	void	cycle(u_char *, u_char *, u_char *);
	void	do_wall(u_char *, u_char *, u_char *);
	void	show_ban_cache(u_char *, u_char *, u_char *);
	/* kick commands */
	void	do_special_k(u_char *, u_char *, u_char *);
	void	filter_kick(u_char *, u_char *, u_char *);
	void	lamer_kick(u_char *, u_char *, u_char *);
	/* (de)op commands */
	void	give_or_take_ops(u_char *, u_char *, u_char *);
#ifdef ALLOW_OJ
	void	oj(u_char *, u_char *, u_char *);
#endif
	/* misc mode commands */
	void	chkey(u_char *, u_char *, u_char *);
	void	change_channel_limit(u_char *, u_char *, u_char *);
	/* mass modes! */
	void	mass(u_char *, u_char *, u_char *);
	void	mass_abbrev(u_char *, u_char *, u_char *);
	void	mdop(u_char *, u_char *, u_char *);
	/* (un)ban commands */
	void	do_ban_stuff(u_char *, u_char *, u_char *);

/* server commands */
	void	addserver(u_char *, u_char *, u_char *);
	void	removeserver(u_char *, u_char *, u_char *);
	void	reconnect(u_char *, u_char *, u_char *);

/* misc commands */
	void	ninja_save(u_char *, u_char *, u_char *);
	void	ninja_redirect(u_char *, u_char *, u_char *);

/* away log commands */
	void	short_eraselog(u_char *, u_char *);
	void	away(u_char *, u_char *, u_char *);
	void	back(u_char *, u_char *, u_char *);

/* /all type commands */
	void	ame(u_char *, u_char *, u_char *);


#endif
