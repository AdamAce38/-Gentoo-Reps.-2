/*
 * orignick.h: header file for orignick.c
 * 
 * written by Joshua J. Drake and Kraig Amador
 */

#ifndef __orignick_h_
# define __orignick_h_

#include "irc.h"

/* prototypes */
	void	nchk_orignick(u_char *);
	void	orignick_queue(WhoisStuff *, u_char *, u_char *);
	void	orignick_cmd(u_char *, u_char *, u_char *);

/* vars */
extern	u_char	*orignickname;

#endif /* __ninja_h_ */
