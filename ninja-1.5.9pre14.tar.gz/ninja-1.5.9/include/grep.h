/*
 * grep.h: header file for grep.c
 * 
 * prototypes for channel greping..
 * 
 * written by Kraig Amador
 */

#ifndef __grep_h_
# define __grep_h_

#include "irc.h"

/* structures */
typedef struct changrep
{
   struct	changrep *next;
   u_char	*channel;
   u_char	*words;
}	ChanGrep;

/* function prototypes */
	void	grep(u_char *, u_char *, u_char *);
	int	checkgrep(u_char *, u_char *);

/* globals */
extern	ChanGrep	*grep_list;

#endif /* __grep_h_ */
