/*
 * ckey.h: Header for ckey.c
 *
 * written ny Joshua J. Drake
 *
 */

#ifndef __ckey_h_
#define __ckey_h_

#include "irc.h"

/* prototypes */
	int	load_ckeys(void);
	int	save_ckeys(int);
	u_char	*get_ckey(u_char *);
	void	add_ckey(u_char *, u_char *);

#endif /* __ckey_h_ */
