/*
 * struct.h: header file for structures needed for prototypes
 *
 * Written by Scott Reynolds, based on code by Michael Sandrof
 *
 * Copyright(c) 1995 Scott Reynolds.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#)$eterna: struct.h,v 1.23 2004/01/06 06:06:32 mrg Exp $
 */

#ifndef __struct_h_
#define	__struct_h_

#include "ninjassl.h"

/*
 * ctcp_entry: the format for each ctcp function.   note that the function
 * described takes 4 parameters, a pointer to the ctcp entry, who the message
 * was from, who the message was to (nickname, channel, etc), and the rest of
 * the ctcp message.  it can return null, or it can return a malloced string
 * that will be inserted into the oringal message at the point of the ctcp.
 * if null is returned, nothing is added to the original message
 */
typedef	struct _ctcp_entry
{
	u_char	*name;		/* name of ctcp datatag */
	u_char	*desc;		/* description returned by ctcp clientinfo */
	int	flag;
	u_char	*(*func)(struct _ctcp_entry *, u_char *, u_char *, u_char *);	/* function that does the dirty deed */
}	CtcpEntry;

typedef	struct	DCC_struct
{
	unsigned	flags;
	int	read;
	int	write;
	int	file;
	off_t	filesize;
	u_char	*description;
	u_char	*user;
	u_char	*othername;
   	u_char	*remname;
	u_short	remport;
	off_t	bytes_read;
	off_t	bytes_sent;
	time_t	lasttime;
	time_t	starttime;
	u_char	*buffer;
	struct DCC_struct	*next;
   /* the following fields added for ninja irc */
        off_t	resume_offset;
        float	minimum_speed;
#ifdef HAVE_SSL
   	SSL	*ssl;
   	SSL_CTX *ctx;
   	char 	*cert;
   	int	sslerr;
#endif
}	DCC_list;

/* Hold: your general doubly-linked list type structure */

typedef struct HoldStru
{
	u_char	*str;
	struct	HoldStru	*next;
	struct	HoldStru	*prev;
	int	logged;
}	Hold;

typedef struct	lastlog_stru
{
	int	level;
	u_char	*msg;
	struct	lastlog_stru	*next;
	struct	lastlog_stru	*prev;
}	Lastlog;

struct	MenuOptionTag
{
	u_char	*Name;
	u_char	*Arguments;
	void	(*Func)(u_char *);
};

typedef	struct	MenuOptionTag	MenuOption;

struct	MenuTag
{
	struct	MenuTag	*next;
	u_char	*Name;
	int	TotalOptions;
	MenuOption	**Options;
};

typedef struct MenuTag Menu;

struct	ScreenStru;	/* ooh! */

struct	WindowMenuTag
{
	Menu	*menu;
	int	lines;
	int	items_per_line;
	int	cursor;
};

typedef	struct	WindowMenuTag	WindowMenu;

/* NickList: structure for the list of nicknames of people on a channel */
typedef struct nick_stru
{
	struct	nick_stru	*next;	/* pointer to next nickname entry */
	u_char	*nick;			/* nickname of person on channel */
   /* ninja specific fields below */
   	int	status;			/* this nick's status */
#define NICK_HERE	0x01
#define NICK_AWAY	0x02
#define NICK_PLACE_MASK	0x0f
#define NICK_CHOP	0x10
#define NICK_VOICE	0x20
#define	NICK_OPER	0x40
#define NICK_PRIV_MASK	0xf0
   	int	hops;			/* how many irc server hops away */
   	u_char	*user;			/* the users username */
   	u_char	*host;			/* the user's host */
   	struct in_addr ip;		/* the user's IP if we happen to come accross it */
   	u_char	*realname;		/* what the users real name is */
   	u_char	*server;		/* what server the user is on */
   	time_t	signon_time;		/* when the user signed on */
   	u_long	idle_secs;		/* how long the user has been idling */
}	Nick;
#define NickList Nick

typedef	struct	DisplayStru
{
	u_char	*line;
	int	linetype;
	struct	DisplayStru	*next;
}	Display;

typedef	struct	WindowStru
{
	unsigned int	refnum;		/* the unique reference number,
					 * assigned by IRCII */
	u_char	*name;			/* window's logical name */
	int	server;			/* server index */
	int	prev_server;		/* previous server index */
	int	top;			/* The top line of the window, screen
					 * coordinates */
	int	bottom;			/* The botton line of the window, screen
					 * coordinates */
	int	cursor;			/* The cursor position in the window, window
					 * relative coordinates */
	int	line_cnt;		/* counter of number of lines displayed in
					 * window */
	int	scroll;			/* true, window scrolls... false window wraps */
	int	display_size;		/* number of lines of window - menu lines */
	int	old_size;		/* if new_size != display_size,
					 * resize_display is called */
	int	visible;		/* true, window is drawn... false window is
					 * hidden */
	int	update;			/* window needs updating flag */
	unsigned miscflags;		/* Miscellaneous flags. */

	u_char	*prompt;		/* A prompt string, usually set by EXEC'd process */
	u_char	*status_line[2];	/* The status line strings */

	int	double_status;		/* Display the 2nd status line ?*/

	Display	*top_of_display,	/* Pointer to first line of display structure */
		*display_ip;		/* Pointer to insertiong point of display
					 * structure */

	u_char	*current_channel;	/* Window's current channel */
	u_char	*bound_channel;		/* Channel that belongs in this window */
	u_char	*query_nick;		/* User being QUERY'ied in this window */
	Nick	*nicks;			/* List of nicks that will go to window */
	int	window_level;		/* The LEVEL of the window, determines what
					 * messages go to it */

	/* hold stuff */
	int	hold_mode;		/* true, hold mode is on for window...
					 * false it isn't */
	int	hold_on_next_rite;	/* true, the next call to rite() will
					 * activate a hold */
	int	held;			/* true, the window is currently being
					 * held */
	int	last_held;		/* Previous value of hold flag.  Used
					 * for various updating needs */
	Hold	*hold_head,		/* Pointer to first entry in hold
					 * list */
		*hold_tail;		/* Pointer to last entry in hold list */
	int	held_lines;		/* number of lines being held */
	int	scrolled_lines;		/* number of lines scrolled back */
	int	new_scrolled_lines;	/* number of lines since scroll back
					 * keys where pressed */
	WindowMenu	menu;		/* The menu (if any) */

	/* lastlog stuff */
	Lastlog	*lastlog_head;		/* pointer to top of lastlog list */
	Lastlog	*lastlog_tail;		/* pointer to bottom of lastlog list */
	int	lastlog_level;		/* The LASTLOG_LEVEL, determines what
					 * messages go to lastlog */
	int	lastlog_size;		/* Max number of messages for the window
					 * lastlog */

	int	notify_level;		/* the notify level.. */

	u_char	*logfile;		/* window's logfile name */
	/* window log stuff */
	int	log;			/* true, file logging for window is on */
	FILE	*log_fp;		/* file pointer for the log file */

	struct	ScreenStru	*screen;
	int	server_group;		/* server group number */

	struct	WindowStru	*next;	/* pointer to next entry in window list (null
					 * is end) */
	struct	WindowStru	*prev;	/* pointer to previous entry in window list
					 * (null is end) */
	int	sticky;			/* make channels stick to window when
					   changing servers ? */
}	Window;

/*
 * WindowStack: The structure for the POP, PUSH, and STACK functions. A
 * simple linked list with window refnums as the data 
 */
typedef	struct	window_stack_stru
{
	unsigned int	refnum;
	struct	window_stack_stru	*next;
}	WindowStack;

typedef	struct
{
	int	top;
	int	bottom;
	int	position;
}	ShrinkInfo;

typedef struct PromptStru
{
	u_char	*prompt;
	u_char	*data;
	int	type;
	void	(*func)(u_char *, u_char *);
	struct	PromptStru	*next;
}	WaitPrompt;


typedef	struct	ScreenStru
{
	int	screennum;
	Window	*current_window;
	unsigned int	last_window_refnum;	/* reference number of the
						 * window that was last
						 * the current_window */
	Window	*window_list;			/* List of all visible
						 * windows */
	Window	*window_list_end;		/* end of visible window
						 * list */
	Window	*cursor_window;			/* Last window to have
						 * something written to it */
	int	visible_windows;		/* total number of windows */
	WindowStack	*window_stack;		/* the windows here */

	int	meta1_hit;			/* if meta1 is hit in this
						 * screen or not */
	int	meta2_hit;			/* above, for meta2 */
	int	meta3_hit;			/* above, for meta3 */
	int	meta4_hit;			/* above, for meta4 */
	int	meta5_hit;			/* above, for meta5 */
	int	meta6_hit;			/* above, for meta6 */
	int	meta7_hit;			/* above, for meta7 */
	int	meta8_hit;			/* above, for meta8 */
	int	quote_hit;			/* true if a key bound to
						 * QUOTE_CHARACTER has been
						 * hit. */
	int	digraph_hit;			/* A digraph key has been hit */
	int	inside_menu;			/* what it says. */

	u_char	digraph_first;

	struct	ScreenStru *prev;		/* These are the Screen list */
	struct	ScreenStru *next;		/* pointers */

	FILE	*fpin;				/* These are the file pointers */
	int	fdin;				/* and descriptions for the */
	FILE	*fpout;				/* screen's input/output */
	int	fdout;
	int	wservin;			/* control socket for wserv */

	u_char	input_buffer[INPUT_BUFFER_SIZE+1];	/* the input buffer */
	int	buffer_pos;			/* and the positions for the */
	int	buffer_min_pos;			/* screen */

	u_char	saved_input_buffer[INPUT_BUFFER_SIZE+1];
	int	saved_buffer_pos;
	int	saved_min_buffer_pos;

	WaitPrompt	*promptlist;

	u_char	*redirect_name;
	u_char	*redirect_token;
	int	redirect_server;

	u_char	*tty_name;
	int	co, li;

	/*
	 * upper_mark and lower_mark: marks the upper and lower positions in
	 * the input buffer which will cause the input display to switch to
	 * the next or previous bunch of text 
	 */
	int	lower_mark, upper_mark;

	/* input.c:update_input() */
	int	old_input_co, old_input_li;

	/* the actual screen line where the input goes */
	int	input_line;

	/* position in buffer of first visible character in the input line */
	int	str_start;

	/* the amount of editable visible text on the screen */
	int	zone;

	/* position of the cursor in the input line on the screen */
	int	cursor;

	/* term.c:term_resize() */
	int	old_term_co, old_term_li;

	int	alive;
}	Screen;

/*
 * this is the structure for a ban list entry.
 */
typedef struct mode_b_stru
{
	struct	mode_b_stru	*next;
	u_char	*ban;
	u_char	*owner;
	time_t	time;
}	Ban;

/*
 * this is the structure for a ban exception list entry.
 */
typedef struct mode_e_stru
{
	struct	mode_e_stru	*next;
	u_char	*exception;
	u_char	*owner;
	time_t	time;
}	Except;

/*
 * this is the structure for a deny (regexp) list entry.
 */
typedef struct mode_d_stru
{
	struct	mode_d_stru	*next;
	u_char	*regexp;
	u_char	*owner;
	time_t	time;
}	Deny;

/* Channel: structure for an entry in the list of channels you are current on */
typedef	struct	channel_stru
{
	struct	channel_stru	*next;	/* pointer to next channel entry */
	u_char	*channel;		/* channel name */
	int	server;			/* server index for this channel */
	u_long	mode;			/* current mode settings for channel */
	u_char	*s_mode;		/* string representation of the above */
	int	limit;			/* max users for the channel */
	u_char	*key;			/* key for this channel */
	int	connected;		/* connection status */
#define	CHAN_LIMBO	-1
#define	CHAN_JOINING	0
#define	CHAN_JOINED	1
	Window	*window;		/* the window that the channel is "on" */
	Nick	*nicks;			/* pointer to list of nicks on channel */
	int	status;			/* different flags */
#define CHAN_CHOP	0x0001
#define CHAN_VOICE	0x0002
   /* ninja uses WHO output to cache nicks, instead of names */
#define CHAN_WHO	0x0004
#define CHAN_NAMES	0x0008
#define	CHAN_MODE	0x0010
#define	CHAN_START	0x0020
#define CHAN_BANS	0x0040
#define CHAN_EXCEPT	0x0080
#define CHAN_DENY	0x0100
#ifdef SHOW_JOIN_TIME
# define CHAN_SHOWED_TIME	0x0200
#endif
   /* ninja specific fields */
   	Ban	*bans;			/* channel bans */
   	Except	*excepts;		/* channel ban exceptions */
   	Deny	*denys;			/* channel regexp denys */
#ifdef SHOW_JOIN_TIME
   	struct	timeval	join_time;	/* when the client entered the channel */
#endif
}	Channel;
#define ChannelList Channel

typedef struct	ckey_stru
{
   	struct ckey_stru *next;
   	u_char *channel;
   	u_char *key;
}	CKey;

typedef	struct	list_stru
{
	struct	list_stru	*next;
	u_char	*name;
}	List;
#endif /* __struct_h_ */
