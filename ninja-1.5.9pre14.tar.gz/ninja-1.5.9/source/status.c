/*
 * status.c: handles the status line updating, etc for IRCII 
 *
 * Written By Michael Sandrof
 *
 * Copyright (c) 1990 Michael Sandrof.
 * Copyright (c) 1991, 1992 Troy Rollo.
 * Copyright (c) 1992-2005 Matthew R. Green.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/*
 * WARNING!  THIS CODE HAS DRAGONS.  BE *VERY* CAREFUL WHEN CHANGING
 * ANYTHING IN HERE.  TEST IT EXTENSIVELY.
 */

#include "irc.h"
IRCII_RCSID("@(#)$eterna: status.c,v 1.85 2005/04/03 02:35:08 mrg Exp $");

#include "dma.h"

#include "ircterm.h"
#include "status.h"
#include "server.h"
#include "vars.h"
#include "hook.h"
#include "input.h"
#include "edit.h"
#include "window.h"
#include "screen.h"
#include "mail.h"
#include "output.h"
#include "names.h"
#include "ircaux.h"
#include "translat.h"

/* ninja includes */
#include "ninja.h"
#include "channels.h"

static	u_char	*convert_format(u_char *, int);
static	u_char	*status_nickname(Window *);
static	u_char	*status_query_nick(Window *);
static	u_char	*status_right_justify(Window *);
static	u_char	*status_chanop(Window *);
static	u_char	*status_channel(Window *);
static	u_char	*status_server(Window *);
static	u_char	*status_mode(Window *);
static	u_char	*status_umode(Window *);
static	u_char	*status_insert_mode(Window *);
static	u_char	*status_overwrite_mode(Window *);
static	u_char	*status_away(Window *);
static	u_char	*status_oper(Window *);
static	u_char	*status_voice(Window *);
static	u_char	*status_user0(Window *);
static	u_char	*status_user1(Window *);
static	u_char	*status_user2(Window *);
static	u_char	*status_user3(Window *);
static	u_char	*status_hold(Window *);
static	u_char	*status_version(Window *);
static	u_char	*status_clock(Window *);
static	u_char	*status_hold_lines(Window *);
static	u_char	*status_window(Window *);
static	u_char	*status_mail(Window *);
static	u_char	*status_refnum(Window *);
static	u_char	*status_null_function(Window *);
static	u_char	*status_notify_windows(Window *);
static	u_char	*status_group(Window *);
static	void	status_make_printable(u_char *, int);
static	void	alarm_switch(int);
static	u_char	*convert_sub_format(u_char *, int);
static	void	make_status_one(Window *, int, int);

/* ninja extensions */
static	u_char	*convert_sub_format_mult(u_char *, int, int);
static	u_char	*status_voice(Window *);
static	u_char	*status_uptime(Window *);
static	u_char	*status_users(Window *);
static	u_char	*status_lag(Window *);
static	u_char	*status_dcc_send(Window *);
static	u_char	*status_dcc_get(Window *);
extern	int	vt100_decode(u_char);
/*
 * Maximum number of "%" expressions in a status line format.  If you change
 * this number, you must manually change the snprintf() in make_status
 */
#define MAX_FUNCTIONS 33

/* The format statements to build each portion of the status line */
static	u_char	*mode_format = (u_char *) 0;
static	u_char	*umode_format = (u_char *) 0;
static	u_char	*status_format[3] = {(u_char *) 0, (u_char *) 0, (u_char *) 0,};
static	u_char	*query_format = (u_char *) 0;
static	u_char	*clock_format = (u_char *) 0;
static	u_char	*hold_lines_format = (u_char *) 0;
static	u_char	*channel_format = (u_char *) 0;
static	u_char	*mail_format = (u_char *) 0;
static	u_char	*server_format = (u_char *) 0;
static	u_char	*notify_format = (u_char *) 0;
static	u_char	*group_format = (u_char *) 0;

/* ninja extensions */
static	u_char	*users_format = (u_char *) 0;
static	u_char	*lag_format = (u_char *) 0;
static	u_char	*away_format = (u_char *) 0;
extern	int	get_server_lag(int);

/*
 * status_func: The list of status line function in the proper order for
 * display.  This list is set in convert_format() 
 */
static	u_char	*(*status_func[3][MAX_FUNCTIONS])(Window *);

/* func_cnt: the number of status line functions assigned */
static	int	func_cnt[3];

static	int	alarm_hours,		/* hour setting for alarm in 24 hour time */
		alarm_minutes;		/* minute setting for alarm */

/* Stuff for the alarm */
static	struct itimerval clock_timer = { { 10L, 0L }, { 1L, 0L } };
static	struct itimerval off_timer = { { 0L, 0L }, { 0L, 0L } };

static	RETSIGTYPE alarmed(int);
	int	do_status_alarmed;

/* alarmed: This is called whenever a SIGALRM is received and the alarm is on */
static	RETSIGTYPE
alarmed(signo)
	int signo;
{
	do_status_alarmed = 1;
}

void
real_status_alarmed()
{
	u_char	time_str[16];

	say("The time is %s", update_clock(time_str, 16, GET_TIME));
	term_beep();
	term_beep();
	term_beep();
}

/*
 * alarm_switch: turns on and off the alarm display.  Sets the system timer
 * and sets up a signal to trap SIGALRMs.  If flag is 1, the alarmed()
 * routine will be activated every 10 seconds or so.  If flag is 0, the timer
 * and signal stuff are reset 
 */
static	void
alarm_switch(flag)
	int	flag;
{
	static	int	alarm_on = 0;

	if (flag)
	{
		if (!alarm_on)
		{
			setitimer(ITIMER_REAL, &clock_timer,
				(struct itimerval *) 0);
			(void) MY_SIGNAL(SIGALRM, alarmed, 0);
			alarm_on = 1;
		}
	}
	else if (alarm_on)
	{
		setitimer(ITIMER_REAL, &off_timer, (struct itimerval *) 0);
		(void) MY_SIGNAL(SIGALRM, (sigfunc *)SIG_IGN, 0);
		alarm_on = 0;
	}
}

/*
 * set_alarm: given an input string, this checks its validity as a clock
 * type time thingy.  It accepts two time formats.  The first is the HH:MM:XM
 * format where HH is between 1 and 12, MM is between 0 and 59, and XM is
 * either AM or PM.  The second is the HH:MM format where HH is between 0 and
 * 23 and MM is between 0 and 59.  This routine also looks for one special
 * case, "OFF", which sets the alarm string to null 
 */
void
set_alarm(str)
	u_char	*str;
{
	u_char	hours[10],
		minutes[10],
		merid[3];
	u_char	time_str[10];
	int	c,
		h,
		m,
		min_hours,
		max_hours;

	if (str == (u_char *) 0)
	{
		alarm_switch(0);
		return;
	}
	if (!my_stricmp(str, UP(var_settings[OFF])))
	{
		set_string_var(CLOCK_ALARM_VAR, (u_char *) 0);
		alarm_switch(0);
		return;
	}
	
	c = sscanf(CP(str), " %2[^:]:%2[^paPA]%2s ", hours, minutes, merid);
	switch (c)
	{
	case 2:
		min_hours = 0;
		max_hours = 23;
		break;
	case 3:
		min_hours = 1;
		max_hours = 12;
		upper(UP(merid));
		break;
	default:
		say("CLOCK_ALARM: Bad time format.");
		set_string_var(CLOCK_ALARM_VAR, (u_char *) 0);
		return;
	}
	
	h = my_atoi(hours);
	m = my_atoi(minutes);
	if (h >= min_hours && h <= max_hours && isdigit(hours[0]) &&
		(isdigit(hours[1]) || hours[1] == (u_char) 0))
	{
		if (m >= 0 && m <= 59 && isdigit(minutes[0]) &&
				isdigit(minutes[1]))
		{
			alarm_minutes = m;
			alarm_hours = h;
			if (max_hours == 12)
			{
				if (merid[0] != 'A')
				{
					if (merid[0] == 'P')
					{
						if (h != 12)
							alarm_hours += 12;
					}
					else
					{
	say("CLOCK_ALARM: alarm time must end with either \"AM\" or \"PM\"");
	set_string_var(CLOCK_ALARM_VAR, (u_char *) 0);
					}
				}
				else
				{
					if (h == 12)
						alarm_hours = 0;
				}
				if (merid[1] == 'M')
				{
					snprintf(CP(time_str), sizeof time_str, "%02d:%02d%s", h, m,
						merid);
				   /* ensure nul termination */
				   time_str[sizeof(time_str)-1] = '\0';
					set_string_var(CLOCK_ALARM_VAR,
						time_str);
				}
				else
				{
	say("CLOCK_ALARM: alarm time must end with either \"AM\" or \"PM\"");
	set_string_var(CLOCK_ALARM_VAR, (u_char *) 0);
				}
			}
			else
			{
				snprintf(CP(time_str), sizeof time_str, "%02d:%02d", h, m);
			   /* ensure nul termination */
			   time_str[sizeof(time_str)-1] = '\0';
				set_string_var(CLOCK_ALARM_VAR, time_str);
			}
		}
		else
		{
	say("CLOCK_ALARM: alarm minutes value must be between 0 and 59.");
	set_string_var(CLOCK_ALARM_VAR, (u_char *) 0);
		}
	}
	else
	{
		say("CLOCK_ALARM: alarm hour value must be between %d and %d.",
			min_hours, max_hours);
		set_string_var(CLOCK_ALARM_VAR, (u_char *) 0);
	}
}


u_char	*
format_clock(buf, len, hour, min)
	u_char	*buf;
	size_t	len;
	int	hour;
	int	min;
{
	char	*merid;

	if (get_int_var(CLOCK_24HOUR_VAR))
		merid = CP(empty_string);
	else
	{
		if (hour < 12)
			merid = "AM";
		else
			merid = "PM";
		if (hour > 12)
			hour -= 12;
		else if (hour == 0)
			hour = 12;
	}
	snprintf(CP(buf), len, "%02d:%02d%s", hour, min, merid);

	return buf;
}


/* update_clock: figures out the current time and returns it in a nice format */
u_char	*
update_clock(buf, len, flag)
	u_char	*buf;
	size_t	len;
	int	flag;
{
	struct tm	*time_val;
	static	u_char	time_str[10];
	static	int	min = -1,
			hour = -1;
	time_t	t;
	int	tmp_hour, tmp_min;

	t = time(0);
	time_val = localtime(&t);
	tmp_hour = time_val->tm_hour;
	tmp_min = time_val->tm_min;

	Debug((8, "update_clock (%s): time %lu (%02d:%02d) [old %02d:%02d]",
	    flag == RESET_TIME ? "reset" :
	     flag == GET_TIME ? "get" :
	     flag == UPDATE_TIME ? "update" : "unknown", 
	    (long unsigned) t, tmp_hour, tmp_min, hour, min));

	if (get_string_var(CLOCK_ALARM_VAR))
	{
		if ((tmp_hour == alarm_hours) && (tmp_min == alarm_minutes))
			alarm_switch(1);
		else
			alarm_switch(0);
	}

	if (flag == RESET_TIME ||
	    (flag == UPDATE_TIME && (tmp_min != min || tmp_hour != hour)))
	{
		int	server;

		format_clock(time_str, sizeof time_str, tmp_hour, tmp_min);
		server = from_server;
		from_server = primary_server;
		Debug((8, "update_clock: in reset_time block, time_str: %s", time_str));
		if (flag == UPDATE_TIME && (tmp_min != min || tmp_hour != hour))
		{
			hour = tmp_hour;
			min = tmp_min;
			do_hook(TIMER_LIST, "%s", time_str);
		}
		do_hook(IDLE_LIST, "%ld", (t - idle_time) / 60L);
		from_server = server;
		flag = GET_TIME;
	}
	if (buf)
	{
		my_strncpy(buf, time_str, len - 1);
		buf[len - 1] = '\0';
	}
	if (flag == GET_TIME)
		return(buf ? buf : time_str);
	else
		return ((u_char *) 0);
}

/*ARGSUSED*/
void
reset_clock(unused)
	int unused;
{
	update_clock(0, 0, RESET_TIME);
	update_all_status();
}

/*
 * convert_sub_format: This is used to convert the formats of the
 * sub-portions of the status line to a format statement specially designed
 * for that sub-portions.  convert_sub_format looks for a single occurence of
 * %c (where c is passed to the function). When found, it is replaced by "%s"
 * for use is a snprintf.  All other occurences of % followed by any other
 * character are left unchanged.  Only the first occurence of %c is
 * converted, all subsequence occurences are left unchanged.  This routine
 * mallocs the returned string. 
 */
static	u_char	*
convert_sub_format(format, c)
	u_char	*format;
	int	c;
{
	u_char	lbuf[BIG_BUFFER_SIZE + 1];
	static	u_char	bletch[] = "%% ";
	u_char	*ptr = (u_char *) 0;
	int	dont_got_it = 1;

	if (format == (u_char *) 0)
		return ((u_char *) 0);
   	*lbuf = (u_char) 0;
	while (format)
	{
		if ((ptr = my_index(format, '%')) != NULL)
		{
			*ptr = (u_char) 0;
			my_strmcat(lbuf, format, BIG_BUFFER_SIZE);
			*(ptr++) = '%';
			if ((*ptr == c) && dont_got_it)
			{
				dont_got_it = 0;
				my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
			}
			else
			{
			   /* XXX: this fixes the % leaking (via %%%) into the format string problem */
			   if (*ptr != '%')
				bletch[2] = *ptr;
			   else
			     bletch[2] = '\0';
				my_strmcat(lbuf, bletch, BIG_BUFFER_SIZE);
			}
		   /* make sure we are not at end of string */
		   if (*ptr)
			ptr++;
		     }
		else
			my_strmcat(lbuf, format, BIG_BUFFER_SIZE);
		format = ptr;
	}
	malloc_strcpy(&ptr, lbuf);
	return (ptr);
}

static	u_char	*
convert_format(format, k)
	u_char	*format;
	int	k;
{
	u_char	lbuf[BIG_BUFFER_SIZE + 1];
	u_char	*ptr,
		*malloc_ptr = (u_char *) 0; 
	int	*cp;
	
	*lbuf = (u_char) 0;
	while (format)
	{
		if ((ptr = my_index(format, '%')) != NULL)
		{
			*ptr = (u_char) 0;
			my_strmcat(lbuf, format, BIG_BUFFER_SIZE);
			*(ptr++) = '%';
			cp = &func_cnt[k];
			if (*cp < MAX_FUNCTIONS)
			{
				switch (*(ptr++))
				{
				case '%':
				   /* XXX: more format string problem fixes */
				   my_strmcat(lbuf, "%%", BIG_BUFFER_SIZE);
					break;
				case 'N':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_nickname;
					break;
				case '>':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_right_justify;
					break;
				case 'G':
					new_free(&group_format);
					group_format =
					convert_sub_format(get_string_var(STATUS_GROUP_VAR), 'G');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_group;
					break;
				case 'Q':
					new_free(&query_format);
					query_format =
		convert_sub_format(get_string_var(STATUS_QUERY_VAR), 'Q');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_query_nick;
					break;
				case 'F':
					new_free(&notify_format);
					notify_format = 
		convert_sub_format(get_string_var(STATUS_NOTIFY_VAR), 'F');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_notify_windows;
					break;
				case '@':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_chanop;
					break;
				case 'C':
					new_free(&channel_format);
					channel_format =
		convert_sub_format(get_string_var(STATUS_CHANNEL_VAR), 'C');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_channel;
					break;
				case 'S':
					new_free(&server_format);
					server_format =
		convert_sub_format(get_string_var(STATUS_SERVER_VAR), 'S');
					my_strmcat(lbuf,"%s",BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_server;
					break;
				case '+':
					new_free(&mode_format);
					mode_format =
		convert_sub_format(get_string_var(STATUS_MODE_VAR), '+');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_mode;
					break;
				case '#':
					new_free(&umode_format);
					umode_format =
		convert_sub_format(get_string_var(STATUS_UMODE_VAR), '#');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_umode;
					break;
				case 'M':
					new_free(&mail_format);
					mail_format =
		convert_sub_format(get_string_var(STATUS_MAIL_VAR), 'M');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_mail;
					break;
				case 'I':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_insert_mode;
					break;
				case 'O':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_overwrite_mode;
					break;
				case 'A':
				   	dma_Free(&away_format);
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_away;
				   	away_format = convert_sub_format(get_string_var(STATUS_AWAY_VAR), 'A');
					break;
				case 'V':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_version;
					break;
				case 'R':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_refnum;
					break;
				case 'T':
					new_free(&clock_format);
					clock_format =
		convert_sub_format(get_string_var(STATUS_CLOCK_VAR), 'T');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_clock;
					break;
				case 'U':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_user0;
					break;
				case 'H':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_hold;
					break;
				case 'B':
					new_free(&hold_lines_format);
					hold_lines_format =
		convert_sub_format(get_string_var(STATUS_HOLD_LINES_VAR), 'B');
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_hold_lines;
					break;
				case '*':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_oper;
					break;
				/* backwards compatible ninja case */
			        case 'D':
				case 'v':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_voice;
					break;
				case 'W':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_window;
					break;
				case 'X':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_user1;
					break;
				case 'Y':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_user2;
					break;
				case 'Z':
					my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
					status_func[k][(*cp)++] =
						status_user3;
					break;
				   
				   /* ninja extensions! */
				 case '1':
				   my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
				   status_func[k][(*cp)++] = status_uptime;
				   break;
				 case '2':
				   new_free(&lag_format);
				   lag_format = convert_sub_format(get_string_var(STATUS_LAG_VAR), '2');
				   my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
				   status_func[k][(*cp)++] = status_lag;
				   break;
				 case '5':
				   my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
				   status_func[k][(*cp)++] = status_dcc_send;
				   break;
				 case '6':
				   my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
				   status_func[k][(*cp)++] = status_dcc_get;
				   break;
				 case '!':
				   new_free(&users_format);
				   users_format = convert_sub_format_mult(get_string_var(STATUS_USERS_VAR), '!', 4);
				   my_strmcat(lbuf, "%s", BIG_BUFFER_SIZE);
				   status_func[k][(*cp)++] = status_users;
				   break;
				   
				   
		/* no default..?? - phone, jan 1993 */
		/* empty is a good default -lynx, mar 93 */
				}
			}
			else
				ptr++;
		}
		else
			my_strmcat(lbuf, format, BIG_BUFFER_SIZE);
		format = ptr;
	}
	/* this frees the old str first */
	malloc_strcpy(&malloc_ptr, lbuf);
	return (malloc_ptr);
}

void
build_status(format)
	u_char	*format;
{
	int	i, k;

	for (k = 0; k < 3; k++) 
	{
		new_free(&status_format[k]);
		func_cnt[k] = 0;
		switch (k)
		{
		case 0 : 
			format = get_string_var(STATUS_FORMAT_VAR);
			break;
			
		case 1 : 
			format = get_string_var(STATUS_FORMAT1_VAR);
			break;
			
		case 2 : 
			format = get_string_var(STATUS_FORMAT2_VAR);
			break;
		}
		if (format != NULL)	/* convert_format mallocs for us */
			status_format[k] = convert_format(format, k);
		for (i = func_cnt[k]; i < MAX_FUNCTIONS; i++)
			status_func[k][i] = status_null_function;
	}
	update_all_status();
}

void
make_status(window)
	Window	*window;
{
	int	k, l, final;

	switch (window->double_status) {
	case -1:
		new_free(&window->status_line[0]);
		new_free(&window->status_line[1]);
		goto out;
	case 0:
		new_free(&window->status_line[1]);
		final = 1;
		break;
	case 1:
		final = 2;
		break;
	default:
		yell("--- make_status: unknown window->double value %d", window->double_status);
		final = 1;
	}
   
	for (k = 0 ; k < final; k++)
	{
		if (k)
			l = 2;
		else if (window->double_status)
			l = 1;
		else
			l = 0;
			
		if (!dumb && status_format[l])
			make_status_one(window, k, l);
	}
out:
	cursor_to_input();
}

static	void
make_status_one(window, k, l)
	Window	*window;
	int	k;
	int	l;
{
	u_char	lbuf[BIG_BUFFER_SIZE + 1];
	u_char	*func_value[MAX_FUNCTIONS];
	size_t	len;
	int	i,
		RJustifyPos = -1,
		RealPosition;
   u_char *tp;		/* pointer used for counting ansi characters */

   /* make sure we have a null buffer */
   memset(lbuf, 0, sizeof(lbuf));
   
	/*
	 * XXX: note that this code below depends on the definition
	 * of MAX_FUNCTIONS (currently 33), and the snprintf must
	 * be updated if MAX_FUNCTIONS is changed.
	 */
	for (i = 0; i < MAX_FUNCTIONS; i++)
		func_value[i] = (status_func[l][i]) (window);
   /* 
    * if ANSI is allowed, we must check whether to 
    * invert the status lines or not..
    */
   if (get_int_var(ANSI_COLOR_VAR))
     {
	i = 0;
	for (tp = status_format[l]; tp && *tp; tp++)
	  if (vt100_decode(*tp))
	    i++;
	if (i > 0)
	  lbuf[0] = ALL_OFF;
	else
	  lbuf[0] = REV_TOG;
     }
   else
     lbuf[0] = REV_TOG;
	snprintf(CP(lbuf+1), sizeof(lbuf) - 1, CP(status_format[l]),
		func_value[0], func_value[1], func_value[2],
		func_value[3], func_value[4], func_value[5],
		func_value[6], func_value[7], func_value[8],
		func_value[9], func_value[10], func_value[11],
		func_value[12], func_value[13], func_value[14],
		func_value[15], func_value[16], func_value[17],
		func_value[18], func_value[19], func_value[20],
		func_value[21], func_value[22], func_value[23],
		func_value[24], func_value[25], func_value[26],
		func_value[27], func_value[28], func_value[29],
		func_value[30], func_value[31], func_value[32]);
	for (i = 0; i < MAX_FUNCTIONS; i++)
		new_free(&(func_value[i]));
			
	/*  Patched 26-Mar-93 by Aiken
	 *  make_window now right-justifies everything 
	 *  after a %>
	 *  it's also more efficient.
	 */
	
	RealPosition = 0;
	RJustifyPos = -1;
	for (i = 0; lbuf[i]; i++)
		/* formfeed is a marker for left/right border*/
		if (lbuf[i] == '\f')
			RJustifyPos = i;
		else if (lbuf[i] != REV_TOG
			 && lbuf[i] != UND_TOG 
			 && lbuf[i] != ALL_OFF 
			 && lbuf[i] != BOLD_TOG
			 /* real position does not get incremented unless
			  * it is not part of an ANSI escape code */
			 && !vt100_decode(lbuf[i]))
		{
			if (RealPosition == current_screen->co)
			{
				lbuf[i] = '\0';
				break;
			}
			RealPosition++;
		}
	
	/* note that i points to the nul, RealPosition is vis.chars */
	if (RJustifyPos == -1)
		RJustifyPos = i;
	else
	{
	   char *d = (char *)&lbuf[RJustifyPos];
	   
	   /* get rid of the marker */
	   memmove(d, d+1, my_strlen(d+1));
	   i--;
	}
		
	/* don't adjust the status bar if it is full already */
	if (RealPosition < current_screen->co)
	{
		if (get_int_var(FULL_STATUS_LINE_VAR))
		{
			int	diff;
			u_char	c;
			
			if (RJustifyPos == 0)
				c = ' ';
			else
				c = lbuf[RJustifyPos - 1];
			
			/*
			 * does this work when the right justified position
			 * has non-printable characters (eg UNG_TOG)?
			 */
			diff = current_screen->co - RealPosition;
			
			for ( ; i >= RJustifyPos; i--)
				lbuf[i + diff] = lbuf[i];
			
			for (i++ ; diff > 0 ; diff--, i++)
				lbuf[i] = c;
		}
	}
	
	len = my_strlen(lbuf);
	if (len > (BIG_BUFFER_SIZE - 1))
		len = BIG_BUFFER_SIZE - 1;
	lbuf[len] = ALL_OFF;
	lbuf[len+1] =  '\0';
	
	status_make_printable(lbuf, len);
   
	/*
	 * Thanks to Max Bell (mbell@cie.uoregon.edu) for info
	 * about TVI terminals and the sg terminal capability 
	 */
	RealPosition = 0;
/*
 *
 * this could use a more permanent fix, but without that fix,
 * we can't keep colors going on the status bar..
 *  -jjd
 *
	if (window->status_line[k] && (SG == -1))
	{
		for (i = 0; lbuf[i] && window->status_line[k][i]; i++)
		{
			if ((u_char) lbuf[i] != window->status_line[k][i])
				break;
			if (lbuf[i] != REV_TOG 
			    && lbuf[i] != UND_TOG
			    && lbuf[i] != ALL_OFF
			    && lbuf[i] != BOLD_TOG
			    && !vt100_decode(lbuf[i]))
				RealPosition++;
		}
	}
	else
 */
		i = 0;
	
	if ((len = my_strlen(lbuf + i)) || lbuf[i] ||
	    window->status_line[k] || window->status_line[k][i])
	{
		Screen *old_current_screen;
		
		old_current_screen = current_screen;
		set_current_screen(window->screen);
		term_move_cursor(RealPosition, window->bottom + k);
		output_line(lbuf, NULL, i);
		cursor_in_display();
		if (term_clear_to_eol())
			term_space_erase(len);
		malloc_strcpy(&window->status_line[k], lbuf);
		set_current_screen(old_current_screen);
	}
}

static	u_char	*
status_nickname(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;

	if ((connected_to_server == 1) && !get_int_var(SHOW_STATUS_ALL_VAR)
	    && (!window->current_channel) &&
	    (window->screen->current_window != window))
		malloc_strcpy(&ptr, empty_string);
	else
		malloc_strcpy(&ptr, get_server_nickname(window->server));
	return (ptr);
}

static	u_char	*
status_server(window)
	Window	*window;
{
	u_char	*ptr = NULL,
		*rest,
		*name;
	u_char	lbuf[BIG_BUFFER_SIZE];
	
	if (connected_to_server != 1)
	{
		if (window->server != -1)
		{
			if (server_format)
			{
				name = get_server_name(window->server);
				rest = my_index(name, '.');
				if (rest != NULL
#ifdef SUPPORT_ICB						
				    && my_strnicmp(name, UP("irc"), 3) != 0
				    && my_strnicmp(name, UP("icb"), 3) != 0 
#endif
				    )
				{
					if (is_number(name))
						snprintf(CP(lbuf), sizeof lbuf, CP(server_format), name);
					else
					{
						*rest = '\0';
						snprintf(CP(lbuf), sizeof lbuf, CP(server_format), name);
						*rest = '.';
					}
				}
				else
					snprintf(CP(lbuf), sizeof lbuf, CP(server_format), name);
			   /* ensure proper termination */
			   lbuf[sizeof(lbuf)-1] = '\0';
			}
			else
				*lbuf = '\0';
		}
		else
			my_strcpy(lbuf, " No Server"); /* safe */
	}
	else
		*lbuf = '\0';
	malloc_strcpy(&ptr, lbuf);
	return (ptr);
}

static	u_char	*
status_group(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;

	if (window->server_group && group_format)
	{
		u_char	lbuf[BIG_BUFFER_SIZE];

		snprintf(CP(lbuf), sizeof lbuf, CP(group_format), find_server_group_name(window->server_group));
	   /* ensure proper termination */
	   lbuf[sizeof(lbuf)-1] = '\0';
		malloc_strcpy(&ptr, lbuf);
	}
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_query_nick(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;

	if (window->query_nick && query_format)
	{
		u_char	lbuf[BIG_BUFFER_SIZE];

		snprintf(CP(lbuf), sizeof lbuf, CP(query_format), window->query_nick);
	   /* ensure proper terminaion */
	   lbuf[sizeof(lbuf)-1] = '\0';
		malloc_strcpy(&ptr, lbuf);
	}
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_right_justify(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;

	malloc_strcpy(&ptr, UP("\f"));
	return (ptr);
}

static	u_char	*
status_notify_windows(window)
	Window	*window;
{
	u_char	refnum[10];
	int	doneone = 0;
	u_char	*ptr = (u_char *) 0;
	int	flag = 1;
	u_char	buf2[81];

	if (get_int_var(SHOW_STATUS_ALL_VAR) ||
	    window == window->screen->current_window)
	{
		*buf2='\0';
		while ((window = traverse_all_windows(&flag)) != NULL)
		{
			if (window->miscflags & WINDOW_NOTIFIED)
			{
				if (!doneone)
				{
					doneone++;
					snprintf(CP(refnum), sizeof refnum, "%d", window->refnum);
				}
				else
					snprintf(CP(refnum), sizeof refnum, ",%d", window->refnum);
			   /* ensure proper termination */
			   refnum[sizeof(refnum)-1] = '\0';
				my_strmcat(buf2, refnum, sizeof buf2);
			}
		}
	}
	if (doneone && notify_format)
	{
		u_char	lbuf[BIG_BUFFER_SIZE];
	   
		snprintf(CP(lbuf), sizeof lbuf, CP(notify_format), buf2);
	   /* ensure proper termination */
	   lbuf[sizeof(lbuf)-1] = '\0';
		malloc_strcpy(&ptr, lbuf);
	}
	else
		malloc_strcpy(&ptr, empty_string);
	return ptr;
}

static	u_char	*
status_clock(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;

	if ((get_int_var(CLOCK_VAR) && clock_format)  &&
	    (get_int_var(SHOW_STATUS_ALL_VAR) ||
	    (window == window->screen->current_window)))
	{
		u_char	lbuf[BIG_BUFFER_SIZE];
		u_char	time_str[16];

		snprintf(CP(lbuf), sizeof lbuf, CP(clock_format), update_clock(time_str, 16, GET_TIME));
	   /* ensure proper termination */
	   lbuf[sizeof(lbuf)-1] = '\0';
		malloc_strcpy(&ptr, lbuf);
	}
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_mode(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
		*mode;

	if (window->current_channel && chan_is_connected(window->current_channel, window->server))
	{
		mode = get_channel_mode(window->current_channel,window->server);
		if (mode && *mode && mode_format)
		{
			u_char	lbuf[BIG_BUFFER_SIZE];

			snprintf(CP(lbuf), sizeof lbuf, CP(mode_format), mode);
		   /* ensure proper termination */
		   lbuf[sizeof(lbuf)-1] = '\0';
			malloc_strcpy(&ptr, lbuf);
			return (ptr);
		}
	}
	malloc_strcpy(&ptr, empty_string);
	return (ptr);
}


static	u_char	*
status_umode(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;
	u_char	localbuf[10];
	u_char	*c;

	if (connected_to_server == 0)
		malloc_strcpy(&ptr, empty_string);
	else if ((connected_to_server == 1) && !get_int_var(SHOW_STATUS_ALL_VAR)
	    && (window->screen->current_window != window))
		malloc_strcpy(&ptr, empty_string);
	else
	{
		c = localbuf;
		if (get_server_flag(window->server, USER_MODE_I))
			*c++ = 'i';
		if (get_server_operator(window->server))
			*c++ = 'o';
		if (get_server_flag(window->server, USER_MODE_R))
			*c++ = 'r';
		if (get_server_flag(window->server, USER_MODE_S))
			*c++ = 's';
		if (get_server_flag(window->server, USER_MODE_W))
			*c++ = 'w';
		if (get_server_flag(window->server, USER_MODE_Z))
			*c++ = 'z';
		*c++ = '\0';
		if (*localbuf != '\0' && umode_format)
		{
			u_char	lbuf[BIG_BUFFER_SIZE];

			snprintf(CP(lbuf), sizeof lbuf, CP(umode_format), localbuf);
		   /* ensure proper termination */
		   lbuf[sizeof(lbuf)-1] = '\0';
			malloc_strcpy(&ptr, lbuf);
		}
		else
			malloc_strcpy(&ptr, empty_string);
	}
	return (ptr);
}

static	u_char	*
status_chanop(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
		*text;

	if (window->current_channel &&
	    chan_is_connected(window->current_channel, window->server) &&
	    get_channel_oper(window->current_channel, window->server) &&
	    (text = get_string_var(STATUS_CHANOP_VAR)))
		malloc_strcpy(&ptr, text);
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}


static	u_char	*
status_hold_lines(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;
	int	num;
	u_char	localbuf[40];

	num = window->held_lines - window->held_lines%10;
	if (num)
	{
		u_char	lbuf[BIG_BUFFER_SIZE];

		snprintf(CP(localbuf), sizeof localbuf, "%d", num);
		snprintf(CP(lbuf), sizeof lbuf, CP(hold_lines_format), localbuf);
	   /* ensure proper termination */
	   localbuf[sizeof(localbuf)-1] = '\0';
	   lbuf[sizeof(lbuf)-1] = '\0';
		malloc_strcpy(&ptr, lbuf);
	}
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_channel(window)
	Window	*window;
{
	int	num;
	u_char	*s, *ptr,
		channel[IRCD_BUFFER_SIZE + 1];

	s = window->current_channel;
	if (s && chan_is_connected(s, window->server))
	{
		u_char	lbuf[BIG_BUFFER_SIZE];

		if (get_int_var(HIDE_PRIVATE_CHANNELS_VAR) &&
		    is_channel_mode(window->current_channel,
				MODE_PRIVATE | MODE_SECRET,
				window->server))
			ptr = UP("*private*");
		else
			ptr = window->current_channel;
		strmcpy(channel, ptr, IRCD_BUFFER_SIZE);
		if ((num = get_int_var(CHANNEL_NAME_WIDTH_VAR)) &&
		    ((int) my_strlen(channel) > num))
			channel[num] = (u_char) 0;
		/* num = my_atoi(channel); */
		ptr = (u_char *) 0;
		snprintf(CP(lbuf), sizeof lbuf, CP(channel_format), channel);
	   /* ensure proper termination */
	   lbuf[sizeof(lbuf)-1] = '\0';
		malloc_strcpy(&ptr, lbuf);
	}
	else
	{
		ptr = (u_char *) 0;
		malloc_strcpy(&ptr, empty_string);
	}
	return (ptr);
}

static	u_char	*
status_mail(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
		*number;

	if ((get_int_var(MAIL_VAR) && (number = check_mail()) && mail_format) &&
	    (get_int_var(SHOW_STATUS_ALL_VAR) ||
	    (window == window->screen->current_window)))
	{
		u_char	lbuf[BIG_BUFFER_SIZE];

		snprintf(CP(lbuf), sizeof lbuf, CP(mail_format), number);
	   /* ensure proper termination */
	   lbuf[sizeof(lbuf)-1] = '\0';
		malloc_strcpy(&ptr, lbuf);
	}
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_insert_mode(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
	*text;

	text = empty_string;
	if (get_int_var(INSERT_MODE_VAR) && (get_int_var(SHOW_STATUS_ALL_VAR)
	    || (window->screen->current_window == window)))
	{
		if ((text = get_string_var(STATUS_INSERT_VAR)) == (u_char *) 0)
			text = empty_string;
	}
	malloc_strcpy(&ptr, text);
	return (ptr);
}

static	u_char	*
status_overwrite_mode(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
	*text;

	text = empty_string;
	if (!get_int_var(INSERT_MODE_VAR) && (get_int_var(SHOW_STATUS_ALL_VAR)
	    || (window->screen->current_window == window)))
	{
	    if ((text = get_string_var(STATUS_OVERWRITE_VAR)) == (u_char *) 0)
		text = empty_string;
	}
	malloc_strcpy(&ptr, text);
	return (ptr);
}

static	u_char	*
status_away(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0 /* , *text */;


	if (connected_to_server == 0)
		malloc_strcpy(&ptr, empty_string);
	else if ((connected_to_server == 1) && !get_int_var(SHOW_STATUS_ALL_VAR)
	    && (window->screen->current_window != window))
		malloc_strcpy(&ptr, empty_string);
	else
	{
		if (server_list[window->server].away_set && away_format)
				/* (text = get_string_var(STATUS_AWAY_VAR))) */
	     	{
		   u_char lbuf[128], num[16];
		   	
		   snprintf(num, sizeof(num)-1, CP("%lu"), server_list[window->server].away_count);
		   snprintf(lbuf, sizeof(lbuf)-1, CP(away_format), num);
		   /* ensure proper termination */
		   num[sizeof(num)-1] = '\0';
		   lbuf[sizeof(lbuf)-1] = '\0';
		   malloc_strcpy(&ptr, lbuf);
		}
		else
			malloc_strcpy(&ptr, empty_string);
	}
	return (ptr);
}

static	u_char	*
status_user0(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
	*text;

	if ((text = get_string_var(STATUS_USER_VAR)) &&
	    (get_int_var(SHOW_STATUS_ALL_VAR) ||
	    (window == window->screen->current_window)))
		malloc_strcpy(&ptr, text);
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static  u_char    *
status_user1(window)
	Window  *window;
{
        u_char    *ptr = (u_char *) 0,
        *text;

        if ((text = get_string_var(STATUS_USER1_VAR)) &&
            (get_int_var(SHOW_STATUS_ALL_VAR) ||
            (window == window->screen->current_window)))
                malloc_strcpy(&ptr, text);
        else
                malloc_strcpy(&ptr, empty_string);
        return (ptr);
}

static  u_char    *
status_user2(window)
	Window  *window;
{
        u_char    *ptr = (u_char *) 0,
        *text;

        if ((text = get_string_var(STATUS_USER2_VAR)) &&
            (get_int_var(SHOW_STATUS_ALL_VAR) ||
            (window == window->screen->current_window)))
                malloc_strcpy(&ptr, text);
        else
                malloc_strcpy(&ptr, empty_string);
        return (ptr);
}

static  u_char    *
status_user3(window)
	Window  *window;
{
        u_char    *ptr = (u_char *) 0,
        *text;

        if ((text = get_string_var(STATUS_USER3_VAR)) &&
            (get_int_var(SHOW_STATUS_ALL_VAR) ||
            (window == window->screen->current_window)))
                malloc_strcpy(&ptr, text);
        else
                malloc_strcpy(&ptr, empty_string);
        return (ptr);
}

static	u_char	*
status_hold(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
	*text;

	if (window->held && (text = get_string_var(STATUS_HOLD_VAR)))
		malloc_strcpy(&ptr, text);
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_oper(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
	*text;

	if (!connected_to_server)
		malloc_strcpy(&ptr, empty_string);
	else if (get_server_operator(window->server) &&
			(text = get_string_var(STATUS_OPER_VAR)) &&
			(get_int_var(SHOW_STATUS_ALL_VAR) ||
			connected_to_server != 1 || 
			(window->screen->current_window == window)))
		malloc_strcpy(&ptr, text);
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_voice(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
		*text;

	if (!connected_to_server)
		malloc_strcpy(&ptr, empty_string);
	else if (has_voice(window->current_channel, get_server_nickname(window->server), window->server) &&
			(text = get_string_var(STATUS_VOICE_VAR)) &&
			(get_int_var(SHOW_STATUS_ALL_VAR) ||
			connected_to_server != 1 || 
			(window->screen->current_window == window)))
		malloc_strcpy(&ptr, text);
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_window(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0,
	*text;

	if ((text = get_string_var(STATUS_WINDOW_VAR)) &&
	    (number_of_windows() > 1) && (window->screen->current_window == window))
		malloc_strcpy(&ptr, text);
	else
		malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

static	u_char	*
status_refnum(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;

	if (window->name)
		malloc_strcpy(&ptr, window->name);
	else
	{
		u_char	lbuf[10];

		snprintf(CP(lbuf), sizeof lbuf, "%u", window->refnum);
	   /* ensure proper termination */
	   lbuf[sizeof(lbuf)-1] = '\0';
		malloc_strcpy(&ptr, lbuf);
	}
	return (ptr);
}

static	u_char	*
status_version(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;

	if ((connected_to_server == 1) && !get_int_var(SHOW_STATUS_ALL_VAR)
	    && (window->screen->current_window != window))
		malloc_strcpy(&ptr, empty_string);
	else
	{
		malloc_strcpy(&ptr, irc_version);
	}
	return (ptr);
}


static	u_char	*
status_null_function(window)
	Window	*window;
{
	u_char	*ptr = (u_char *) 0;

	malloc_strcpy(&ptr, empty_string);
	return (ptr);
}

/*
 * pass an already allocated char array with n bits, and this
 * gets rid of nasty unprintables.
 */
static	void
status_make_printable(str, n)
	u_char	*str;
	int n;
{
	u_char	*s, c;
	u_char	lbuf[BIG_BUFFER_SIZE];
	size_t	pos;
   	int so;
   
	if (!str || !*str)
		return;

	bzero(lbuf, BIG_BUFFER_SIZE);
	/* there can be 4 more chars stuff in: REV *s REV \0 */
	for (pos = 0, s = str; s && pos < (BIG_BUFFER_SIZE - 4) && n--; s++)
	{
		so = 0;
		if (translation)
			*s = transToClient[(u_int)*s];
	   
	   /* if its ansi escape sequence, let it through */
	   if (vt100_decode(*s))
	     {
		if (get_int_var(ANSI_COLOR_VAR))
		  lbuf[pos++] = *s;
		continue;
	     }
	   
		switch(*s) {
		case UND_TOG:
		case ALL_OFF:
		case REV_TOG:
		case BOLD_TOG:
			c = *s;
			break;
		case 0x7f:
			c = '?';
			lbuf[pos++] = REV_TOG;
			break;
		case 0x83:
			c = 0xe3;
			so = 1;
			break;
		case 0x84:
			c = 0xe4;
			so = 1;
			break;
		case 0x85:
			c = 0xe5;
			so = 1;
			break;
		case 0x8d:
			c = 0xc3;
			so = 1;
			break;
		case 0x8e:
			c = 0xc4;
			so = 1;
			break;
		case 0x94:
			c = 0x76;
			so = 1;
			break;
		case 0x99:
			c = 0xd6;
			so = 1;
			break;
		default:
			if (*s < 0x20)
			{
				c = (*s & 0x7f) | 0x40;
				so = 1;
			}
			else
				c = *s;
		}
		if (so)
			lbuf[pos++] = REV_TOG;
		lbuf[pos++] = c;
		if (so)
			lbuf[pos++] = REV_TOG;
	}
	lbuf[pos] = '\0';

   if (!get_int_var(EIGHT_BIT_CHARACTERS_VAR))
     {
	char *tmp = strip_8bit(lbuf);
	my_strncpy(str, tmp, strlen(tmp));
     }
   else
     my_strncpy(str, lbuf, pos);
}


/* ninja extensions! */
static u_char *
status_lag(window)
   Window *window;
{
   u_char *ptr, *p = UNULL, fuq[64];
   time_t ti;
   
   ptr = q_mark;
   if (connected_to_server && is_server_connected(window->server))
     {
	ti = get_server_lag(window->server);
	if (ti >= 0)
	  ptr = ninja_etime(ti);
     }
   else
     {
	/* show nothing if not connected.. */
	dma_strcpy(&p, empty_string);
	return p;
     }
   snprintf(fuq, sizeof(fuq)-1, lag_format, ptr);
   fuq[sizeof(fuq)-1] = '\0';
   dma_strcpy(&p, fuq);
   return p;
}

static u_char *
status_uptime(window)
   Window *window;
{
   static u_char text[32];
   u_char *ptr = NULL;
   struct timeval tp;
   struct timezone tzp;
   time_t timediff;

   gettimeofday(&tp, &tzp);
   if (start_time == 0)
     {
	start_time = tp.tv_sec;
	timediff = 0;
     }
   else
      timediff = tp.tv_sec - start_time;
   
   snprintf(text, sizeof(text)-1, "%s", ninja_etime(timediff));
   text[sizeof(text)-1] = '\0';
   dma_strcpy(&ptr, text);
   return ptr;
}

static u_char *
status_dcc_send(window)
   Window *window;
{
   u_char *ptr = NULL;
   u_char text[16];
   extern int dcc_send_count;

   snprintf(text, sizeof(text)-1, "%u", dcc_send_count);
   text[sizeof(text)-1] = '\0';
   dma_strcpy(&ptr, text);
   return ptr;
}

static u_char *
status_dcc_get(window)
   Window *window;
{
   u_char *ptr = NULL;
   u_char text[16];
   extern int dcc_get_count;

   snprintf(text, sizeof(text)-1, "%u", dcc_get_count);
   text[sizeof(text)-1] = '\0';
   dma_strcpy(&ptr, text);
   return ptr;
}

static u_char *
status_users(window)
   Window *window;
{
#define STATUS_USERS_PART_SIZ	32
   u_char tbuf1[STATUS_USERS_PART_SIZ], 
     tbuf2[STATUS_USERS_PART_SIZ], 
     tbuf3[STATUS_USERS_PART_SIZ], 
     tbuf4[STATUS_USERS_PART_SIZ];
   u_char lbuf[STATUS_USERS_PART_SIZ + 128];
   u_char *ptr = NULL;
   Channel *chan;
   Nick *nick;
   
   if (window->current_channel && chan_is_connected(window->current_channel, window->server))
     {
	if ((chan = lookup_channel(window->current_channel, window->server, CHAN_NOUNLINK)))
	  {
	     u_int ops = 0, voice = 0, opers = 0, total = 0;
	     
	     for (nick = chan->nicks; nick; nick = nick->next)
	       {
		  if (nick->status & NICK_CHOP)
		    ops++;
		  if (nick->status & NICK_VOICE)
		    voice++;
		  if (nick->status & NICK_OPER)
		    opers++;
		  total++;
	       }
	     
	     snprintf(tbuf1, sizeof(tbuf1)-1, "%d%s", ops, get_string_var(STATUS_CHANOP_VAR));
	     tbuf1[sizeof(tbuf1)-1] = '\0';
	     snprintf(tbuf2, sizeof(tbuf2)-1, "%d%s", voice, get_string_var(STATUS_VOICE_VAR));
	     tbuf2[sizeof(tbuf2)-1] = '\0';
	     snprintf(tbuf3, sizeof(tbuf3)-1, "%d%s", opers, get_string_var(STATUS_OPER_VAR));
	     tbuf3[sizeof(tbuf3)-1] = '\0';
	     snprintf(tbuf4, sizeof(tbuf4)-1, "%d", total);
	     tbuf4[sizeof(tbuf4)-1] = '\0';
	     
	     snprintf(lbuf, sizeof(lbuf)-1, users_format, tbuf1, tbuf2, tbuf3, tbuf4);
	     lbuf[sizeof(lbuf)-1] = '\0';
	     dma_strcpy(&ptr, lbuf);
	  }
     }
   else
      dma_strcpy(&ptr, empty_string);
   return (ptr);
}



static	u_char	*
convert_sub_format_mult(format, c, l)
	u_char	*format;
	int	c, l;
{
   u_char *ret = NULL;
   u_char tmp[1024];
   u_char *pp, *afpp, *lpp;
   u_char *fmp;
   int i = 0;

   if (!format)
     return UNULL;
   lpp = afpp = pp = format;
   while (afpp && i < l)
     {
	if ((pp = my_index(afpp, '%')))
	  {
	     *pp = '\0';
	     my_strmcpy(tmp, lpp, sizeof(tmp)-1);
	     lpp = pp;
	     *pp++ = '%';
	     
	     fmp = convert_sub_format(tmp, c);
	     dma_strcat(&ret, fmp);
	     dma_Free(&fmp);
	     i++;
	  }
	else
	  dma_strcat(&ret, afpp);
	afpp = pp;
     }
   if (lpp)
     {
	fmp = convert_sub_format(lpp, c);
	dma_strcat(&ret, fmp);
	dma_Free(&fmp);
     }
   return ret;
}
