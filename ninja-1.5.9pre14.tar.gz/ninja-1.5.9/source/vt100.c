/*
 * vt100.c
 *
 * written by Kraig Amador and Joshua J. Drake
 */

#include "irc.h"
#include "vars.h"

/* This function returns 1 if the character passed is NOT printable, it
 * returns 0 if the character IS printable.  It doesnt actually do anything
 * with the character, though.
 */
int
vt100_decode(chr)
   u_char chr;
{
   static enum { 
      Normal, Escape, SCS, CSI, DCS, DCSData, DCSEscape 
   } vtstate = Normal;
   
   if (chr == 0x1B)		/* ASCII ESC */
     {
	if (vtstate == DCSData || vtstate == DCSEscape)
	  vtstate = DCSEscape;
	else
	  {
	     vtstate = Escape;
	     return 1;
	  }
     }
   else if (chr == 0x18 || chr == 0x1A)	/* ASCII CAN & SUB */
     vtstate = Normal;
   else if (chr == 0xE || chr == 0xF)	/* ASCII SO & SI */
     ;
   
   /* C0 codes are dispatched without changing machine state!  Oh, my! */
   else if (chr < 0x20)
     return 0;
   
   switch (vtstate)
     {
      case Normal:
	return 0;
	break;
	
      case Escape:
	switch (chr)
	  {
	   case '[':
	     vtstate = CSI;
	     break;
	     
	   case 'P':
	     vtstate = DCS;
	     break;
	     
	   case '(':
	   case ')':
	     vtstate = SCS;
	     break;
	     
	   default:
	     vtstate = Normal;
	  }
	return 1;
	/* not reached */
	break;
	
      case SCS:
	vtstate = Normal;
	break;
	
      case CSI:
	if (chr >= 0x40 && chr <= 0x7E)
	  vtstate = Normal;
	break;
	
      case DCS:
	if (chr >= 0x40 && chr <= 0x7E)
	  vtstate = DCSData;
	break;
	
      case DCSData:
	break;
	
      case DCSEscape:
	vtstate = Normal;
	break;
     }
   return 1;
}
