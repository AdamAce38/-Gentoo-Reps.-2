
#include "irc.h"
#ifdef HAVE_SSL

#include "output.h"

#include "ninjassl.h"


void
ninja_ssl_init(void)
{
   u_char entpool[128];
   size_t len;
#ifdef HAVE_DEV_RANDOM
   FILE *fp;
#endif
   
   // put_info("Initializing SSL library...");
   SSL_library_init();
   SSL_load_error_strings();
#ifdef HAVE_DEV_RANDOM
   fp = fopen(DEV_RANDOM_PATH, "r");
   if (fp)
     len = fread(entpool, sizeof(entpool), 1, fp);
   if (len != 1)
#endif
     for (len = 0; len < sizeof(entpool); len++)
       entpool[len] = (char)(random() & 0xff);
   RAND_seed(entpool, sizeof(entpool));
}


void
ninja_ssl_show_errors(void)
{
   u_char tb[1024];
   int se;
   
   while ((se = ERR_get_error()))
     {
	ERR_error_string(se, tb);
	put_error("SSL: #%d: %s", se, tb);
     }
}

#endif /* HAVE_SSL */
