/*
 * log.c: handles the irc session logging functions 
 *
 * Written By Michael Sandrof
 *
 * Copyright (c) 1990 Michael Sandrof.
 * Copyright (c) 1991, 1992 Troy Rollo.
 * Copyright (c) 1992-2004 Matthew R. Green.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include "irc.h"
IRCII_RCSID("@(#)$eterna: log.c,v 1.28 2004/01/06 05:42:16 mrg Exp $");

#include <sys/stat.h>

#include "log.h"
#include "vars.h"
#include "output.h"
#include "ircaux.h"
/* ninja irc stuff! */
#include "ninja.h"
#include "screen.h"
#include "dma.h"

FILE *irclog_fp;
/* ninja extensions */
FILE *msg_fp = (FILE *) 0;
static void log_prompt(u_char *, u_char *);

void
do_log(flag, logfile, fpp)
	int	flag;
	u_char	*logfile;
	FILE	**fpp;
{
	time_t	t;

	if (logfile == (u_char *) 0)
	{
		*fpp = (FILE *) 0;
		return;
	}
	t = time(0);
	if (flag)
	{
		if (*fpp)
			say("Logging is already on");
		else
		{
#ifdef DAEMON_UID
			if (getuid() == DAEMON_UID)
			{
				say("You are not permitted to use LOG");
				/* *fpp = (FILE *) 0;  unused */
			}
			else
			{
#endif /* DAEMON_UID */
				say("Starting logfile %s", logfile);
				if ((*fpp = fopen(CP(logfile), "a")) != NULL)
				{
#ifndef _Windows
#ifdef NEED_FCHMOD
					chmod(logfile, S_IREAD | S_IWRITE);
#else
#ifndef _IBMR2
					fchmod(fileno(*fpp),S_IREAD | S_IWRITE);
#else
					int fd = (int) fileno(*fpp);
					fchmod((char *) &fd, S_IREAD |
							S_IWRITE);
#endif /* !_IBMR2 */
#endif /* M_UNIX */
#endif /* _Windows */
					/* fprintf(*fpp, "IRC log started %.16s\n",
							ctime(&t)); */
				   fprintf(*fpp, "-+- NinjaIRC log started at %s\n", ninja_strftime(&t, "%I:%M%p on %a, %b %d"));
					fflush(*fpp);
				}
				else
				{
					say("Couldn't open logfile %s: %s",
						logfile, strerror(errno));
					*fpp = (FILE *) 0;
				}
#ifdef DAEMON_UID
			}
#endif /* DAEMON_UID */
		}
	}
	else
	{
		if (*fpp)
		{
			/* fprintf(*fpp, "IRC log ended %.16s\n", ctime(&t)); */
		   fprintf(*fpp, "-+- NinjaIRC log ended at %s\n", ninja_strftime(&t, "%I:%M%p on %a, %b %d"));
			fflush(*fpp);
			fclose(*fpp);
			*fpp = (FILE *) 0;
			say("Logfile ended");
		}
	}
	return;
}

/* logger: if flag is 0, logging is turned off, else it's turned on */
void
logger(flag)
   int flag;
{
   u_char *logfile;

   if ((logfile = get_string_var(LOGFILE_VAR)) == (u_char *) 0)
     {
	say("You must set the LOGFILE variable first!");
	set_int_var(LOG_VAR, 0);
	return;
     }
   do_log(flag, logfile, &irclog_fp);
   if ((irclog_fp == (FILE *) 0) && flag)
      set_int_var(LOG_VAR, 0);
}

/*
 * set_log_file: sets the log file name.  If logging is on already, this
 * closes the last log file and reopens it with the new name.  This is called
 * automatically when you SET LOGFILE. 
 */
void
set_log_file(filename)
   u_char *filename;
{
   u_char *expanded;

   if (filename)
     {
	if (my_strcmp(filename, get_string_var(LOGFILE_VAR)))
	   expanded = expand_twiddle(filename);
	else
	   expanded = expand_twiddle(get_string_var(LOGFILE_VAR));
	set_string_var(LOGFILE_VAR, expanded);
	new_free(&expanded);
	if (irclog_fp)
	  {
	     logger(0);
	     logger(1);
	  }
     }
}

/*
 * add_to_log: add the given line to the log file.  If no log file is open
 * this function does nothing.
 * 
 * NINJA: if STRIP_LOG_ANSI is on, do it.
 */
void
add_to_log(fp, line)
   FILE *fp;
   u_char *line;
{
   if (fp)
     {
	if (get_int_var(STRIP_LOG_ANSI_VAR))
	  fprintf(fp, "%s\n", strip_ansi(line));
	else
	  fprintf(fp, "%s\n", line);
	fflush(fp);
     }
}


/* below here are Ninja specific extensions to logging */
void
playlog(command, args, subargs)
   u_char *command, *args, *subargs;
{
   u_char *ptr;
   struct stat stat_buf;
   u_char filename[] = NINJA_AWAY_FILE;
   static u_char buf[BIG_BUFFER_SIZE + 1];
   
   /* expand the twiddle */
   ptr = expand_twiddle(filename);
   my_strmcpy(buf, ptr, sizeof(buf));
   new_free(&ptr);
   
   /* check for existence */
   if (stat(buf, &stat_buf) == -1)
     {
	put_error("Unable to stat log file: %s: %s", buf, strerror(errno));
	return;
     }
   
   /* if it's not regular, error! */
   if (!(stat_buf.st_mode & S_IFREG))
     {
	put_error("Unable to open log file: %s: Not a regular file", buf);
	return;
     }
   
   /* try to open it.. */
   if ((msg_fp = fopen(buf, "r")) == NULL)
     {
	put_error("Unable to open log file: %s", buf);
	return;
     }
   log_prompt(buf, NULL);
}

static int
show_log(name)
   u_char *name;
{
   int rows = 0;
   u_char line[BIG_BUFFER_SIZE + 1];
   
   if (!msg_fp)
     return 0;
   rows = curr_scr_win->display_size;
   while (--rows)
     {
	if (fgets(line, sizeof(line), msg_fp))
	  {
	     if (line[strlen(line) - 1] == '\n')
	       line[strlen(line) - 1] = (u_char) 0;
	     if (line[strlen(line) - 1] == '\r')
	       line[strlen(line) - 1] = (u_char) 0;
	     put_raw("%s", line);
	  }
	else
	  {
	     if (msg_fp)
	       fclose(msg_fp);
	     msg_fp = NULL;
	     return 0;
	  }
     }
   return 1;
}

void
eraselog(command, args, subargs)
   u_char *command, *args, *subargs;
{
   u_char *ptr;
   extern FILE *awayfile;

   if (awayfile == NULL)
     {
	ptr = expand_twiddle(NINJA_AWAY_FILE);
	if (unlink(ptr))
	  {
	     put_error("Could not unlink: %s: %s", ptr, strerror(errno));
	     dma_Free(&ptr);
	     return;
	  }
	put_info("Your saved messages have been erased.");
	dma_Free(&ptr);
     }
   else
     put_info("Not erasing your messages because the awayfile is still open.");
}

void
short_eraselog(data, line)
   u_char *data, *line;
{
   if (!(strcasecmp(line, "Y")))
     eraselog(NULL, NULL, NULL);
}

void
log_prompt(name, line)
   u_char *name, *line;
{
   if (line && ((*line == 'q') || (*line == 'Q')))
     {
	if (msg_fp)
	  fclose(msg_fp);
	msg_fp = NULL;
	add_wait_prompt("Erase your stored messages? [y/N] ", short_eraselog, "", WAIT_PROMPT_LINE);
	return;
     }

   if (show_log(name))
     add_wait_prompt("More? (Q to quit) ", log_prompt, name, WAIT_PROMPT_KEY);
   else
     {
	if (msg_fp)
	  fclose(msg_fp);
	msg_fp = NULL;
	add_wait_prompt("Erase your stored messages? [y/N] ", short_eraselog, "", WAIT_PROMPT_LINE);
     }
}
