/*
 * dcc.c: Things dealing client to client connections. 
 *
 * Written By Troy Rollo <troy@cbme.unsw.oz.au> 
 *
 * Copyright (c) 1991, 1992 Troy Rollo.
 * Copyright (c) 1992-2004 Matthew R. Green.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include "irc.h"
IRCII_RCSID("@(#)$eterna: dcc.c,v 1.141 2004/01/07 23:29:58 gkm Exp $");

#if defined(ISC30) && defined(_POSIX_SOURCE)
# undef _POSIX_SOURCE
#include <sys/stat.h>
# define _POSIX_SOURCE
#else
# include <sys/stat.h>
#endif /* ICS30 || _POSIX_SOURCE */

#ifdef HAVE_WRITEV
#include <sys/uio.h>
#endif

#ifdef HAVE_DIRENT_H
# include <dirent.h>
#endif

#include "server.h"
#include "ircaux.h"
#include "whois.h"
#include "lastlog.h"
#include "ctcp.h"
#include "dcc.h"
#include "hook.h"
#include "vars.h"
#include "window.h"
#include "output.h"
#include "newio.h"
#include "irccrypt.h"

/* ninja specific includes */
#include "screen.h"
#include "dma.h"
#include "ircterm.h"
#include "hosts.h"
#include "tabkey.h"
#include "ndcc.h"
#include "ninja.h"
#include "friends.h"
#include "parse.h"

static	void	dcc_chat(u_char *);
static	void	dcc_chat_rename(u_char *);
/* ninja has a better dcc_filesend
 * 
static	void	dcc_filesend(u_char *);
 */
static	int	dcc_filesend2(u_char *, u_char *);

static	void	dcc_getfile(u_char *);
/* ninja also has some nice stuff */
static	void	dcc_getbynumber(int);
static	void	dcc_getbyptr(DCC_list *);
static	void	dcc_getall(u_char *);

static	void	dcc_close(u_char *);
/* more nice ninja stuff */
static	void	dcc_closebynumber(int);
static	void	dcc_closebyptr(DCC_list *);
static	void	dcc_closeall(void);

static	void	dcc_rename(u_char *);
static	void	dcc_send_raw(u_char *);
static	void	process_incoming_chat(DCC_list *);
static	void	process_outgoing_file(DCC_list *);
static	void	process_incoming_file(DCC_list *);
static	void	process_incoming_raw(DCC_list *);
static	void	process_incoming_listen(DCC_list *);
#ifdef HAVE_SSL
static	void	dcc_schat(u_char *);
static	int	ninja_ssl_dcc_connect(DCC_list *);
static	int	ninja_ssl_dcc_accept(DCC_list *);
#endif

/* ninja specific functions */
static	void	dcc_getfile_resume(u_char *);
static	void	dcc_getfile_resume_demanded(u_char *, u_char *, u_char *, u_char *);
static	void	dcc_getfile_resume_start(u_char *, u_char *, u_char *, u_char *);
static	int	dcc_sanitize_blocksize(int, int);
extern	int	cs_match(u_char *, u_char *);

#ifndef O_BINARY
#define O_BINARY 0
#endif /* O_BINARY */

struct
{
	u_char	*name;	/* *MUST* be in ALL CAPITALS */
	int	uniq; /* minimum length to be a unique command */
	void	(*function)(u_char *);
}	dcc_commands[] =
{
	{ UP("CHAT"),	2, dcc_chat },
	{ UP("LIST"),	1, dcc_list },
#ifdef HAVE_SSL
	{ UP("SCHAT"),	2, dcc_schat },
#endif
	{ UP("SEND"),	2, dcc_sendfiles },
	{ UP("GET"),	1, dcc_getfile },
	{ UP("CLOSE"),	2, dcc_close },
	{ UP("RENAME"),	3, dcc_rename },
	{ UP("RAW"),	2, dcc_send_raw },
   	{ UP("RESUME"),	3, dcc_getfile_resume },
	{ NULL,		0, (void (*)(u_char *)) NULL }
};

/*
 * this list needs to be kept in sync with the DCC_TYPES defines
 * in dcc.h
 */
	u_char	*dcc_types[] =
{
	UP("<null>"),
	UP("CHAT"),
	UP("SEND"),
	UP("GET"),
	UP("RAW_LISTEN"),
	UP("RAW"),
#ifdef HAVE_SSL
   	UP("SCHAT"),
#endif
	NULL
};

struct	deadlist
{
	DCC_list *it;
	struct deadlist *next;
}	*deadlist = NULL;

extern	int	in_ctcp_flag;
extern int dgets_errno;

/* why global?
static	off_t	filesize = 0; */

/* ninja extensions.. */
extern	FILE	*awayfile;
int	dcc_send_count = 0;
int	dcc_get_count = 0;

DCC_list	*ClientList = NULL;

static	void	add_to_dcc_buffer(DCC_list *, u_char *);
static	void	dcc_really_erase(void);
static	void	dcc_add_deadclient(DCC_list *);
static	int	dcc_open(DCC_list *);
/* not used by ninja
static	u_char	*dcc_time(time_t); */
static	u_char	*dcc_sockname(SOCKADDR_STORAGE *, int);

static	u_char *
dcc_sockname(ss, salen)
	SOCKADDR_STORAGE *ss;
	int	salen;
{
	static u_char buf[NI_MAXHOST + NI_MAXSERV + 2];
	u_char hbuf[NI_MAXHOST], sbuf[NI_MAXSERV];

	if (getnameinfo((struct sockaddr *)ss, salen,
	    CP(hbuf), sizeof hbuf, CP(sbuf), sizeof sbuf,
	    NI_NUMERICSERV | NI_NUMERICHOST))
	{
		my_strmcpy(hbuf, "[unknown]", sizeof(hbuf) - 1);
		my_strmcpy(sbuf, "[unknown]", sizeof(sbuf) - 1);
	}
	snprintf(buf, sizeof buf, "%s:%s", hbuf, sbuf);
	return buf;
}

/*
 * dcc_searchlist searches through the dcc_list and finds the client
 * with the the flag described in type set.
 */
DCC_list *
dcc_searchlist(name, user, type, flag, othername, filesize)
	u_char	*name,
		*user;
	int	type,
		flag;
	u_char	*othername;
	off_t	filesize;
{
   DCC_list **Client, *NewClient;
   
   for (Client = (&ClientList); *Client ; Client = (&(**Client).next))
     {
	if ((((**Client).flags&DCC_TYPES) != type))
	  continue;
	if (my_stricmp(user, (**Client).user) != 0)
	  continue;
	if ((!name || (my_stricmp(name, (**Client).description) == 0)) ||
	     (othername && (**Client).othername
	      && (my_stricmp(othername, (**Client).othername)) == 0))
	  return *Client;
     }
   if (!flag)
     return NULL;
   *Client = NewClient = (DCC_list *) new_malloc(sizeof(DCC_list));
   NewClient->flags = type;
   NewClient->read = NewClient->write = NewClient->file = -1;
   NewClient->filesize = filesize;
   /*
    * setting stuff to 0 doesn't make much difference because
    * new_malloc() already does memst(x, 0, len) on malloc'd memory
    *
   NewClient->next = (DCC_list *) 0;
   NewClient->user = NewClient->description = NewClient->othername = NULL;
   NewClient->bytes_read = NewClient->bytes_sent = 0L;
   NewClient->starttime = 0;
   NewClient->buffer = 0;
   NewClient->remname = 0;
   NewClient->locport = 0;
   NewClient->resume_offset = 0;
   NewClient->minimum_speed = 0.0;
    */
   malloc_strcpy(&NewClient->description, name);
   malloc_strcpy(&NewClient->user, user);
   if (othername)
     malloc_strcpy(&NewClient->othername, strip_path(othername));
   time(&NewClient->lasttime);
   return NewClient;
}

static	void
dcc_add_deadclient(client)
	DCC_list *client;
{
   struct deadlist *new;
   
   new = (struct deadlist *) new_malloc(sizeof(struct deadlist));
   new->next = deadlist;
   new->it = client;
   deadlist = new;
}

/*
 * dcc_erase searches for the given entry in the dcc_list and
 * removes it
 */
void
dcc_erase(Element)
	DCC_list	*Element;
{
   DCC_list	**Client;
   
   for (Client = &ClientList; *Client; Client = &(**Client).next)
     if (*Client == Element)
       {
	  *Client = Element->next;
	  
	  if ((Element->flags & DCC_TYPES) != DCC_RAW_LISTEN)
	    new_close(Element->write);
	  new_close(Element->read);
	  if (Element->file != -1)
	    new_close(Element->file);
	  new_free(&Element->description);
	  new_free(&Element->user);
	  new_free(&Element->othername);
	  new_free(&Element->buffer);
	  new_free(&Element->remname);
	  new_free(&Element);
	  return;
       }
}

static	void
dcc_really_erase()
{
   struct deadlist *dies;
   
   while ((dies = deadlist) != NULL)
     {
	deadlist = deadlist->next;
	dcc_erase(dies->it);
	new_free(&dies);
     }
}

/*
 * Set the descriptor set to show all fds in Client connections to
 * be checked for data.
 */
void
set_dcc_bits(rd, wd)
	fd_set	*rd, *wd;
{
   DCC_list	*Client;
   
   for (Client = ClientList; Client != NULL; Client = Client->next)
     {
#ifdef DCC_CNCT_PEND
	if (Client->write != -1 && (Client->flags & DCC_CNCT_PEND))
	  FD_SET(Client->write, wd);
#endif /* DCC_CNCT_PEND */
	if (Client->read != -1)
	  FD_SET(Client->read, rd);
     }
}

/*
 * Check all DCCs for data, and if they have any, perform whatever
 * actions are required.
 */
void
dcc_check(rd, wd)
	fd_set	*rd,
		*wd;
{
   DCC_list	**Client;
   struct	timeval	time_out;
   int	previous_server;
   int	lastlog_level;
   
   previous_server = from_server;
   from_server = (-1);
   time_out.tv_sec = time_out.tv_usec = 0;
   lastlog_level = set_lastlog_msg_level(LOG_DCC);
   for (Client = (&ClientList); *Client != NULL && !break_io_processing;)
     {
#ifdef NON_BLOCKING_CONNECTS
	/*
	 * run all connect-pending sockets.. suggested by deraadt@theos.com
	 */
	if ((*Client)->flags & DCC_CNCT_PEND)
	  {
	     SOCKADDR_STORAGE	remaddr;
	     int	rl = sizeof(remaddr);
	     
	     if (getpeername((*Client)->read, (struct sockaddr *)&remaddr, &rl) != -1)
	       {
		  if ((*Client)->flags & DCC_OFFER)
		    {
		       (*Client)->flags &= ~DCC_OFFER;
		       save_message_from();
		       message_from((*Client)->user, LOG_DCC);
		       dcc_get_count++;
		       if (((*Client)->flags & DCC_TYPES) != DCC_RAW)
			 say("DCC: %s connection with %s[%s] established. (1)",
			     dcc_types[(*Client)->flags&DCC_TYPES], (*Client)->user, dcc_sockname(&remaddr, rl));
		       /*
			* XXX: fix ninja_host() to support IPv6 addressing
			* 
		         say("DCC: %s connection with %s[%s:%d] established. (1)",
				  dcc_types[(*Client)->flags&DCC_TYPES], (*Client)->user,
				  ninja_host(remaddr.sin_addr), ntohs(remaddr.sin_port));
			*/
		       
		       /* 
			* if its a chat, add a tab key 
			*/
		       if (((*Client)->flags & DCC_TYPES) == DCC_CHAT)
			 add_tab_key(0, "msg =", (*Client)->user);
		       
		       /* 
			* if it is a GET then we should attempt to open the file for writing 
			*/
		       if (((*Client)->flags & DCC_TYPES) == DCC_FILEREAD)
			 {
			    /*
			     * if we are resuming, we already opened it!
			     *
			     * not sure, but maybe we should O_EXCL? 
			     */
			    if ((*Client)->file == -1)
			      (*Client)->file = open((*Client)->description, O_WRONLY | O_TRUNC | O_CREAT, 0600);
			    
			    if ((*Client)->file == -1)
			      {
				 DCC_list *tmp = *Client;
				 
				 Client = (&(**Client).next);
				 dcc_erase(tmp);
				 continue;
			      }
			 }
		       
		       restore_message_from();
		    }
		  (*Client)->starttime = time(NULL);
		  (*Client)->flags &= ~DCC_CNCT_PEND;
		  set_blocking((*Client)->read);
		  if ((*Client)->read != (*Client)->write)
		    set_blocking((*Client)->write);

#ifdef HAVE_SSL
		  if (((*Client)->flags & DCC_TYPES) == DCC_SCHAT
		      && ninja_ssl_dcc_connect(*Client) < 0)
		    {
		       DCC_list *tmp = *Client;
		       
		       ninja_ssl_show_errors();
		       Client = (&(**Client).next);
		       dcc_erase(tmp);
		       continue;
		    }
#endif /* HAVE_SSL */
	       } /* else we're not connected yet */
	  }
#endif /* NON_BLOCKING_CONNECTS */
	if ((*Client)->read != -1 && FD_ISSET((*Client)->read, rd))
	  {
	     switch((*Client)->flags & DCC_TYPES)
	       {
#ifdef HAVE_SSL
		case DCC_SCHAT:
#endif
		case DCC_CHAT:
		  process_incoming_chat(*Client);
		  break;
		case DCC_RAW_LISTEN:
		  process_incoming_listen(*Client);
		  break;
		case DCC_RAW:
		  process_incoming_raw(*Client);
		  break;
		case DCC_FILEOFFER:
		  process_outgoing_file(*Client);
		  break;
		case DCC_FILEREAD:
		  process_incoming_file(*Client);
		  break;
	       }
	  }
	if ((*Client)->flags & DCC_DELETE)
	  {
	     dcc_add_deadclient(*Client);
	     Client = (&(**Client).next);
	  }
	else
	  Client = (&(**Client).next);
     }
   (void) set_lastlog_msg_level(lastlog_level);
   dcc_really_erase();
   from_server = previous_server;
}

/*
 * Process a DCC command from the user.
 */
void
process_dcc(args)
	u_char	*args;
{
   u_char	*command;
   int	i;
   size_t	len;

   if (!(command = next_arg(args, &args)))
     return;
   len = my_strlen(command);
   upper(command);
   for (i = 0; dcc_commands[i].name != NULL; i++)
     {
	if (!my_strncmp(dcc_commands[i].name, command, len))
	  {
	     if (len < dcc_commands[i].uniq)
	       {
		  yell("DCC: command not unique: %s", command );
		  return;
	       }
	     save_message_from();
	     message_from((u_char *) 0, LOG_DCC);
	     dcc_commands[i].function(args);
	     restore_message_from();
	     return;
	  }
     }
   yell("DCC: Unknown command: %s", command);
}

int listen_dcc(u_char *);

int
listen_dcc(src_host)
	u_char	*src_host;
{
	SOCKADDR_STORAGE *ss;
	struct addrinfo hints, *res, *res0;
	int err, s;

	ss = get_server_localaddr(from_server);
	memset(&hints, 0, sizeof hints);
	hints.ai_flags = AI_PASSIVE;
	hints.ai_protocol = 0;
	hints.ai_addrlen = 0;
	hints.ai_canonname = NULL;
	hints.ai_addr = NULL;
	hints.ai_next = NULL;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_family = AF_UNSPEC;
	errno = 0;
	err = getaddrinfo(src_host, zero, &hints, &res0);
	if (err != 0) 
	{
		errno = err;
		return -2;
	}
	for (res = res0; res; res = res->ai_next) {
		if (ss && SS_FAMILY(ss) != res->ai_family)
			continue;

		if ((s = socket(res->ai_family, res->ai_socktype,
		    res->ai_protocol)) < 0)
			continue;
		set_socket_options(s);
		if (bind(s, res->ai_addr, res->ai_addrlen) == 0 &&
		    listen(s, 1) == 0)
		{
			freeaddrinfo(res0);
			return s;
		}
		close(s);
	}
	
	freeaddrinfo(res0);
	return -1;
}

static	int
dcc_open(Client)
	DCC_list	*Client;
{
	u_char    *user, *Type;
	int	old_server, error;
	struct	addrinfo hints, *res0;
#ifndef NON_BLOCKING_CONNECTS
	SOCKADDR_STORAGE	remaddr;
	int	rl = sizeof(remaddr);
#endif /* NON_BLOCKING_CONNECTS */

   user = Client->user;
   old_server = from_server;
   if (-1 == from_server)
     from_server = get_window_server(0);
   
   Type = dcc_types[Client->flags & DCC_TYPES];
   if (Client->flags & DCC_OFFER)
     {
#ifdef DCC_CNCT_PEND
	Client->flags |= DCC_CNCT_PEND;
#endif /* DCC_CNCT_PEND */
	if ((Client->write = connect_by_number(Client->remport, Client->remname, 1, 0, 0)) < 0)
	  {
	     save_message_from();
	     message_from(user, LOG_DCC);
	     if (Client->write == -5)
	       yell("DCC: Unable to create connection: %s", errno ? strerror(errno) : "Unknown Source Host");
	     else
	       yell("DCC: Unable to create connection: %s%s", errno ? strerror(errno) : "Unknown Host");
	     restore_message_from();
	     dcc_erase(Client);
	     from_server = old_server;
	     return 0;
	  }
	Client->read = Client->write;
	/* if (Client->resume_offset == 0) */
	Client->bytes_read = Client->bytes_sent = 0L;
	Client->flags |= DCC_ACTIVE;
#ifndef NON_BLOCKING_CONNECTS
	Client->flags &= ~DCC_OFFER;
	Client->starttime = time(NULL);
	if (getpeername(Client->read, (struct sockaddr *)&remaddr, &rl) == -1)
	  {
	     save_message_from();
	     message_from(user, LOG_DCC);
	     yell("DCC: getpeername failed: %s", strerror(errno));
	     restore_message_from();
	     dcc_erase(Client);
	     from_server = old_server;
	     return 0;
	  }
#ifdef HAVE_SSL
	if ((Client->flags & DCC_TYPES) == DCC_SCHAT && ninja_ssl_dcc_connect(Client) < 0)
	  {
	     ninja_ssl_show_errors();
	     dcc_erase(Client);
	     from_server = old_server;
	     return 0;
	  }
#endif /* HAVE_SSL */
	if ((Client->flags & DCC_TYPES) != DCC_RAW)
	  {
	     /*
	      * if it is a DCC GET then we want to open the file immediately
	      */
	     if (my_strcmp(Type, "GET") == 0)
	       {
		  if ((Client->file = open(Client->description, O_WRONLY | O_TRUNC | O_CREAT, 0600)) == -1)
		    {
		       save_message_from();
		       message_from(user, LOG_DCC);
		       yell("DCC: Unable to open %s: %s", Client->description, strerror(errno));
		       restore_message_from();
		       dcc_erase(Client);
		       from_server = old_server;
		       return 0;
		    }
	       }
	     save_message_from();
	     message_from(user, LOG_DCC);
	     say("DCC: %s connection with %s[%s] established. (2)", Type, user, dcc_sockname(&remaddr, rl));
	     /*
	      * XXX: fix ninja_host() to allow IPv6 addressing
	      *
	     say("DCC: %s connection with %s[%s:%d] established. (2)",
		      Type, user, ninja_host(remaddr.sin_addr),
		      ntohs(remaddr.sin_port));
	      */
	     restore_message_from();
	  }
#endif /* NON_BLOCKING_CONNECTS */
	from_server = old_server;
	return 1;
     }
   else
     {
#ifdef DCC_CNCT_PEND
	Client->flags |= DCC_WAIT|DCC_CNCT_PEND;
#else
	Client->flags |= DCC_WAIT;
#endif /* DCC_CNCT_PEND */
	if ((Client->read = listen_dcc(dcc_source_host)) < 0)
	  {
	     save_message_from();
	     message_from(user, LOG_DCC);
	     yell("DCC: Unable to create connection: %s",
		  Client->read ? gai_strerror(errno) : strerror(errno));
	     restore_message_from();
	     dcc_erase(Client);
	     from_server = old_server;
	     return 0;
	  }
	if (Client->flags & DCC_TWOCLIENTS)
	  {
	     SOCKADDR_STORAGE	locaddr;
	     SOCKADDR_STORAGE	*myip, me;
	     u_char hbuf[NI_MAXHOST], sbuf[NI_MAXSERV];
	     u_char *printhbuf = 0;
	     u_char	*nopath, *sh;
	     int	sla;
	     int	times = 0;
	     
	     if (((Client->flags & DCC_TYPES) == DCC_FILEOFFER) &&
		 (nopath = my_rindex(Client->description, '/')))
	       nopath++;
	     else
	       nopath = Client->description;

	     sla = sizeof locaddr;
	     getsockname(Client->read,
			 (struct sockaddr *) &locaddr, &sla);
	     
	     if ((error = getnameinfo((struct sockaddr *)&locaddr,
				      sla, 0, 0, CP(sbuf), sizeof sbuf, NI_NUMERICSERV)))
	       {
		  save_message_from();
		  message_from(user, LOG_DCC);
		  yell("DCC: Unable to get socket port address: %s",
		      gai_strerror(error));
		  restore_message_from();
		  dcc_erase(Client);
		  from_server = old_server;
		  return 0;
	       }
	     
	     myip = 0;
	     sh = dcc_source_host;
	     if (sh && *sh)
	       {
do_it_again:
		  memset(&hints, 0, sizeof hints);
		  hints.ai_flags = 0;
		  hints.ai_protocol = 0;
		  hints.ai_addrlen = 0;
		  hints.ai_canonname = NULL;
		  hints.ai_addr = NULL;
		  hints.ai_next = NULL;
		  hints.ai_socktype = SOCK_STREAM;
		  hints.ai_family = PF_UNSPEC;
		  error = getaddrinfo(sh, 0, &hints, &res0);
		  if (error == 0)
		    {
		       bcopy((char *) res0->ai_addr, &me, sizeof me);
		       myip = &me;
		       sla = res0->ai_addrlen;
		       freeaddrinfo(res0);
		    }
		  else
		    {
		       save_message_from();
		       message_from(user, LOG_DCC);
		       yell("DCC: Unable to create address from %s: %s", sh,
			   gai_strerror(error));
		       restore_message_from();
		       dcc_erase(Client);
		       from_server = old_server;
		       return 0;
		    }
	       }
	     else
	       {
		  myip = server_list[from_server].localaddr;
		  sla = server_list[from_server].localaddrlen;
	       }
	     if (!myip)
	       myip = &locaddr;
	     
	     error = getnameinfo((struct sockaddr *) myip, sla,
				 CP(hbuf), sizeof hbuf, 0, 0, NI_NUMERICHOST);
	     if (error)
	       {
		  save_message_from();
		  message_from(user, LOG_DCC);
		  yell("DCC: Unable to getnameinfo: %s", gai_strerror(error));
		  restore_message_from();
		  dcc_erase(Client);
		  from_server = old_server;
		  return 0;
	       }
	     
#ifdef INET6
	     /* Make sure IPv4 goes as a single number */
	     if (SS_FAMILY(myip) == PF_INET)
#endif
	       {
		  struct sockaddr_in *in = (struct sockaddr_in *) myip;
		  u_32int l;
		  
		  malloc_strcpy(&printhbuf, hbuf);
		  bcopy((char *) &in->sin_addr.s_addr, &l, sizeof l);
		  snprintf(CP(hbuf), sizeof hbuf, "%lu", (unsigned long)ntohl(l));
	       }
	     
	     /* if the host is "0", force it to source_host or then hostname */
	     if (my_strcmp(hbuf, zero) == 0)
	       {
		  if (times == 0)
		    {
		       sh = source_host;
		       if (!sh || !*sh)
			 times++;
		    }
		  if (times == 1)
		    sh = hostname;
		  else
		    {
		       save_message_from();
		       message_from(user, LOG_DCC);
		       yell("DCC: Unable to generate a source address");
		       restore_message_from();
		       dcc_erase(Client);
		       from_server = old_server;
		       if (printhbuf)
			 new_free(&printhbuf);
		       return 0;
		    }
		  times++;
		  goto do_it_again;
	       }
	     
	     /*
	      * XXX
	      * should make the case below for the filesize into
	      * generic off_t2str() function, or something.  this
	      * cast is merely a STOP-GAP measure.
	      */
	     if (Client->filesize)
	       send_ctcp(ctcp_type[in_ctcp_flag], user, UP("DCC"),
			 "%s %s %s %s %lu", Type, nopath, hbuf, sbuf, (u_long)Client->filesize);
	     else
	       send_ctcp(ctcp_type[in_ctcp_flag], user, UP("DCC"), "%s %s %s %s", Type, nopath, hbuf, sbuf);
	     
	     /* hmmm.. lets not print this.. for file offers..
	      * it is handled elsewhere..
	      */
	     if (!((Client->flags & DCC_TYPES) == DCC_FILEOFFER))
	       {
		  save_message_from();
		  message_from(user, LOG_DCC);
		  say("DCC: Sent %s [%s:%s] request to %s",
		      Type, printhbuf ? printhbuf : hbuf, sbuf, user);
		  /*
		   * XXX: more ninja_host
		   * 
		  say("DCC: Sent %s [%s:%u] request to %s",
			   Type,
			   ninja_host(myip),
			   (unsigned) ntohs(localaddr.sin_port),
			   user);
		   */
		  restore_message_from();
		  if (printhbuf)
		    new_free(&printhbuf);
	       }
	  }
	Client->starttime = 0;
	from_server = old_server;
	return 2;
     }
}

static void
dcc_chat(args)
	u_char	*args;
{
   u_char	*user;
   DCC_list	*Client;
   
   if ((user = next_arg(args, &args)) == NULL)
     {
	usage("dcc chat", "<nickname>");
	return;
     }
   Client = dcc_searchlist(UP("chat"), user, DCC_CHAT, 1, (u_char *) 0, 0);
   if ((Client->flags&DCC_ACTIVE) || (Client->flags&DCC_WAIT))
     {
	yell("DCC: A previous CHAT to %s exists.", user);
	return;
     }
   Client->flags |= DCC_TWOCLIENTS;
   dcc_open(Client);
}

u_char	*
dcc_raw_listen(iport)
	u_int	iport;
{
   DCC_list	*Client;
   u_char	PortName[10];
   struct sockaddr_in locaddr;	/* XXX DCC IPv6: this one doesn't matter; for now only support DCC RAW for ipv4 */
   u_char	*RetName = NULL;
   int	size;
   int	lastlog_level;
   u_short	port = (u_short) iport;

   lastlog_level = set_lastlog_msg_level(LOG_DCC);
   if (port && port < 1025)
     {
	yell("DCC: Cannot bind to a privileged port");
	(void) set_lastlog_msg_level(lastlog_level);
	return NULL;
     }
   snprintf(CP(PortName), sizeof(PortName)-1, "%d", port);
   PortName[sizeof(PortName)-1] = '\0';
   Client = dcc_searchlist(UP("raw_listen"), PortName, DCC_RAW_LISTEN, 1, (u_char *) 0, 0);
   if (Client->flags & DCC_ACTIVE)
     {
	yell("DCC: A previous RAW_LISTEN on %s exists.", PortName);
	(void) set_lastlog_msg_level(lastlog_level);
	return RetName;
     }
   if (0 > (Client->read = socket(AF_INET, SOCK_STREAM, 0)))
     {
	dcc_erase(Client);
	yell("DCC: socket() failed: %s", strerror(errno));
	(void) set_lastlog_msg_level(lastlog_level);
	return RetName;
     }
   set_socket_options(Client->read);
   bzero((char *) &locaddr, sizeof(locaddr));
   locaddr.sin_family = AF_INET;
   locaddr.sin_addr.s_addr = htonl(INADDR_ANY);
   locaddr.sin_port = htons(port);
   if (bind(Client->read, (struct sockaddr *) &locaddr, sizeof(locaddr)) == -1)
     {
	dcc_erase(Client);
	yell("DCC: Could not bind port: %s", strerror(errno));
	(void) set_lastlog_msg_level(lastlog_level);
	return RetName;
     }
   listen(Client->read, 4);
   size = sizeof(locaddr);
   Client->starttime = time((time_t *) 0);
   getsockname(Client->read, (struct sockaddr *) &locaddr, &size);
   Client->write = ntohs(locaddr.sin_port);
   Client->flags |= DCC_ACTIVE;
   snprintf(CP(PortName), sizeof(PortName)-1, "%d", Client->write);
   PortName[sizeof(PortName)-1] = '\0';
   malloc_strcpy(&Client->user, PortName);
   malloc_strcpy(&RetName, PortName);
   (void) set_lastlog_msg_level(lastlog_level);
   return RetName;
}

u_char	*
dcc_raw_connect(host, iport)
	u_char	*host;
	u_int	iport;
{
   DCC_list	*Client;
   struct	addrinfo hints, *res = 0, *res0 = 0;
   struct	sockaddr_in	address;
   u_char	addr[NI_MAXHOST];
   u_char	PortName[10], *RetName = (u_char *) 0;
   u_short	port = (u_short)iport;
   int	lastlog_level, err;

   lastlog_level = set_lastlog_msg_level(LOG_DCC);
   
   memset(&hints, 0, sizeof hints);
   hints.ai_flags = 0;
   hints.ai_protocol = 0;
   hints.ai_addrlen = 0;
   hints.ai_canonname = NULL;
   hints.ai_addr = NULL;
   hints.ai_next = NULL;
   hints.ai_socktype = SOCK_STREAM;
   hints.ai_family = AF_INET;
   err = getaddrinfo(host, 0, &hints, &res0);
   if (err == 0)
     {
	for (res = res0; res; res = res->ai_next)
	  if (res->ai_family == PF_INET)
	    {
	       bcopy(res->ai_addr, &address, sizeof address);
	       break;
	    }
	freeaddrinfo(res0);
     }
   if (!res || err)
     {
	yell("DCC: Unknown host: %s", host);
	(void) set_lastlog_msg_level(lastlog_level);
	goto out;
     }
   
   snprintf(CP(PortName), sizeof(PortName)-1, "%d", port);
   PortName[sizeof(PortName)-1] = '\0';
   Client = dcc_searchlist(host, PortName, DCC_RAW, 1, (u_char *) 0, 0);
   if (Client->flags & DCC_ACTIVE)
     {
	yell("DCC: A previous RAW to %s on %s exists", host, PortName);
	(void) set_lastlog_msg_level(lastlog_level);
	return RetName;
     }
   Client->remport = port;
   err = getnameinfo((struct sockaddr *) &address, sizeof address, CP(addr), NI_MAXHOST, 0, 0, NI_NUMERICHOST);
   if (err != 0) 
     {
	my_strncpy(addr, "[unknown]", sizeof(addr) - 1);
	yell("dcc_raw_connect: getnameinfo failed: %s", gai_strerror(err));
     }
   malloc_strcpy(&Client->remname, addr);
   Client->flags = DCC_OFFER | DCC_RAW;
   if (!dcc_open(Client))
     return RetName;
   snprintf(CP(PortName), sizeof(PortName)-1, "%d", Client->read);
   PortName[sizeof(PortName)-1] = '\0';
   malloc_strcpy(&Client->user, PortName);
   if (do_hook(DCC_RAW_LIST, "%s %s E %d", PortName, host, port))
     say("DCC: RAW connection to %s on %s via %d established.",
	      host, PortName, port);
   malloc_strcpy(&RetName, PortName);
   (void) set_lastlog_msg_level(lastlog_level);
out:
   return RetName;
}


/*
 * this is not used by Ninja IRC
 * 
static	void
dcc_filesend(args)
	u_char	*args;
{
	u_char	*user;
	u_char	*filename,
		*fullname;
	DCC_list *Client;
	u_char	FileBuf[BIG_BUFFER_SIZE+1];
	struct	stat	stat_buf;

#ifdef  DAEMON_UID
	if (DAEMON_UID == getuid())
	{
		say("You are not permitted to use DCC to exchange files");
		return;
	}
#endif / * DAEMON_UID * /
	if (0 == (user = next_arg(args, &args)) ||
	    0 == (filename = next_arg(args, &args)))
	{
		say("You must supply a nickname and filename for DCC SEND");
		return;
	}
	if (IS_ABSOLUTE_PATH(filename))
	{
		my_strmcpy(FileBuf, filename, BIG_BUFFER_SIZE);
	}
	else if (*filename == '~')
	{
		if (0 == (fullname = expand_twiddle(filename)))
		{
			yell("Unable to expand %s", filename);
			return;
		}
		my_strmcpy(FileBuf, fullname, BIG_BUFFER_SIZE);
		new_free(&fullname);
	}
	else
	{
		getcwd(CP(FileBuf), sizeof(FileBuf));
		my_strmcat(FileBuf, "/", BIG_BUFFER_SIZE);
		my_strmcat(FileBuf, filename, BIG_BUFFER_SIZE);
	}
	if (0 != access(CP(FileBuf), R_OK))
	{
		yell("Cannot access %s", FileBuf);
		return;
	}
	stat(CP(FileBuf), &stat_buf);
/ * some unix didn't have this ???? * /
#ifdef S_IFDIR
	if (stat_buf.st_mode & S_IFDIR)
	{
		yell("Cannot send a directory");
		return;
	}
#endif / * S_IFDER * /
	if (scanstr(FileBuf, UP("/etc/")))
	{
		yell("Send request rejected");
		return;
	}
	if ((int) my_strlen(FileBuf) >= 7 && 0 == my_strcmp(FileBuf + my_strlen(FileBuf) - 7, "/passwd"))
	{
		yell("Send request rejected");
		return;
	}
	filesize = stat_buf.st_size;
	Client = dcc_searchlist(FileBuf, user, DCC_FILEOFFER, 1, filename);
	if ((Client->file = open(CP(Client->description), O_RDONLY | O_BINARY)) == -1)
	{
		say("Unable to open %s: %s\n", Client->description, errno ? strerror(errno) : "Unknown Host");
		new_close(Client->read);
		Client->read = Client->write = (-1);
		Client->flags |= DCC_DELETE;
		return;
	}
	filesize = 0;
	if ((Client->flags & DCC_ACTIVE) || (Client->flags & DCC_WAIT))
	{
		say("A previous DCC SEND:%s to %s exists", FileBuf, user);
		return;
	}
	Client->flags |= DCC_TWOCLIENTS;
	dcc_open(Client);
}
 */

static	void
dcc_getfile(args)
	u_char	*args;
{
   u_char	*user;
   u_char	*filename;
   DCC_list	*Client;
/*   u_char	*fullname = (u_char *) 0; */
   int		number;
   
#ifdef  DAEMON_UID
   if (DAEMON_UID == getuid())
     {
	yell("DCC: You are not permitted to exchange files.");
	return;
     }
#endif /* DAEMON_UID */
   if (0 == (user = next_arg(args, &args)))
     {
	/* say("You must supply a nickname for DCC GET");
	 */
	usage("dcc get", "<#>, or *, or <nick> *, or <nick> [<file 1> .. <file n>]");
	return;
     }
   
   /* get by number */
   if (isdigit(*user) && (number = my_atoi(user)) != 0)
     {
	dcc_getbynumber(number);
	return;
     }
   /* get all! */
   else if (*user == '*')
     {
	dcc_getall(UNULL);
	return;
     }
   filename = next_arg(args, &args);
   
   /* get all from a user! */
   if (filename && *filename == '*')
     {
	dcc_getall(user);
	return;
     }
   
   /* check all remaining words as filenames for the specified user */
   while (1)
     {
	if (0 == (Client = dcc_searchlist(filename, user, DCC_FILEREAD, 0, (u_char *) 0, 0)))
	  {
	     if (filename)
	       yell("DCC: %s isn't trying to send you \"%s\".", user, filename);
	     else
	       {
		  yell("DCC: %s isn't trying to send you anything.", user);
		  return;
	       }
	  }
	else
	  dcc_getbyptr(Client);
	filename = next_arg(args, &args);
	/* no more filenames? */
	if (!filename)
	  return;
     }
}

void
register_dcc_offer(user, type, description, address, port, size)
	u_char	*user;
	u_char	*type;
	u_char	*description;
	u_char	*address;
	u_char	*port;
	u_char	*size;
{
   DCC_list	*Client;
   u_char	*c, *s, *cmd = (u_char *) 0;
   unsigned	TempInt;
   int	CType;
   int	do_auto = 0;	/* used in dcc chat collisions */
   int	lastlog_level;
   /* ninja extensions vars */
   Friend *f = NULL;
   off_t filesize;
   
   lastlog_level = set_lastlog_msg_level(LOG_DCC);
   if (0 != (c = my_rindex((description), '/')))
     description = c + 1;
   if ('.' == *description)
     *description = '_';
   if (size && *size)
     filesize = my_atol(size);  /* atoi() isn't big enough */
   else
     filesize = 0;
   malloc_strcpy(&cmd, type);
   upper(cmd);
   if (!my_strcmp(cmd, "CHAT"))
     CType = DCC_CHAT;
#ifdef HAVE_SSL
   else if (!my_strcmp(cmd, "SCHAT"))
     CType = DCC_SCHAT;
#endif /* HAVE_SSL */
#ifndef  DAEMON_UID
   else if (!my_strcmp(cmd, "SEND"))
#else
   else if (!my_strcmp(cmd, "SEND") && DAEMON_UID != getuid())
#endif /* DAEMON_UID */
       CType = DCC_FILEREAD;
   /* 
    * ninja dcc resume extensions
    */
   else if (!my_strcmp(cmd, "RESUME"))
     {
	dcc_getfile_resume_demanded(user, description, address, port);
	goto out;
     }
   else if (!my_strcmp(cmd, "ACCEPT"))
     {
	dcc_getfile_resume_start(user, description, address, port);
	goto out;
     }
   else
     {
	yell("DCC: Unknown request: %s (%s) received from %s", type, description, user);
	goto out;
     }
   Client = dcc_searchlist(description, user, CType, 1, (u_char *) 0, filesize);
   filesize = 0;
   if (Client->flags & DCC_WAIT)
     {
	new_close(Client->read);
	dcc_erase(Client);
	if (DCC_CHAT == CType 
#ifdef HAVE_SSL
	    || CType == DCC_SCHAT
#endif /* HAVE_SSL */
	    )
	  {
	     Client = dcc_searchlist(description, user, CType, 1, (u_char *) 0, 0);
	     do_auto = 1;
	  }
	else
	  {
	     yell("DCC: %s collision for %s:%s", type, user, description);
	     send_ctcp_reply(user, UP("DCC"), "DCC: %s collision occured while connecting to %s (%s)", type, nickname,
			     description);
	     goto out;
	  }
     }
   if (Client->flags & DCC_ACTIVE)
     {
	yell("DCC: Received %s request from %s while previous session still active.", type, user);
	goto out;
     }
   Client->flags |= DCC_OFFER;
   
   TempInt = 0;
   sscanf(CP(port), "%u", &TempInt);
   if (TempInt < 1024)
     {
	yell("DCC: %s (%s) request from %s rejected [addr = %s, port = %d]", type, description, user, address, TempInt);
	dcc_erase(Client);
	goto out;
     }
   
   for (s = address; *s; s++)
     if (!isdigit(*s))
       break;
   if (*s)
     malloc_strcpy(&Client->remname, address);
   else
     {
	/* This is definately an IPv4 address, convert to a.b.c.d */
	u_char	buf[20];
	u_long	TempLong;
	u_int	dots[4], i;
	
	sscanf(CP(address), "%lu", &TempLong);
	if (0 == TempLong)
	  {
	     say("DCC %s (%s) request from %s rejected [addr = %s, port = %d]", type, description, user, address, (int)TempLong);
	     dcc_erase(Client);
	     goto out;
	  }
	for (i = 0; i < 4; i++)
	  {
	     dots[i] = TempLong & 0xff;
	     TempLong >>= 8;
	  }
	snprintf(buf, sizeof buf, "%u.%u.%u.%u", dots[3], dots[2], dots[1], dots[0]);
	malloc_strcpy(&Client->remname, buf);
     }
   Client->remport = TempInt;
   if (do_auto)
     {
	say("DCC: %s already requested by %s, connecting to [%s:%s]", type, user, Client->remname, port);
	dcc_chat(user);
     }
   else if ((Client->flags & DCC_TYPES) == DCC_FILEREAD)
     {	
	u_char mfmt[] = "DCC: %s (%s %s) request received from %s[%s:%s]";
	
	say(mfmt, type, description, ninja_size(Client->filesize),
	    user, Client->remname, port);
	/* if we are away, log it */
	if (awayfile)
	  add_to_awaylog(mfmt, type, description, ninja_size(Client->filesize),
			 user, Client->remname, port);
	
	/* is this coming from a friend? */
	f = check_friend_autoget(user, FromUser, FromHost);
	/* if we're autogetting from this friend or we are autogetting from everyone,
	 * do the autoget stuff..
	 */
	if (get_int_var(DCC_AUTOGET_VAR) || f)
	  {
	     u_char *ffn, dbuf[1024];
	     struct stat sb;
	     int statret;
	     
	     getcwd(dbuf, sizeof(dbuf)-1);
	     dbuf[sizeof(dbuf)-1] = '\0';
	     ffn = new_malloc(my_strlen(dbuf) + my_strlen(description) + 2);
	     if (!ffn)
	       {
		  yell("DCC: can't allocate memory for checking for local file");
		  goto out;
	       }
	     strcpy(ffn, dbuf);			/* safe, malloc'd */
	     strcat(ffn, "/");			/* safe, malloc'd */
	     strcat(ffn, description); 		/* safe, malloc'd */
	     statret = stat(ffn, &sb);
	     new_free(&ffn);
	     if (statret == -1)
	       {
		  if (f)
		    {
		       u_char fmt[] = "DCC: Automatically getting \"%s\" from your friend, %s(%s)!";
		       
		       say(fmt, description, user, f->nick);
		       if (awayfile)
			 add_to_awaylog(fmt, description, user, f->nick);
		    }
		  else
		    {
		       u_char fmt[] = "DCC: Automatically getting \"%s\" from %s";
		       
		       say(fmt, description, user);
		       if (awayfile)
			 add_to_awaylog(fmt, description, user);
		    }
		  dcc_getbyptr(Client);
	       }
	     else
	       {
		  if (Client->filesize > sb.st_size)
		    {
		       u_char gfargs[256];
		       
		       if (f)
			 {
			    u_char fmt[] = "DCC: Automatically resuming transfer of \"%s\" at %s from your friend, %s(%s)!";
			    
			    say(fmt, description, ninja_size(sb.st_size), user, f->nick);
			    if (awayfile)
			      add_to_awaylog(fmt, description, ninja_size(sb.st_size), user, f->nick);
			 }
		       else
			 {
			    u_char fmt[] = "DCC: Automatically resuming transfer of \"%s\" at %s.";
			    
			    say(fmt, description, ninja_size(sb.st_size));
			    if (awayfile)
			      add_to_awaylog(fmt, description, ninja_size(sb.st_size));
			 }
		       /* XXX nasty hack! */
		       snprintf(CP(gfargs), sizeof(gfargs)-1, "%s %s", user, description);
		       gfargs[sizeof(gfargs)-1] = '\0';
		       dcc_getfile_resume(gfargs);
		    }
		  else
		    {
		       u_char fmt[] = "DCC: Automatically closing \"%s\" because it exists.";
		       
		       say(fmt, description);
		       if (awayfile)
			 add_to_awaylog(fmt, description);
		       dcc_closebyptr(Client);
		    }
	       }
	  }
	else
	  {
	     u_char gfargs[256];
	     
	     /* XXX nasty hack! */
	     snprintf(CP(gfargs), sizeof(gfargs)-1, "%s %s", user, description);
	     gfargs[sizeof(gfargs)-1] = '\0';
	     add_tab_key(1, "DCC GET ", gfargs);
	  }
     }
   else
     {
	u_char mfmt[] = "DCC: %s (%s) request received from %s[%s:%s]";
	
	say(mfmt, type, description, user, Client->remname, port);
	if (awayfile)
	  add_to_awaylog(mfmt, type, description, user, Client->remname, port);
	
	/* is this coming from a friend? */
	f = check_friend_autoget(user, FromUser, FromHost);
	/* if we're autogetting from this friend or we are autogetting from everyone,
	 * do the autoget stuff..
	 */
	if (get_int_var(DCC_AUTOGET_VAR) || f)
	  {
	     if (f)
	       {
		  u_char fmt[] = "DCC: Automatically accepting chat from your friend, %s(%s)!";
		  
		  say(fmt, user, f->nick);
		  if (awayfile)
		    add_to_awaylog(fmt, user, f->nick);
	       }
	     else
	       {
		  u_char fmt[] = "DCC: Automatically accepting chat from %s";
		  
		  say(fmt, user);
		  if (awayfile)
		    add_to_awaylog(fmt, user);
	       }
#ifdef HAVE_SSL
	     if (CType == DCC_SCHAT)
	       dcc_schat(user);
	     else
#endif /* HAVE_SSL */
	     dcc_chat(user);
	  }
	else
#ifdef HAVE_SSL
	  {
	     if (CType == DCC_SCHAT)
	       add_tab_key(1, "DCC SCHAT ", user);
	     else
#endif /* HAVE_SSL */
	  add_tab_key(1, "DCC CHAT ", user);
#ifdef HAVE_SSL
	  }
#endif /* HAVE_SSL */
     }
   if (beep_on_level & LOG_CTCP)
     beep_em(1);
out:
   set_lastlog_msg_level(lastlog_level);
   new_free(&cmd);
}

static	void
process_incoming_chat(Client)
	DCC_list	*Client;
{
   SOCKADDR_STORAGE	remaddr;
   int	sra;
   u_char	tmp[BIG_BUFFER_SIZE+1];
   u_char	tmpuser[IRCD_BUFFER_SIZE];
   u_char	*s, *bufptr;
   long	bytesread;
   int	old_timeout;
   size_t	len;
   
   save_message_from();
   message_from(Client->user, LOG_DCC);
   if (Client->flags & DCC_WAIT)
     {
	sra = sizeof remaddr;
	Client->write = accept(Client->read, (struct sockaddr *)&remaddr, &sra);
	if (Client->write == -1)
	  {
	     yell("DCC: %s connect to %s failed in accept: %s",
		  dcc_types[Client->flags & DCC_TYPES],
		  Client->user, strerror(errno));
	     Client->read = -1;
	     Client->flags |= DCC_DELETE;
	     goto out;
	  }
#ifdef HAVE_SSL
	if ((Client->flags & DCC_TYPES) == DCC_SCHAT && ninja_ssl_dcc_accept(Client) < 0)
	  {
	     ninja_ssl_show_errors();
	     Client->read = -1;
	     Client->flags |= DCC_DELETE;
	     goto out;
	  }
#endif /* HAVE_SSL */
	new_close(Client->read);
	Client->read = Client->write;
	Client->flags &= ~DCC_WAIT;
	Client->flags |= DCC_ACTIVE;
	say("DCC: %s connection to %s[%s] established.",
	    dcc_types[Client->flags & DCC_TYPES],
	    Client->user, dcc_sockname(&remaddr, sra));
	/* XXX: ninja_host != IPv6
	 * 
	say("DCC: chat connection to %s[%s:%d] established.", Client->user,
		 ninja_host(remaddr.sin_addr), ntohs(remaddr.sin_port));
	 */
	add_tab_key(0, "msg =", Client->user);
	Client->starttime = time(NULL);
	goto out;
     }
   s = Client->buffer;
   bufptr = tmp;
   if (s && *s)
     {
	len = my_strlen(s);
	my_strncpy(tmp, s, len);
	bufptr += len;
     }
   else
     len = 0;
   old_timeout = dgets_timeout(1);
#ifdef HAVE_SSL
   bytesread = dgets(bufptr, (int)((BIG_BUFFER_SIZE/2) - len), Client->read, (u_char *) 0, Client->ssl);
#else
   bytesread = dgets(bufptr, (int)((BIG_BUFFER_SIZE/2) - len), Client->read, (u_char *) 0, 0);
#endif
   (void) dgets_timeout(old_timeout);
   switch ((int)bytesread)
     {
      case -1:
	add_to_dcc_buffer(Client, bufptr);
	if (Client->buffer && (my_strlen(Client->buffer) > BIG_BUFFER_SIZE/2))
	  {
	     new_free(&Client->buffer);
	     yell("DCC: dropped long %s message from %s",
		  dcc_types[Client->flags & DCC_TYPES],
		  Client->user);
	  }
	break;
      case 0:
	yell("DCC: %s connection to %s lost: %s", 
	     dcc_types[Client->flags & DCC_TYPES],
	     Client->user, dgets_errno == -1 ? "Remote end closed connection" : strerror(dgets_errno));
	new_close(Client->read);
	Client->read = Client->write = -1;
	Client->flags |= DCC_DELETE;
	break;
      default:
	new_free(&Client->buffer);
	len = my_strlen(tmp);
	if (len > BIG_BUFFER_SIZE/2)
	  len = BIG_BUFFER_SIZE/2;
	Client->bytes_read += len;
	*tmpuser = '=';
	strmcpy(tmpuser+1, Client->user, IRCD_BUFFER_SIZE-2);
	s = do_ctcp(tmpuser, nickname, tmp);
	s[my_strlen(s) - 1] = '\0';	/* remove newline */
	if (s && *s)
	  {
	     s[BIG_BUFFER_SIZE/2-1] = '\0';	/* XXX XXX: stop dcc long messages, stupid but "safe"? */
	     if (do_hook(DCC_CHAT_LIST, "%s %s", Client->user, s))
	       {
		  if (awayfile)
		    add_to_awaylog("=%s= %s", Client->user, s);
		  put_it("=%s= %s", Client->user, s);
	       }
	     add_tab_key(0, "msg =", Client->user);
	     if (beep_on_level & LOG_DCC)
	       {
		  if (away_set)
		    beep_em(get_int_var(BEEP_WHEN_AWAY_VAR));
		  else
		    beep_em(1);
	       }
	  }
     }
out:
   restore_message_from();
}

static	void
process_incoming_listen(Client)
	DCC_list	*Client;
{
   SOCKADDR_STORAGE	remaddr;
   DCC_list *NewClient;
   u_char host[NI_MAXHOST], FdName[10], *Name;
   int	sra;
   int	new_socket, err;

   sra = sizeof remaddr;
   new_socket = accept(Client->read, (struct sockaddr *) &remaddr, &sra);
   err = getnameinfo((struct sockaddr *) &remaddr, sra, CP(host), NI_MAXHOST, 0, 0, 0);
   if (err != 0) 
     {
	my_strncpy(host, "[unknown]", sizeof(host) - 1);
	yell("process_incoming_listen: getnameinfo failed?");
     }
   Name = host;
   /* XXX: ninja_host not ready:
    * Name = ninja_host(remaddr.sin_addr); */
   snprintf(CP(FdName), sizeof(FdName)-1, "%d", new_socket); /* safe */
   FdName[sizeof(FdName)-1] = '\0';
   NewClient = dcc_searchlist(Name, FdName, DCC_RAW, 1, (u_char *) 0, 0);
   NewClient->starttime = time((time_t *) 0);
   NewClient->read = NewClient->write = new_socket;
   NewClient->flags |= DCC_ACTIVE;
   NewClient->bytes_read = NewClient->bytes_sent = 0L;
   malloc_strcpy(&NewClient->remname, Name);
   if (SS_FAMILY(&remaddr) == PF_INET)
     {
	struct sockaddr_in *in = (struct sockaddr_in *) &remaddr;
	NewClient->remport = in->sin_port;
     }
#ifdef INET6
   else 
     if (SS_FAMILY(&remaddr) == PF_INET6)
       {
	  struct sockaddr_in6 *in = (struct sockaddr_in6 *) &remaddr;
	  NewClient->remport = in->sin6_port;
       }
#endif
   save_message_from();
   message_from(NewClient->user, LOG_DCC);
   if (do_hook(DCC_RAW_LIST, "%s %s N %d", NewClient->user,
	       NewClient->description,
	       Client->write))
     say("DCC: RAW connection to %s on #%s via %d established.",
	 NewClient->description,
	 NewClient->user,
	 Client->write);
   restore_message_from();
}

static	void
process_incoming_raw(Client)
	DCC_list	*Client;
{
   u_char	tmp[BIG_BUFFER_SIZE+1];
   u_char	*s, *bufptr;
   long	bytesread;
   int     old_timeout;
   size_t	len;
   
   save_message_from();
   message_from(Client->user, LOG_DCC);
   
   s = Client->buffer;
   bufptr = tmp;
   if (s && *s)
     {
	len = my_strlen(s);
	my_strncpy(tmp, s, len);
	bufptr += len;
     }
   else
     len = 0;
   old_timeout = dgets_timeout(1);
   switch( (int)(bytesread = dgets(bufptr, (int)((BIG_BUFFER_SIZE/2) - len), Client->read, (u_char *) 0, 0)) )
     {
      case -1:
	add_to_dcc_buffer(Client, bufptr);
	if (Client->buffer && (my_strlen(Client->buffer) > BIG_BUFFER_SIZE/2))
	  {
	     new_free(&Client->buffer);
	     yell("DCC: dropping long RAW message from %s", Client->user);
	  }
	break;
      case 0:
	if (do_hook(DCC_RAW_LIST, "%s %s C",
		    Client->user, Client->description))
	  yell("DCC: RAW connection to %s on %s lost.",
		    Client->user, Client->description);
	new_close(Client->read);
	Client->read = Client->write = -1;
	Client->flags |= DCC_DELETE;
	(void) dgets_timeout(old_timeout);
	break;
      default:
	new_free(&Client->buffer);
	len = my_strlen(tmp);
	if (len > BIG_BUFFER_SIZE / 2)
	  len = BIG_BUFFER_SIZE / 2;
	tmp[len - 1] = '\0';
	Client->bytes_read += len;
	if (do_hook(DCC_RAW_LIST, "%s %s D %s",
		    Client->user, Client->description, tmp))
	  say("DCC: RAW data on %s from %s: %s",
		   Client->user, Client->description, tmp);
	(void) dgets_timeout(old_timeout);
     }
   restore_message_from();
}

static	void
process_outgoing_file(Client)
	DCC_list	*Client;
{
   SOCKADDR_STORAGE	remaddr;
   int	sra;
   u_char	tmp[8192+1];
   u_32int	bytesrecvd;
   int	bytesread;
   int	BlockSize;
   
   save_message_from();
   message_from(Client->user, LOG_DCC);
   if (Client->flags & DCC_WAIT)
     {
	sra = sizeof remaddr;
	Client->write = accept(Client->read, (struct sockaddr *) &remaddr, &sra);
	new_close(Client->read);
	Client->read = Client->write;
	Client->flags &= ~DCC_WAIT;
	Client->flags |= DCC_ACTIVE;
	/* this will break resuming
	 *
	Client->bytes_sent = 0L;
	 */
	Client->starttime = time(NULL);
	if (Client->bytes_sent)
	  say("DCC: SEND connection to %s[%s] established, resuming at %s.", Client->user,
	      dcc_sockname(&remaddr, sra), ninja_size(Client->bytes_sent));
	else
	  say("DCC: SEND connection to %s[%s] established.", Client->user,
	      dcc_sockname(&remaddr, sra));
	dcc_send_count++;
	/* open file file!!! */
	if ((Client->file = open(Client->description, O_RDONLY)) == -1)
	  {
	     yell("DCC: Unable to open %s: %s", Client->description, errno ? strerror(errno) : "Unknown error");
	     close(Client->read);
	     Client->read = Client->write = (-1);
	     Client->flags |= DCC_DELETE;
	     return;
	  }
	/* if we're resuming seek to the resume offset.. */
	if (Client->bytes_sent)
	  {
	     if (lseek(Client->file, Client->bytes_sent, SEEK_SET) == -1)
	       {
		  yell("DCC: Unable to seek to %lu in %s: %s", Client->bytes_sent, Client->file, errno ? strerror(errno) : "Unknown error");
		  close(Client->read);
		  Client->read = Client->write = (-1);
		  Client->flags |= DCC_DELETE;
		  return;
	       }
	  }
     }
   else 
     { 
	if ((bytesread = recv(Client->read, (char *) &bytesrecvd, sizeof(u_32int), 0)) < sizeof(u_32int))
	  {
#ifdef _Windows
	     int	recv_error;
	     
	     recv_error = WSAGetLastError();
	     if (bytesread == -1 &&
		 recv_error == WSAEWOULDBLOCK ||
		 recv_error == WSAEINTR)
	       goto out;
#endif /* _Windows */
	     
	     yell("DCC: SEND: of %s to %s lost: %s", strip_path(Client->description), Client->user, strerror(errno));
	     new_close(Client->read);
	     Client->read = Client->write = (-1);
	     Client->flags |= DCC_DELETE;
	     new_close(Client->file);
	     goto out;
	  }
	else
	  if (ntohl(bytesrecvd) != Client->bytes_sent)
	    goto out;
     }
   BlockSize = dcc_sanitize_blocksize(BlockSize, sizeof(tmp));
   bytesread = read(Client->file, tmp, sizeof(tmp));
   if (bytesread > 0)
     {
	send(Client->write, CP(tmp), (size_t)bytesread, 0);
	Client->bytes_sent += bytesread;
     }
   else if (bytesread < 0)
     {
	yell("DCC: read() error from file: %s", strerror(errno));
        Client->flags |= DCC_DELETE;
     }
   else
     {
	/*
	 * We do this here because lame Ultrix doesn't let us
	 * call put_it() with a float.  Perhaps put_it() should
	 * be fixed properly, and this kludge removed ..
	 * sometime....  -phone jan, 1993.
	 */
	
	u_char	lame_ultrix[10];	/* should be plenty */
	time_t	xtime = time(NULL) - Client->starttime;
	double	sent = (double)Client->bytes_sent;
	/* ninja extensions */
	u_char	rate_unit[2] = "\0\0";

	/* resumed ? */
	sent -= (double)Client->resume_offset;
	if (sent <= 0)
	  sent = 1;
	/* bytes -> bytes/sec */
	if (xtime <= 0)
	  xtime = 1;
	sent /= (double)xtime;
	/* find the rate unit and change bytes/sec -> unit/sec */
	if (sent > 1048756)
	  {
	     sent /= 1048756.0;
	     rate_unit[0] = 'M';
	  }
	else if (sent > 1024)
	  {
	     sent /= 1024.0;
	     rate_unit[0] = 'k';
	  }
	
	snprintf(CP(lame_ultrix), sizeof(lame_ultrix)-1, "%.3g", sent);
	lame_ultrix[sizeof(lame_ultrix)-1] = '\0';
	say("DCC: SEND of %s to %s completed in %s at %s%sB/s",
		 strip_path(Client->description), Client->user, ninja_etime(xtime), lame_ultrix, rate_unit);
	new_close(Client->read);
	Client->read = Client->write = -1;
	Client->flags |= DCC_DELETE;
	new_close(Client->file);
     }
out:
   restore_message_from();
}

static	void
process_incoming_file(Client)
	DCC_list	*Client;
{
   u_char	tmp[8192+1];
   u_32int	bytestemp;
   int	bytesread;
   int	BlockSize;
   
   BlockSize = dcc_sanitize_blocksize(BlockSize, sizeof(tmp));
   if ((bytesread = recv(Client->read, CP(tmp), BlockSize, 0)) <= 0)
     {
	/*
	 * We do this here because lame Ultrix doesn't let us
	 * call put_it() with a float.  Perhaps put_it() should
	 * be fixed properly, and this kludge removed ..
	 * sometime....  -phone jan, 1993.
	 */
	
	u_char	lame_ultrix[10];        /* should be plenty */
	time_t	xtime = time(NULL) - Client->starttime;
	double	sent = (double)Client->bytes_read;
	/* ninja extensions */
	u_char	rate_unit[2] = "\0\0";

#ifdef _Windows
	  {
	     int	recv_error;
	     recv_error = WSAGetLastError();
	     if (bytesread == -1 &&
		 recv_error == WSAEWOULDBLOCK ||
		 recv_error == WSAEINTR)
	       return;
	  }
#endif /* _Windows */

#ifdef NON_BLOCKING_CONNECTS
	/* wait, recv() may fail if we couldn't connect! and non-blocking is on */
	if (bytesread == -1)
	  {
	     yell("DCC: Unable to create connection: %s", errno ? strerror(errno) : "Unknown Host");
	     Client->flags |= DCC_DELETE;
	     return;
	  }
#endif
	
	/* resumed ? */
	sent -= (double)Client->resume_offset;
	if (sent <= 0)
	  sent = 1;
	/* bytes -> bytes/sec */
	if (xtime <= 0)
	  xtime = 1;
	sent /= (double)xtime;
	/* find rate unit and convert bytes -> unit */
	if (sent > 1048756)
	  {
	     sent /= 1048756.0;
	     rate_unit[0] = 'M';
	  }
	else if (sent > 1024)
	  {
	     sent /= 1024.0;
	     rate_unit[0] = 'k';
	  }

	snprintf(CP(lame_ultrix), sizeof(lame_ultrix)-1, "%.3g", sent);
	lame_ultrix[sizeof(lame_ultrix)-1] = '\0';
	save_message_from();
	message_from(Client->user, LOG_DCC);
	say("DCC: GET of %s from %s completed in %s at %s%sB/s",
		 strip_path(Client->description), Client->user, ninja_etime(xtime), lame_ultrix, rate_unit);
	restore_message_from();
	new_close(Client->read);
	new_close(Client->file);
	Client->read = Client->write = (-1);
	Client->flags |= DCC_DELETE;
	return;
     }
   write(Client->file, tmp, (size_t)bytesread);
   Client->bytes_read += bytesread;
   bytestemp = htonl(Client->bytes_read);
   send(Client->write, (char *)&bytestemp, sizeof(u_32int), 0);
}

/* flag == 1 means show it.  flag == 0 used by redirect */

void
dcc_message_transmit(user, text, type, flag)
	u_char	*user;
	u_char	*text;
	int	type,
		flag;
{
   DCC_list	*Client;
   u_char	tmp[BIG_BUFFER_SIZE+1];
   u_char	nickbuf[128];
   u_char	thing = '\0';
   u_char	*host = (u_char *) 0;
   crypt_key	*key;
   u_char	*line;
   int	lastlog_level;
   int	list = 0;
   size_t	len;
   
   lastlog_level = set_lastlog_msg_level(LOG_DCC);
   switch(type)
     {
      case DCC_CHAT:
	host = UP("chat");
	thing = '=';
	list = SEND_DCC_CHAT_LIST;
	break;
#ifdef HAVE_SSL
      case DCC_SCHAT:
	host = UP("schat");
	thing = '=';
	list = SEND_DCC_CHAT_LIST;
	break;
#endif
      case DCC_RAW:
	host = next_arg(text, &text);
	if (!host)
	  {
	     yell("DCC: No host specified for RAW.");
	     goto out1;
	  }
	break;
     }
   save_message_from();
   message_from(user, LOG_DCC);
   if (!(Client = dcc_searchlist(host, user, type, 0, (u_char *) 0, 0)) || !(Client->flags&DCC_ACTIVE))
     {
	yell("DCC: No active %s:%s connection for %s.", dcc_types[type], host ? host : (u_char *) "<any>", user);
	goto out;
     }
#ifdef DCC_CNCT_PEND
   /*
    * XXX - should make this buffer
    * XXX - just for dcc chat ?  maybe raw dcc too.  hmm.
    */
   if (Client->flags & DCC_CNCT_PEND)
     {
	yell("DCC: %s:%s to %s is still connecting...", dcc_types[type], host ? host : (u_char *) "<any>", user);
	goto out;
     }
#endif /* DCC_DCNT_PEND */
   strmcpy(tmp, text, BIG_BUFFER_SIZE);
   if (type == DCC_CHAT
#ifdef HAVE_SSL
       || type == DCC_SCHAT
#endif
       ) {
      nickbuf[0] = '=';
      strmcpy(nickbuf+1, user, sizeof(nickbuf) - 2);
      
      if ((key = is_crypted(nickbuf)) == 0 || (line = crypt_msg(tmp, key, 1)) == 0)
	line = tmp;
      
      add_tab_key(0, "msg =", Client->user);
   }
   else
     line = tmp;
/* #ifdef HAVE_WRITEV
     {
	struct iovec iov[2];
	
	iov[0].iov_base = CP(line);
	iov[0].iov_len = len = my_strlen(line);
	iov[1].iov_base = "\n";
	iov[1].iov_len = 1;
	len++;
	(void)writev(Client->write, iov, 2);
     }
#else
 */
   /* XXX XXX XXX THIS IS TERRIBLE! XXX XXX XXX */
#define CRYPT_BUFFER_SIZE (IRCD_BUFFER_SIZE - 50)    /* XXX XXX FROM: crypt.c XXX XXX */
   strmcat(line, "\n", (size_t)((line == tmp) ? BIG_BUFFER_SIZE : CRYPT_BUFFER_SIZE));
   len = my_strlen(line);
#ifdef HAVE_SSL
   if ((type == DCC_SCHAT) && Client->ssl)
     (void)SSL_write(Client->ssl, line, len);
   else
#endif
   (void)send(Client->write, line, len, 0);
// #endif
   Client->bytes_sent += len;
   if (flag && type != DCC_RAW) {
      if (do_hook(list, "%s %s", Client->user, text))
	put_it("=> %c%s%c %s", thing, Client->user, thing, text);
   }
out:   
   restore_message_from();
out1:   
   set_lastlog_msg_level(lastlog_level);
   return;
}

void
dcc_chat_transmit(user,	text)
	u_char	*user;
	u_char	*text;
{
   dcc_message_transmit(user, text, DCC_CHAT, 1);
}

static	void
dcc_send_raw(args)
	u_char	*args;
{
   u_char	*name;
   
   if (!(name = next_arg(args, &args)))
	{
	   int	lastlog_level;
	   
	   lastlog_level = set_lastlog_msg_level(LOG_DCC);
	   /*
	    * ninja handles this a little differently
	    *
	   say("No name specified for DCC RAW");
	    */
	   usage("dcc raw", "<name> <host> <message>");
	   (void) set_lastlog_msg_level(lastlog_level);
	   return;
	}
   dcc_message_transmit(name, args, DCC_RAW, 1);
}

/*
 * dcc_time: Given a time value, it returns a string that is in the
 * format of "hours:minutes:seconds month day year" .  Used by 
 * dcc_list() to show the start time.
 * 
 * ----------------------- *
 * NINJA DOES NOT USE THIS *
 * ----------------------- *
 *
static	u_char	*
dcc_time(the_time)
	time_t	the_time;
{
	struct	tm	*btime;
	u_char	*buf;
	static	char	*months[] = 
	{
		"Jan", "Feb", "Mar", "Apr", "May", "Jun",
		"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
	};

	btime = localtime(&the_time);
	buf = (u_char *) malloc(22);
	if (snprintf(CP(buf), 22, "%-2.2d:%-2.2d:%-2.2d %s %-2.2d %d",
			btime->tm_hour, btime->tm_min, btime->tm_sec,
			months[btime->tm_mon], btime->tm_mday,
			btime->tm_year + 1900))
		return buf;
	else
		return empty_string;
}

#define DCC_FORM "%-7.7s %-9.9s %-10.10s %-20.20s %-8.8s %-8.8s %s"
#define DCC_FORM_HOOK "%s %s %s %s %s %s %s"
#define DCC_FORM_HEADER \
	"Type", "Nick", "Status", "Start time", "Sent", "Read", "Arguments"

void
dcc_list(args)
	u_char	*args;
{
	DCC_list	*Client;
	unsigned	flags;
	int	lastlog_level;

	lastlog_level = set_lastlog_msg_level(LOG_DCC);
	if (do_hook(DCC_LIST_LIST, DCC_FORM_HOOK, DCC_FORM_HEADER))
		put_it(DCC_FORM, DCC_FORM_HEADER);
	for (Client = ClientList ; Client != NULL ; Client = Client->next)
	{
		u_char	sent[9],
			rd[9];
		u_char	*timestr;

		snprintf(CP(sent), sizeof sent, "%ld", (long)Client->bytes_sent);
		snprintf(CP(rd), sizeof rd, "%ld", (long)Client->bytes_read);
		timestr = (Client->starttime) ? dcc_time(Client->starttime) : empty_string;
		flags = Client->flags;

#ifdef DCC_DCNT_PEND
#define DCC_CONT_PEND_FORM	flags & DCC_CNCT_PEND ?	"Connecting" :
#else / * DCC_DCNT_PEND * /
#define DCC_CONT_PEND_FORM	/ * nothing * /
#endif / * DCC_DCNT_PEND * /

#define DCC_FORM_BODY		dcc_types[flags & DCC_TYPES],		\
				Client->user,				\
				flags & DCC_OFFER ? "Offered" :		\
				flags & DCC_DELETE ? "Closed" :		\
				flags & DCC_ACTIVE ? "Active" :		\
				flags & DCC_WAIT ? "Waiting" :		\
				DCC_CONT_PEND_FORM			\
				"Unknown",				\
				timestr,				\
				sent,					\
				rd,					\
				Client->description

		if (do_hook(DCC_LIST_LIST, DCC_FORM_HOOK, DCC_FORM_BODY))
			put_it(DCC_FORM, DCC_FORM_BODY);
		if (*timestr)
			new_free(&timestr);
	}
	(void) set_lastlog_msg_level(lastlog_level);
}
 */

void
dcc_list(args)
	u_char	*args;
{
   DCC_list	*Client;
   int	lastlog_level;
   /* ninja formats */
   u_char beg_fmt[128];
   u_char file_fmt[] = "Up %s, %s%% at %s %sB/s";	/* send/get format */
   u_char old_fmt[] = "Up %s, %s sent, %s read.";   	/* old format (chats, etc) */
   int count = 1, arglen = MAX(10, current_screen->co - 70);
   
   /* beginning format for all types
    * 
    * this changes along with the screen width..
    */
   snprintf(beg_fmt, sizeof(beg_fmt)-1, "%%-2.2s %%-10.10s %%-9.9s %%-%d.%ds %%s", arglen, arglen);
   beg_fmt[sizeof(beg_fmt)-1] = '\0';
   
#define DCC_FORM_HOOK		"%s %s %s %s %s"
#define DCC_FORM_HEADER		"##", "Type", "With", "Args", "Status"
#define DCC_FORM_BODY 		cntstr,        							\
   				dcc_types[Client->flags & DCC_TYPES], 				\
     				Client->user, 							\
     				strip_path(Client->description), 				\
   				status

   lastlog_level = set_lastlog_msg_level(LOG_DCC);
   if (do_hook(DCC_LIST_LIST, DCC_FORM_HOOK, DCC_FORM_HEADER))
     put_raw(beg_fmt, DCC_FORM_HEADER);
   for (Client = ClientList ; Client != NULL ; Client = Client->next, count++)
     {
	u_char status[512], cntstr[16];
	
	/* make the count string */
	snprintf(cntstr, sizeof(cntstr)-1, "%02d", count);
	cntstr[sizeof(cntstr)-1] = '\0';

	/* build the status string */
	if (Client->flags & DCC_WAIT)
	  my_strmcpy(status, "Waiting for connection...", sizeof(status));
	else if (Client->flags & DCC_OFFER)
	  my_strmcpy(status, "Offered...", sizeof(status));
	else if (Client->flags & DCC_DELETE)
	  my_strmcpy(status, "Closed?!", sizeof(status));
#ifdef DCC_DCNT_PEND
	else if (Client->flags & DCC_CNCT_PEND)
	  my_strmcpy(status, "Connecting...", sizeof(status));
#endif
	 /* for active DCCs we must fill in the status var with dynamic stuff */
	else if (Client->flags & DCC_ACTIVE)
	  {
	     time_t eltime = (time(NULL) - Client->starttime);
	     
	     /* file transfers.. */
	     if ((Client->flags & DCC_TYPES) == DCC_FILEREAD || (Client->flags & DCC_TYPES) == DCC_FILEOFFER)
	       {
		  char perc[16], ratestr[16], rate_unit[2] = "\0\0";
		  double ratio, rate, bytes;
		  
		  if ((Client->flags & DCC_TYPES) == DCC_FILEOFFER)
		    bytes = (double)Client->bytes_sent;
		  else
		    bytes = (double)Client->bytes_read;
		  
		  /* calculate % done */
		  ratio = 100 * ((double)bytes / (double)Client->filesize);
		  
		  /* calculate the speed */
		  rate = (double)(bytes - Client->resume_offset);
		  rate /= (double)(eltime > 0 ? eltime : 1);
		  
		  /* convert bytes/sec -> units/sec and set rate_unit */
		  if (rate > 1048576)
		    {
		       rate /= 1048576.0;
		       rate_unit[0] = 'M';
		    }
		  else if (rate > 1024)
		    {
		       rate /= 1024.0;
		       rate_unit[0] = 'k';
		    }
		  
		  /* convert #'s to strings */
		  snprintf(perc, sizeof(perc)-1, "%.3g", ratio);
		  perc[sizeof(perc)-1] = '\0';
		  snprintf(ratestr, sizeof(ratestr)-1, "%.3g", rate);
		  ratestr[sizeof(ratestr)-1] = '\0';
		  
		  /* show the send or get line */
		  snprintf(status, sizeof(status)-1, file_fmt, ninja_etime(eltime), perc, ratestr, rate_unit);
	       }
	     /* some other active thing (chat/raw/etc) */
	     else
	       {
		  u_char *this_sucks = NULL;
		  
		  malloc_strcpy(&this_sucks, ninja_size(Client->bytes_sent));
		  snprintf(status, sizeof(status)-1, old_fmt, ninja_etime(eltime), this_sucks, ninja_size(Client->bytes_read));
		  new_free(&this_sucks);
	       }
	     status[sizeof(status)-1] = '\0';
	  }
	else
	  my_strmcpy(status, "Unknown", sizeof(status));
	
	/* try the hook, and if it did not print, we will */
	if (do_hook(DCC_LIST_LIST, DCC_FORM_HOOK, DCC_FORM_BODY))
	  put_raw(beg_fmt, DCC_FORM_BODY);
     }
   (void) set_lastlog_msg_level(lastlog_level);
}


#undef DCC_FORM
#undef DCC_FORM_HOOK
#undef DCC_FORM_HEADER
#undef DCC_CONT_PEND_FORM
#undef DCC_FORM_BODY

static	void
dcc_close(args)
	u_char	*args;
{
   DCC_list	*Client;
   /*
   unsigned	flags;
    */
   u_char	*Type;
   u_char	*user;
   u_char	*description;
   int	CType;
   u_char	*cmd = NULL;
   int	lastlog_level;
   /* ninja extension */
   int	number;

   lastlog_level = set_lastlog_msg_level(LOG_DCC);
   if (!(Type = next_arg(args, &args)))
     {
	/* say("you must specify a type and nick for DCC CLOSE"); */
	usage("dcc close", "*, <#>, or <type> <nick> [<filename>]");
	goto out;
     }
   if (*Type == '*')
     {
	dcc_closeall();
	goto out;
     }
   if (isdigit(*Type))
     {
	number = my_atoi(Type);
	if (number > 0 /* && number <= count_dccs() */ )
	  dcc_closebynumber(number);
	goto out;
     }
   if (!(user=next_arg(args, &args)))
     {
	usage("dcc close", "*, <#>, or <type> <nick> [<filename>]");
	goto out;
     }
   description = next_arg(args, &args);
   malloc_strcpy(&cmd, Type);
   upper(cmd);
   for (CType = 0; dcc_types[CType] != NULL; CType++)
     if (!my_strcmp(cmd, dcc_types[CType]))
       break;
   new_free(&cmd);
   if (!dcc_types[CType])
     {
	yell("DCC: Unknown type: %s", Type);
	goto out;
     }
   
   if (0 == (Client = dcc_searchlist(description, user, CType, 0, description, 0)))
     {
	yell("DCC: No %s:%s to %s found.", Type,
		 description ? description : (u_char *) "<any>", user);
	goto out;
     }
   
   dcc_closebyptr(Client);
   /*
    * this should be dcc_closebyptr
    * 
	flags = Client->flags;
	if (flags & DCC_DELETE)
	  goto out;
	if ((flags & DCC_WAIT) || (flags & DCC_ACTIVE))
	  {
	     new_close(Client->read);
	     if (Client->file)
	       new_close(Client->file);
	  }
	say("DCC %s:%s to %s closed", Type,
		 description ? description : (u_char *) "<any>", user);
	dcc_erase(Client);
    */
out:
   (void) set_lastlog_msg_level(lastlog_level);
}

/* this depends on dcc_rename() setting loglevel */
static void
dcc_chat_rename(args)
	u_char	*args;
{
   DCC_list	*Client;
   u_char	*user;
   u_char	*temp;
   
   if (!(user = next_arg(args, &args)) || !(temp = next_arg(args, &args)))
     {
	/* yell("DCC: You must specify a current CHAT connection, and a new name for it."); */
	usage("dcc rename -chat", "<user> <new name>");
	return;
     }
   if (dcc_searchlist(UP("chat"), temp, DCC_CHAT, 0, (u_char *) 0, 0))
     {
	yell("DCC: You already have a CHAT connection with %s, unable to rename.", temp);
	return;
     }
   if ((Client = dcc_searchlist(UP("chat"), user, DCC_CHAT, 0, (u_char *) 0, 0)))
     {
	new_free(&(Client->user));
	malloc_strcpy(&(Client->user), temp);
	say("DCC: CHAT connection with %s renamed to %s", user, temp);
     }
   else
     yell("DCC: No CHAT connection with %s", user);
}


static	void
dcc_rename(args)
	u_char	*args;
{
   DCC_list	*Client;
   u_char	*user;
   u_char	*description;
   u_char	*newdesc;
   u_char	*temp;
   int	lastlog_level;
   
   lastlog_level = set_lastlog_msg_level(LOG_DCC);
   if ((user = next_arg(args, &args)) && my_strnicmp(user, UP("-chat"), my_strlen(user)) == 0)
     {
	dcc_chat_rename(args);
	goto out;
     }
   if (!user || !(temp = next_arg(args, &args)))
     {
	/* yell("DCC: You must specify a nick and new filename for DCC RENAME"); */
	usage("dcc rename", "<nick> [<old file name>] <new file name>");
	goto out;
     }
   if ((newdesc = next_arg(args, &args)) != NULL)
     description = temp;
   else
     {
	newdesc = temp;
	description = NULL;
     }
   if ((Client = dcc_searchlist(description, user, DCC_FILEREAD, 0, (u_char *) 0, 0)))
     {
	if (!(Client->flags & DCC_OFFER))
	  {
	     yell("DCC: Too late to rename that file");
	     goto out;
	  }
	new_free(&(Client->description));
	malloc_strcpy(&(Client->description), newdesc);
	say("DCC: File %s from %s renamed to %s",
		 description ? description : (u_char *) "<any>", user, newdesc);
     }
   else
     yell("DCC: No file %s from %s found",
	      description ? description : (u_char *) "<any>", user);
out:
   (void) set_lastlog_msg_level(lastlog_level);
}

/*
 * close_all_dcc:  We call this when we create a new process so that
 * we don't leave any fd's lying around, that won't close when we
 * want them to..
 */

void
close_all_dcc()
{
	DCC_list *Client;

	while ((Client = ClientList))
		dcc_erase(Client);
}

static	void
add_to_dcc_buffer(Client, buf)
	DCC_list	*Client;
	u_char	*buf;
{
	if (buf && *buf)
	{
		if (Client->buffer)
			dma_strcat(&Client->buffer, buf);
		else
			malloc_strcpy(&Client->buffer, buf);
	}
}

void
dcc_getbynumber(number)
   int number;
{
   int i;
   DCC_list *dcctmp;

   for (i = 1, dcctmp = ClientList; dcctmp != NULL; dcctmp = dcctmp->next, i++)
      if (i == number)
	 break;
   if (dcctmp == NULL)
     {
	yell("DCC: Session #%d does not exist!", number);
	return;
     }
   dcc_getbyptr(dcctmp);
}

void
dcc_getbyptr(Client)
   DCC_list *Client;
{
   if ((Client->flags & DCC_ACTIVE) || (Client->flags & DCC_WAIT))
     {
	say("DCC: You're already getting \"%s\" from %s.", Client->description, Client->user);
	return;
     }
   if (!(Client->flags & DCC_OFFER))
     {
	yell("I'm little a teapot! *holy shit*");
	irc_exit("I'm little a teapot! *holy shit*");
/*
 * NOT REACHED
	dcc_erase(Client);
	return;
 */
     }
   Client->flags |= DCC_TWOCLIENTS;
   if (!dcc_open(Client))
      return;
   return;
}

void
dcc_getall(user)
    u_char *user;
{
   DCC_list *Client;

   for (Client = ClientList; Client != NULL; Client = Client->next)
     if (((Client->flags & DCC_TYPES) == DCC_FILEREAD) && (Client->flags & DCC_OFFER))
     {
	if (user == NULL)
	  dcc_getbyptr(Client);
	else if (my_stricmp(user, Client->user) == 0)
	  dcc_getbyptr(Client);
     }
}

/*
 * Usage: /DCC RESUME <nick> [file]
 */
void
dcc_getfile_resume(args)
   u_char *args;
{
   u_char *user;
   u_char *filename = NULL;
   DCC_list *Client;
   struct stat sb;

   if (!(user = next_arg(args, &args)))
     {
	usage("dcc resume", "<nickname> <filename>");
	return;
     }

   if (args && *args)
     {
	filename = next_arg(args, &args);
     }

   if (!(Client = dcc_searchlist(filename, user, DCC_FILEREAD, 0, NULL, 0)))
     {
	if (filename)
	   yell("DCC: %s isn't trying to send you \"%s\".", user, filename);
	else
	   yell("DCC: %s isn't trying to send you anything.", user);
	return;
     }

   if (stat(Client->description, &sb) == -1)
     {
	u_char tb1[512];
	
	yell("DCC: You tried to resume a file that does not exist, starting from the beginning.");
	snprintf(tb1, sizeof(tb1)-1, "%s %s", user, filename ? filename : empty_string);
	tb1[sizeof(tb1)-1] = '\0';
	dcc_getfile(tb1);
	return;
     }

   if ((Client->flags & DCC_ACTIVE) || (Client->flags & DCC_WAIT))
     {
	yell("DCC: A previous GET:%s from %s exists!", filename ? filename : UP("<any>"), user);
	return;
     }
   
   Client->bytes_sent = 0L;
   Client->bytes_read = sb.st_size;
   
   say("DCC: Attempting to rseume GET of %s from %s at %lu",
       Client->description, user, sb.st_size);

   doing_privmsg = in_ctcp_flag = 0;
   send_ctcp(ctcp_type[in_ctcp_flag], user, "DCC", "RESUME %s %hd %d",
	     Client->description, Client->remport, sb.st_size);
}

/*
 * When the peer demands DCC RESUME
 * We send out a DCC ACCEPT
 */
void
dcc_getfile_resume_demanded(user, filename, port, offset)
    u_char *user, *filename, *port, *offset;
{
   DCC_list *Client;
   int old_dp, old_icf;

   if ((Client = dcc_searchlist(NULL, user, DCC_FILEOFFER, 0, filename, 0)) == NULL || !offset)
     {
	yell("DCC: Invalid resume of \"%s\" requested by %s", filename, user);
	return;
     }
   Client->bytes_sent = atoi(offset);
   Client->resume_offset = atoi(offset);
   Client->bytes_read = 0L;
   
   old_dp = doing_privmsg;
   old_icf = in_ctcp_flag;
   doing_privmsg = in_ctcp_flag = 0;
   send_ctcp(ctcp_type[in_ctcp_flag], user, "DCC", "ACCEPT %s %s %s", filename, port, offset);
   doing_privmsg = old_dp;
   in_ctcp_flag = old_icf;
}

/*
 * When we get the DCC ACCEPT
 * We start the connection
 */
void
dcc_getfile_resume_start(nick, filename, port, offset)
    u_char *nick, *filename, *port, *offset;
{
   DCC_list *Client;
   u_char *fullname = NULL;

   if (!(Client = dcc_searchlist(filename, nick, DCC_FILEREAD, 0, port, 0)))
      return;
   Client->flags |= DCC_TWOCLIENTS;
   
   /* dcc_open handles its own errors */
   if (!dcc_open(Client))
      return;
   
   /* if we have a tilde, expand the path, if it fails get out */
   if (*Client->description == '~')
     { 
	fullname = expand_twiddle(Client->description);
	if (!fullname)
	  {
	     yell("Unable to expand %s", Client->description);
	     close(Client->read);
	     Client->read = -1;
	     Client->flags |= DCC_DELETE;
	     return;
	  }
     }
   else
     malloc_strcpy(&fullname, Client->description);
   
   Client->bytes_read = atoi(offset);
   Client->resume_offset = atoi(offset);
   Client->bytes_sent = 0L;
   if (!(Client->file = open(fullname ? fullname : Client->description, O_WRONLY | O_APPEND, 0644)))
     {
	yell("Unable to open %s: %s", Client->description, errno ? strerror(errno) : "<No Error>");
	close(Client->read);
	Client->read = -1;
	Client->flags |= DCC_DELETE;
     }
   if (fullname)
     new_free(&fullname);
}

/* this helps the code below... */
static u_char *gbl_dcc_sf_name = UNULL;
int
dcc_sf_selectent(entry)
   SCANDIR_A3ATYPE entry;
{
   /* no dir entries beginning with dots. 
    *
    * and must match static global gbl_dcc_sf_name
    * 
    */
   return (*(entry->d_name) != '.'
	   && (!gbl_dcc_sf_name
	       || (gbl_dcc_sf_name 
		   && cs_match(gbl_dcc_sf_name, UP(entry->d_name)))));
}

/*
 * dcc send argument processor.
 * this function takes a comma delimited list of nicknames any number of file masks
 * and scans for the file mask.  then sends each of the nicknames a SEND request for each of the files
 * it's nice to be able to specify masks, but it's not recommended to send * really.
 * it would be better to just package the stuff up and send the one file.. it's more work tho for a lazy
 * ass.
 */
void
dcc_sendfiles(args)
    u_char *args;
{
   u_char *user, *ptr, *filename = NULL, *fullname = NULL;
   u_char buf[1024], path[1024], buf2[1024];
   int numfiles = 0, n;
   off_t totsize = 0;
   struct stat stbuf;
   struct dirent **dirfiles;

#ifdef	DAEMON_UID
   if (DAEMON_UID == getuid())
     {
	yell("You are not permitted to use DCC to exchange files");
	return;
     }
#endif
   buf2[0] = '\0';
   /* check to make sure we have arguments, if not, tell the usage. */
   if ((user = next_arg(args, &args)) == NULL || !(args && *args))
     {
	usage("dcc send", "<nick 1,nick 2,..,nick n> <mask 1> [<mask 2> .. <mask n>]");
	return;
     }
   save_message_from();
   message_from(user, LOG_DCC);
   /* this is currently rather broken..
    *  numfiles = ninja_chkfiles(&args, buf, &totsize);
    */
   while ((ptr = next_arg(args, &args)) != NULL)
     {
	if (strlen(ptr) < 1)
	   continue;
	if (*ptr == '/')
	   strncpy(path, ptr, sizeof(path)-1);
	else if (*ptr == '~')
	  {
	     if ((fullname = expand_twiddle(ptr)) == NULL)
		continue;
	     strncpy(path, fullname, sizeof(path));
	     new_free(&fullname);
	  }
	else
	  {
	     if (getcwd(path, sizeof(path)-1) == NULL)
	       {
		  yell("DCC: Unable to get cwd: %s", strerror(errno));
		  restore_message_from();
		  return;
	       }
	     strmcat(path, "/", sizeof(path)-1);
	     strmcat(path, ptr, sizeof(path)-1);
	  }
	malloc_strcpy(&fullname, path);
	if ((filename = rindex(path, '/')) != NULL)
	  *filename++ = '\0';
	memset(&stbuf, 0, sizeof(stbuf));
	if (stat(fullname, &stbuf) != -1)	/* we found it already */
	  {
	     if (stbuf.st_mode & S_IFDIR)
	       {
		  say("DCC: To send a directory, use %s/*", fullname);
		  new_free(&fullname);
		  continue;
	       }
	     if (dcc_filesend2(user, fullname) > 0)
	       {
		  numfiles++;
		  totsize += stbuf.st_size;
		  strmcat(buf2, strip_path(fullname), sizeof(buf2) - 1);
	       }
	     else
	       {
		  /* yell("DCC: Unable to send \"%s\".", fullname); */
		  new_free(&fullname);
		  continue;
	       }
	  }
	else if (my_index(filename, '*')	/* not found.. check for wildcards */
		 || my_index(filename, '?'))
	  {
	     malloc_strcpy(&gbl_dcc_sf_name, filename);
	     n = scandir(path, &dirfiles,
			 (int (*)(SCANDIR_A3ATYPE)) dcc_sf_selectent,
			 (int (*)(const void *, const void *))compar);
	     new_free(&gbl_dcc_sf_name);
	     if (n < 0)
	       {
		  yell("DCC: scandir() ran out of memory!");
		  new_free(&fullname);
		  continue;
	       }
	     else if (n == 0)	/* no files in the directory!! */
	       {
		  yell("DCC: No files found matching \"%s\".", filename);
		  new_free(&fullname);
		  restore_message_from();
		  continue;
	       }
	     else
	       {
		  while (n--)
		    {
		       /*
			* this is already handled by our selectent.. 
			* 
		       if (wild_match(filename, dirfiles[n]->d_name))
			 {
			*/
			    snprintf(buf, sizeof(buf), "%s/%s", path, dirfiles[n]->d_name);
			    if (dcc_filesend2(user, buf) > 0)
			      {
				 numfiles++;
				 stat(buf, &stbuf);
				 totsize += stbuf.st_size;
				 if (buf2[0] != '\0')
				   strmcat(buf2, " ", sizeof(buf2) - 1);
				 strmcat(buf2, dirfiles[n]->d_name, sizeof(buf2) - 1);
			      }
			    else
			      {
				 /* yell("DCC: Unable to send \"%s\".", buf); */
				 new_free(&fullname);
				 continue;
			      }
		       /*
			 }
			*/
		    }
	       }
	  }
	else	/* not found and no wildcards */
	  {
	     yell("DCC: Unable to send file \"%s\": %s", filename, strerror(errno));
	     new_free(&fullname);
	     continue;
	  }
     }
   new_free(&fullname);
   if (numfiles)
     say("DCC: Sending %s %d file%s (%s) [%s]", user, numfiles, numfiles == 1 ? "" : "s", buf2,
	      ninja_size(totsize));
   /* else
    *  yell("No files matching \"%s\" were found.", filename);
    */
   restore_message_from();
}

int
dcc_filesend2(u_char *user, u_char *filename)
{
   DCC_list *Client;
   struct stat stat_buf;
   int /* old_display, */ total = 0;
   u_char *ptr, *ptr2 = NULL, *free_ptr;
   u_char *errstr1 = UP("DCC: Unable to send file \"%s\": %s");
   u_char *errstr2 = UP("DCC: Unable to send file \"%s\" to \"%s\": %s");

   if (0 != access(filename, R_OK))
     {
	yell(errstr1, strip_path(filename), strerror(errno));
	return -1;
     }
   stat(filename, &stat_buf);
   if (stat_buf.st_mode & S_IFDIR)
     {
	yell(errstr1, strip_path(filename), "no directories allowed.");
	return -1;
     }
   /* make a copy becuz strsep modifies the string */
   malloc_strcpy(&ptr2, user);
   free_ptr = ptr2;
   while ((ptr = my_strsep(&ptr2, ",")))
     {
	Client = dcc_searchlist(filename, ptr, DCC_FILEOFFER, 1, filename, stat_buf.st_size);
	if ((Client->flags & DCC_ACTIVE) || (Client->flags & DCC_WAIT))
	  {
	     yell(errstr2, strip_path(filename), ptr, "you are already sending it.");
	     continue;
	  }
	Client->flags |= DCC_TWOCLIENTS;
	/* this is a nasty hack
	old_display = window_display;
	window_display = 0;
	 */
	dcc_open(Client);
	/*
	window_display = old_display;
	/ * end nasty hack */
	total++;
     }
   new_free(&free_ptr);
   return total;
}

void
dcc_closebynumber(number)
   int number;
{
   DCC_list *Client;
   int count;

   for (count = 1, Client = ClientList; Client != NULL; Client = Client->next, count++)
     {
	if (count == number)
	  {
	     dcc_closebyptr(Client);
	     return;
	  }
     }
   if (Client == NULL)
     {
	yell("DCC: Session #%d doesn't exist!", number);
	return;
     }
}

void
dcc_closebyptr(Client)
   DCC_list *Client;
{
   char *type = dcc_types[Client->flags & DCC_TYPES];

   save_message_from();
   message_from(Client->user, LOG_DCC);
   if (Client->flags & DCC_DELETE)
     {
	yell("DCC: %s session (%s) with %s is already marked for deletion.", type, strip_path(Client->description),
	    Client->user);
	restore_message_from();
	return;
     }
   say("DCC: %s session (%s) with %s closed.", type, strip_path(Client->description), Client->user);
   dcc_erase(Client);
   restore_message_from();
}

void
dcc_closeall(void)
{
   DCC_list *Client;

   for (Client = ClientList; Client != NULL; Client = Client->next)
      dcc_closebyptr(Client);
}

static int
dcc_sanitize_blocksize(now, max)
   int now, max;
{
#define DCC_MIN_BLOCKSIZE	512
   int BlockSize = get_int_var(DCC_BLOCK_SIZE_VAR);
   
   if (BlockSize > max)
     {
	yell("DCC: block size too high, setting to %d", max);
	BlockSize = max;
     }
   if (BlockSize < DCC_MIN_BLOCKSIZE)
     {
	yell("DCC: block size too small, setting to %d", DCC_MIN_BLOCKSIZE);
	BlockSize = DCC_MIN_BLOCKSIZE;
     }
   return BlockSize;
}

#ifdef HAVE_SSL
static void
dcc_schat(args)
	u_char	*args;
{
   u_char	*user;
   DCC_list	*Client;
   
   if ((user = next_arg(args, &args)) == NULL)
     {
	usage("dcc schat", "<nickname>");
	return;
     }
   Client = dcc_searchlist(UP("schat"), user, DCC_SCHAT, 1, (u_char *) 0, 0);
   if ((Client->flags&DCC_ACTIVE) || (Client->flags&DCC_WAIT))
     {
	yell("DCC: A previous SCHAT to %s exists.", user);
	return;
     }
   Client->flags |= DCC_TWOCLIENTS;
   dcc_open(Client);
}

static int
ninja_ssl_dcc_connect(cli)
   DCC_list *cli;
{
   if (!(cli->ctx = SSL_CTX_new(SSLv23_client_method())))
     {
	ninja_ssl_show_errors();
	put_error("DCC: SSL: Unable to create client context");
	return -1;
     }
   SSL_CTX_set_cipher_list(cli->ctx, "ADH:@STRENGTH");
   if (!(cli->ssl = SSL_new(cli->ctx)))
     {
	ninja_ssl_show_errors();
	put_error("DCC: SSL: Unable to create client connection");
	return -1;
     }
   SSL_set_fd(cli->ssl, cli->write);
   return SSL_connect(cli->ssl);
}

static int
ninja_ssl_dcc_accept(cli)
   DCC_list *cli;
{
   if (!(cli->ctx = SSL_CTX_new(SSLv23_server_method())))
     {
	ninja_ssl_show_errors();
	put_error("DCC: SSL: Unable to create server context");
	return -1;
     }
   SSL_CTX_set_cipher_list(cli->ctx, "ADH:@STRENGTH");
   if (!(cli->ssl = SSL_new(cli->ctx)))
     {
	ninja_ssl_show_errors();
	put_error("DCC: SSL: Unable to create server connection");
	return -1;
     }
   SSL_set_fd(cli->ssl, cli->write);
   return SSL_accept(cli->ssl);
}
#endif
