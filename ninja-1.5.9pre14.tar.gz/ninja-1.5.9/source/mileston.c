/*
 * milestone.c -- the release date/time
 * This file is auto-magically created.   Changes will be nuked.
 */

char ninja_release[] = "2003-04-23 00:36";
unsigned long ninja_internal = 20030423;

