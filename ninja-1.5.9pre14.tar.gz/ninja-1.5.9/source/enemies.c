/*
 * enemies.c: Ninja IRC enemy list implementation
 * 
 * written by Joshua J. Drake and Kraig Amador
 */

#include "irc.h"
#include "enemies.h"

#include "server.h"
#include "channels.h"
#include "dma.h"
#include "screen.h"
#include "vars.h"
#include "ircaux.h"
#include "output.h"
#include "ignore.h"
#include "whois.h"

#include "ninja.h"


/* whether or not channel names will match '*' */
#define MUST_BE_EXACT 1


/* local command translations.. */
static	void	ecmd_add(u_char *);
/* add_host declared in enemies.h */

static	void	ecmd_chan_flags(u_char *);
static	void	ecmd_rename(u_char *);

static	void	ecmd_list(u_char *);
static	void	ecmd_whois(u_char *);

static	void	ecmd_rm(u_char *);
static	void	ecmd_rm_chan(u_char *);
static	void	ecmd_rm_host(u_char *);

static	void	ecmd_rehash(u_char *);


/* struct/commands.. */
struct
{
   u_char *name;
   u_int uniq;
   void (*function)(u_char *);
}
enemy_commands[] =
{
     { UP("ADD"),		3, ecmd_add },
     { UP("ADDHOST"),		4, ecmd_add_host },
     { UP("CFLAGS"),		1, ecmd_chan_flags },
     { UP("LIST"),		1, ecmd_list },
     { UP("RM"),		2, ecmd_rm },
     { UP("RMCHANNEL"),       	3, ecmd_rm_chan },
     { UP("RMHOST"),		3, ecmd_rm_host },
     { UP("REHASH"),		3, ecmd_rehash },
     { UP("RENAME"),		3, ecmd_rename },
     { UP("WHOIS"),		1, ecmd_whois },
     { NULL, 0, (void (*)())NULL }
};

/* the list head */
Enemy *enemy_list = NULL;

static const u_char ecmode_str[] = EL_CMODE_STRING;

/* for adding hosts from nicks that are on irc */
extern void eaddhost_queue(WhoisStuff *, u_char *, u_char *);
extern void add_userhost_to_whois();

extern	void	timercmd(u_char *, u_char *, u_char *);

/* static stuff */
static	int	decifer_ecmode(u_char *, unsigned long *);
static	void	free_enemy(Enemy *);
static	void	free_echan(EChan *);
static	void	free_ehost(EHost *);
static	int 	enemy_cmd_chk(u_char *, u_char *, u_char *, Enemy **);
static	void	ec_sync_bans(Channel *);


/*
 * this routine dispatches the enemy commands based on
 * the first parameter to /enemy
 */
void
enemy_cmd(command, args, subargs)
   u_char *command, *args, *subargs;
{
   u_char *cmd;
   u_int i, len;
   
   if (!(cmd = next_arg(args, &args)))
     {
	usage("enemy", "<command> [<args>]");
	return;
     }
   
   len = my_strlen(cmd);
   upper(cmd);
   for (i = 0; enemy_commands[i].name != NULL; i++)
     {
	if (!my_strncmp(enemy_commands[i].name, cmd, len))
	  {
	     if (len < enemy_commands[i].uniq)
	       {
		  put_error("Enemy: Ambiguous command: %s", cmd);
		  return;
	       }
	     enemy_commands[i].function(args);
	     return;
	  }
       }
   put_error("Enemy: Unknown command: %s", cmd);
}

/*
 * add enemies to the enemy list if needed, otherwise just add the hostmask/channel
 */
void
ecmd_add(args)
   u_char *args;
{
   Enemy *e;
   EChan *c = (EChan *)NULL;
   EHost *h = (EHost *)NULL;
   u_char *nick, *mask, *channel, *flags, *reason;
   u_char *uastr = UP("<enemy> <hostmask|nick> <channel> <flags> [<reason>]");
   u_char *cmdstr = UP("enemy add");
   int link_it = 0;

   nick = next_arg(args, &args);
   if (!enemy_cmd_chk(cmdstr, uastr, nick, &e))
     return;
   
   /* check out the parameters */
   mask = next_arg(args, &args);
   channel = next_arg(args, &args);
   flags = next_arg(args, &args);
   reason = args;
   /* check for required args */
   if (!mask || !channel || !flags)
     {
	usage(cmdstr, uastr);
	return;
     }
   /* validate the channel */
   if (my_stricmp(channel, "*"))
     channel = make_chan(channel);

   /* if they are not on the list, add them */
   if (!e)
     {
	e = (Enemy *) dma_Malloc(sizeof(Enemy));
	if (!e || !dma_strcpy(&e->nick, nick))
	  {
	     free_enemy(e);
	     return;
	  }
	link_it = 1;
     }

   /* if they are an enemy on this channel already, replace it */
   if ((c = (EChan *) remove_from_list((List **) & (e->channels), channel)) != NULL)
     free_echan(c);
   /* make the channel */
   c = (EChan *) dma_Malloc(sizeof(EChan));
   if (!c || !dma_strcpy(&c->channel, channel)
       || (reason && !dma_strcpy(&c->reason, reason))
       || !decifer_ecmode(flags, &c->modes))
     {
	if (link_it)
	  free_enemy(e);
	free_echan(c);
	return;
     }
   c->date = time(NULL);
   /* add it (back) */
   add_to_list((List **)&e->channels, (List *)c);
   /* link it if its not already linked */
   if (link_it)
     add_to_list((List **)&enemy_list, (List *)e);
   
   /* add the host if its a mask and is not already present */
   if (match("*!*@*", mask)
       && !(h = get_ehost(e, mask)))
     {
	h = (EHost *) dma_Malloc(sizeof(EHost));
	if (!h || !dma_strcpy(&h->host, mask))
	  free_ehost(h);
	else
	  add_to_list((List **)&e->hosts, (List *)h);
     }
   else
     /* try userhost */;
     add_userhost_to_whois(mask, eaddhost_queue);
   
   put_info("Added %s to your enemy list on %s(%s)%s%s",
	    e->nick, channel, flags,
	    reason ? UP(", reason: ") : empty_string,
	    reason ? reason : empty_string);
   (void) save_enemies(1);
}


/*
 * add a hostmask that an enemy comes from
 */
void
ecmd_add_host(args)
   u_char *args;
{
   Enemy *e;
   EHost *h;
   u_char *nick, *mask;
   u_char *cmdstr = UP("enemy addhost");
   u_char *uastr = UP("<enemy> [<nick/hostmask>] [<nick/hostmask>] ..");
   
   nick = next_arg(args, &args);
   if (!enemy_cmd_chk(cmdstr, uastr, nick, &e))
     return;
   
   /* we need at least one */
   mask = next_arg(args, &args);
   if (!mask)
     {
	usage(cmdstr, uastr);
	return;
     }
   
   /* while we have one, add it */
   while (mask)
     {
	/* if its not a full host mask, submit it to be looked up and sent back into this function */
	if (!match("*!*@*", mask))
	  add_userhost_to_whois(mask, eaddhost_queue);
	else
	  {
	     h = get_ehost(e, mask);
	     if (!h)
	       {
		  h = (EHost *) dma_Malloc(sizeof(EHost));
		  if (!h || !dma_strcpy(&h->host, mask))
		    {
		       free_ehost(h);
		       return;
		    }
		  add_to_list((List **)&e->hosts, (List *)h);
	       }
	     put_info("hostmask %s added to enemy %s", mask, e->nick);
	  }
	mask = next_arg(args, &args);
     }
   (void) save_enemies(1);
}


/*
 * change the channels flags for an ememy
 */
void
ecmd_chan_flags(args)
   u_char *args;
{
   Enemy *e;
   EChan *c;
   u_char *nick, *channel, *flags;
   u_char *cmdstr = UP("enemy cflags");
   u_char *uastr = UP("<enemy> <channel> +/-<flags>");
   
   nick = next_arg(args, &args);
   if (!enemy_cmd_chk(cmdstr, uastr, nick, &e))
     return;
   
   /* check required params */
   channel = next_arg(args, &args);
   flags = next_arg(args, &args);
   if (!channel || !flags)
     {
	usage(cmdstr, uastr);
	return;
     }
   if (!(c = get_echan(e, channel, MUST_BE_EXACT)))
     {
	put_info("%s is not an enemy on %s", nick, channel);
	return;
     }
   if (!decifer_ecmode(flags, &c->modes))
     return;
   put_info("%s's enemy flags on %s are now: %s%s",
	    nick, channel,
	    c->modes ? "+" : "<empty>",
	    recreate_ecmode(c));
   (void) save_enemies(1);
}

   


/*
 * show the enemy list.. (/enemy list)
 */
void
ecmd_list(args)
   u_char *args;
{
   Enemy *e = enemy_list;
   EChan *c;
   int count = 0, first;
   u_char fmt[128];
   u_char tb[1024];

   if (!e)
     {
	put_info("Your enemy list is empty.");
	return;
     }
   my_strmcpy(fmt, "%-9.9s %s", sizeof(fmt));
   put_info(fmt, "Nick", "Channels");
   for (e = enemy_list; e; e = e->next)
     {
	first = 1;
	for (c = e->channels; c; c = c->next)
	  {
	     snprintf(tb, sizeof(tb)-1, "%s(%s%s, %s): %s",
		      c->channel, 
		      c->modes ? UP("+") : empty_string,
		      recreate_ecmode(c),
		      ninja_strftime(&c->date, "%Y-%m-%d"),
		      c->reason);
	     tb[sizeof(tb)-1] = '\0';
	     
	     if (first)
	       {
		  first = 0;
		  put_info(fmt, e->nick, tb);
	       }
	     else
	       put_info(fmt, empty_string, tb);
	  }
	count++;
     }
   put_info("End of enemy list, %d counted.", count);
}



/*
 * clear and reload the enemy list...
 * for those manual edit people..
 */
static	void
ecmd_rehash(args)
   u_char *args;
{
   Enemy *e, *n;
   
   /* clear the list.. */
   for (e = enemy_list; e; e = n)
     {
	n = e->next;
	free_enemy(e);
     }
   enemy_list = (Enemy *)NULL;
   
   /* reload it! */
   put_info("Enemy list rehashed, loaded %d enemies.", load_enemies(1));
}



/*
 * remove a user from the enemy list
 */
void
ecmd_rm(args)
   u_char *args;
{
   u_char *nick;
   Enemy *e;
   u_char *urstr = UP("<enemy>");
   u_char *cmdstr = UP("enemy rm");
   
   nick = next_arg(args, &args);
   if (!enemy_cmd_chk(cmdstr, urstr, nick, &e))
     return;
   
   /* we now have e if its ok! */
   e = (Enemy *) remove_from_list((List **) & enemy_list, e->nick);
   if (e)
     {
	free_enemy(e);
	put_info("%s is no longer your enemy.", nick);
	(void) save_enemies(1);
     }
   else
     put_error("Unable to remove \"%s\" from your enemy list.", nick);
}


/*
 * remove a channel from an enemy's channel list
 * 
 * accessed via /enemy rmchan
 */
void
ecmd_rm_chan(args)
   u_char *args;
{
   EChan *c;
   Enemy *e;
   u_char *nick = NULL, *channel = NULL;
   u_char *urstr = UP("<enemy> <channel>");
   u_char *cmdstr = UP("enemy rmchannel");
   
   nick = next_arg(args, &args);
   if (!enemy_cmd_chk(cmdstr, urstr, nick, &e))
     return;
   
   if (!(channel = next_arg(args, &args)))
     {
	usage(cmdstr, urstr);
	return;
     }
   
   /* for this we remove it regardless! */
   if ((c = (EChan *) remove_from_list((List **) & (e->channels), channel)) != NULL)
     free_echan(c);
   
   put_info("%s is no longer an enemy on \"%s\".", e->nick, channel);
   (void) save_enemies(1);
}


/*
 * remove a hostmask from an enemy's entry in the enemy list
 * 
 * first argument: enemy's nick
 * remaining arguments: hostmask or #
 */
void
ecmd_rm_host(args)
   u_char *args;
{
   EHost *h;
   Enemy *e;
   u_char *nick = NULL, *newhost = NULL;
   u_char *urstr = UP("<enemy> [<mask #>/<mask>] [<mask #>/<mask>] ..");
   u_char *cmdstr = UP("enemy rmhost");
   int shift_mod = 1;
   
   nick = next_arg(args, &args);
   if (!enemy_cmd_chk(cmdstr, urstr, nick, &e))
     return;
   
   /* if there isn't at least one nick/host show usage.. */
   newhost = next_arg(args, &args);
   if (!newhost)
     {
	usage(cmdstr, urstr);
	return;
     }
   
   /* while we have one, remove it.. */
   while (newhost)
     {
	int ti = atoi(newhost);
	
	if (ti > 0)
	  {
	     int oti = ti;
	     
	     ti -= shift_mod;
	     for (h = e->hosts; h && ti > 0;
		  h = h->next, ti--);
	     ti = oti;
	     if (h)
	       {
		  h = (EHost *) remove_from_list((List **)&e->hosts, h->host);
		  if (ti >= shift_mod)
		    shift_mod++;
	       }
	  }
	else
	  h = (EHost *) remove_from_list((List **)&e->hosts, newhost);
	
	/* if we have no host error.. else free it.. */
	if (!h)
	  {
	     if (ti > 0)
	       put_info("Unable to locate mask #%d for %s", ti, e->nick);
	     else
	       put_info("Unable to locate mask \"%s\" for %s.", newhost, nick);
	  }
	else
	  {
	     put_info("%s is no longer an enemy from \"%s\".", nick, h->host);
	     free_ehost(h);
	  }
	newhost = next_arg(args, &args);
     }
   (void) save_enemies(1);
}


/*
 * rename a user on the friend list
 */
void
ecmd_rename(args)
   u_char *args;
{
   u_char *nick, *nnick;
   Enemy *e;
   u_char *urstr = UP("<enemy> <new name>");
   u_char *cmdstr = UP("enemy rename");
   
   nick = next_arg(args, &args);
   if (!enemy_cmd_chk(cmdstr, urstr, nick, &e))
     return;
   if (!(nnick = next_arg(args, &args)) || !*nnick)
     {
	usage(cmdstr, urstr);
	return;
     }
   
   /* check for new-nick in use */
   if (get_enemy(nnick))
     {
	put_error("The new name you chose is already in use.");
	return;
     }
   
   /* we now have e and a new name if its ok! */
   dma_Free(&(e->nick));
   dma_strcpy(&(e->nick), nnick);
   put_info("%s is now known as %s.", nick, nnick);
   (void) save_enemies(1);
}


/*
 * shows all information about a friend..
 * accessed via /friend whois
 */
static	void
ecmd_whois(args)
   u_char *args;
{
   Enemy *e;
   EChan *c;
   EHost *h;
   u_char *nick = NULL;
   u_char tb[BIG_BUFFER_SIZE], tb2[BIG_BUFFER_SIZE];
   int count = 0, printed = 0;
   u_char *urstr = UP("<enemy>");
   u_char *cmdstr = UP("enemy whois");

   nick = next_arg(args, &args);
   if (!enemy_cmd_chk(cmdstr, urstr, nick, &e))
     return;
   
   /* ok, we have a valid enemy. */
   *tb = '\0';
   for (c = e->channels; c; c = c->next)
     {
	snprintf(tb2, sizeof(tb2)-1, "%s(%s%s, %s): %s",
		 c->channel, 
		 c->modes ? "+" : "<empty>",
		 recreate_ecmode(c),
		 ninja_strftime(&c->date, "%Y-%m-%d"),
		 c->reason);
	tb2[sizeof(tb2)-1] = '\0';
	if (*tb)
	  my_strmcat(tb, " ", sizeof(tb));
	my_strmcat(tb, tb2, sizeof(tb));
	count++;
     }
   if (*tb)
     {
	put_info("%s is an enemy on the following channel%s: %s", 
		 e->nick, PLURAL(count), tb);
	printed = 1;
     }
   
   /* show what hostsmasks they use */
   *tb = '\0';
   count = 0;
   for (h = e->hosts; h; h = h->next)
     {
	if (*tb)
	  my_strmcat(tb, " ", sizeof(tb));
	my_strmcat(tb, h->host, sizeof(tb));
	count++;
     }
   if (*tb)
     {
	put_info("%s is an enemy from the following hostmask%s: %s", 
		 e->nick, PLURAL(count), tb);
	printed = 1;
     }
   if (!printed)
     put_info("%s is your enemy", e->nick);
}




/*
 * this does initial checking for an enemy /command
 * .. if 0 is return, the supplied information is no good.
 * 
 * e will be set to the enemy list entry if it is found,
 * otherwise unmodified
 * 
 */
static	int
enemy_cmd_chk(cmd, args, nick, e)
   u_char *cmd;
   u_char *args;
   u_char *nick;
   Enemy **e;
{
   Enemy *tmp;
   
   if (!cmd || !*cmd) /* just in case */
     return 0;
   if (!nick || !*nick)
     {
	usage(cmd, args);
	return 0;
     }
   tmp = get_enemy(nick);
   /* if no enemy found and not adding an enemy... */
   if (!tmp 
       && my_stricmp(cmd, "enemy add") != 0)
     {
	put_error("Unable to locate \"%s\" in your enemy list.", nick);
	return 0;
     }
   *e = tmp;
   return 1;
}




/* 
 * decifer the channel mode from mode_string
 * examples: +aiouk +acn etc.
 * modifies the long integer pointed to by mode to reflect the modes
 */
int
decifer_ecmode(mode_string, mode)
   u_char *mode_string;
   unsigned long *mode;
{
   return ninja_parse_mode(mode_string, mode, ecmode_str);
}

/*
 * returns a pointer to a string with the ascii representation of the modes
 * from the channel list entries' mode element
 * takes an argument of an address of a EChan entry
 */
u_char *
recreate_ecmode(e)
   EChan *e;
{
   static u_char retbuf[32];

   (void) ninja_recreate_mode(e->modes, ecmode_str, retbuf, sizeof(retbuf));
   return retbuf;
}



/*
 * checks to see if:
 * a) enemies are on the channel who shouldn't be
 * b) permban'd enemies are not band
 * and proceeds to:
 * a) kick and/or ban them
 * b) re-set the ban
 */
void
enemy_channel_sync(Channel *chan)
{
   Nick *n;
   Enemy *e;
   EChan *c;
   EHost *h;
   
   /* no enemies or no ops? */
   if (!enemy_list
       || !(chan->status & CHAN_CHOP))
     return;
   
   /* see if anyone on the channel deserves anything */
   for (n = chan->nicks; n; n = n->next)
     {
	u_char *tb;
	
	/* they're not an enemy? */
	tb = ninja_make_nuh(n->nick, n->user, n->host);
	if (tb)
	  {
	     e = get_enemy_by_mask(tb, &h);
	     dma_Free(&tb);
	  }
	if (!e)
	  continue;
   
	/* they're not an enemy on this channel? */
	if (!(c = get_echan(e, chan->channel, !MUST_BE_EXACT)))
	  continue;

	/* auto ban them? */
	if (c->modes & EL_CMODE_AUTO_BAN)
	  {
	     if (!h || !h->host)
	       put_info("Unable to ban %s(%s) due to a missing hostmask", n->nick, e->nick);
	     else
	       send_to_server("MODE %s +b %s", chan->channel, h->host);
	  }
	
	/* auto kick them? */
	if (c->modes & EL_CMODE_AUTO_KICK)
	  send_to_server("KICK %s %s :[%s]: %s",
			 chan->channel, n->nick,
			 ninja_strftime(&c->date, "%Y-%m-%d")
			 ,
			 c->reason
			 );
     }
   /* see if any of my permbanned hostmasks are banned..
    * if so remove the bans.. 
    */
   ec_sync_bans(chan);
}

/*
 * cycle through my permban list and look for
 * ones that are not on the ban list...
 * 
 * add the ones that are not on the list...
 */
static void
ec_sync_bans(Channel *chan)
{
   Enemy *e;
   EChan *c;
   EHost *h;
   Ban *b;
   int mch, rmch, count = 0;
   char tb[BIG_BUFFER_SIZE];
   
   /* look through my permbanned host masks.. */
   for (e = enemy_list; e; e = e->next)
     {
	/* enemy on this channel? */
	if ((c = get_echan(e, chan->channel, !MUST_BE_EXACT)))
	  {
	     /* permbanned? */
	     if (c->modes & EL_CMODE_PERMBAN)
	       {
		  /* check all host masks against the ban/except/deny lists */
		  *tb = '\0';
		  for (h = e->hosts; h; h = h->next)
		    {
		       int found = 0;
		       
		       /* look for the mask on the ban list, if not found add it */
		       for (b = chan->bans; b; b = b->next)
			 {
			    mch = match(h->host, b->ban);
			    rmch = match(b->ban, h->host);
			    /* found one?  add it! */
			    if (mch || rmch)
			      {
				 found = 1;
				 break;
			      }
			 }
		       if (!found)
			 {
			    if (*tb)
			      my_strmcat(tb, " ", sizeof(tb));
			    my_strmcat(tb, h->host, sizeof(tb));
			    count++;
			    
			    /* max bans per line? */
			    if (count == 4)
			      {
				 send_to_server("MODE %s +bbbb %s", chan->channel, tb);
				 *tb = '\0';
				 count = 0;
			      }
			 }
		       
		       /* look for the mask on the exception list, if found, remove it.. */
		    }
	       }
	  }
     }
   /* if there are some left.. do the banning.. */
   if (count > 0)
     send_to_server("MODE %s +%s %s", chan->channel, strfill('b', count), tb);
}


/*
 * check to see if we should do something to this person that is joining
 * this channel...
 * 
 */
void
check_enemy_join(chan, nick, user, host)
   Channel *chan;
   u_char *nick, *user, *host;
{
   Enemy *e;
   EChan *c;
   EHost *h;
   Nick *n;
   u_char *tb;
   
   /* there was not enough information specified? */
   if (!chan || !nick || !user || !host)
     return;
   
   /* they're not on the channel? */
   if (!(n = find_nick(nick, UNULL, chan->server, chan)))
     return;
   
   /* i'm not opped? */
   if (!(chan->status & CHAN_CHOP))
     return;
   
   /* they're not an enemy? */
   tb = ninja_make_nuh(nick, user, host);
   if (tb)
     {
	e = get_enemy_by_mask(tb, &h);
	dma_Free(&tb);
     }
   if (!e)
     return;
   
   /* they're not an enemy on this channel? */
   if (!(c = get_echan(e, chan->channel, !MUST_BE_EXACT)))
     return;
   
   /* auto ban them? */
   if (c->modes & EL_CMODE_AUTO_BAN)
     {
	if (!h || !h->host)
	  put_info("Unable to ban %s(%s) due to a missing hostmask", nick, e->nick);
	else
	  send_to_server("MODE %s +b %s", chan->channel, h->host);
     }

   /* auto kick them? */
   if (c->modes & EL_CMODE_AUTO_KICK)
     send_to_server("KICK %s %s :[%s]: %s",
		    chan->channel, nick,
		    ninja_strftime(&c->date, "%Y-%m-%d")
		    ,
		    c->reason
		    );
}




/*
 * load the enemy list
 */
int
load_enemies(quiet)
   int quiet;
{
   Enemy *e = NULL;
   EChan *c;
   EHost *h;
   
   u_char file[] = NINJA_ENEMY_FILE;
   FILE *infile;
   
   u_char *ptr, *kraig;
   u_char line[1024];
   int position, count = 0, errocc = 0, linecnt = 0;

   /* open the file */
   ptr = expand_twiddle(file);
   infile = fopen(ptr, "r");
   dma_Free(&ptr);
   if (infile == (FILE *) NULL)
     {
	if (!quiet)
	  put_info("Unable to load your enemy list from \"%s\"..", file);
	return 0;
     }
   
   /* loop until we've read everything.. */
   memset(line, 0, sizeof(line));
   while (fgets(line, sizeof(line), infile))
     {
	/* line number.. regardless of comments */
	linecnt++;

	/* comments.. */
	if (*line == '#')
	  continue;
	
	/* strip cr/lf */
	if ((ptr = strchr(line, '\r')))
	  *ptr = '\0';
	if ((ptr = strchr(line, '\n')))
	  *ptr = '\0';
	
	/* empty line? */
	if (*line == '\0')
	  continue;
	
	/* allocate memory for an enemy */
	e = (Enemy *) dma_Malloc(sizeof(Enemy));
	if (!e)
	  {
	     put_error("Unable to allocate memory for enemy at %s:%d", file, linecnt);
	     break;
	  }
	
	/* reset position */
	errocc = position = 0;

	/* while we have more fields..
	 * 
	 * nick:host1:..:hostN:#chan1,mode,date,reason:..:#chanN,mode,date,reason\n
	 */
	kraig = line;
	while ((ptr = my_strsep(&kraig, ":")))
	  {
	     /* what position are we in? */
	     switch (position)
	       {
		  /* position 0: the nick */
		case 0:
		  if (!*ptr)
		    {
		       errocc = 1;
		       break;
		    }
		  dma_strcpy(&e->nick, ptr);
		  position++;
		  break;

		  /* position 1+: a host or channel */
		default:
		  /* a host? */
		  if (!is_channel(ptr)
		      && match("*!*@*", ptr))
		    {
		       /* free it we found it */
		       if ((h = (EHost *) remove_from_list((List **)&e->hosts, ptr)) != NULL)
			 free_ehost(h);
		       
		       /* add it (again?) */
		       h = (EHost *) dma_Malloc(sizeof(EHost));
		       if (!h || !dma_strcpy(&h->host, ptr))
			 {
			    put_error("Unable to allocate memory for enemy host at %s:%d (%d)", file, linecnt, position);
			    free_ehost(h);
			    errocc = quiet = 1;
			    break;
			 }
		       add_to_list((List **)&e->hosts, (List *)h);
		    }

		  /* a channel? */
		  else if ((is_channel(ptr) || *ptr == '*'))
		    {
		       u_char *copy = UNULL, *tc, *tm, *td, *tr;
		       
		       /* copy it so we can munge it up and add the channel */
		       dma_strcpy(&copy, ptr);
		       
		       /* get the channel, modes, date, and reason */
		       tc = copy;
		       if ((tm = strchr(tc, ',')))
			 *tm++ = '\0';
		       if ((td = strchr(tm, ',')))
			 *td++ = '\0';
		       if ((tr = strchr(td, ',')))
			 *tr++ = '\0';
		       
		       /* free it if we found it */
		       if ((c = (EChan *) remove_from_list((List **)&e->channels, tc)) != NULL)
			 free_echan(c);
		       
		       c = (EChan *) dma_Malloc(sizeof(EChan));
		       if (!c
			   || !dma_strcpy(&c->channel, tc)
			   || !dma_strcpy(&c->reason, tr)
			   || !decifer_ecmode(tm, &c->modes))
			 {
			    put_error("Unable to allocate memory for enemy channel at %s:%d (%d)", file, linecnt, position);
			    dma_Free(&copy);
			    free_echan(c);
			    errocc = quiet = 1;
			    break;
			 }
		       dma_Free(&copy);
		       c->date = atol(td);
		       /* link it! */
		       add_to_list((List **)&e->channels, (List *)c);
		    }
		  
		  /* regardless... */
		  position++;
		  break;
	       }
	     
	     /* error occurred?? */
	     if (errocc)
	       {
		  if (!quiet)
		    put_error("Skipping malformed saved enemy at %s:%d (at position %d)", file, linecnt, position);
		  free_enemy(e);
		  break;
	       }
	  }
	/* only link it if there were no errors */
	if (!errocc)
	  {
	     /* add it to the list */
	     add_to_list((List **) & enemy_list, (List *) e);
	     /* increase the count */
	     count++;
	  }
	memset(line, 0, sizeof(line));
     }
   fclose(infile);
   return count;
}

/*
 * save the enemy list
 * format:
 * 
 * <nick>:<host1>:<hostn>:#channel1,chanmodes,date,reason:*,chanmodes,date,reason
 * 
 * saves to ~/.ninja/enemies  if (quiet) we don't show the output.. 
 *
 * returns the # of enemies saved
 */
int
save_enemies(quiet)
   int quiet;
{
   Enemy *e;
   EChan *c;
   EHost *h;
   u_char file[] = NINJA_ENEMY_FILE;
   FILE *outfile;
   u_char *ptr, tb1[BIG_BUFFER_SIZE], tb2[BIG_BUFFER_SIZE];
   int count = 0;

   ptr = expand_twiddle(file);
   outfile = fopen(ptr, "w");
   dma_Free(&ptr);
   if (outfile == NULL)
     {
	if (!quiet)
	  put_info("Unable to write to \"%s\", aborting Enemy save..", file);
	return 0;
     }
   for (e = enemy_list; e; e = e->next)
     {
	/* the nick */
	my_strmcpy(tb1, e->nick, sizeof(tb1));
	
	/* first hosts */
	for (h = e->hosts; h; h = h->next)
	  {
	     my_strmcat(tb1, ":", sizeof(tb1));
	     my_strmcat(tb1, h->host, sizeof(tb1));
	  }
	
	/* then channels */
	for (c = e->channels; c; c = c->next)
	  {
	     my_strmcat(tb1, ":", sizeof(tb1));
	     
	     snprintf(tb2, sizeof(tb2)-1, "%s,%s%s,%lu,%s", 
		      c->channel,
		      c->modes ? "+" : "",
		      recreate_ecmode(c),
		      (u_long)c->date,
		      c->reason);
	     tb2[sizeof(tb2)-1] = '\0';
	     my_strmcat(tb1, tb2, sizeof(tb1));
	  }
	fprintf(outfile, "%s\n", tb1);
	count++;
     }
   if (!quiet && count > 0)
     put_info("Saved %d enem%s...", count, Y_PLURAL(count));
   fclose(outfile);
   return count;
}

/*
 * lookup an enemy in the list
 */
Enemy *
get_enemy(nick)
   u_char *nick;
{
   return (Enemy *) find_in_list((List **)&enemy_list, nick, !USE_WILDCARDS);
}

/*
 * lookup a channel for an enemy
 */
EChan *
get_echan(e, chan, exact)
   Enemy *e;
   u_char *chan;
   int exact;
{
   EChan *c;

   if ((c = (EChan *) find_in_list((List **)&e->channels, chan, !USE_WILDCARDS)) != NULL)
     return c;
   if (!exact)
     {
	for (c = e->channels; c; c = c->next)
	  if (!my_strcmp(c->channel, "*"))
	    return c;
     }
   return (EChan *)NULL;
}


/*
 * get an enemys's host entry that the passed hostmask matches
 */
EHost *
get_ehost(e, mask)
   Enemy *e;
   u_char *mask;
{
   EHost *h;
   int ip = 0;
   u_char *p, *oldp;

   for (h = e->hosts; h; h = h->next)
     {
	/* first see if this host is an IP */
	oldp = p = my_rindex(h->host, '@');
	if (!p)
	  {
	     put_error("missing @ in h->host");
	     return NULL;
	  }
	p++;
	while (*p)
	  {
	     if (isdigit(*p) || *p == '.' || *p == '*' || *p == '?' || *p == '%')
	       ip = 1;
	     else
	       {
		  ip = 0;
		  break;
	       }
	     p++;
	  }
	
	/* if its an IP treat it differently.. */
	if (ip)
	  {
	     u_char *q;
	     int mch = 0;
	     
	     /* split the hostmask */
	     q = my_rindex(mask, '@');
	     if (!q)
	       {
		  put_error("missing @ in hostmask");
		  return NULL;
	       }
	     *q = *oldp = '\0';
	     if (match(h->host, mask)
		 && ip_match(oldp+1, q+1))
	       mch = 1;
	     *q = *oldp = '@';
	     if (mch)
	       return h;
	  }
	else if (match(h->host, mask))
	  return h;
     }
   return NULL;
}

/*
 * find an enemy by trying to match the passed user@host
 */
Enemy *
get_enemy_by_mask(mask, hp)
   u_char *mask;
   EHost **hp;
{
   Enemy *e, *done = NULL;
   EHost *h;
   
   if (hp)
     *hp = (EHost *)NULL;
   /* traverse the entire list looking for duplicates, return when we have finished */
   for (e = enemy_list; e; e = e->next)
     {
	if ((h = get_ehost(e, mask)))
	  {
	     if (done)
	       put_info("WARNING: %s matches more than one friend, using %s", mask, done->nick);
	     else
	       {
		  if (hp)
		    *hp = h;
		  done = e;
	       }
	  }
     }
   return done;
}

/*
 * find an enemy by trying to match the passed user@host
 */
Enemy *
get_enemy_by_nuh(nick, user, host)
   u_char *nick, *user, *host;
{
   Enemy *e;
   u_char *tb = ninja_make_nuh(nick, user, host);
   
   if (!tb)
     return (Enemy *)NULL;
   e = get_enemy_by_mask(tb, NULL);
   dma_Free(&tb);
   return e;
}




/* free routines... */
static	void
free_enemy(e)
   Enemy *e;
{
   EHost *host, *thost;
   EChan *chan, *tchan;
   
   if (!e)
     return;
   dma_Free(&e->nick);
   /* free hosts */
   for (host = e->hosts; host != NULL; host = thost)
     {
	thost = host->next;
	free_ehost(host);
     }
   /* free channels */
   for (chan = e->channels; chan != NULL; chan = tchan)
     {
	tchan = chan->next;
	free_echan(chan);
     }
   dma_Free(&e);
}

static	void
free_echan(ec)
   EChan *ec;
{
   if (!ec)
     return;
   dma_Free(&ec->channel);
   dma_Free(&ec);
}

static	void
free_ehost(eh)
   EHost *eh;
{
   if (!eh)
     return;
   dma_Free(&eh->host);
   dma_Free(&eh);
}
