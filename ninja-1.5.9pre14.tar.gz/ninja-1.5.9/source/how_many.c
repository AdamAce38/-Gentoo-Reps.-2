/*
 * how_many.c
 *
 * written by Joshua J. Drake
 */

#include "how_many.h"

/* 
 * count how many ch's are in str..
 * ..but!, don't count repeated spaces
 */


int
how_many(u_char *str, u_char ch)
{
   int count = 0;
   u_char *ptr = str;
   
   while (*ptr)
     {
	if (*ptr == ch)
	  {
	     if (ch == ' ')
	       {
		  if (ptr - str > 0 && *(ptr - 1) != ' ')
		    count++;
	       }
	     else
	       count++;
	  }
	ptr++;
     }
   return count;
}
