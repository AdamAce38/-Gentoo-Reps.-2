/* This file is generated from: eterna: mkmksiginc.pl,v 1.6 2004/02/16 09:55:53 mrg Exp  */

/*
 * Copyright (c) 2003-2004 Matthew R. Green
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include "irc.h"
IRCII_RCSID("@(#)$eterna: mkmksiginc.pl,v 1.6 2004/02/16 09:55:53 mrg Exp $");

#include <sys/types.h>
#include <signal.h>
#include <stdio.h>

#ifndef NSIG
#define NSIG 64
#endif

#define MAXSIG NSIG+1
char *signames[MAXSIG];

int main(int, char *[], char *[]);
int
main(argc, argv, envp)
	int	argc;
	char	*argv[];
	char	*envp[];
{
	int i;

	signames[0] = "ZERO";
	for (i = 1; i < MAXSIG; i++);
		signames[i] = 0;

#ifdef SIGABRT
	signames[SIGABRT] = "ABRT";
#endif

#ifdef SIGALRM
	signames[SIGALRM] = "ALRM";
#endif

#ifdef SIGALRM1
	signames[SIGALRM1] = "ALRM1";
#endif

#ifdef SIGBUS
	signames[SIGBUS] = "BUS";
#endif

#ifdef SIGCANCEL
	signames[SIGCANCEL] = "CANCEL";
#endif

#ifdef SIGCHLD
	signames[SIGCHLD] = "CHLD";
#endif

#ifdef SIGCLD
	signames[SIGCLD] = "CLD";
#endif

#ifdef SIGCONT
	signames[SIGCONT] = "CONT";
#endif

#ifdef SIGDANGER
	signames[SIGDANGER] = "DANGER";
#endif

#ifdef SIGDIL
	signames[SIGDIL] = "DIL";
#endif

#ifdef SIGEMT
	signames[SIGEMT] = "EMT";
#endif

#ifdef SIGFPE
	signames[SIGFPE] = "FPE";
#endif

#ifdef SIGFREEZE
	signames[SIGFREEZE] = "FREEZE";
#endif

#ifdef SIGGRANT
	signames[SIGGRANT] = "GRANT";
#endif

#ifdef SIGHUP
	signames[SIGHUP] = "HUP";
#endif

#ifdef SIGILL
	signames[SIGILL] = "ILL";
#endif

#ifdef SIGINFO
	signames[SIGINFO] = "INFO";
#endif

#ifdef SIGINT
	signames[SIGINT] = "INT";
#endif

#ifdef SIGIO
	signames[SIGIO] = "IO";
#endif

#ifdef SIGIOT
	signames[SIGIOT] = "IOT";
#endif

#ifdef SIGKAP
	signames[SIGKAP] = "KAP";
#endif

#ifdef SIGKILL
	signames[SIGKILL] = "KILL";
#endif

#ifdef SIGKILLTHR
	signames[SIGKILLTHR] = "KILLTHR";
#endif

#ifdef SIGLOST
	signames[SIGLOST] = "LOST";
#endif

#ifdef SIGLWP
	signames[SIGLWP] = "LWP";
#endif

#ifdef SIGMIGRATE
	signames[SIGMIGRATE] = "MIGRATE";
#endif

#ifdef SIGMSG
	signames[SIGMSG] = "MSG";
#endif

#ifdef SIGPIPE
	signames[SIGPIPE] = "PIPE";
#endif

#ifdef SIGPOLL
	signames[SIGPOLL] = "POLL";
#endif

#ifdef SIGPRE
	signames[SIGPRE] = "PRE";
#endif

#ifdef SIGPROF
	signames[SIGPROF] = "PROF";
#endif

#ifdef SIGPWR
	signames[SIGPWR] = "PWR";
#endif

#ifdef SIGQUIT
	signames[SIGQUIT] = "QUIT";
#endif

#ifdef SIGRETRACT
	signames[SIGRETRACT] = "RETRACT";
#endif

#ifdef SIGRTMAX
	signames[SIGRTMAX] = "RTMAX";
#endif

#ifdef SIGRTMIN
	signames[SIGRTMIN] = "RTMIN";
#endif

#ifdef SIGSAK
	signames[SIGSAK] = "SAK";
#endif

#ifdef SIGSEGV
	signames[SIGSEGV] = "SEGV";
#endif

#ifdef SIGSOUND
	signames[SIGSOUND] = "SOUND";
#endif

#ifdef SIGSTOP
	signames[SIGSTOP] = "STOP";
#endif

#ifdef SIGSYS
	signames[SIGSYS] = "SYS";
#endif

#ifdef SIGTERM
	signames[SIGTERM] = "TERM";
#endif

#ifdef SIGTHAW
	signames[SIGTHAW] = "THAW";
#endif

#ifdef SIGTRAP
	signames[SIGTRAP] = "TRAP";
#endif

#ifdef SIGTSTP
	signames[SIGTSTP] = "TSTP";
#endif

#ifdef SIGTTIN
	signames[SIGTTIN] = "TTIN";
#endif

#ifdef SIGTTOU
	signames[SIGTTOU] = "TTOU";
#endif

#ifdef SIGURG
	signames[SIGURG] = "URG";
#endif

#ifdef SIGUSR1
	signames[SIGUSR1] = "USR1";
#endif

#ifdef SIGUSR2
	signames[SIGUSR2] = "USR2";
#endif

#ifdef SIGVIRT
	signames[SIGVIRT] = "VIRT";
#endif

#ifdef SIGVTALRM
	signames[SIGVTALRM] = "VTALRM";
#endif

#ifdef SIGWAITING
	signames[SIGWAITING] = "WAITING";
#endif

#ifdef SIGWINCH
	signames[SIGWINCH] = "WINCH";
#endif

#ifdef SIGWINDOW
	signames[SIGWINDOW] = "WINDOW";
#endif

#ifdef SIGXCPU
	signames[SIGXCPU] = "XCPU";
#endif

#ifdef SIGXFSZ
	signames[SIGXFSZ] = "XFSZ";
#endif

	printf("int max_signo = %d;\n", NSIG);
	puts("char *signals[] = { ");
	for (i = 0; i < MAXSIG; i++)
		if (signames[i])
			printf("\"%s\", ", signames[i]);
		else
			printf("\"SIG%d\", ", i);
	puts("NULL };\n");

	exit(0);
}
