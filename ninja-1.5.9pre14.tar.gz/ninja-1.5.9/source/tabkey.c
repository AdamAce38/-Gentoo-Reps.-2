/*
 * tabkey.c: Ninja IRC tab completion
 *
 * written by Joshua J. Drake and Kraig Amador
 */

#include "irc.h"
#include "dma.h"

#include "tabkey.h"

#include "input.h"
#include "ircaux.h"
#include "list.h"
#include "vars.h"
#include "server.h"
#include "screen.h"

static Reply *tabkey_array = (Reply *) 0;


static u_char *make_tab_string(u_char *, u_char *, int);
			       
/*
 * tab reply!
 */
void
tab_reply(u_int dumb, u_char *dumber)
{
   u_char *tmp = NULL;
   u_char *cmdchar = NULL;

   tmp = get_tab_key();
   if (tmp && *tmp)
     {
	u_char tmp1[1024], *p;
	
	if (!(cmdchar = get_string_var(CMDCHARS_VAR)))
	   cmdchar = "/";
	input_clear_line('\0', NULL);
	snprintf(tmp1, sizeof(tmp1)-1, "%s%s ", cmdchar, tmp);
	p = tmp1;
	while (p && *p)
	  input_add_character(*p++, NULL);
     }
}

void
add_tab_key(int times, u_char *prompt, u_char *targ)
{
   Reply *tmp, *last, *newtk;
   
   if (!prompt || !targ)
     return;

   /* first we look for our entry */
   last = NULL;
   tmp = tabkey_array;
   while (tmp)
     {
	if (tmp->server == from_server 
	    && my_stricmp(tmp->prompt, prompt) == 0
	    && my_stricmp(tmp->nick, targ) == 0)
	  break;
	last = tmp;
	tmp = tmp->next;
     }
   /* if we found it, delink it */
   if (tmp)
     {
	if (last)
	  last->next = tmp->next;
	else
	  tabkey_array = tmp->next;
     }
   /* otherwise, add a new one */
   else
     {
	newtk = (Reply *) dma_Malloc(sizeof(Reply));
	if (!newtk)
	  return;
	dma_strcpy(&(newtk->prompt), prompt);
	dma_strcpy(&(newtk->nick), targ);
	newtk->server = from_server;
	newtk->times = times;
	tmp = newtk;
     }
   
   tmp->last_used = time(NULL);
   /* now we must relink the tabkey at the head */
   tmp->next = tabkey_array;
   tabkey_array = tmp;
}

u_char *
get_tab_key(void)
{
   Reply *tmp, *toptk;
   u_char *ret;
   
   /* we have any? */
   if (!tabkey_array)
     return NULL;
   
   toptk = tabkey_array;
   /* behead the list if there are more */
   if (toptk->next)
     {
	tabkey_array = toptk->next;
	toptk->next = NULL;
   
	/* if it must be relinked... */
	if (!toptk->times)
	  {
	     /* move it to the end of the list */
	     tmp = tabkey_array;
	     while (tmp)
	       {
		  if (tmp->next)
		    tmp = tmp->next;
		  else
		    break;
	       }
	     /* and put the top one here */
	     tmp->next = toptk;
	  }
     }
   /* it is the only one in the list */
   else 
     {
	/* if it must be relinked... make it the only one again */
	if (!toptk->times)
	  tabkey_array = toptk;
	/* if not there are none left now */
	else
	  tabkey_array = NULL;
     }

   /* build the return string */
   ret = make_tab_string(toptk->prompt, toptk->nick, toptk->server);
   
   /* if it can only be used once purge it */
   if (toptk->times)
     {
	/* free the memory of the non-linked tk */
	dma_Free(&toptk->prompt);
	dma_Free(&toptk->nick);
	dma_Free(&toptk);
     }
   
   /* return our static string */
   return ret;
}

#ifndef NFREQ_TAB_KEY_EXPIRE
# define NFREQ_TAB_KEY_EXPIRE	3600 /* default, 1 hour */
#endif
/*
 * expire tab reply entries...
 */
void
nchk_tabkeys(current)
   time_t current;
{
   Reply *tmp, *last = NULL, *tmp2;

   tmp = tabkey_array;
   while (tmp)
     {
	if ((current - tmp->last_used) > NFREQ_TAB_KEY_EXPIRE)
	  {
	     tmp2 = tmp->next;
	     if (last)
	       last->next = tmp2;
	     else
	       tabkey_array = tmp2;
	     dma_Free(&tmp->prompt);
	     dma_Free(&tmp->nick);
	     dma_Free(&tmp);
	     tmp = tmp2;
	  }
	else
	  {
	     last = tmp;
	     tmp = tmp->next;
	  }
     }
}


static
u_char *make_tab_string(prompt, targ, server)
   u_char *prompt, *targ;
   int server;
{
   static u_char tb[512];
   u_char ch[2] = { 0, 0 };
   u_char idx_buf[32];
   
   my_strmcpy(tb, prompt, sizeof(tb)-1);
   
   /* only insert server option for servers in other windows (not for dcc) */
   if (server >= 0 && server < number_of_servers
       && server != curr_scr_win->server
       && my_strnicmp(prompt, "/dcc ", 4) != 0)
     {
	snprintf(idx_buf, sizeof(idx_buf)-1, "%d", server + 1);
	
	if (tb[strlen(tb)-1] == '=')
	  ch[0] = '=';
	my_strmcat(tb, "-server ", sizeof(tb)-1);
	my_strmcat(tb, idx_buf, sizeof(tb)-1);
	my_strmcat(tb, " ", sizeof(tb)-1);
	if (ch[0] != 0)
	  my_strmcat(tb, ch, sizeof(tb)-1);
     }
   my_strmcat(tb, targ, sizeof(tb)-1);
   return tb;
}

