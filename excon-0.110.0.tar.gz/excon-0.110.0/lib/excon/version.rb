# frozen_string_literal: true

module Excon
  VERSION = '0.110.0'
end
