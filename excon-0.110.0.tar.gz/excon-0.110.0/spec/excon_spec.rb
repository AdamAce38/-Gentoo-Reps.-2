require 'spec_helper'

describe Excon do
  it 'has a version number' do
    expect(Excon::VERSION).not_to be nil
  end
end
