## Security contact information

To report a security vulnerability, please contact
[Tidelift security](https://tidelift.com/security).

Tidelift will coordinate the fix and disclosure.
