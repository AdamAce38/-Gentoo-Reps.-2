* Aaron Stone
* Adam Avilla
* Adam Esterline
* Alexander Sandström
* Alexandr Burov
* Andrew Katz
* Andrew Metcalf
* Andrew Sullivan Cant
* André Diego Piske
* Andy Delcambre
* Anshul Khandelwal
* Anton Chuchkalov
* Antonio Terceiro
* Ash Wilson
* Atul Bhosale
* Bart de Water
* Ben Burkert
* Benedikt Böhm
* Bill Mill
* Bo Jeanes
* Brandur
* Brian D. Burns
* Brian Hartsock
* Bryan Paxton
* Caio Chassot
* Caius Durling
* Carl Hörberg
* Carl Hörberg
* Carlos Sanchez
* Casper Thomsen
* Chris Hanks
* Christoph Rieß
* Christophe Taton
* Claudio Poli
* Craig Shannon
* Damien Mathieu
* Dan Hensgen
* Dan Peterson
* Dan Prince
* Dane Harrigan
* Daniel Berger
* Dave Myron
* Dave Newton
* Dave Vasilevsky
* David Biehl
* David Taylor
* Dimitrij Denissenko
* Dominik Richter
* Doug McInnes
* Esteban Pastorino
* Eugene Howe
* Evan Phoenix
* Fabian Wiesel
* Federico Ravasio
* Felix Wolfsteller
* Glenn Pratt
* Graeme Nelson
* Grey Baker
* Guillaume Balaine
* Hakan Ensari
* Hiroshi Hatake
* Ian Neubert
* Igor Fedoronchuk
* Jacob Atzen
* James Cox
* James Watling
* Jean Mertz
* Jeremy Hinegardner
* Jesse Kempf
* Jessica Jiang
* Joe Rafaniello
* John Keiser
* John Leach
* Jonas Pfenniger
* Jonathan Dance
* Jonathan Roes
* Joshua B. Smith
* Joshua Gross
* Joshua Mckinney
* Joshua Napoli
* Kelly Mahan
* Kensuke Nagae
* Kimmo Lehto
* Koen Rouwhorst
* Konstantin Shabanov
* Kyle Purkiss
* Kyle Rames
* Lewis Marshall
* Lincoln Stoll
* Louis Sobel
* Mahemoff
* Marco Costa
* Markus Bucher
* Mathias Meyer
* Matt Gauger
* Matt Palmer
* Matt Sanders
* Matt Snyder
* Matt Todd
* Maurice Schreiber
* Max Lincoln
* Michael Brodhead
* Michael Hale
* Michael Rowe
* Michael Rykov
* Mike Heffner
* Milovan Zogovic
* Myron Marston
* Nathan Long
* Nathan Sutton
* Nick Osborn
* Nicolas Leger
* Nicolas Sanguinetti
* Paul Gideon Dann
* Pavel
* Pavel Valena
* Peter Meier
* Peter Weldon
* Phil Ross
* Raul Murciano
* Richard Godbee
* Richard Ramsden
* Rohan Mendon
* Ruslan Korolev
* Ruslan Kyrychuk
* Ryan Bigg
* Ryan Mohr
* Ryan Schlesinger
* Ryoji Yoshioka
* Sam
* Sam Lehman
* Sam Withrow
* Scott Gonyea
* Scott Walkinshaw
* Sean Cribbs
* Sergio Rubio
* Shai Rosenfeld
* Stan Hu
* Stefan Merettig
* Stephen Chu
* Swanand Pagnis
* Terry Howe
* Thom Mahoney & Josh Lane
* Thom May
* Tim Carey-Smith
* Timothée Peignier
* Tobias Schmidt
* Todd Lunter
* Tom Maher
* Trym Skaar
* Tuomas Silen
* Victor Costan
* Viven
* Vít Ondruch
* Wesley Beary
* Yusuke Nakamura
* Zach Anker
* chrisrhoden
* dependabot[bot]
* dickeyxxx
* geemus
* geemus (Wesley Beary)
* ggoodale
* ivan.filenko
* jasquat
* karimb
* marios
* mkb
* nathannaveen
* ojab
* patrick brisbin
* pavel
* phiggins
* rin_ne
* rinrinne
* rkyrychuk
* shale
* sshaw
* starbelly
* twrodriguez
* wsnarski
* zimbatm