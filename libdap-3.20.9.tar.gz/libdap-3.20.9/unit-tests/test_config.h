#ifndef E_test_config_h
#define E_test_config_h

#define TEST_SRC_DIR "/Users/ndp/OPeNDAP/hyrax/libdap4/unit-tests"

#endif

