# Downloads
Download the latest builds.

**Note: These binaries are just the artifacts of the builders and have not
  undergone any QA, thus they should be considered unsupported.**

## Release
| Windows | Linux | MacOS |
| --- | --- | --- |
| [MSVC 2019](https://storage.googleapis.com/shaderc/badges/build_link_windows_vs2019_release.html) | [clang](https://storage.googleapis.com/shaderc/badges/build_link_linux_clang_release.html) | [clang](https://storage.googleapis.com/shaderc/badges/build_link_macos_clang_release.html) |
| [MSVC 2017](https://storage.googleapis.com/shaderc/badges/build_link_windows_vs2017_release.html) | [gcc](https://storage.googleapis.com/shaderc/badges/build_link_linux_gcc_release.html) | |

## Debug
| Windows | Linux | MacOS |
| --- | --- | --- |
| [MSVC 2019](https://storage.googleapis.com/shaderc/badges/build_link_windows_vs2019_debug.html) | [clang](https://storage.googleapis.com/shaderc/badges/build_link_linux_clang_debug.html) | [clang](https://storage.googleapis.com/shaderc/badges/build_link_macos_clang_debug.html) |
| [MSVC 2017](https://storage.googleapis.com/shaderc/badges/build_link_windows_vs2017_debug.html) | [gcc](https://storage.googleapis.com/shaderc/badges/build_link_linux_gcc_debug.html) | |
