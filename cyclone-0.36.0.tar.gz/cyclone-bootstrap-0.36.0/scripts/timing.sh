#!/bin/bash
time for i in {1..10}; do cyclone -d scheme/base.sld; done
