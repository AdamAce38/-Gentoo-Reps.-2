The ImageIO Plugin API
======================

.. automodule:: imageio.plugins

Example / template plugin
-------------------------

.. code-block:: python
    :linenos:

    {% for line in example_plugin %}
    {{line}}
    {% endfor %}
