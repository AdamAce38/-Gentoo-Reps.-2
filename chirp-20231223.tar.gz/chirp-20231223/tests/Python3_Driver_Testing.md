## Status
| Driver | Tester | Tested | Byte Clean | "Market Share" |
| ------ | ------ | ------ | ---------- | -------------- |
| <a name="ARRL_Travel_Plus"></a> ARRL_Travel_Plus |  |  |  | 0.00% |
| <a name="Abbree_AR-518"></a> Abbree_AR-518 | [@KC9HI](https://github.com/KC9HI) | 16-Dec-2022 | Yes | 0.24% |
| <a name="Abbree_AR-63"></a> Abbree_AR-63 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.03% |
| <a name="Abbree_AR-730"></a> Abbree_AR-730 | [@KC9HI](https://github.com/KC9HI) | 17-Aug-2023 | Yes |  |
| <a name="Abbree_AR-869"></a> Abbree_AR-869 | [Implied by Radtel_RT-490](#user-content-Radtel_RT-490) | 11-Nov-2023 | Yes | 0.01% |
| <a name="Abbree_AR-F5"></a> Abbree_AR-F5 | [@KC9HI](https://github.com/KC9HI) | 09-Aug-2023 | Yes |  |
| <a name="Alinco_DJ-G7EG"></a> Alinco_DJ-G7EG | [@HB9UF](https://github.com/HB9UF) | 09-Dec-2022 | Yes | 0.44% |
| <a name="Alinco_DJ-G7T"></a> Alinco_DJ-G7T | [Reported working](https://chirp.danplanet.com/issues/10567) | 09-May-2023 | Yes |  |
| <a name="Alinco_DJ175"></a> Alinco_DJ175 | [Implied by Alinco_DR235T](#user-content-Alinco_DR235T) | 12-Dec-2022 | Yes | 0.03% |
| <a name="Alinco_DJ596"></a> Alinco_DJ596 | [Implied by Alinco_DR235T](#user-content-Alinco_DR235T) | 12-Dec-2022 | Yes | 0.02% |
| <a name="Alinco_DR03T"></a> Alinco_DR03T | [Implied by Alinco_DR235T](#user-content-Alinco_DR235T) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Alinco_DR06T"></a> Alinco_DR06T | [Implied by Alinco_DR235T](#user-content-Alinco_DR235T) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Alinco_DR135T"></a> Alinco_DR135T | [Implied by Alinco_DR235T](#user-content-Alinco_DR235T) | 12-Dec-2022 | Yes | 0.04% |
| <a name="Alinco_DR235T"></a> Alinco_DR235T | [@kk7ds](https://github.com/kk7ds) | 12-Dec-2022 | Yes | 0.02% |
| <a name="Alinco_DR435T"></a> Alinco_DR435T | [Implied by Alinco_DR235T](#user-content-Alinco_DR235T) | 12-Dec-2022 | Yes | 0.02% |
| <a name="AnyTone_5888UV"></a> AnyTone_5888UV | [@kk7ds](https://github.com/kk7ds) | 9-Dec-2022 | Yes | 0.14% |
| <a name="AnyTone_5888UVIII"></a> AnyTone_5888UVIII | [@bschuler42](https://github.com/bschuler42) | 9-Jan-2023 | Yes | 0.04% |
| <a name="AnyTone_778UV"></a> AnyTone_778UV | [Implied by Retevis_RT95](#user-content-Retevis_RT95) | 13-Nov-2022 | Yes | 0.17% |
| <a name="AnyTone_778UV_VOX"></a> AnyTone_778UV_VOX | [Implied by Retevis_RT95](#user-content-Retevis_RT95) | 13-Nov-2022 | Yes | 0.23% |
| <a name="AnyTone_OBLTR-8R"></a> AnyTone_OBLTR-8R | [@KC9HI](https://github.com/KC9HI) | 17-Dec-2022 | Yes | 0.02% |
| <a name="AnyTone_TERMN-8R"></a> AnyTone_TERMN-8R | [@KC9HI](https://github.com/KC9HI) | 17-Dec-2022 | Yes | 0.02% |
| <a name="Anysecu_AC-580"></a> Anysecu_AC-580 | [Implied by Radioddity_GS-5B](#user-content-Radioddity_GS-5B) | 17-Mar-2023 | Yes |  |
| <a name="Anysecu_UV-A37"></a> Anysecu_UV-A37 | [@KC9HI](https://github.com/KC9HI) | 5-Jun-2023 | Yes |  |
| <a name="Anysecu_WP-9900"></a> Anysecu_WP-9900 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.03% |
| <a name="BTECH_FRS-A1"></a> BTECH_FRS-A1 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.01% |
| <a name="BTECH_FRS-B1"></a> BTECH_FRS-B1 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.04% |
| <a name="BTECH_GMRS-20V2"></a> BTECH_GMRS-20V2 | [@KC9HI](https://github.com/KC9HI) | 13-Nov-2022 | Yes | 0.03% |
| <a name="BTECH_GMRS-50V2"></a> BTECH_GMRS-50V2 | [@KC9HI](https://github.com/KC9HI) | 15-Feb-2023 | Yes | 0.00% |
| <a name="BTECH_GMRS-50X1"></a> BTECH_GMRS-50X1 | [@KC9HI](https://github.com/KC9HI) | 13-Nov-2022 | Yes | 0.13% |
| <a name="BTECH_GMRS-V1"></a> BTECH_GMRS-V1 | [@KC9HI](https://github.com/KC9HI) | 10-Dec-2022 | Yes | 0.16% |
| <a name="BTECH_GMRS-V2"></a> BTECH_GMRS-V2 | [@KC9HI](https://github.com/KC9HI) | 10-Dec-2022 | Yes | 0.16% |
| <a name="BTECH_MURS-V1"></a> BTECH_MURS-V1 | [@KC9HI](https://github.com/KC9HI) | 10-Dec-2022 | Yes | 0.04% |
| <a name="BTECH_MURS-V2"></a> BTECH_MURS-V2 | [@KC9HI](https://github.com/KC9HI) | 2-Mar-2023 | Yes | 0.00% |
| <a name="BTECH_UV-2501"></a> BTECH_UV-2501 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.02% |
| <a name="BTECH_UV-2501+220"></a> BTECH_UV-2501+220 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.02% |
| <a name="BTECH_UV-25X2"></a> BTECH_UV-25X2 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.15% |
| <a name="BTECH_UV-25X2_G2"></a> BTECH_UV-25X2_G2 | [@KC9HI](https://github.com/KC9HI) | 23-Apr-2023 | Yes |  |
| <a name="BTECH_UV-25X4"></a> BTECH_UV-25X4 | [@KC9HI](https://github.com/KC9HI) | 10-Nov-2022 | Yes | 0.11% |
| <a name="BTECH_UV-25X4_G2"></a> BTECH_UV-25X4_G2 | [@KC9HI](https://github.com/KC9HI) | 23-Apr-2023 | Yes |  |
| <a name="BTECH_UV-5001"></a> BTECH_UV-5001 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.03% |
| <a name="BTECH_UV-50X2"></a> BTECH_UV-50X2 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.13% |
| <a name="BTECH_UV-50X2_G2"></a> BTECH_UV-50X2_G2 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.00% |
| <a name="BTECH_UV-50X3"></a> BTECH_UV-50X3 | [@KC9HI](https://github.com/KC9HI) | 10-Dec-2022 | Yes | 0.06% |
| <a name="BTECH_UV-5X3"></a> BTECH_UV-5X3 | [@KC9HI](https://github.com/KC9HI) | 9-Dec-2022 | Yes | 0.43% |
| <a name="Baofeng_5RM"></a> Baofeng_5RM | [@vdwel](https://github.com/vdwel) | 7-Dec-2023 | Yes |  |
| <a name="Baofeng_BF-1901"></a> Baofeng_BF-1901 | [@cetinajero](https://github.com/cetinajero) | 3-Jul-2023 | Yes |  |
| <a name="Baofeng_BF-1904"></a> Baofeng_BF-1904 | [@cetinajero](https://github.com/cetinajero) | 3-Jul-2023 | Yes |  |
| <a name="Baofeng_BF-888"></a> Baofeng_BF-888 | [@kk7ds](https://github.com/kk7ds) | 13-Feb-2019 | Yes | **15.53%** |
| <a name="Baofeng_BF-A58"></a> Baofeng_BF-A58 | [@KC9HI](https://github.com/KC9HI) | 3-Dec-2022 | Yes | **1.46%** |
| <a name="Baofeng_BF-A58S"></a> Baofeng_BF-A58S | [@KC9HI](https://github.com/KC9HI) | 3-Dec-2022 | Yes | 0.59% |
| <a name="Baofeng_BF-F8HP"></a> Baofeng_BF-F8HP | [@KC9HI](https://github.com/KC9HI) | 18-Nov-2022 | Yes | **6.33%** |
| <a name="Baofeng_BF-M4"></a> Baofeng_BF-M4 | [@cetinajero](https://github.com/cetinajero) | 8-May-2023 | Yes |  |
| <a name="Baofeng_BF-T1"></a> Baofeng_BF-T1 | [@KC9HI](https://github.com/KC9HI) | 10-Dec-2022 | Yes | 0.76% |
| <a name="Baofeng_BF-T20"></a> Baofeng_BF-T20 | [@KC9HI](https://github.com/KC9HI) | 15-Dec-2023 | Yes |  |
| <a name="Baofeng_BF-T20FRS"></a> Baofeng_BF-T20FRS | [@KC9HI](https://github.com/KC9HI) | 17-Dec-2023 | Yes |  |
| <a name="Baofeng_BF-T8"></a> Baofeng_BF-T8 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.42% |
| <a name="Baofeng_BF-V8A"></a> Baofeng_BF-V8A | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.03% |
| <a name="Baofeng_F-11"></a> Baofeng_F-11 | [Implied by Baofeng_UV-5R](#user-content-Baofeng_UV-5R) | 18-Nov-2022 | Yes | 0.12% |
| <a name="Baofeng_GT-3WP"></a> Baofeng_GT-3WP | [@KC9HI](https://github.com/KC9HI) | 3-Dec-2022 | Yes | 0.43% |
| <a name="Baofeng_GT-5R"></a> Baofeng_GT-5R | [@KC9HI](https://github.com/KC9HI) | 18-Nov-2022 | Yes | 0.68% |
| <a name="Baofeng_UV-17"></a> Baofeng_UV-17 | [@vdwel](https://github.com/vdwel) | 27-Nov-2023 | Yes |  |
| <a name="Baofeng_UV-17Pro"></a> Baofeng_UV-17Pro | [@vdwel](https://github.com/vdwel) | 27-Nov-2023 | Yes |  |
| <a name="Baofeng_UV-17ProGPS"></a> Baofeng_UV-17ProGPS | [@vdwel](https://github.com/vdwel) | 27-Nov-2023 | Yes |  |
| <a name="Baofeng_UV-3R"></a> Baofeng_UV-3R | [@yarda](https://github.com/yarda) | 26-Sep-2022 | Yes | 0.45% |
| <a name="Baofeng_UV-5R"></a> Baofeng_UV-5R | [@lekv](https://github.com/lekv) | 23-Oct-2022 | Yes | **28.81%** |
| <a name="Baofeng_UV-6"></a> Baofeng_UV-6 | [Implied by Baofeng_UV-5R](#user-content-Baofeng_UV-5R) | 18-Nov-2022 | Yes | 0.46% |
| <a name="Baofeng_UV-6R"></a> Baofeng_UV-6R | [@KC9HI](https://github.com/KC9HI) | 10-Dec-2022 | Yes | 0.71% |
| <a name="Baofeng_UV-82"></a> Baofeng_UV-82 | [@KC9HI](https://github.com/KC9HI) | 18-Nov-2022 | Yes | **8.78%** |
| <a name="Baofeng_UV-82HP"></a> Baofeng_UV-82HP | [@KC9HI](https://github.com/KC9HI) | 18-Nov-2022 | Yes | **2.38%** |
| <a name="Baofeng_UV-82WP"></a> Baofeng_UV-82WP | [@KC9HI](https://github.com/KC9HI) | 3-Dec-2022 | Yes | 0.32% |
| <a name="Baofeng_UV-9G"></a> Baofeng_UV-9G | [@KC9HI](https://github.com/KC9HI) | 3-Dec-2022 | Yes | 0.65% |
| <a name="Baofeng_UV-9R"></a> Baofeng_UV-9R | [@KC9HI](https://github.com/KC9HI) | 3-Dec-2022 | Yes | **2.52%** |
| <a name="Baofeng_UV-B5"></a> Baofeng_UV-B5 | [@KC9HI](https://github.com/KC9HI) | 18-Nov-2022 | Yes | 0.35% |
| <a name="Baofeng_UV-S9X3"></a> Baofeng_UV-S9X3 | [@KC9HI](https://github.com/KC9HI) | 22-Aug-2023 | Yes |  |
| <a name="Baofeng_W31E"></a> Baofeng_W31E | [@KC9HI](https://github.com/KC9HI) | 14-Aug-2023 | Yes |  |
| <a name="Baojie_BJ-218"></a> Baojie_BJ-218 | [Implied by LUITON_LT-725UV](#user-content-LUITON_LT-725UV) | 16-Feb-2023 | Yes | 0.29% |
| <a name="Baojie_BJ-318"></a> Baojie_BJ-318 | [@KC9HI](https://github.com/KC9HI) | 2-Jan-2023 | Yes | 0.10% |
| <a name="Baojie_BJ-9900"></a> Baojie_BJ-9900 |  |  |  | 0.02% |
| <a name="Baojie_BJ-UV55"></a> Baojie_BJ-UV55 |  |  | Yes | 0.03% |
| <a name="Boblov_X3Plus"></a> Boblov_X3Plus |  |  |  | 0.02% |
| <a name="Boristone_8RS"></a> Boristone_8RS | [Implied by Radtel_RT-490](#user-content-Radtel_RT-490) | 11-Nov-2023 | Yes | 0.00% |
| <a name="CRT_Micron_UV"></a> CRT_Micron_UV | [Implied by Retevis_RT95](#user-content-Retevis_RT95) | 13-Nov-2022 | Yes | 0.08% |
| <a name="CRT_Micron_UV_V2"></a> CRT_Micron_UV_V2 | [Implied by Retevis_RT95](#user-content-Retevis_RT95) | 13-Nov-2022 | Yes | 0.10% |
| <a name="Cignus_XTR-5"></a> Cignus_XTR-5 | [Implied by Radioddity_GS-5B](#user-content-Radioddity_GS-5B) | 17-Mar-2023 | Yes |  |
| <a name="Commander_KG-UV"></a> Commander_KG-UV |  |  |  | 0.00% |
| <a name="Explorer_QRZ-1"></a> Explorer_QRZ-1 | [Implied by TYT_TH-UV88](#user-content-TYT_TH-UV88) | 5-Dec-2022 | Yes | 0.04% |
| <a name="Feidaxin_FD-150A"></a> Feidaxin_FD-150A |  |  |  | 0.02% |
| <a name="Feidaxin_FD-160A"></a> Feidaxin_FD-160A |  |  |  | 0.01% |
| <a name="Feidaxin_FD-268A"></a> Feidaxin_FD-268A |  |  |  | 0.01% |
| <a name="Feidaxin_FD-268B"></a> Feidaxin_FD-268B |  |  |  | 0.01% |
| <a name="Feidaxin_FD-288A"></a> Feidaxin_FD-288A |  |  |  | 0.01% |
| <a name="Feidaxin_FD-288B"></a> Feidaxin_FD-288B |  |  |  | 0.01% |
| <a name="Feidaxin_FD-450A"></a> Feidaxin_FD-450A |  |  |  | 0.01% |
| <a name="Feidaxin_FD-460A"></a> Feidaxin_FD-460A |  |  |  | 0.01% |
| <a name="Feidaxin_FD-460UH"></a> Feidaxin_FD-460UH |  |  |  | 0.01% |
| <a name="Generic_CSV"></a> Generic_CSV | [@kk7ds](https://github.com/kk7ds) | 4-Dec-2022 |  |  |
| <a name="HamGeek_HG-590"></a> HamGeek_HG-590 | [Implied by Radtel_RT-490](#user-content-Radtel_RT-490) | 11-Nov-2023 | Yes | 0.00% |
| <a name="Hiroyasu_HI-8811"></a> Hiroyasu_HI-8811 | [@KC9HI](https://github.com/KC9HI) | 4-Jun-2023 | Yes |  |
| <a name="HobbyPCB_RS-UV3"></a> HobbyPCB_RS-UV3 | [@kk7ds](https://github.com/kk7ds) | 9-Dec-2022 | Yes | 0.02% |
| <a name="Icom_IC-208H"></a> Icom_IC-208H | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.05% |
| <a name="Icom_IC-2100H"></a> Icom_IC-2100H | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.04% |
| <a name="Icom_IC-2200H"></a> Icom_IC-2200H | [@kk7ds](https://github.com/kk7ds) | 24-Oct-2022 | Yes | 0.05% |
| <a name="Icom_IC-2300H"></a> Icom_IC-2300H | [Reported working](https://chirp.danplanet.com/issues/10264) | 13-Jan-2022 | Yes | 0.08% |
| <a name="Icom_IC-2720H"></a> Icom_IC-2720H | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.02% |
| <a name="Icom_IC-2730A"></a> Icom_IC-2730A | [Reported working](https://chirp.danplanet.com/issues/10261) | 17-Dec-2022 | Yes | 0.21% |
| <a name="Icom_IC-2820H"></a> Icom_IC-2820H | [@kk7ds](https://github.com/kk7ds) | 22-Oct-2022 | Yes | 0.04% |
| <a name="Icom_IC-7000"></a> Icom_IC-7000 | [Reported working](https://chirp.danplanet.com/issues/10510) | 10-Apr-2023 | Yes | 0.03% |
| <a name="Icom_IC-7100"></a> Icom_IC-7100 | Mike W | 16-Feb-2023 | Yes | 0.06% |
| <a name="Icom_IC-7200"></a> Icom_IC-7200 | [@kk7ds](https://github.com/kk7ds) | 22-Oct-2022 | Yes |  |
| <a name="Icom_IC-7300"></a> Icom_IC-7300 | [@kk7ds](https://github.com/kk7ds) | 22-Oct-2022 | Yes | 0.03% |
| <a name="Icom_IC-746"></a> Icom_IC-746 | [Reported working](https://chirp.danplanet.com/issues/10346) | 3-Feb-2023 | Yes |  |
| <a name="Icom_IC-7610"></a> Icom_IC-7610 | [@kk7ds](https://github.com/kk7ds) | 24-Oct-2022 | Yes | 0.00% |
| <a name="Icom_IC-910"></a> Icom_IC-910 | [@mfncooper](https://github.com/mfncooper) | 1-Oct-2021 | Yes | 0.00% |
| <a name="Icom_IC-91_92AD"></a> Icom_IC-91_92AD | [@kk7ds](https://github.com/kk7ds) | 23-Nov-2022 | Yes | 0.03% |
| <a name="Icom_IC-E90"></a> Icom_IC-E90 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.04% |
| <a name="Icom_IC-P7"></a> Icom_IC-P7 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Icom_IC-Q7A"></a> Icom_IC-Q7A | [@KC9HI](https://github.com/KC9HI) | 20-Nov-2022 | Yes | 0.01% |
| <a name="Icom_IC-T70"></a> Icom_IC-T70 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.03% |
| <a name="Icom_IC-T7H"></a> Icom_IC-T7H | [Reported working](https://chirp.danplanet.com/issues/10752) | 30-Jul-2023 | Yes | 0.02% |
| <a name="Icom_IC-T8A"></a> Icom_IC-T8A | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Icom_IC-U82"></a> Icom_IC-U82 | [Implied by Icom_IC-V82](#user-content-Icom_IC-V82) | 25-Jan-2023 | Yes |  |
| <a name="Icom_IC-V80"></a> Icom_IC-V80 | [@kk7ds](https://github.com/kk7ds) | 16-Feb-2023 | Yes | 0.00% |
| <a name="Icom_IC-V82"></a> Icom_IC-V82 | [@kk7ds](https://github.com/kk7ds) | 25-Jan-2023 | Yes |  |
| <a name="Icom_IC-V86"></a> Icom_IC-V86 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.04% |
| <a name="Icom_IC-W32A"></a> Icom_IC-W32A | [Reported working](https://chirp.danplanet.com/issues/10238) | 12-Dec-2022 | Yes | 0.02% |
| <a name="Icom_IC-W32E"></a> Icom_IC-W32E | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Icom_ID-31A"></a> Icom_ID-31A | [@kk7ds](https://github.com/kk7ds) | 1-Dec-2022 | Yes | 0.01% |
| <a name="Icom_ID-4100"></a> Icom_ID-4100 | [@n8sqt](https://github.com/n8sqt) | 18-Dec-2022 | Yes | 0.00% |
| <a name="Icom_ID-51"></a> Icom_ID-51 | [Implied by Icom_ID-31A](#user-content-Icom_ID-31A) | 1-Dec-2022 | Yes | 0.02% |
| <a name="Icom_ID-5100"></a> Icom_ID-5100 | [@kk7ds](https://github.com/kk7ds) | 17-Dec-2022 | Yes | 0.00% |
| <a name="Icom_ID-51_Plus"></a> Icom_ID-51_Plus | [Implied by Icom_ID-31A](#user-content-Icom_ID-31A) | 1-Dec-2022 | Yes | 0.02% |
| <a name="Icom_ID-51_Plus2"></a> Icom_ID-51_Plus2 | [Implied by Icom_ID-31A](#user-content-Icom_ID-31A) | 17-Dec-2022 | Yes | 0.00% |
| <a name="Icom_ID-800H_v2"></a> Icom_ID-800H_v2 | [@kk7ds](https://github.com/kk7ds) | 22-Oct-2022 | Yes | 0.01% |
| <a name="Icom_ID-80H"></a> Icom_ID-80H | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/icf.py) | 22-Oct-2022 | Yes | 0.01% |
| <a name="Icom_ID-880H"></a> Icom_ID-880H | [@kk7ds](https://github.com/kk7ds) | 22-Oct-2022 | Yes | 0.02% |
| <a name="Intek_HR-2040"></a> Intek_HR-2040 | [Implied by AnyTone_5888UV](#user-content-AnyTone_5888UV) | 9-Dec-2022 | Yes | 0.02% |
| <a name="Intek_KT-980HP"></a> Intek_KT-980HP | [Implied by Baofeng_BF-F8HP](#user-content-Baofeng_BF-F8HP) | 18-Nov-2022 | Yes | 0.04% |
| <a name="JJCC_JC-8629"></a> JJCC_JC-8629 | [Implied by Radtel_RT-490](#user-content-Radtel_RT-490) | 11-Nov-2023 | Yes |  |
| <a name="Jetstream_JT220M"></a> Jetstream_JT220M | [Implied by Alinco_DR235T](#user-content-Alinco_DR235T) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Jetstream_JT270M"></a> Jetstream_JT270M | [Implied by Jetstream_JT270M](#user-content-Jetstream_JT270M) | 13-Dec-2022 | Yes | 0.01% |
| <a name="Jetstream_JT270MH"></a> Jetstream_JT270MH | [@kk7ds](https://github.com/kk7ds) | 13-Dec-2022 | Yes | 0.01% |
| <a name="Jianpai_8800_Plus"></a> Jianpai_8800_Plus | [Implied by Radtel_RT-490](#user-content-Radtel_RT-490) | 11-Nov-2023 | Yes | 0.01% |
| <a name="KYD_IP-620"></a> KYD_IP-620 |  |  |  | 0.02% |
| <a name="KYD_NC-630A"></a> KYD_NC-630A |  |  |  | 0.02% |
| <a name="Kenwood_HMK"></a> Kenwood_HMK | [Implied by Generic_CSV](#user-content-Generic_CSV) | 4-Dec-2022 |  | 0.00% |
| <a name="Kenwood_ITM"></a> Kenwood_ITM |  |  |  | 0.00% |
| <a name="Kenwood_TH-D7"></a> Kenwood_TH-D7 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/kenwood_live.py) | 12-Dec-2022 | Yes | 0.00% |
| <a name="Kenwood_TH-D72_clone_mode"></a> Kenwood_TH-D72_clone_mode | [@kk7ds](https://github.com/kk7ds) | 28-Nov-2022 | Yes | 0.02% |
| <a name="Kenwood_TH-D72_live_mode"></a> Kenwood_TH-D72_live_mode | [@kk7ds](https://github.com/kk7ds) | 21-Oct-2022 | Yes | 0.00% |
| <a name="Kenwood_TH-D74_clone_mode"></a> Kenwood_TH-D74_clone_mode | [@kk7ds](https://github.com/kk7ds) | 30-Nov-2022 | Yes | 0.00% |
| <a name="Kenwood_TH-D74_live_mode"></a> Kenwood_TH-D74_live_mode | [@kk7ds](https://github.com/kk7ds) | 20-Oct-2022 | Yes | 0.00% |
| <a name="Kenwood_TH-D7G"></a> Kenwood_TH-D7G | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/kenwood_live.py) | 12-Dec-2022 | Yes | 0.00% |
| <a name="Kenwood_TH-F6"></a> Kenwood_TH-F6 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.03% |
| <a name="Kenwood_TH-F7"></a> Kenwood_TH-F7 | [@sv1](https://github.com/sv1) | 19-Oct-2022 | Yes | 0.03% |
| <a name="Kenwood_TH-G71"></a> Kenwood_TH-G71 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/kenwood_live.py) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TH-K2"></a> Kenwood_TH-K2 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/kenwood_live.py) | 12-Dec-2022 | Yes | 0.00% |
| <a name="Kenwood_TK-2140K"></a> Kenwood_TK-2140K | [Implied by Kenwood_TK-3140K](#user-content-Kenwood_TK-3140K) | 2-Feb-2023 | Yes |  |
| <a name="Kenwood_TK-2180"></a> Kenwood_TK-2180 | [@kk7ds](https://github.com/kk7ds) | 4-Dec-2022 | Yes | 0.04% |
| <a name="Kenwood_TK-260"></a> Kenwood_TK-260 |  |  |  | 0.02% |
| <a name="Kenwood_TK-260G"></a> Kenwood_TK-260G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.02% |
| <a name="Kenwood_TK-270"></a> Kenwood_TK-270 |  |  |  | 0.02% |
| <a name="Kenwood_TK-270G"></a> Kenwood_TK-270G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.02% |
| <a name="Kenwood_TK-272"></a> Kenwood_TK-272 |  |  |  | 0.01% |
| <a name="Kenwood_TK-272G"></a> Kenwood_TK-272G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.02% |
| <a name="Kenwood_TK-278"></a> Kenwood_TK-278 |  |  |  | 0.02% |
| <a name="Kenwood_TK-278G"></a> Kenwood_TK-278G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-3140K"></a> Kenwood_TK-3140K | [@kk7ds](https://github.com/kk7ds) | 2-Feb-2023 | Yes |  |
| <a name="Kenwood_TK-3140K2"></a> Kenwood_TK-3140K2 | [Implied by Kenwood_TK-3140K](#user-content-Kenwood_TK-3140K) | 2-Feb-2023 | Yes |  |
| <a name="Kenwood_TK-3140K3"></a> Kenwood_TK-3140K3 | [Implied by Kenwood_TK-3140K](#user-content-Kenwood_TK-3140K) | 2-Feb-2023 | Yes |  |
| <a name="Kenwood_TK-3180K"></a> Kenwood_TK-3180K | [@kk7ds](https://github.com/kk7ds) | 4-Dec-2022 | Yes | 0.03% |
| <a name="Kenwood_TK-3180K2"></a> Kenwood_TK-3180K2 | [Implied by Kenwood_TK-3180K](#user-content-Kenwood_TK-3180K) | 4-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-360"></a> Kenwood_TK-360 |  |  |  | 0.02% |
| <a name="Kenwood_TK-360G"></a> Kenwood_TK-360G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-370"></a> Kenwood_TK-370 |  |  |  | 0.02% |
| <a name="Kenwood_TK-370G"></a> Kenwood_TK-370G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.02% |
| <a name="Kenwood_TK-372"></a> Kenwood_TK-372 |  |  |  | 0.01% |
| <a name="Kenwood_TK-372G"></a> Kenwood_TK-372G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-378"></a> Kenwood_TK-378 |  |  |  | 0.01% |
| <a name="Kenwood_TK-378G"></a> Kenwood_TK-378G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-388G"></a> Kenwood_TK-388G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.00% |
| <a name="Kenwood_TK-7102"></a> Kenwood_TK-7102 | [@kk7ds](https://github.com/kk7ds) | 15-Feb-2019 | Yes | 0.02% |
| <a name="Kenwood_TK-7108"></a> Kenwood_TK-7108 | [@kk7ds](https://github.com/kk7ds) | 15-Feb-2019 | Yes | 0.01% |
| <a name="Kenwood_TK-7160K"></a> Kenwood_TK-7160K | [@kk7ds](https://github.com/kk7ds) | 27-Jan-2023 | Yes |  |
| <a name="Kenwood_TK-7160M"></a> Kenwood_TK-7160M | [Implied by Kenwood_TK-7160K](#user-content-Kenwood_TK-7160K) | 27-Jan-2023 | Yes |  |
| <a name="Kenwood_TK-7180"></a> Kenwood_TK-7180 | [@kk7ds](https://github.com/kk7ds) | 18-Oct-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-7180E"></a> Kenwood_TK-7180E | [Implied by Kenwood_TK-7180](#user-content-Kenwood_TK-7180) | 18-Oct-2022 | Yes | 0.00% |
| <a name="Kenwood_TK-760"></a> Kenwood_TK-760 | [@kk7ds](https://github.com/kk7ds) | 5-Dec-2022 | Yes | 0.02% |
| <a name="Kenwood_TK-760G"></a> Kenwood_TK-760G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.03% |
| <a name="Kenwood_TK-762"></a> Kenwood_TK-762 | [Implied by Kenwood_TK-760](#user-content-Kenwood_TK-760) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-762G"></a> Kenwood_TK-762G | [@kk7ds](https://github.com/kk7ds) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-768"></a> Kenwood_TK-768 | [Implied by Kenwood_TK-760](#user-content-Kenwood_TK-760) | 5-Dec-2022 | Yes | 0.00% |
| <a name="Kenwood_TK-768G"></a> Kenwood_TK-768G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-8102"></a> Kenwood_TK-8102 | [@kk7ds](https://github.com/kk7ds) | 15-Feb-2019 | Yes | 0.02% |
| <a name="Kenwood_TK-8108"></a> Kenwood_TK-8108 | [@kk7ds](https://github.com/kk7ds) | 15-Feb-2019 | Yes | 0.01% |
| <a name="Kenwood_TK-8160K"></a> Kenwood_TK-8160K | [Implied by Kenwood_TK-7160K](#user-content-Kenwood_TK-7160K) | 27-Jan-2023 | Yes |  |
| <a name="Kenwood_TK-8160M"></a> Kenwood_TK-8160M | [Implied by Kenwood_TK-7160K](#user-content-Kenwood_TK-7160K) | 27-Jan-2023 | Yes |  |
| <a name="Kenwood_TK-8180"></a> Kenwood_TK-8180 | [@kk7ds](https://github.com/kk7ds) | 18-Oct-2022 | Yes | 0.02% |
| <a name="Kenwood_TK-8180E"></a> Kenwood_TK-8180E | [Implied by Kenwood_TK-8180](#user-content-Kenwood_TK-8180) | 18-Dec-2022 | Yes | 0.00% |
| <a name="Kenwood_TK-860"></a> Kenwood_TK-860 | [Implied by Kenwood_TK-760](#user-content-Kenwood_TK-760) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-860G"></a> Kenwood_TK-860G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.02% |
| <a name="Kenwood_TK-862"></a> Kenwood_TK-862 | [Implied by Kenwood_TK-760](#user-content-Kenwood_TK-760) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-862G"></a> Kenwood_TK-862G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-868"></a> Kenwood_TK-868 | [Implied by Kenwood_TK-760](#user-content-Kenwood_TK-760) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TK-868G"></a> Kenwood_TK-868G | [Implied by Kenwood_TK-762G](#user-content-Kenwood_TK-762G) | 5-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TM-271"></a> Kenwood_TM-271 | [Implied by Kenwood_TM-281](#user-content-Kenwood_TM-281) | 23-Oct-2022 | Yes | 0.01% |
| <a name="Kenwood_TM-281"></a> Kenwood_TM-281 | [@kk7ds](https://github.com/kk7ds) | 23-Oct-2022 | Yes | 0.02% |
| <a name="Kenwood_TM-471"></a> Kenwood_TM-471 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/kenwood_live.py) | 12-Dec-2022 | Yes | 0.00% |
| <a name="Kenwood_TM-D700"></a> Kenwood_TM-D700 | [@kk7ds](https://github.com/kk7ds) | 20-Oct-2022 | Yes | 0.01% |
| <a name="Kenwood_TM-D710"></a> Kenwood_TM-D710 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/kenwood_live.py) | 22-Oct-2022 | Yes | 0.01% |
| <a name="Kenwood_TM-D710G"></a> Kenwood_TM-D710G | [@kk7ds](https://github.com/kk7ds) | 22-Oct-2022 | Yes | 0.01% |
| <a name="Kenwood_TM-D710G_CloneMode"></a> Kenwood_TM-D710G_CloneMode | [@kk7ds](https://github.com/kk7ds) | 22-Oct-2022 | Yes | 0.00% |
| <a name="Kenwood_TM-D710_CloneMode"></a> Kenwood_TM-D710_CloneMode |  |  | Yes | 0.00% |
| <a name="Kenwood_TM-G707"></a> Kenwood_TM-G707 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/kenwood_live.py) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TM-V7"></a> Kenwood_TM-V7 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/kenwood_live.py) | 12-Dec-2022 | Yes | 0.01% |
| <a name="Kenwood_TM-V71"></a> Kenwood_TM-V71 | [@kk7ds](https://github.com/kk7ds) | 21-Oct-2022 | Yes | 0.04% |
| <a name="Kenwood_TS-2000"></a> Kenwood_TS-2000 | ZS6CRW | 10-Jan-2022 | Yes | 0.03% |
| <a name="Kenwood_TS-480_CloneMode"></a> Kenwood_TS-480_CloneMode |  |  |  | 0.00% |
| <a name="Kenwood_TS-480_LiveMode"></a> Kenwood_TS-480_LiveMode |  |  | Yes | 0.00% |
| <a name="Kenwood_TS-590SG_CloneMode"></a> Kenwood_TS-590SG_CloneMode |  |  |  | 0.00% |
| <a name="Kenwood_TS-590S_CloneMode"></a> Kenwood_TS-590S_CloneMode |  |  |  | 0.00% |
| <a name="Kenwood_TS-590S_SG_LiveMode"></a> Kenwood_TS-590S_SG_LiveMode |  |  | Yes | 0.00% |
| <a name="Kenwood_TS-850"></a> Kenwood_TS-850 |  |  | Yes | 0.00% |
| <a name="LUITON_LT-316"></a> LUITON_LT-316 | [Implied by Retevis_RT22](#user-content-Retevis_RT22) | 9-Dec-2022 | Yes | 0.04% |
| <a name="LUITON_LT-580_UHF"></a> LUITON_LT-580_UHF | [@KC9HI](https://github.com/KC9HI) | 8-Dec-2022 | Yes | 0.01% |
| <a name="LUITON_LT-580_VHF"></a> LUITON_LT-580_VHF | [@KC9HI](https://github.com/KC9HI) | 8-Dec-2022 | Yes | 0.01% |
| <a name="LUITON_LT-588UV"></a> LUITON_LT-588UV | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.01% |
| <a name="LUITON_LT-725UV"></a> LUITON_LT-725UV | [@KC9HI](https://github.com/KC9HI) | 11-Dec-2022 | Yes | 0.02% |
| <a name="Lanchonlh_HG-UV98"></a> Lanchonlh_HG-UV98 |  |  | Yes | 0.00% |
| <a name="Leixen_VV-898"></a> Leixen_VV-898 | [Implied by Jetstream_JT270MH](#user-content-Jetstream_JT270MH) | 13-Dec-2022 | Yes | 0.18% |
| <a name="Leixen_VV-898S"></a> Leixen_VV-898S | [@READ10](https://github.com/READ10) | 19-Dec-2022 | Yes | 0.10% |
| <a name="MMLradio_JC-8629"></a> MMLradio_JC-8629 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2023 | Yes | 0.01% |
| <a name="MTC_UV-5R-3"></a> MTC_UV-5R-3 | [Implied by BTECH_UV-5X3](#user-content-BTECH_UV-5X3) | 9-Dec-2022 | Yes | 0.02% |
| <a name="Maverick_RA-100"></a> Maverick_RA-100 | [@cetinajero](https://github.com/cetinajero) | 7-Jul-2023 | Yes |  |
| <a name="Maverick_RA-425"></a> Maverick_RA-425 | [@cetinajero](https://github.com/cetinajero) | 7-Jul-2023 | Yes |  |
| <a name="Midland_DBR2500"></a> Midland_DBR2500 | [Implied by Retevis_RT95](#user-content-Retevis_RT95) | 13-Nov-2022 | Yes | 0.05% |
| <a name="Polmar_DB-50M"></a> Polmar_DB-50M | [Implied by AnyTone_5888UV](#user-content-AnyTone_5888UV) | 9-Dec-2022 | Yes | 0.03% |
| <a name="Powerwerx_DB-750X"></a> Powerwerx_DB-750X | [Implied by AnyTone_5888UV](#user-content-AnyTone_5888UV) | 9-Dec-2022 | Yes | 0.01% |
| <a name="Puxing_PX-2R"></a> Puxing_PX-2R |  |  |  | 0.05% |
| <a name="Puxing_PX-777"></a> Puxing_PX-777 |  |  | Yes | 0.11% |
| <a name="Puxing_PX-888K"></a> Puxing_PX-888K | [Reported working](https://chirp.danplanet.com/issues/10544) | 09-May-2023 | Yes | 0.07% |
| <a name="Q-MAC_HF-90_v300_or_earlier"></a> Q-MAC_HF-90_v300_or_earlier | [@fthain](https://github.com/fthain) | 9-Mar-2023 | Yes |  |
| <a name="Q-MAC_HF-90_v301_or_later"></a> Q-MAC_HF-90_v301_or_later | [@fthain](https://github.com/fthain) | 9-Mar-2023 | Yes |  |
| <a name="QYT_KT-8R"></a> QYT_KT-8R | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.09% |
| <a name="QYT_KT-UV980"></a> QYT_KT-UV980 | [Implied by WACCOM_MINI-8900](#user-content-WACCOM_MINI-8900) | 11-Nov-2022 | Yes | 0.04% |
| <a name="QYT_KT-WP12"></a> QYT_KT-WP12 | [Implied by Anysecu_WP-9900](#user-content-Anysecu_WP-9900) | 11-Nov-2022 | Yes | 0.02% |
| <a name="QYT_KT5800"></a> QYT_KT5800 | [Implied by BTECH_UV-25X2](#user-content-BTECH_UV-25X2) | 11-Nov-2022 | Yes | 0.01% |
| <a name="QYT_KT7900D"></a> QYT_KT7900D | [Implied by BTECH_UV-25X4](#user-content-BTECH_UV-25X4) | 11-Nov-2022 | Yes | 0.37% |
| <a name="QYT_KT8900"></a> QYT_KT8900 | [Implied by LUITON_LT-588UV](#user-content-LUITON_LT-588UV) | 11-Nov-2022 | Yes | 0.42% |
| <a name="QYT_KT8900D"></a> QYT_KT8900D | [Implied by BTECH_UV-25X2](#user-content-BTECH_UV-25X2) | 11-Nov-2022 | Yes | 0.52% |
| <a name="QYT_KT8900R"></a> QYT_KT8900R | [Implied by BTECH_UV-2501+220](#user-content-BTECH_UV-2501+220) | 11-Nov-2022 | Yes | 0.13% |
| <a name="QYT_KT980PLUS"></a> QYT_KT980PLUS | [Implied by BTECH_UV-25X2](#user-content-BTECH_UV-25X2) | 11-Nov-2022 | Yes | 0.09% |
| <a name="Quansheng_TG-UV2+"></a> Quansheng_TG-UV2+ | [Reported working](https://chirp.danplanet.com/issues/10398) | 26-Feb-2023 | Yes | 0.05% |
| <a name="Quansheng_UV-K5"></a> Quansheng_UV-K5 | [@sq5bpf](https://github.com/sq5bpf) | 29-May-2023 | Yes |  |
| <a name="RT_Systems_CSV"></a> RT_Systems_CSV |  |  |  |  |
| <a name="Radioddity_DB25-G"></a> Radioddity_DB25-G | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.17% |
| <a name="Radioddity_GA-2S"></a> Radioddity_GA-2S | [@KC9HI](https://github.com/KC9HI) | 4-Dec-2022 | Yes | 0.19% |
| <a name="Radioddity_GA-510"></a> Radioddity_GA-510 | [@kk7ds](https://github.com/kk7ds) | 21-Oct-2022 | Yes | 0.42% |
| <a name="Radioddity_GS-5B"></a> Radioddity_GS-5B | [@lunapiercook](https://github.com/lunapiercook) | 5-Mar-2023 | Yes |  |
| <a name="Radioddity_R2"></a> Radioddity_R2 | [@KC9HI](https://github.com/KC9HI) | 17-Dec-2022 | Yes | 0.04% |
| <a name="Radioddity_UV-5G"></a> Radioddity_UV-5G | [@KC9HI](https://github.com/KC9HI) | 18-Nov-2022 | Yes | 0.47% |
| <a name="Radioddity_UV-5RX3"></a> Radioddity_UV-5RX3 | [@KC9HI](https://github.com/KC9HI) | 18-Nov-2022 | Yes | 0.90% |
| <a name="Radioddity_UV-82X3"></a> Radioddity_UV-82X3 | [@KC9HI](https://github.com/KC9HI) | 18-Nov-2022 | Yes | 0.05% |
| <a name="Radtel_RT-470"></a> Radtel_RT-470 | [@KC9HI](https://github.com/KC9HI) | 2-Apr-2023 | Yes | 0.00% |
| <a name="Radtel_RT-470L"></a> Radtel_RT-470L | [@KC9HI](https://github.com/KC9HI) | 5-May-2023 | Yes |  |
| <a name="Radtel_RT-470X"></a> Radtel_RT-470X | [@KC9HI](https://github.com/KC9HI) | 10-Aug-2023 | Yes |  |
| <a name="Radtel_RT-490"></a> Radtel_RT-490 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2023 | Yes | 0.08% |
| <a name="Radtel_T18"></a> Radtel_T18 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.07% |
| <a name="Retevis_H777S"></a> Retevis_H777S | [@KC9HI](https://github.com/KC9HI) | 22-Dec-2022 | Yes |  |
| <a name="Retevis_H777_Plus"></a> Retevis_H777_Plus | [@KC9HI](https://github.com/KC9HI) | 4-Dec-2022 | Yes | 0.06% |
| <a name="Retevis_RA685"></a> Retevis_RA685 | [@KC9HI](https://github.com/KC9HI) | 19-Nov-2022 | Yes | 0.25% |
| <a name="Retevis_RA79"></a> Retevis_RA79 | [@KC9HI](https://github.com/KC9HI) | 27-Oct-2023 | Yes |  |
| <a name="Retevis_RA85"></a> Retevis_RA85 | [@KC9HI](https://github.com/KC9HI) | 19-Nov-2022 | Yes | 0.05% |
| <a name="Retevis_RA89"></a> Retevis_RA89 | [@KC9HI](https://github.com/KC9HI) | 23-Nov-2023 | Yes |  |
| <a name="Retevis_RB15"></a> Retevis_RB15 | [@KC9HI](https://github.com/KC9HI) | 18-Dec-2022 | Yes | 0.01% |
| <a name="Retevis_RB17"></a> Retevis_RB17 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.02% |
| <a name="Retevis_RB17A"></a> Retevis_RB17A | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.01% |
| <a name="Retevis_RB17P"></a> Retevis_RB17P | [@KC9HI](https://github.com/KC9HI) | 18-Dec-2022 | Yes | 0.02% |
| <a name="Retevis_RB17V"></a> Retevis_RB17V | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.01% |
| <a name="Retevis_RB18"></a> Retevis_RB18 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.04% |
| <a name="Retevis_RB19"></a> Retevis_RB19 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.00% |
| <a name="Retevis_RB19P"></a> Retevis_RB19P | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.01% |
| <a name="Retevis_RB23"></a> Retevis_RB23 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.00% |
| <a name="Retevis_RB26"></a> Retevis_RB26 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.04% |
| <a name="Retevis_RB27"></a> Retevis_RB27 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.09% |
| <a name="Retevis_RB27B"></a> Retevis_RB27B | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.02% |
| <a name="Retevis_RB27V"></a> Retevis_RB27V | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.01% |
| <a name="Retevis_RB28"></a> Retevis_RB28 | [@KC9HI](https://github.com/KC9HI) | 9-Feb-2023 | Yes | 0.00% |
| <a name="Retevis_RB28B"></a> Retevis_RB28B | [@KC9HI](https://github.com/KC9HI) | 27-Jan-2023 | Yes |  |
| <a name="Retevis_RB29"></a> Retevis_RB29 | [@KC9HI](https://github.com/KC9HI) | 24-Dec-2022 | Yes | 0.00% |
| <a name="Retevis_RB615"></a> Retevis_RB615 | [@KC9HI](https://github.com/KC9HI) | 18-Dec-2022 | Yes | 0.01% |
| <a name="Retevis_RB617"></a> Retevis_RB617 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.02% |
| <a name="Retevis_RB618"></a> Retevis_RB618 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.16% |
| <a name="Retevis_RB619"></a> Retevis_RB619 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.01% |
| <a name="Retevis_RB627B"></a> Retevis_RB627B | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.05% |
| <a name="Retevis_RB628"></a> Retevis_RB628 | [@KC9HI](https://github.com/KC9HI) | 10-Feb-2023 | Yes |  |
| <a name="Retevis_RB628B"></a> Retevis_RB628B | [@KC9HI](https://github.com/KC9HI) | 28-Jan-2023 | Yes |  |
| <a name="Retevis_RB629"></a> Retevis_RB629 | [@KC9HI](https://github.com/KC9HI) | 24-Dec-2022 | Yes | 0.00% |
| <a name="Retevis_RB75"></a> Retevis_RB75 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.02% |
| <a name="Retevis_RB85"></a> Retevis_RB85 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.02% |
| <a name="Retevis_RB87"></a> Retevis_RB87 | [@KC9HI](https://github.com/KC9HI) | 10-Mar-2023 | Yes |  |
| <a name="Retevis_RT1"></a> Retevis_RT1 | [@KC9HI](https://github.com/KC9HI) | 11-Dec-2022 | Yes | 0.08% |
| <a name="Retevis_RT15"></a> Retevis_RT15 | [@KC9HI](https://github.com/KC9HI) | 18-Feb-2023 | Yes | 0.00% |
| <a name="Retevis_RT16"></a> Retevis_RT16 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.02% |
| <a name="Retevis_RT19"></a> Retevis_RT19 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.00% |
| <a name="Retevis_RT20"></a> Retevis_RT20 | [@k9ps-paul](https://github.com/k9ps-paul) | 7-Sep-2023 | Yes |  |
| <a name="Retevis_RT21"></a> Retevis_RT21 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.20% |
| <a name="Retevis_RT21V"></a> Retevis_RT21V | [@KC9HI](https://github.com/KC9HI) | 24-Jul-2023 | Yes | 0.00% |
| <a name="Retevis_RT22"></a> Retevis_RT22 | [@KC9HI](https://github.com/KC9HI) | 9-Dec-2022 | Yes | 0.53% |
| <a name="Retevis_RT22FRS"></a> Retevis_RT22FRS | [@KC9HI](https://github.com/KC9HI) | 9-Dec-2022 | Yes | 0.04% |
| <a name="Retevis_RT22S"></a> Retevis_RT22S | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.04% |
| <a name="Retevis_RT23"></a> Retevis_RT23 | [@KC9HI](https://github.com/KC9HI) | 17-Dec-2022 | Yes | 0.04% |
| <a name="Retevis_RT24"></a> Retevis_RT24 | [@KC9HI](https://github.com/KC9HI) | 22-Dec-2022 | Yes | 0.31% |
| <a name="Retevis_RT24V"></a> Retevis_RT24V | [@KC9HI](https://github.com/KC9HI) | 27-Aug-2023 | Yes |  |
| <a name="Retevis_RT26"></a> Retevis_RT26 | [@KC9HI](https://github.com/KC9HI) | 17-Dec-2022 | Yes | 0.03% |
| <a name="Retevis_RT29_UHF"></a> Retevis_RT29_UHF | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.03% |
| <a name="Retevis_RT29_VHF"></a> Retevis_RT29_VHF | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.02% |
| <a name="Retevis_RT40B"></a> Retevis_RT40B | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.00% |
| <a name="Retevis_RT47"></a> Retevis_RT47 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.00% |
| <a name="Retevis_RT47V"></a> Retevis_RT47V | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.00% |
| <a name="Retevis_RT6"></a> Retevis_RT6 | [@KC9HI](https://github.com/KC9HI) | 3-Dec-2022 | Yes | 0.04% |
| <a name="Retevis_RT619"></a> Retevis_RT619 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.00% |
| <a name="Retevis_RT622"></a> Retevis_RT622 | [@KC9HI](https://github.com/KC9HI) | 9-Dec-2022 | Yes | 0.09% |
| <a name="Retevis_RT647"></a> Retevis_RT647 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.00% |
| <a name="Retevis_RT668"></a> Retevis_RT668 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.03% |
| <a name="Retevis_RT68"></a> Retevis_RT68 | [@KC9HI](https://github.com/KC9HI) | 28-Nov-2022 | Yes | 0.03% |
| <a name="Retevis_RT76"></a> Retevis_RT76 | [@KC9HI](https://github.com/KC9HI) | 30-Nov-2022 | Yes | 0.02% |
| <a name="Retevis_RT76P"></a> Retevis_RT76P | [@KC9HI](https://github.com/KC9HI) | 17-Dec-2022 | Yes | 0.04% |
| <a name="Retevis_RT85"></a> Retevis_RT85 | [@KC9HI](https://github.com/KC9HI) | 5-Dec-2022 | Yes | 0.22% |
| <a name="Retevis_RT86"></a> Retevis_RT86 | [@KC9HI](https://github.com/KC9HI) | 17-Feb-2023 | Yes |  |
| <a name="Retevis_RT87"></a> Retevis_RT87 | [@KC9HI](https://github.com/KC9HI) | 17-Dec-2022 | Yes | 0.03% |
| <a name="Retevis_RT9000D_136-174"></a> Retevis_RT9000D_136-174 | [@KC9HI](https://github.com/KC9HI) | 8-Dec-2022 | Yes | 0.01% |
| <a name="Retevis_RT9000D_220-260"></a> Retevis_RT9000D_220-260 | [@KC9HI](https://github.com/KC9HI) | 8-Dec-2022 | Yes | 0.01% |
| <a name="Retevis_RT9000D_400-490"></a> Retevis_RT9000D_400-490 | [@KC9HI](https://github.com/KC9HI) | 8-Dec-2022 | Yes | 0.01% |
| <a name="Retevis_RT9000D_66-88"></a> Retevis_RT9000D_66-88 | [@KC9HI](https://github.com/KC9HI) | 8-Dec-2022 | Yes | 0.00% |
| <a name="Retevis_RT95"></a> Retevis_RT95 | [@KC9HI](https://github.com/KC9HI) | 13-Nov-2022 | Yes | 0.08% |
| <a name="Retevis_RT95_VOX"></a> Retevis_RT95_VOX | [Implied by Retevis_RT95](#user-content-Retevis_RT95) | 13-Nov-2022 | Yes | 0.15% |
| <a name="Retevis_RT98"></a> Retevis_RT98 | [@KC9HI](https://github.com/KC9HI) | 14-Dec-2022 | Yes | 0.05% |
| <a name="Rugged_RH5R-V2"></a> Rugged_RH5R-V2 |  |  |  | 0.05% |
| <a name="Ruyage_UV58Plus"></a> Ruyage_UV58Plus | [@KC9HI](https://github.com/KC9HI) | 18-Mar-2023 | Yes |  |
| <a name="Sainsonic_AP510"></a> Sainsonic_AP510 |  |  |  | 0.00% |
| <a name="SenhaiX_8800"></a> SenhaiX_8800 | [Implied by Radioddity_GS-5B](#user-content-Radioddity_GS-5B) | 17-Mar-2023 | Yes |  |
| <a name="Socotran_FB-8629"></a> Socotran_FB-8629 | [Implied by Radtel_RT-490](#user-content-Radtel_RT-490) | 11-Nov-2023 | Yes | 0.00% |
| <a name="Socotran_JC-8629"></a> Socotran_JC-8629 | [Implied by Radtel_RT-490](#user-content-Radtel_RT-490) | 11-Nov-2023 | Yes |  |
| <a name="TDXone_TD-Q8A"></a> TDXone_TD-Q8A | [@KC9HI](https://github.com/KC9HI) | 18-Dec-2022 |  | 0.02% |
| <a name="TIDRADIO_TD-H3"></a> TIDRADIO_TD-H3 | [@songjunbiao](https://github.com/songjunbiao) | 1-Dec-2023 | Yes |  |
| <a name="TIDRADIO_TD-H3-GMRS"></a> TIDRADIO_TD-H3-GMRS | [@songjunbiao](https://github.com/songjunbiao) | 1-Dec-2023 | Yes |  |
| <a name="TIDRADIO_TD-H3-HAM"></a> TIDRADIO_TD-H3-HAM | [@songjunbiao](https://github.com/songjunbiao) | 1-Dec-2023 | Yes |  |
| <a name="TIDRADIO_TD-H6"></a> TIDRADIO_TD-H6 | [@kk7ds](https://github.com/kk7ds) | 21-Oct-2022 | Yes | 0.43% |
| <a name="TIDRADIO_TD-H8"></a> TIDRADIO_TD-H8 | [@Sandmann34](https://github.com/Sandmann34) | 7-Feb-2023 | Yes |  |
| <a name="TIDRADIO_TD-H8-GMRS"></a> TIDRADIO_TD-H8-GMRS | [@Sandmann34](https://github.com/Sandmann34) | 7-Feb-2023 | Yes |  |
| <a name="TIDRADIO_TD-H8-HAM"></a> TIDRADIO_TD-H8-HAM | [@Sandmann34](https://github.com/Sandmann34) | 7-Feb-2023 | Yes |  |
| <a name="TID_TD-M8"></a> TID_TD-M8 | [Implied by Retevis_RT22](#user-content-Retevis_RT22) | 9-Dec-2022 | Yes | 0.04% |
| <a name="TID_TD-UV68"></a> TID_TD-UV68 | [@Sandmann34](https://github.com/Sandmann34) | 7-Feb-2023 | Yes |  |
| <a name="TYT_TH-350"></a> TYT_TH-350 |  |  | Yes | 0.07% |
| <a name="TYT_TH-7800"></a> TYT_TH-7800 | [Reported working](https://chirp.danplanet.com/issues/10585) | 4-Jul-2023 | Yes | 0.13% |
| <a name="TYT_TH-7800_File"></a> TYT_TH-7800_File |  |  |  | 0.00% |
| <a name="TYT_TH-9800"></a> TYT_TH-9800 | [Reported working](https://chirp.danplanet.com/issues/10755) | 30-Jul-2023 | Yes | 0.65% |
| <a name="TYT_TH-9800_File"></a> TYT_TH-9800_File |  |  | Yes | 0.00% |
| <a name="TYT_TH-UV3R"></a> TYT_TH-UV3R |  |  | Yes | 0.04% |
| <a name="TYT_TH-UV3R-25"></a> TYT_TH-UV3R-25 |  |  | Yes | 0.02% |
| <a name="TYT_TH-UV8000"></a> TYT_TH-UV8000 | [@KC9HI](https://github.com/KC9HI) | 6-Jan-2023 | Yes | 0.31% |
| <a name="TYT_TH-UV88"></a> TYT_TH-UV88 | [@KC9HI](https://github.com/KC9HI) | 5-Dec-2022 | Yes | 0.51% |
| <a name="TYT_TH-UVF1"></a> TYT_TH-UVF1 | [@kk7ds](https://github.com/kk7ds) | 13-Dec-2022 | Yes | 0.06% |
| <a name="TYT_TH-UVF8D"></a> TYT_TH-UVF8D | [@MELERIX](https://github.com/MELERIX) | 2-Feb-2023 | Yes | 0.05% |
| <a name="TYT_TH9000_144"></a> TYT_TH9000_144 | [Implied by Retevis_RT9000D_136-174](#user-content-Retevis_RT9000D_136-174) | 8-Dec-2022 | Yes | 0.06% |
| <a name="TYT_TH9000_220"></a> TYT_TH9000_220 | [Implied by Retevis_RT9000D_220-260](#user-content-Retevis_RT9000D_220-260) | 8-Dec-2022 | Yes | 0.04% |
| <a name="TYT_TH9000_440"></a> TYT_TH9000_440 | [Implied by Retevis_RT9000D_400-490](#user-content-Retevis_RT9000D_400-490) | 8-Dec-2022 | Yes | 0.04% |
| <a name="Talkpod_A36plus"></a> Talkpod_A36plus | [@KC9HI](https://github.com/KC9HI) | 12-Jun-2023 | Yes |  |
| <a name="Vertex_Standard_FTL-1011"></a> Vertex_Standard_FTL-1011 |  |  |  | 0.02% |
| <a name="Vertex_Standard_FTL-2011"></a> Vertex_Standard_FTL-2011 |  |  |  | 0.05% |
| <a name="Vertex_Standard_FTL-7011"></a> Vertex_Standard_FTL-7011 |  |  |  | 0.03% |
| <a name="Vertex_Standard_FTL-8011"></a> Vertex_Standard_FTL-8011 |  |  |  | 0.01% |
| <a name="Vertex_Standard_VXA-700"></a> Vertex_Standard_VXA-700 |  |  |  | 0.02% |
| <a name="WACCOM_MINI-8900"></a> WACCOM_MINI-8900 | [@KC9HI](https://github.com/KC9HI) | 11-Nov-2022 | Yes | 0.12% |
| <a name="WLN_KD-C1"></a> WLN_KD-C1 | [Implied by Retevis_RT22](#user-content-Retevis_RT22) | 9-Dec-2022 | Yes | **1.73%** |
| <a name="Wouxun_KG-1000G"></a> Wouxun_KG-1000G | [@mrtjr1](https://github.com/mrtjr1) | 23-jan-2023 | Yes |  |
| <a name="Wouxun_KG-1000G_Plus"></a> Wouxun_KG-1000G_Plus | [@mrtjr1](https://github.com/mrtjr1) | 23-jan-2023 | Yes | 0.00% |
| <a name="Wouxun_KG-816"></a> Wouxun_KG-816 | [Implied by Wouxun_KG-UV6](#user-content-Wouxun_KG-UV6) | 11-Dec-2022 | Yes | 0.07% |
| <a name="Wouxun_KG-818"></a> Wouxun_KG-818 | [Implied by Wouxun_KG-UV6](#user-content-Wouxun_KG-UV6) | 11-Dec-2022 | Yes | 0.04% |
| <a name="Wouxun_KG-935G"></a> Wouxun_KG-935G | [@mrtjr1](https://github.com/mrtjr1) | 4-Jan-2022 | Yes | 0.05% |
| <a name="Wouxun_KG-935G_Plus"></a> Wouxun_KG-935G_Plus | [@mrtjr1](https://github.com/mrtjr1) | 7-Feb-2023 | Yes |  |
| <a name="Wouxun_KG-UV6"></a> Wouxun_KG-UV6 | [@KC9HI](https://github.com/KC9HI) | 11-Dec-2022 | Yes | 0.19% |
| <a name="Wouxun_KG-UV8D"></a> Wouxun_KG-UV8D | Unit tested; needs confirm | 24-Dec-2022 | Yes | 0.24% |
| <a name="Wouxun_KG-UV8D_Plus"></a> Wouxun_KG-UV8D_Plus | Unit tested; needs confirm | 2-Jan-2022 | Yes | 0.08% |
| <a name="Wouxun_KG-UV8E"></a> Wouxun_KG-UV8E | W5EGL | 2-Jan-2022 | Yes | 0.05% |
| <a name="Wouxun_KG-UV8H"></a> Wouxun_KG-UV8H | [@mrtjr1](https://github.com/mrtjr1) | 27-Mar-2023 | Yes | 0.01% |
| <a name="Wouxun_KG-UV920P-A"></a> Wouxun_KG-UV920P-A | [@KC9HI](https://github.com/KC9HI) | 22-Dec-2022 | Yes | 0.04% |
| <a name="Wouxun_KG-UV980P"></a> Wouxun_KG-UV980P | [@mrtjr1](https://github.com/mrtjr1) | 23-jan-2023 | Yes | 0.01% |
| <a name="Wouxun_KG-UV9D_Plus"></a> Wouxun_KG-UV9D_Plus | [@samwich](https://github.com/samwich) | 10-Jan-2023 | Yes | 0.39% |
| <a name="Wouxun_KG-UV9GX"></a> Wouxun_KG-UV9GX | [@mrtjr1](https://github.com/mrtjr1) | 27-Mar-2023 | Yes |  |
| <a name="Wouxun_KG-UV9G_Pro"></a> Wouxun_KG-UV9G_Pro | [@mrtjr1](https://github.com/mrtjr1) | 25-Apr-2023 | Yes |  |
| <a name="Wouxun_KG-UV9K"></a> Wouxun_KG-UV9K | [@mrtjr1](https://github.com/mrtjr1) | 14-Apr-2023 | Yes |  |
| <a name="Wouxun_KG-UV9PX"></a> Wouxun_KG-UV9PX | [@mrtjr1](https://github.com/mrtjr1) | 20-Jan-2022 | Yes |  |
| <a name="Wouxun_KG-UVD1P"></a> Wouxun_KG-UVD1P | [Implied by Wouxun_KG-UV6](#user-content-Wouxun_KG-UV6) | 11-Dec-2022 | Yes | 0.35% |
| <a name="Yaesu_FT-1500M"></a> Yaesu_FT-1500M | [@f3sty](https://github.com/f3sty) | 05-Dec-2022 | Yes | 0.02% |
| <a name="Yaesu_FT-1802M"></a> Yaesu_FT-1802M |  |  | Yes | 0.02% |
| <a name="Yaesu_FT-1D_R"></a> Yaesu_FT-1D_R | [Implied by Yaesu_FT3D_R](#user-content-Yaesu_FT3D_R) | 30-Dec-2022 | Yes | 0.03% |
| <a name="Yaesu_FT-25R"></a> Yaesu_FT-25R | [Implied by Yaesu_FT-4XE](#user-content-Yaesu_FT-4XE) | 24-Dec-2022 | Yes | 0.01% |
| <a name="Yaesu_FT-2800M"></a> Yaesu_FT-2800M | [Reported working](https://chirp.danplanet.com/issues/10616) | 05-Jun-2023 | Yes | 0.03% |
| <a name="Yaesu_FT-2900R_1900R"></a> Yaesu_FT-2900R_1900R | [Reported working](https://chirp.danplanet.com/issues/10274) | 14-Jan-2023 | Yes | 0.05% |
| <a name="Yaesu_FT-2900R_1900RTXMod_Opened_Xmit"></a> Yaesu_FT-2900R_1900RTXMod_Opened_Xmit | [Implied by Yaesu_FT-2900R_1900R](#user-content-Yaesu_FT-2900R_1900R) | 14-Jan-2023 | Yes |  |
| <a name="Yaesu_FT-450"></a> Yaesu_FT-450 | [@WCurlew](https://github.com/WCurlew) | 03-Nov-2023 | Yes |  |
| <a name="Yaesu_FT-450D"></a> Yaesu_FT-450D | [@Old-Phart](https://github.com/Old-Phart) | 01-Jun-2023 | Yes | 0.01% |
| <a name="Yaesu_FT-4VR"></a> Yaesu_FT-4VR | [Implied by Yaesu_FT-4XE](#user-content-Yaesu_FT-4XE) | 24-Dec-2022 | Yes | 0.01% |
| <a name="Yaesu_FT-4XE"></a> Yaesu_FT-4XE | Unit tested; needs confirm | 24-Dec-2022 | Yes | 0.14% |
| <a name="Yaesu_FT-4XR"></a> Yaesu_FT-4XR | [Implied by Yaesu_FT-4XE](#user-content-Yaesu_FT-4XE) | 24-Dec-2022 | Yes | 0.11% |
| <a name="Yaesu_FT-50"></a> Yaesu_FT-50 | [Reported working](https://chirp.danplanet.com/issues/10824) | 5-Sep-2023 | Yes | 0.04% |
| <a name="Yaesu_FT-60"></a> Yaesu_FT-60 | N0EYE | 9-Jan-2023 | Yes | 0.49% |
| <a name="Yaesu_FT-65E"></a> Yaesu_FT-65E | [@kwirk](https://github.com/kwirk) | 27-Jan-2023 | Yes | 0.08% |
| <a name="Yaesu_FT-65R"></a> Yaesu_FT-65R | [Reported working](https://chirp.danplanet.com/issues/10266) | 13-Jan-2022 | Yes | 0.18% |
| <a name="Yaesu_FT-70D"></a> Yaesu_FT-70D | [@n8sqt](https://github.com/n8sqt) | 05-Dec-2022 | Yes | 0.27% |
| <a name="Yaesu_FT-7100M"></a> Yaesu_FT-7100M |  |  | Yes | 0.03% |
| <a name="Yaesu_FT-7800_7900"></a> Yaesu_FT-7800_7900 | [@kk7ds](https://github.com/kk7ds) | 24-Oct-2022 | Yes | 0.14% |
| <a name="Yaesu_FT-8100"></a> Yaesu_FT-8100 | [Reported working](https://chirp.danplanet.com/issues/10904) | 19-Oct-2023 | Yes | 0.01% |
| <a name="Yaesu_FT-817"></a> Yaesu_FT-817 | [@kk7ds](https://github.com/kk7ds) | 14-Feb-2019 | Yes | 0.04% |
| <a name="Yaesu_FT-817ND"></a> Yaesu_FT-817ND | [Implied by Yaesu_FT-817](#user-content-Yaesu_FT-817) | 14-Feb-2019 | Yes | 0.07% |
| <a name="Yaesu_FT-817ND_US"></a> Yaesu_FT-817ND_US | [Implied by Yaesu_FT-817](#user-content-Yaesu_FT-817) | 14-Feb-2019 | Yes | 0.02% |
| <a name="Yaesu_FT-818"></a> Yaesu_FT-818 | [@thomasrussellmurphy](https://github.com/thomasrussellmurphy) | 4-Feb-2023 | Yes | 0.05% |
| <a name="Yaesu_FT-818ND_US"></a> Yaesu_FT-818ND_US | [Implied by Yaesu_FT-817](#user-content-Yaesu_FT-817) | 14-Feb-2019 | Yes | 0.02% |
| <a name="Yaesu_FT-857_897"></a> Yaesu_FT-857_897 | [Implied by Yaesu_FT-817](#user-content-Yaesu_FT-817) | 14-Feb-2019 | Yes | 0.25% |
| <a name="Yaesu_FT-857_897_US"></a> Yaesu_FT-857_897_US | [Implied by Yaesu_FT-817](#user-content-Yaesu_FT-817) | 14-Feb-2019 | Yes | 0.08% |
| <a name="Yaesu_FT-8800"></a> Yaesu_FT-8800 | [@kk7ds](https://github.com/kk7ds) | 24-Oct-2022 | Yes | 0.08% |
| <a name="Yaesu_FT-8900"></a> Yaesu_FT-8900 | [Reported working](https://chirp.danplanet.com/issues/10753) | 30-Jul-2023 | Yes | 0.11% |
| <a name="Yaesu_FT-90"></a> Yaesu_FT-90 | [Reported working](https://chirp.danplanet.com/issues/10386) | 22-Feb-2023 | Yes | 0.02% |
| <a name="Yaesu_FT2D_R"></a> Yaesu_FT2D_R | [Implied by Yaesu_FT3D_R](#user-content-Yaesu_FT3D_R) | 30-Dec-2022 | Yes | 0.02% |
| <a name="Yaesu_FT2D_Rv2"></a> Yaesu_FT2D_Rv2 | [Implied by Yaesu_FT3D_R](#user-content-Yaesu_FT3D_R) | 30-Dec-2022 | Yes |  |
| <a name="Yaesu_FT3D_R"></a> Yaesu_FT3D_R | [@kk7ds](https://github.com/kk7ds) | 30-Dec-2022 | Yes | 0.03% |
| <a name="Yaesu_FTM-3200D_R"></a> Yaesu_FTM-3200D_R |  |  | Yes | 0.02% |
| <a name="Yaesu_FTM-350"></a> Yaesu_FTM-350 | [@kk7ds](https://github.com/kk7ds) | 4-Dec-2022 | Yes | 0.02% |
| <a name="Yaesu_FTM-7250D_R"></a> Yaesu_FTM-7250D_R |  |  | Yes | 0.04% |
| <a name="Yaesu_VX-170"></a> Yaesu_VX-170 |  |  | Yes | 0.03% |
| <a name="Yaesu_VX-2"></a> Yaesu_VX-2 | [@thomasrussellmurphy](https://github.com/thomasrussellmurphy) | 20-Jan-2023 | Yes | 0.04% |
| <a name="Yaesu_VX-3"></a> Yaesu_VX-3 | [@kk7ds](https://github.com/kk7ds) | 15-Feb-2019 | Yes | 0.08% |
| <a name="Yaesu_VX-5"></a> Yaesu_VX-5 | [Probably works](https://github.com/kk7ds/chirp/blob/py3/chirp/drivers/yaesu_clone.py) | 12-Dec-2022 | Yes | 0.07% |
| <a name="Yaesu_VX-6"></a> Yaesu_VX-6 | [@dominickpastore](https://github.com/dominickpastore) | 10-Dec-2022 | Yes | 0.16% |
| <a name="Yaesu_VX-7"></a> Yaesu_VX-7 | [@kk7ds](https://github.com/kk7ds) | 15-Feb-2019 | Yes | 0.09% |
| <a name="Yaesu_VX-8DR"></a> Yaesu_VX-8DR | [@kk7ds](https://github.com/kk7ds) | 15-Feb-2019 | Yes | 0.03% |
| <a name="Yaesu_VX-8GE"></a> Yaesu_VX-8GE | [Implied by Yaesu_VX-8DR](#user-content-Yaesu_VX-8DR) | 15-Feb-2019 | Yes | 0.01% |
| <a name="Yaesu_VX-8R"></a> Yaesu_VX-8R | [Implied by Yaesu_VX-8DR](#user-content-Yaesu_VX-8DR) | 15-Feb-2019 | Yes | 0.03% |
| <a name="Yedro_YC-M04VUS"></a> Yedro_YC-M04VUS | [Implied by Retevis_RT95](#user-content-Retevis_RT95) | 13-Nov-2022 | Yes | 0.02% |
| <a name="Zastone_ZT-X6"></a> Zastone_ZT-X6 | [Implied by Retevis_RT22](#user-content-Retevis_RT22) | 9-Dec-2022 | Yes | 0.11% |
## Stats

**Drivers:** 441

**Tested:** 87% (388/53) (93% of usage stats)

**Byte clean:** 90% (401/40)

## Meaning of this testing

The goal here is not necessarily to test the drivers themselves in terms of
actual functionality, but rather to validate the Python 3 conversion
work required of nearly all drivers. Thus, we are not trying to
comprehensively test these models so much as make sure they work at least
as well as they do on the Python 2 branch. Uncovering and reporting new
bugs is definitely welcome, but for the purpoes of this effort, "no worse
than the legacy branch" is good enough. There are multiple levels of
confirmation in the matrix above:
* Tested with real hardware (i.e. a person listed in the "Tester" column)
  using roughly the procedure below.
* An "implied by (model)" link means that another model was tested, and it
  is so similar, that the model on that line can be considered tested as
  well.
* A "probably works" link means that the driver has not been tested with
  real hardware, nor is it substantially similar to another model, but
  shares a common base that entirely provides the cloning routines with
  other drivers that have been tested with real hardware, such that
  confidence is high that it will work. Only drivers with test images in
  the tree (or live drivers) should be marked with this class.
* A "unit tested" link means that the driver has not been tested with
  real hardware, nor does it share common cloning routines with another
  radio. However, synthetic simulation tests have been added to exercise
  the parts of the cloning routines that are likely to fail under python3.
  This is the lowest-confidence status and a real confirmation is needed.

If you have a model listed in this matrix with either "implied" or
"probably works" status, an actual confirmation with real hardware is
welcome and can replace the weaker reference.

## Minimal test procedure
For the purposes of the Python 3 effort, a "tested" radio means
at least the following procedure was followed:
1. Download from the radio
1. Make some change to a memory
1. If the radio has settings support, make sure settings load and tweak
   one setting
1. Upload to the radio
1. Confirm that the changes stick and look correct, or at least are not a
   regression from the master py2 branch.

The drivers are all passing the automated tests, but tests with real
hardware and serial ports is important, especially around bytes-vs-string
safety.

To update this document, add/edit entries in `tests/py3_driver_testers.txt`
and then run `tox -e makesupported`. Commit the result (including the
changes to this `.md` file) and submit a PR.

The "Byte Clean" flag refers to whether or not the radio has set the
`NEEDS_COMPAT_SERIAL = False` flag on the radio class, and thus uses
`MemoryMapBytes` exclusively internally. Whenever possible, all radios
that are fixed for py3 should do so with this flag set to False and with
the byte-native memory map.
