char codeversion[] = VERSION;
