Unit Tests for TLP
==================
Tests cover only part of the functionality of TLP.
For objectives see the individual files.

Prequisites
-----------
Software
^^^^^^^^
Tests are executed with the tool
`clitest <https://github.com/aureliojargas/clitest>`_.

Hardware
^^^^^^^^
Unit tests must be run on real hardware, not in a virtual machine or container.
See the individual files for hardware details.
