@see:
http://code.google.com/p/json-smart/