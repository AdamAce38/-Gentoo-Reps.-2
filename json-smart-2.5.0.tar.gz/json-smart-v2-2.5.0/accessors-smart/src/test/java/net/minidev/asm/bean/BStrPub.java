package net.minidev.asm.bean;

public class BStrPub {
	public String value;
}
