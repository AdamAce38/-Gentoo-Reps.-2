package net.minidev.asm.bean;

public class BBoolPriv {
	private boolean value;

	public boolean isValue() {
		return value;
	}

	public void setValue(boolean value) {
		this.value = value;
	}
}
