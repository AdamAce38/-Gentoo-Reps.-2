package net.minidev.asm.bean;

public class BObjectPriv {
	private Object value;

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}
}
