package net.minidev.asm.bean;

public enum TEnum {
	V1, V2, V3
}
