package net.minidev.asm.bean;

public class BObjectPub {
	public Object value;
}
