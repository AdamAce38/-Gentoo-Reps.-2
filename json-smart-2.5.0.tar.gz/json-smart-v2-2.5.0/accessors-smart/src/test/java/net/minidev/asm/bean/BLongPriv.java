package net.minidev.asm.bean;

public class BLongPriv {
	private Long value;

	public Long getValue() {
		return value;
	}

	public void setValue(Long value) {
		this.value = value;
	}
}
