package net.minidev.asm.bean;

public class BEnumPriv {
	private TEnum value;

	public TEnum getValue() {
		return value;
	}

	public void setValue(TEnum value) {
		this.value = value;
	}
}
