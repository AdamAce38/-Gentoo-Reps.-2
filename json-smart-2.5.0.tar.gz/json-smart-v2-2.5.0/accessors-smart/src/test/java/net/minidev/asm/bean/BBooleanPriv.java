package net.minidev.asm.bean;

public class BBooleanPriv {
	private Boolean value;

	public Boolean getValue() {
		return value;
	}

	public void setValue(Boolean value) {
		this.value = value;
	}
}
