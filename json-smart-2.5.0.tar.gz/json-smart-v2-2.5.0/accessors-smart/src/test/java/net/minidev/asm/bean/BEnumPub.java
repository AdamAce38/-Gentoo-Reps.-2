package net.minidev.asm.bean;

public class BEnumPub {
	public TEnum value;
}
