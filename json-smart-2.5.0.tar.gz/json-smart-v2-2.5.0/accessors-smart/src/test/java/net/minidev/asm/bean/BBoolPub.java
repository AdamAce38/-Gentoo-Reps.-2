package net.minidev.asm.bean;

public class BBoolPub {
	public boolean value;
}
