package net.minidev.asm.bean;

public class BBooleanPub {
	public Boolean value;
}
