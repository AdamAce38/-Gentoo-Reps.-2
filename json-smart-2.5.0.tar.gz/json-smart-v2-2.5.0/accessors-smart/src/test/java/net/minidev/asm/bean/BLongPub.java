package net.minidev.asm.bean;

public class BLongPub {
	public Long value;
}
