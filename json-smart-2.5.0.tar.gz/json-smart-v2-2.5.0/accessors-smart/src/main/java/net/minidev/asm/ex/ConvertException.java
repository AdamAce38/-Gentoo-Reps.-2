package net.minidev.asm.ex;

public class ConvertException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public ConvertException() {
		super();
	}

	public ConvertException(String message) {
		super(message);
	}

}
