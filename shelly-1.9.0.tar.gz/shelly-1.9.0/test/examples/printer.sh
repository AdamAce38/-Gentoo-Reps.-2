#!/bin/sh

while true; do
  echo "hello"
  sleep 1
done
