// No-op Javascript counter placeholder.
document.write(" Counter zapped. ");
