// Counter Javascript placeholder.
document.write(" Counter zapped. ");
