// No-op Javascript placeholder.
document.write(" This ad zapped. ");
