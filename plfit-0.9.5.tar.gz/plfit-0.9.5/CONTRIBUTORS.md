# Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tr>
    <td align="center"><img src="https://avatars.githubusercontent.com/u/195637?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Tamás Nepusz</b></sub><br /><a href="https://github.com/ntamas/plfit/commits?author=ntamas" title="Code">💻</a></td>
    <td align="center"><a href="http://szhorvat.net/"><img src="https://avatars.githubusercontent.com/u/1212871?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Szabolcs Horvát</b></sub></a><br /><a href="https://github.com/ntamas/plfit/commits?author=szhorvat" title="Code">💻</a></td>
    <td align="center"><a href="https://www.rezozer.net/"><img src="https://avatars.githubusercontent.com/u/8476716?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Jérôme Benoit</b></sub></a><br /><a href="https://github.com/ntamas/plfit/commits?author=jgmbenoit" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/dotlambda"><img src="https://avatars.githubusercontent.com/u/6806011?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Robert Schütz</b></sub></a><br /><a href="https://github.com/ntamas/plfit/commits?author=dotlambda" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/Biswa96"><img src="https://avatars.githubusercontent.com/u/31443074?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Biswapriyo Nath</b></sub></a><br /><a href="https://github.com/ntamas/plfit/commits?author=Biswa96" title="Code">💻</a></td>
    <td align="center"><a href="https://michael.orlitzky.com/"><img src="https://avatars.githubusercontent.com/u/1432135?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Michael Orlitzky</b></sub></a><br /><a href="https://github.com/ntamas/plfit/commits?author=orlitzky" title="Code">💻</a></td>
  </tr>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!
