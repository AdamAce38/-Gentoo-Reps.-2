# Changelog

## [2.9.4.1]
### [Added]
- Nix stuff

### [Changed]
- Fix haddock by removing stray TODOs
- Change CHANGELOG format

## [2.9.4]
- Initial release
