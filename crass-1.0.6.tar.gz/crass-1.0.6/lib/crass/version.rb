# encoding: utf-8

module Crass
  VERSION = '1.0.6'
end
