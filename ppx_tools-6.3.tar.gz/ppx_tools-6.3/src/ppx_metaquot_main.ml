let () = Ppx_metaquot.Main.main ()
