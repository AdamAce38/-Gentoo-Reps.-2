security
========

Please report security vulnerabilities via e-mail, you can optionally
PGP-encrypt them:

 https://schokokeks.org/kontakt
