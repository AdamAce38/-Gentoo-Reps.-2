# Copyright (C) 2010-2021 Sebastian Pipping <sebastian@pipping.org>
# Licensed under GPL v3 or later

VERSION = (1, 7, 1)
VERSION_STR = '.'.join(str(e) for e in VERSION)
