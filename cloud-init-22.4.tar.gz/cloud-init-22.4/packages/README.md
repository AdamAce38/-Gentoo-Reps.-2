# packages

Package builders under this folder are development only templates. Do not rely on them.

Downstream packaging resources:

* [debian](https://packages.debian.org/sid/cloud-init)
* [fedora](https://src.fedoraproject.org/rpms/cloud-init)
* [opensuse](https://build.opensuse.org/package/show/Cloud:Tools/cloud-init)
* [ubuntu](https://launchpad.net/cloud-init)
