.. include:: ../../../CONTRIBUTING.rst
.. vi: textwidth=79
