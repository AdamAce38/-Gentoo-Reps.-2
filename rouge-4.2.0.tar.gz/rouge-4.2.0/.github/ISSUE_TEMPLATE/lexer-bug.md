---
name: Lexer bug
about: Tell us about the lexer bug
title: ''
labels: bugfix-request
assignees: ''

---

**Name of the lexer**
The name of the lexer with the bug.

**Code sample**
A sample of the code that produces the bug.

```
<insert code>
```

It also helps if you can provide a link to a code sample on [rouge.jneen.net][dingus].

**Additional context**
Add any other context about the problem here.

[dingus]: http://rouge.jneen.net/
