# v0.11

Drop dependency on Base.

# v0.10

Initial release
