# SPDX-License-Identifier: WTFPL
# SPDX-FileCopyrightText: 2022 Anna <cyber@sysrq.in>
# No warranty

""" Gentoo Metadata XML generator """

__version__ = "0.4.0"
