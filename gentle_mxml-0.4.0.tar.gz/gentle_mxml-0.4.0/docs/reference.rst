.. SPDX-FileCopyrightText: 2023 Anna <cyber@sysrq.in>
.. SPDX-License-Identifier: WTFPL
.. No warranty.

API Reference
=============

.. autosummary::
    :toctree: api
    :recursive:

    gentle
