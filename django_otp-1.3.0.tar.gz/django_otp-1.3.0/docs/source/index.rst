.. include:: ../../README.rst
   :end-before: .. end-of-doc-intro

Contents
--------

.. toctree::
    :maxdepth: 3

    overview
    auth
    extend
    contributing
    changes


License
-------

.. include:: ../../LICENSE
