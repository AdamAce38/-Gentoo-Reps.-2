from django.apps import AppConfig


class DefaultConfig(AppConfig):
    name = 'django_otp.plugins.otp_hotp'
    default_auto_field = 'django.db.models.AutoField'
