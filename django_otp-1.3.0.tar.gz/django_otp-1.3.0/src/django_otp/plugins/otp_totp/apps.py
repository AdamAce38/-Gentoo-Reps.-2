from django.apps import AppConfig


class DefaultConfig(AppConfig):
    name = 'django_otp.plugins.otp_totp'
    default_auto_field = 'django.db.models.AutoField'
