# frozen_string_literal: true

require 'rmagick_internal.rb'
