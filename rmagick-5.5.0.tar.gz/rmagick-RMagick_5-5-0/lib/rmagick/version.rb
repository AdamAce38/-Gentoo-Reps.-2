# frozen_string_literal: true

module Magick
  VERSION = '5.5.0'
  MIN_RUBY_VERSION = '2.3.0'
  MIN_IM_VERSION = '6.7.7'
end
