# 1.2.5.3 August 2022

* Tested with GHC 7.0 - 9.4.1.
* Remove remnants of GHC 6.x support.
* Silence incomplete pattern matching warning, refactor code.
* Add section about limitations to README.

# 1.2.5.2 November 2021

* Tested with GHC 7.0 - 9.2.
* Silence warning caused by missing `other-modules` in cabal file.
* Add README and CHANGELOG to dist.

# 1.2.5.1 July 2019

No changelog for this and earlier versions.
