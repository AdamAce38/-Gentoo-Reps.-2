#!/usr/bin/python3
from setuptools import setup

setup()
