Title
=====

.. tabbed:: Tab 1

    Tab 1 content

.. tabbed:: Tab 2
    :class-content: pl-1 bg-primary

    Tab 2 content

.. tabbed:: Tab 3
    :new-group:

    Tab 3 content

    .. code-block:: python

        import pip

.. tabbed:: Tab 4
    :selected:

    Tab 4 content
