Title
=====

.. dropdown:: My Content
    :container: + shadow
    :title: bg-primary text-white text-center font-weight-bold
    :body: bg-light text-right font-italic

    Is formatted

.. dropdown:: Fade In
    :animate: fade-in-slide-down

    Content
