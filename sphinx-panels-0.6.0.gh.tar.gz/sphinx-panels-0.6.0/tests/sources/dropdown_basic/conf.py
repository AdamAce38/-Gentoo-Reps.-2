extensions = ["sphinx_panels"]
