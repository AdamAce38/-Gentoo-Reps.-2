=======
Authors
=======

* David Runge <dave@sleepmap.de>
* Dmitry S. Baikov <c0ff@konstruktiv.org>
* Juuso Alasuutari has copyright ownership on some D-Bus related code, taken from other projects (lash, jackdbus).
* Nedko Arnaudov <nedko@arnaudov.name>
* Paul Davis <paul@linuxaudiosystems.com>
* Torben Hohn <torbenh@gmx.de>
