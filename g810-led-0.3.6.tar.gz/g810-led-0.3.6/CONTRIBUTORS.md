# g810-led - CONTRIBUTORS (alpha order) :</br>

## [andreast1990](https://github.com/andreast1990) :
* Add Wireshark dump for g910

## [barul42](https://github.com/barul42) :
* Improve INSTALL.MD

## [carlba](https://github.com/carlba) :
* Improve install file

## [CReimer](https://github.com/CReimer) :
* Add Wireshark dump for g910 M and G keys
* Debug hidapi missing keys on certain computer

## [dkolosa](https://github.com/dkolosa) :
* Provide alternative productid for g910

## [francoisfreitag](https://github.com/francoisfreitag) :
* Refactor makefile (hard work)

## [hschreck](https://github.com/hschreck) :
* Fix typo

## [jdagerbo](https://github.com/jdagerbo) :
* Refactor many of the code (very hard work)

## [Landrovan](https://github.com/Landrovan) :
* Improve support of G410 (two times)

## [larsnaesbye](https://github.com/larsnaesbye) :
* Fix typo

## [lynix](https://github.com/lynix) :
* Improve makefile

## [matthunz](https://github.com/matthunz) :
* Improve INSTALL.MD for ArchLinux

## [MohamadSaada](https://github.com/MohamadSaada) :
* Add poweron effect bytes for g910
* Debug setKeys (hard work)

## [noisycat](https://github.com/noisycat) :
* Add wireshark dump effects
* Improve makefile

## [pearsonk](https://github.com/pearsonk) :
* Add g213 protocol (very hard work)
* Add support of g213
* Implement underlying device IO as a shared library
* Add multiple keyboard support (very hard work)

## [wextia](https://github.com/wextia) :
* Fixed incorrect markdown formatting in README.md
