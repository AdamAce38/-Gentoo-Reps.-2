using System.Reflection;
// Version 2.4.1; year 2018+1, month 5, day 3
[assembly: AssemblyVersion("2.4.1.10503")]
[assembly: AssemblyFileVersion("2.4.1.10503")]
