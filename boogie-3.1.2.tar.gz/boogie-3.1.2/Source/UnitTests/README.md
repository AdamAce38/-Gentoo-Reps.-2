Unit testing infrastructure
===========================

Boogie uses the [NUnit](http://www.nunit.org/) unit testing framework.
We currently use NUnit 3.12.0.

Run the tests as follows:

```
$ dotnet test Source/Boogie.sln
```

NUnit tests can also be run within most IDEs, like Visual Studio and
MonoDevelop.
