module Bench = Bench

module Core_bench_private = struct
  module Simplified_benchmark = Simplified_benchmark (* needed by core_bench/comparison *)
end
