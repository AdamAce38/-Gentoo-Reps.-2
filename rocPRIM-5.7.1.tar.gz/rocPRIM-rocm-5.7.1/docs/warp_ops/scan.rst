Scan
----

.. doxygenclass:: rocprim::warp_scan
   :members:
