Exchange
--------

.. doxygenclass:: rocprim::warp_exchange
   :members:
