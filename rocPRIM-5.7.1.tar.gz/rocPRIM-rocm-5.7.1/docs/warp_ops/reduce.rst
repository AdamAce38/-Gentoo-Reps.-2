Reduce
------

.. doxygenclass:: rocprim::warp_reduce
   :members:
