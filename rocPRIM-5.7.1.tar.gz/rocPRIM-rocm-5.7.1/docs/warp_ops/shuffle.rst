Shuffle
-------

.. doxygenfunction:: rocprim::warp_shuffle (const T &input, const int src_lane, const int width)
.. doxygenfunction:: rocprim::warp_shuffle_down (const T &input, const unsigned int delta, const int width)
.. doxygenfunction:: rocprim::warp_shuffle_xor (const T &input, const int lane_mask, const int width)
