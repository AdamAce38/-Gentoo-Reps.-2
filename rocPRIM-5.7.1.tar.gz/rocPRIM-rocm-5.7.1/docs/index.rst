+++++++++++++++++++++++
 rocPRIM Documentation 
+++++++++++++++++++++++

``rocPRIM`` is a header-only library providing HIP parallel primitives to ease the maintainability of performant and yet portable GPU-accelerated code on AMD ROCm platform.

Acknowledgements
================

The following contributors helped to make this documentation better:

* `v01dXYZ <https://github.com/v01dXYZ>`_ has proposed a new structure for the documentation.
