Adjacent difference
~~~~~~~~~~~~~~~~~~~

.. doxygenclass:: rocprim::block_adjacent_difference
   :members:
