Exchange
~~~~~~~~

.. doxygenclass:: rocprim::block_exchange
   :members:
