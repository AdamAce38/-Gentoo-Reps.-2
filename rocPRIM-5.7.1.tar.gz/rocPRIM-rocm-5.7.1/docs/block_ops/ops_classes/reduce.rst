Reduce
~~~~~~

Class
.....

.. doxygenclass:: rocprim::block_reduce
   :members:

Algorithms
..........

.. doxygenenum:: rocprim::block_reduce_algorithm
