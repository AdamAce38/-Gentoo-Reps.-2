Scan
~~~~

Class
.....

.. doxygenclass:: rocprim::block_scan
   :members:

Algorithms
..........

.. doxygenenum:: rocprim::block_scan_algorithm
