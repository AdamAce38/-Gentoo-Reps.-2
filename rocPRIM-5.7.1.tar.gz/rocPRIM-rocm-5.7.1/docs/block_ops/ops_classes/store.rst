Store
~~~~~

Class
.....

.. doxygenclass:: rocprim::block_store
   :members:

Algorithms
..........

.. doxygenenum:: rocprim::block_store_method
