Shuffle
~~~~~~~

.. doxygenclass:: rocprim::block_shuffle
   :members:
