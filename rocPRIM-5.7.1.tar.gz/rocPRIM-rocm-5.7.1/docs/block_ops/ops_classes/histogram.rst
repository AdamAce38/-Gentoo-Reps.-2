Histogram
~~~~~~~~~
Class
.....

.. doxygenclass:: rocprim::block_histogram
   :members:

Algorithms
..........

.. doxygenenum:: rocprim::block_histogram_algorithm
