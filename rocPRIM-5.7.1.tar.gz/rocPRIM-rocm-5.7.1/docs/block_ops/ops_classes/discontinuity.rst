Discontinuity
~~~~~~~~~~~~~

.. doxygenclass:: rocprim::block_discontinuity
   :members:
