Operation classes
-----------------

.. toctree::
   load
   store

   adjacent_difference
   discontinuity

   scan
   reduce

   shuffle
   exchange
   sort

   histogram
