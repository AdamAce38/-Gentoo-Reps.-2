Block-Wide Operations
=====================

.. toctree::
   ops_classes/index
   data_mov_funcs
