Binary Search
-------------

.. doxygenfunction:: rocprim::binary_search(void *temporary_storage, size_t &storage_size, HaystackIterator haystack, NeedlesIterator needles, OutputIterator output, size_t haystack_size, size_t needles_size, CompareFunction compare_op=CompareFunction(), hipStream_t stream=0, bool debug_synchronous=false)
