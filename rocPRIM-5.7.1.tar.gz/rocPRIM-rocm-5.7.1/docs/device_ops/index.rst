Device-Wide Operations
======================

.. toctree::
   :maxdepth: 6

   config

   transform
   unique
   sort
   merge
   partition
   run_length_encoding
   scan
   select
   reduce
   adjacent_difference
   binary_search
   histogram
