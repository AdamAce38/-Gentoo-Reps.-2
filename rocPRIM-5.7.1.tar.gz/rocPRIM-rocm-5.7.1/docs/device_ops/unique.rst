Unique
------

unique
~~~~~~

.. doxygenfunction:: rocprim::unique(void *, size_t &, InputIterator, OutputIterator, UniqueCountOutputIterator, const size_t, EqualityOp, const hipStream_t, const bool)

unique_by_key
~~~~~~~~~~~~~

.. doxygenfunction:: rocprim::unique_by_key(void *, size_t &, const KeyIterator, const ValueIterator, const OutputKeyIterator, const OutputValueIterator, const UniqueCountOutputIterator, const size_t, const EqualityOp, const hipStream_t, const bool)

