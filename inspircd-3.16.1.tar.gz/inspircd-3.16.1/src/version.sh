#!/bin/sh
echo "InspIRCd-3.16.1"
