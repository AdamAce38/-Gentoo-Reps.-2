kiwisolver
==========

.. toctree::
   :maxdepth: 2

   Python API <python.rst>
   C++ API <cpp.rst>
