require 'stringio.jar'
JRuby::Util.load_ext("org.jruby.ext.stringio.StringIOLibrary")
