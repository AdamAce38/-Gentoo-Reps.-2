______________________________________________________________________

## name: Bug report about: Create a report to help us improve

<!--- Description --->

<!--- Can you list steps to reproduce this issue? --->

<!--- Can you, if possible, please attach a minimum notebook that reproduces this issue on conversion?
You may need to attach the .ipynb as a .txt --->

<!--- Can you attach screenshots if relevant? --->

<!--- Are you running the latest version of nbconvert? --->

**Nbconvert version:**
