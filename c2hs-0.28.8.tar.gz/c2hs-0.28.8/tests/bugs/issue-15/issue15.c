const int tst_val(void)
{
  return 'drag';
}
