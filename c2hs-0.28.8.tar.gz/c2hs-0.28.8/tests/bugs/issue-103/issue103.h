typedef enum {
  E_1,
  E_2,
  E_3
} test_enum;

void test_func(test_enum val);
