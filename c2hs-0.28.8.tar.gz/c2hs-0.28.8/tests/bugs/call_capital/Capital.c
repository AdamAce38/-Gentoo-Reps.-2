#include "Capital.h"
#include <stdio.h>
void c() { printf("lower c();\n"); }
void C() { printf("upper C();\n"); }
