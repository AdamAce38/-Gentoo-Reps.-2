enum foo {
  A = 1,
  B = 2,
  C = 2,
  D = 3
};
