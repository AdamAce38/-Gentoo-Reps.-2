typedef struct _ptr1 { int a; } ptr1;
void f1(ptr1 *p, int x);

typedef struct _ptr2 { int a; } ptr2;
void f2(ptr2 *p, int x);

typedef struct _ptr3 { int a; } ptr3;
void f3(ptr3 *p, int x);
