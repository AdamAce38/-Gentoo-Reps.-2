#include "issue140.h"

void f1(ptr1 *p, int x) { p->a = x; }
void f2(ptr2 *p, int x) { p->a = x; }
void f3(ptr3 *p, int x) { p->a = x; }
