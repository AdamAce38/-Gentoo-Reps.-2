struct a { int f; };

typedef struct a s_a;
