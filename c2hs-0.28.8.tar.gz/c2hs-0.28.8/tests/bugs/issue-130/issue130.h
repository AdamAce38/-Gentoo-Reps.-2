void my_add(int *a, int *b, int *result);
