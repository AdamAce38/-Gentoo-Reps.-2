#include <sys/types.h>

int64_t foo(int64_t n);
