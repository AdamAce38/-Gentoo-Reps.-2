void foo1(int);
void foo2(int);
