void foo1(int n) { }
void foo2(int n) { }
