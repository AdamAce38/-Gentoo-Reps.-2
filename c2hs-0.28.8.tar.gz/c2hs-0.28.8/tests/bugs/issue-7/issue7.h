void foo ();
