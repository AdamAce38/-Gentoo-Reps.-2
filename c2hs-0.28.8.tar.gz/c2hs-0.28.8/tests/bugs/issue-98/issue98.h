char identichar(char c);
unsigned char identiuchar(unsigned char c);
signed char identischar(signed char c);
