typedef struct {
    int x;
    int y;
} foo_t;

void simple_func(foo_t *f);
