#include "issue96.h"

void simple_func(foo_t *f) { }
