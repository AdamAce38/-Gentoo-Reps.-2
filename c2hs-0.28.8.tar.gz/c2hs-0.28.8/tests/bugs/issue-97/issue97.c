/* foo.c */
#include "issue97.h"

int foo_x(foo_t *f) {
    return f->x;
}
