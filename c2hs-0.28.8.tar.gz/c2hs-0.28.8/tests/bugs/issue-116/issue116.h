typedef enum {
  E_1,
  E_2,
  E_3,
  TOTAL_ENUM_COUNT
} test_enum;
