#include <stdlib.h>

size_t foo(int n)
{
  return n * sizeof(int);
}
