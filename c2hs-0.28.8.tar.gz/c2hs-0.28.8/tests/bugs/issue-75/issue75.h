struct CHK_TST { int a; };

typedef struct CHK_TST CHK_TST;

CHK_TST *chk_make_tst(void);
