#include "issue10.h"

size_t size_of_s1(void) { return sizeof(S1); }
size_t size_of_s2(void) { return sizeof(S2); }
size_t size_of_s3(void) { return sizeof(S3); }
size_t size_of_s4(void) { return sizeof(S4); }
size_t size_of_s5(void) { return sizeof(S5); }
