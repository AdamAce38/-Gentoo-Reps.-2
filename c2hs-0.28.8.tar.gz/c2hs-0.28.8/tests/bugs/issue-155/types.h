typedef struct {
  int a;
} example_struct;

typedef struct {
  int b;
} child_struct;
