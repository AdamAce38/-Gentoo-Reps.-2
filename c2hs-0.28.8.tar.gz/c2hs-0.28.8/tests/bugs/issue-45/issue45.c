void foo(int n) { }
