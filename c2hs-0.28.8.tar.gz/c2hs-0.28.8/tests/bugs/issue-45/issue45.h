void foo(int);
