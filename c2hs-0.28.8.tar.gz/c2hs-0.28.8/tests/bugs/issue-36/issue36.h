typedef struct { int a; } hit_int;
typedef struct { double a; } hit_double;
