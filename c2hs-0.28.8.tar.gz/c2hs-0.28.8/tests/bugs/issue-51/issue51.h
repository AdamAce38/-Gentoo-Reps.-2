int fooGnu(int);
int fooNonGnu(int);
