enum Test1 {
  TEST1_A,
  TEST1_B,
  TEST1_C = 5,
  TEST1_D
};

enum {
  ANON_A = 8,
  ANON_B,
  ANON_C = 15,
  ANON_D
};

