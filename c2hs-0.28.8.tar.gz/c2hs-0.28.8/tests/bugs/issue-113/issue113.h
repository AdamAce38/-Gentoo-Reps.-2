enum annoying { annoying_0 };
