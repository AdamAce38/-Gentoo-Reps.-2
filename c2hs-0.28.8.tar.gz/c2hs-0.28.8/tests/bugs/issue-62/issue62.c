#include "issue62.h"

int f1(int x, int y, int z) {
  return 0;
}

int f2(int x, int* y, int* z) {
  return 0;
}
