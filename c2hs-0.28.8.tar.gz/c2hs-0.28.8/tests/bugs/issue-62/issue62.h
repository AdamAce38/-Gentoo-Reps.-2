/* @(#)issue62.h
 */

#ifndef _ISSUE62_H_
#define _ISSUE62_H_

int f1(int x, int y, int z);
int f2(int x, int* y, int* z);

#endif /* _ISSUE62_H_ */

