enum Foo {
  BAR,
  BAZ,
  QUX = 5,
  XYZZY_THUD
};
