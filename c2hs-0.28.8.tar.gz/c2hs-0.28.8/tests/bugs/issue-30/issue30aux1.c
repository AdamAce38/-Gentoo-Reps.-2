int foo1(int n) { return n * 2; }
