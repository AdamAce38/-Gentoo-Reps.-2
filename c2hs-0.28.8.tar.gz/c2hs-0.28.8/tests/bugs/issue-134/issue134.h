struct tst { int a; };

int tst(int, int);
