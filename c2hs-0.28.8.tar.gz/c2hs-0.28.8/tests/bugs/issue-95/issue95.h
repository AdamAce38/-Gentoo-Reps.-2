struct foo {
  int x;
  int y;
  int z;
};
