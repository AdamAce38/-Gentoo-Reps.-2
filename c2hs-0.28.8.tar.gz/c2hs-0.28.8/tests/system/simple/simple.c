#include <stdio.h>

void foo () {
  printf ("I am the mighty foo!\n");
}
