#include <stdlib.h>

#include "enums.h"

enum colour colourOfSide (side aside)
{
  /* not executed, but needed for linking */
  abort ();
}
