Authors
=======

`Oleg Pidsadnyi <oleg.pidsadnyi@gmail.com>`_
    original idea, initial implementation and further improvements
`Anatoly Bubenkov <bubenkoff@gmail.com>`_
    key implementation idea and realization, many new features and improvements

These people have contributed to `pytest-bdd`, in alphabetical order:

* `Adam Coddington <me@adamcoddington.net>`_
* `Albert-Jan Nijburg <albertjan@curit.com>`_
* `Alessio Bogon <youtux>`_
* `Andrey Makhnach <andrey.makhnach@gmail.com>`_
* `Aron Curzon <curzona@gmail.com>`_
* `Dmitrijs Milajevs <dimazest@gmail.com>`_
* `Dmitry Kolyagin <pauk-slon>`_
* `Florian Bruhin <me@the-compiler.org>`_
* `Floris Bruynooghe <flub@devork.be>`_
* `Harro van der Klauw <hvdklauw@gmail.com>`_
* `Hugo van Kemenade <https://github.com/hugovk>`_
* `Laurence Rowe <l@lrowe.co.uk>`_
* `Leonardo Santagada <santagada@github.com>`_
* `Milosz Sliwinski <sliwinski-milosz>`_
* `Michiel Holtkamp <github@elfstone.nl>`_
* `Robin Pedersen <ropez@github.com>`_
* `Sergey Kraynev <sergejyit@gmail.com>`_
