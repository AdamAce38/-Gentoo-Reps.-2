from __future__ import annotations

import pytest
from packaging.utils import Version

# We leave this here for the future as an easy way to do feature-based testing.
PYTEST_VERSION = Version(pytest.__version__)
