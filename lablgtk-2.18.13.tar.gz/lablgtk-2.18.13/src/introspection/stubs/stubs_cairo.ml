type -'a obj

module RectangleInt = struct
  end
module Path = struct
  end
module ScaledFont = struct
  end
module FontFace = struct
  end
module FontType = struct
  end
module FontOptions = struct
  end
module Region = struct
  end
module Pattern = struct
  end
module Matrix = struct
  end
module Surface = struct
  end
module Context = struct
  end
(* Global functions *)
external image_surface_create: unit -> unit = "ml_cairo_image_surface_create"
(* End of global functions *)

