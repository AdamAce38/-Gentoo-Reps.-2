// Copyright (c) Tailscale Inc & AUTHORS
// SPDX-License-Identifier: BSD-3-Clause

//go:build !go1.21

package tailscale

func init() {
	you_need_Go_1_21_to_compile_Tailscale()
}
