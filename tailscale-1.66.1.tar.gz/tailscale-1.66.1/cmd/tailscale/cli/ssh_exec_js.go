// Copyright (c) Tailscale Inc & AUTHORS
// SPDX-License-Identifier: BSD-3-Clause

package cli

import (
	"errors"
)

func findSSH() (string, error) {
	return "", errors.New("Not implemented")
}

func execSSH(ssh string, argv []string) error {
	return errors.New("Not implemented")
}
