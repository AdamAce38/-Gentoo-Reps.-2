# SPDX-License-Identifier: ISC
# Copyright (c) Lucas Hoffmann

from afew.commands import main

main()
