# SPDX-License-Identifier: ISC
# Copyright (c) 2013 Patrick Gerken <do3cc@patrick-gerken.de>
