#
import unittest

from afew import utils


class TestUtils(unittest.TestCase):
    pass


if __name__ == '__main__':
    unittest.main()
