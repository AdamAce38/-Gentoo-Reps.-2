void thru(),toKana(),nulcmd(),flthru(),thruToAsc();
void toAsc(),iKanaV(),iKanaC(),tglK();
void toZenA(),iZenAl(),iZenEx(),kanaBS();
void kfthru(),kZenAl(),kZenEx(),kKanaV(),kKanaC(),fxthru(),selIt();
void okKanaV(),okKanaC(),cancelOkuri(),okuriBS();
void kkBeg(),kkBegC(),kkBegV(),kfFix(),kkconv(),fixIt(),kfCancel(),cancelSel();
void nxCand(),pvCand(),kOkuri(),kfBS(),kfFixToAsc(),kfFixToZenA(),kfFixThru();
void okfFix(),okfFixToAsc(),okfFixToZenA(),okfFixThru();
void thruKfFixToAsc(),thruOkfFixToAsc(),thruFixItToAsc();
void kkBegA(),kalpha(),kaBS();
void inputCode(),enterCode(),cancelCode(),codein(),inputbslash();
void stPrefixCv(),stSuffix();
void toEsc(),thruToEsc(),thruKfFixToEsc(),thruOkfFixToEsc(),thruFixItToEsc();
void thruBack(),thru1();
void h2kkana(),hira2kata();

KeymapPtr convertKeymap();
