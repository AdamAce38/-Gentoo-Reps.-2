/*
 * Configuration for Ultrix 4.4 (MIPS)
 */

#define BSD		/* My machine is BSD-like system */
#define NO_USLEEP	/* My machine has no usleep() */
/*#define TERMIOS*/	/* Has but only partial */

#define HAVE_SETENV	/* My machine has setenv() */
