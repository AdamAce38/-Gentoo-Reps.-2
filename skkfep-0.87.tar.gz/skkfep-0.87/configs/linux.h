/*
 * config file for Linux (0.99.12)
 */

#define LINUX
#define SYSV
#define TERMIOS

#define HAVE_SETENV
#define NO_VFORK

#define HAVE_SETREUID
