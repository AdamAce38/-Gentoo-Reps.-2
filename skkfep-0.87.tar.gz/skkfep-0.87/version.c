char *version = "0.87 by A.ITO, WATANABE,M. and KANEKO,Y.";
