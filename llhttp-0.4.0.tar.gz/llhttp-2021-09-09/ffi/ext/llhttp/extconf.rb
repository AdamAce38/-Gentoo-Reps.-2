# frozen_string_literal: true

require "mkmf"

dir_config("llhttp_ext")
create_makefile("llhttp_ext")
