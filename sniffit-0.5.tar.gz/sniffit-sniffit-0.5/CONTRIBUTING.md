## HOW TO CONTRIBUTE TO SNIFFIT DEVELOPMENT

Sniffit is available at https://github.com/resurrecting-open-source-projects/sniffit

If you are interested in contribute to sniffit development, please, follow
these steps:

1. Send me a patch that fix an issue or that implement a new feature.
   Alternatively, you can do a 'pull request'[1] in GitHub.

   [1] https://help.github.com/articles/using-pull-requests

2. Ask for join to the Sniffit project in GitHub, if you want to work
   officially. Note that this second step is not compulsory. However,
   to accept you in project, I need a minimum collaboration before. You
   can do easy works, as fix compilatiion warnings.

If you want to join, please contact me: eriberto at eriberto.pro.br

  -- Eriberto, Tue, 15 Nov 2016 09:40:21 -0200
