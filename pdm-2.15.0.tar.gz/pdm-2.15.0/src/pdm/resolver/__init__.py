from pdm.resolver.core import resolve

__all__ = ["resolve"]
