import sys


def main():
    print(sys.executable)
    print(sys.version)
    print(sys.base_prefix)
    print(sys.prefix)


if __name__ == "__main__":
    main()
