
# pcre-light library

A small, efficient and portable regex library for Perl 5 compatible regular expressions

The PCRE library is a set of functions that implement regular
expression pattern matching using the same syntax and semantics as Perl 5.

## Authorship

This library was originally written by Donald Stewart.
