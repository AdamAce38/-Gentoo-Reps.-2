bfs_diff -d basic
