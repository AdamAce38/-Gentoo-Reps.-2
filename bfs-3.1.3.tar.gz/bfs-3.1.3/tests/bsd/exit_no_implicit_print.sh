bfs_diff basic -not -name foo -o -exit
