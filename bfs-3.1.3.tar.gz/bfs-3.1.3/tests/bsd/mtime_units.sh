bfs_diff times -mtime +500w400d300h200m100s
