! bfs_diff -X weirdnames
