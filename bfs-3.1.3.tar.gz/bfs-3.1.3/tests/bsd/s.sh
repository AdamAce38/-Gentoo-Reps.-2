invoke_bfs -s weirdnames -maxdepth 1 >"$OUT"
diff_output
