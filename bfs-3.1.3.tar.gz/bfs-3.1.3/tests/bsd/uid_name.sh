bfs_diff basic -uid "$(id -un)"
