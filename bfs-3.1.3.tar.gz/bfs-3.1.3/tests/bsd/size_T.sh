bfs_diff basic -type f -size 1T
