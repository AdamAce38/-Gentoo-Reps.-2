cd weirdnames
bfs_diff -f '-' -f '('
