bfs_diff basic -depth +1 -depth -4
