bfs_diff basic -depth -4294967296
