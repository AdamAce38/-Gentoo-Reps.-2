bfs_diff basic \( -sparse -not -sparse \) -o \( -sparse -o -not -sparse \)
