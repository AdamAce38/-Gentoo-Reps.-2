bfs_diff times -asince 1991-12-14T00:01
