bfs_diff basic -gid "$(id -gn)"
