bfs_diff times -msince 1991-12-14T00:01
