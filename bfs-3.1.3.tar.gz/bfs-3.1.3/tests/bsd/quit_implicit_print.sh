bfs_diff basic -name basic -o -quit
