cd weirdnames
bfs_diff -E . -regex '\./(\()'
