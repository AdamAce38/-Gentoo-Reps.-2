bfs_diff basic -depth -depth -2
