bfs_diff basic -depth +2
