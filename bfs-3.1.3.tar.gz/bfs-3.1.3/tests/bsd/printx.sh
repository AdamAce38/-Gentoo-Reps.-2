bfs_diff weirdnames -printx
