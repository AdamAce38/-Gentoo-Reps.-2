bfs_diff basic/g -print -name g -quit
