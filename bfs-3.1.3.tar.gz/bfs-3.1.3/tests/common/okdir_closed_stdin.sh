bfs_diff basic -okdir echo {} \; <&-
