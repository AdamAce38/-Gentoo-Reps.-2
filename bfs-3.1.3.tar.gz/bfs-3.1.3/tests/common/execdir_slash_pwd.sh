bfs_diff / -maxdepth 0 -execdir pwd \;
