bfs_diff links -follow
