bfs_diff basic -maxdepth 2 -depth
