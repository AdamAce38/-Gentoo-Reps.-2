bfs_diff basic -regex 'basic/./.'
