! invoke_bfs basic -maxdepth
