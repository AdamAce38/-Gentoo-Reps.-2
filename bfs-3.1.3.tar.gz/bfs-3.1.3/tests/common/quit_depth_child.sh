bfs_diff basic/g -depth -print -name h -quit
