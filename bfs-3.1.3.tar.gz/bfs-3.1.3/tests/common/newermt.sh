bfs_diff times -newermt 1991-12-14T00:01 \
               -newermt "1991-12-14 01:01+01:00" \
               -newermt "19911213 20:31:00-0330"
