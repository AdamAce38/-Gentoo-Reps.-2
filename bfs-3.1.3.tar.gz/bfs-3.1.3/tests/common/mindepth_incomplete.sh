! invoke_bfs basic -mindepth
