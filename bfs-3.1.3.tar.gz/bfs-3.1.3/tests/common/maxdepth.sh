bfs_diff basic -maxdepth 1
