bfs_diff basic -inum "$(inum basic/k/foo/bar)"
