bfs_diff basic -ok echo \; <&-
