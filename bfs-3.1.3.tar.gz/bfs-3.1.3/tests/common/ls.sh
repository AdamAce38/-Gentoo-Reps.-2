invoke_bfs rainbow -ls >"$OUT"
