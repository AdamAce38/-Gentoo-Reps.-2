bfs_diff -L links -samefile links/notdir
