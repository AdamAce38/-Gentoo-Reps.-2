bfs_diff basic -iregex 'basic/[A-Z]/[a-z]'
