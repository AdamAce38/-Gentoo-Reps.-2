bfs_diff -H links -samefile links/symlink
