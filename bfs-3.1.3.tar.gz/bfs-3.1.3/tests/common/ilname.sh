invoke_bfs -quit -ilname PATTERN || skip
bfs_diff links -ilname '[AQ]'
