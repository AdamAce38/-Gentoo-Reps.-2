bfs_diff times -newerma times/a
