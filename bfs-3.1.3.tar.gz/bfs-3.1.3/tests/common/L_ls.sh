invoke_bfs -L rainbow -ls >"$OUT"
