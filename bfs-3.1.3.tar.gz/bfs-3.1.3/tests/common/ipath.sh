invoke_bfs -quit -ipath PATTERN || skip
bfs_diff basic -ipath 'basic/*F*'
