bfs_diff basic -mindepth 2 -depth
