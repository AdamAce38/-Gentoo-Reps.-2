bfs_diff basic/g -depth -print -name g -quit
