bfs_diff -L links -lname '[aq]'
