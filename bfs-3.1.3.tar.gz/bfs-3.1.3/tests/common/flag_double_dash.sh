cd basic
bfs_diff -L -- . -type f
