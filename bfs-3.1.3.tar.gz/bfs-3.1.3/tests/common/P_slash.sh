bfs_diff -P links/deeply/nested/dir/
