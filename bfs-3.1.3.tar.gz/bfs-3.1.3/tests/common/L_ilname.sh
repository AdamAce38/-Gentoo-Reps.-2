invoke_bfs -quit -ilname PATTERN || skip
bfs_diff -L links -ilname '[AQ]'
