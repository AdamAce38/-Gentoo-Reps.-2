bfs_diff links -lname '[aq]'
