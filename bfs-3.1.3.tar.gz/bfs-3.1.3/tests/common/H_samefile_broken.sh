bfs_diff -H links -samefile links/broken
