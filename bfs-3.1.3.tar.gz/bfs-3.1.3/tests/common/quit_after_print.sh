bfs_diff basic basic -print -quit
