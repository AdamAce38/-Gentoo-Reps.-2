cd weirdnames
bfs_diff . -regex '\./\((\)'
