bfs_diff times -newermt 1969-12-31T23:59:59Z
