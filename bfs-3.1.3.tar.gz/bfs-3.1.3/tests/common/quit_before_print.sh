bfs_diff basic basic -quit -print
