bfs_diff links -samefile links/file
