bfs_diff basic/g -print -name h -quit
