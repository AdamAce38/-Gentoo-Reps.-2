bfs_diff basic -mindepth 1 -depth
