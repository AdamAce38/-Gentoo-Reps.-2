cd basic
bfs_diff -- . -type f
