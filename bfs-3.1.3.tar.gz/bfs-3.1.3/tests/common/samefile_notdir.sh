bfs_diff links -samefile links/notdir
