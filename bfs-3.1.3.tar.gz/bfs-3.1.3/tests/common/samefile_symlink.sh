bfs_diff links -samefile links/symlink
