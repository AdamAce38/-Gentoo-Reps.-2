bfs_diff basic -depth -exclude -name foo
