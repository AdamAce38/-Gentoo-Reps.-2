bfs_diff rainbow -color
