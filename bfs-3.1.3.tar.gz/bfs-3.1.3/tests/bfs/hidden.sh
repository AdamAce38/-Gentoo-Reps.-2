bfs_diff weirdnames -hidden
