# Regression test: don't segfault on LS_COLORS="*"
! LS_COLORS="*" invoke_bfs rainbow -color
