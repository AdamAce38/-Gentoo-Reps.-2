LS_COLORS="no=01;92:" bfs_diff rainbow -color
