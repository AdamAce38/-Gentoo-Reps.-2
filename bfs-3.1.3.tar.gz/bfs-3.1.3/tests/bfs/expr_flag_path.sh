bfs_diff -type l -H links/skip
