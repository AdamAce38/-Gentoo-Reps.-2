bfs_pty basic -status -print -depth 0 -exec stty cols 123 rows 14 \; >"$OUT"
