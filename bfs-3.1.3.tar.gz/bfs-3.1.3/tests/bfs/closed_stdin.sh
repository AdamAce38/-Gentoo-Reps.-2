bfs_diff basic <&-
