LS_COLORS="st=00:tw=00:ow=00:" bfs_diff rainbow -color
