! invoke_bfs links -links
