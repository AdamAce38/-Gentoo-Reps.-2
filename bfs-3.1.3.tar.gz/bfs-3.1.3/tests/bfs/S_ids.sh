invoke_bfs -S ids -s basic >"$OUT"
diff_output
