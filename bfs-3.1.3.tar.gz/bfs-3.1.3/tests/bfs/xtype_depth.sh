# Make sure -xtype is considered side-effecting for facts_when_impure
! invoke_bfs loops -xtype l -depth 100
