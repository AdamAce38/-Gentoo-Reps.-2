bfs_diff basic -exclude -name foo
