bfs_diff -D all basic
