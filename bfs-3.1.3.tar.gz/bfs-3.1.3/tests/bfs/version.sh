invoke_bfs -version >/dev/null
