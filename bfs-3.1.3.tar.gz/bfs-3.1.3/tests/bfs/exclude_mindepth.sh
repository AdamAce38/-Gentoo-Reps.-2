bfs_diff basic -mindepth 3 -exclude -name foo
