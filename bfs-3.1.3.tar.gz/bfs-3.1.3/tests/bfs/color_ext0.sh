LS_COLORS="*.txt=00:" bfs_diff rainbow -color
