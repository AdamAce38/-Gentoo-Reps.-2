bfs_diff -O1 basic -not \( -type f -not -type f \)
