! invoke_bfs -$'\xFF'
