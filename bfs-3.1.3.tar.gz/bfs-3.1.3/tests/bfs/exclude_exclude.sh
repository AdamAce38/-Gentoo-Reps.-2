! invoke_bfs basic -exclude -exclude -name foo
