bfs_diff -D opt,tree,unknown basic
