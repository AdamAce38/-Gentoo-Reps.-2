bfs_diff -O0 basic -not \( -type f -not -type f \)
