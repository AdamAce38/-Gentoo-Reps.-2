# Regression test: don't crash if -mount is the last option
bfs_diff basic -warn -xdev -mount
