LS_COLORS="fi=01;91:no=01;92:" bfs_diff rainbow -color
