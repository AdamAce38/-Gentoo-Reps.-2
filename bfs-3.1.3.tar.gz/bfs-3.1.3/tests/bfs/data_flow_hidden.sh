bfs_diff basic \( -hidden -not -hidden \) -o \( -hidden -o -not -hidden \)
