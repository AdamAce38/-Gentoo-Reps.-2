bfs_diff -O3 basic -not \( -type f -not -type f \)
