bfs_diff -L loops/deeply/nested -unique -depth
