bfs_diff -H -type l links/skip
