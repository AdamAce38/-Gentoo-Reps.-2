bfs_diff -Ofast basic -not \( -xtype f -not -xtype f \)
