invoke_bfs -dikkiq 2>&1 | grep follow >/dev/null
