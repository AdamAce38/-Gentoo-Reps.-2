bfs_diff rainbow -nocolor
