LS_COLORS="st=37;44:tw=40;32:ow=00:" bfs_diff rainbow -color
