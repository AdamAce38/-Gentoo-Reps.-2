LS_COLORS="mi=01:" bfs_diff rainbow -color
