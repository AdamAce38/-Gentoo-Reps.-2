bfs_diff -O2 basic -not \( -type f -not -type f \)
