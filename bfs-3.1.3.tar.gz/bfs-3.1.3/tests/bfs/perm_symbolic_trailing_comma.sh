! invoke_bfs perms -perm a+r,
