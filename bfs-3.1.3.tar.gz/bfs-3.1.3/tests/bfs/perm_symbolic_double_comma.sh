! invoke_bfs perms -perm a+r,,u+w
