LS_COLORS="or=00:mi=01;33:" bfs_diff rainbow -color
