LS_COLORS="su=00:sg=30;43:" bfs_diff rainbow -color
