bfs_diff -j1 basic
