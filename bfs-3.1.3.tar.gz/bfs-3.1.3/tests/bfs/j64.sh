bfs_diff -j64 basic
