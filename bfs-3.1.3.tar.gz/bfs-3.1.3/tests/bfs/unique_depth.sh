bfs_diff basic -unique -depth
