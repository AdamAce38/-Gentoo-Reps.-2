bfs_diff links/skip -H -type l
