bfs_diff links/{file,symlink,hardlink} -unique
