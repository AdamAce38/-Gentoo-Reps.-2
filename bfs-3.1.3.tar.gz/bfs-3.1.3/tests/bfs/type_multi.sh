bfs_diff links -type f,d,c
