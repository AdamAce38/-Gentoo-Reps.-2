LS_COLORS="su=37;41:sg=00:" bfs_diff rainbow -color
