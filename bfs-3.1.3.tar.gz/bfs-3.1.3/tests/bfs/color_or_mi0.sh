LS_COLORS="or=01;31:mi=00:" bfs_diff rainbow -color
