! invoke_bfs basic -printf '%!'
