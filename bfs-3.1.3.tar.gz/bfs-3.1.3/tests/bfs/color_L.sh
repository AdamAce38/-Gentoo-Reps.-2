bfs_diff -L rainbow -color
