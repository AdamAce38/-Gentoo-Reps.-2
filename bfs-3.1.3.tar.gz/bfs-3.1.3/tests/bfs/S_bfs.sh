invoke_bfs -S bfs -s basic >"$OUT"
diff_output
