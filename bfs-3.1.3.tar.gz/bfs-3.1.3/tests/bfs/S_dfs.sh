invoke_bfs -S dfs -s basic >"$OUT"
diff_output
