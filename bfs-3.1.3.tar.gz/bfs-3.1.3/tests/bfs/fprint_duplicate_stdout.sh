invoke_bfs basic -fprint "$OUT" -print >"$OUT"
sort_output
diff_output
