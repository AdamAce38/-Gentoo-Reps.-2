! invoke_bfs basic -printf '%+p'
