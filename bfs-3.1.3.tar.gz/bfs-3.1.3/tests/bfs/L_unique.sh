bfs_diff -L links/{file,symlink,hardlink} -unique
