NO_COLOR= bfs_pty rainbow >"$OUT"
sort_output
diff_output
