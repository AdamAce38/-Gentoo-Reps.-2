! invoke_bfs links -links +-1
