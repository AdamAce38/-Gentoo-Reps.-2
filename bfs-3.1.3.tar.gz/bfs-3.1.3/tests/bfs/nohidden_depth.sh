bfs_diff weirdnames -depth -nohidden
