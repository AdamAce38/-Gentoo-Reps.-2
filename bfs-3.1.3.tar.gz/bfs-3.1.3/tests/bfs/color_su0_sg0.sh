LS_COLORS="su=00:sg=00:" bfs_diff rainbow -color
