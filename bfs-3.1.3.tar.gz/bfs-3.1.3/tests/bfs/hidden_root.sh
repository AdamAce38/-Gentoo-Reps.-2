cd weirdnames
bfs_diff . ./. ... ./... .../.. -hidden
