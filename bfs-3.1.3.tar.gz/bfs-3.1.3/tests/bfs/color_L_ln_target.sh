LS_COLORS="ln=target:or=01;31:mi=01;33:" bfs_diff -L rainbow -color
