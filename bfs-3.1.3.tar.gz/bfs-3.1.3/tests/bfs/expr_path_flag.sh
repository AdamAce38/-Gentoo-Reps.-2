bfs_diff -type l links/skip -H
