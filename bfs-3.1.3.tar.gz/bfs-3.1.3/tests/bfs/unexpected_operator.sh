! invoke_bfs \! -o -print
