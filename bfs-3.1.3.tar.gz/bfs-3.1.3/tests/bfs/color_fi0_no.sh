LS_COLORS="fi=0:no=01;92:" bfs_diff rainbow -color
