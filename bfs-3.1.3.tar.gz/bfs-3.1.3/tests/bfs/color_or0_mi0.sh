LS_COLORS="or=00:mi=00:" bfs_diff rainbow -color
