LS_COLORS="or=01;31:mi=01;33:" bfs_diff rainbow -color
