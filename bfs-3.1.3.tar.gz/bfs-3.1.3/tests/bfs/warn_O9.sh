# Regression test: don't crash when warning if -O9 is the last argument
cd basic
bfs_diff -warn -O9
