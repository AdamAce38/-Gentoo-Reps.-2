LS_COLORS="ln=target:cd=0:no=01;92:" bfs_diff rainbow -color
