bfs_diff links/skip -type l -H
