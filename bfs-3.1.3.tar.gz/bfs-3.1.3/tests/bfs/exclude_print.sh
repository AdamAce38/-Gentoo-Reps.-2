! invoke_bfs basic -exclude -print
