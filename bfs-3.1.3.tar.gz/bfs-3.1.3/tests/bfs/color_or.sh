LS_COLORS="or=01:" bfs_diff rainbow -color
