bfs_diff weirdnames -nohidden
