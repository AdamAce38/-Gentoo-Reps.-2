LS_COLORS="mh=00:" bfs_diff rainbow -color
