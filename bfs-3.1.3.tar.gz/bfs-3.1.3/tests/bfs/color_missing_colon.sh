LS_COLORS="*.txt=01" bfs_diff rainbow -color
