bfs_diff basic -maxdepth 0 -printf '\18\118\1118\11118\n\cfoo'
