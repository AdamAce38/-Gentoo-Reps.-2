bfs_diff basic -name foo -and -type d
