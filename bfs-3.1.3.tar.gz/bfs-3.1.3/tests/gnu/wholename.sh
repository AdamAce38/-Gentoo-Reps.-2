bfs_diff basic -wholename 'basic/*f*'
