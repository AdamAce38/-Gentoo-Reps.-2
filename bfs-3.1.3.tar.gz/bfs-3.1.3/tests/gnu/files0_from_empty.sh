! printf "\0" | invoke_bfs -files0-from -
