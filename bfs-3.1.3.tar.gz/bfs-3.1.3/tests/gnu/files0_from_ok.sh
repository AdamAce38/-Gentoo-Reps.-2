! printf "basic\0" | invoke_bfs -files0-from - -ok echo {} \;
