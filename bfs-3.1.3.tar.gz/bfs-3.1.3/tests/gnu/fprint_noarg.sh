! invoke_bfs basic -fprint
