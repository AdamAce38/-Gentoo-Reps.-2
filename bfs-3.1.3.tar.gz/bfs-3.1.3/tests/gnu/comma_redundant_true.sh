# Test (, lhs(always_true) -true) <==> lhs
bfs_diff basic -prune , -true
