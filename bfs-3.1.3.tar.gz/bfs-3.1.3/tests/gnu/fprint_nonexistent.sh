! invoke_bfs basic -fprint nonexistent/path
