test "$(id -g)" -eq 0 && skip
bfs_diff basic -gid ++0
