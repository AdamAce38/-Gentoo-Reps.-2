! PATH="foo:$PATH" invoke_bfs basic -execdir echo {} +
