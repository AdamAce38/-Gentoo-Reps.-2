bfs_diff perms -perm /a+r,u=wX,g+wX-w
