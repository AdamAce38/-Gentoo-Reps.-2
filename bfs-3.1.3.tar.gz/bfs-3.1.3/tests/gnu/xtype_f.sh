bfs_diff links -xtype f
