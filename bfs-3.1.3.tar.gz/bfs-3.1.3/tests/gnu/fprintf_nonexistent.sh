! invoke_bfs basic -fprintf nonexistent/path '%p\n'
