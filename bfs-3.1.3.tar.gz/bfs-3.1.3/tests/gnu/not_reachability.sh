bfs_diff basic -print \! -quit -print
