bfs_diff / -maxdepth 0 -printf '(%h)/(%f)\n'
