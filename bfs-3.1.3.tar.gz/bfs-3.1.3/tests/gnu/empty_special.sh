bfs_diff rainbow -empty
