! invoke_bfs basic -regex '['
