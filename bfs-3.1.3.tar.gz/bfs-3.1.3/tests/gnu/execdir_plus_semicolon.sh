bfs_diff basic -execdir echo foo {} bar + baz \;
