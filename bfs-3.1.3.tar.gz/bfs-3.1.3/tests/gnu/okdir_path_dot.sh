! PATH=".:$PATH" invoke_bfs basic -okdir echo {} \;
