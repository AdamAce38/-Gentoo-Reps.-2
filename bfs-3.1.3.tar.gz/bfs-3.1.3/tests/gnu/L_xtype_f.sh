bfs_diff -L links -xtype f
