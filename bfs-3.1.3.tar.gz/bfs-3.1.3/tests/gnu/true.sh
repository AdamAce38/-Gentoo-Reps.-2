bfs_diff basic -true
