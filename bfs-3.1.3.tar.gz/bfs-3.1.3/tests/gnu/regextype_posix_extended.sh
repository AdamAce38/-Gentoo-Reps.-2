cd weirdnames
bfs_diff -regextype posix-extended -regex '\./(\()'
