bfs_diff perms -perm /+rwx
