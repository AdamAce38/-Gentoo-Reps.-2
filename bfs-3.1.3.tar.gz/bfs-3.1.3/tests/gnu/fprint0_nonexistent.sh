! invoke_bfs basic -fprint0 nonexistent/path
