! invoke_bfs basic -fprintf /dev/null
