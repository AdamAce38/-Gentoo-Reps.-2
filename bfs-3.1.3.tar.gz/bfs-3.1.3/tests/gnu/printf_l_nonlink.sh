bfs_diff links -printf '| %26p -> %-26l |\n'
