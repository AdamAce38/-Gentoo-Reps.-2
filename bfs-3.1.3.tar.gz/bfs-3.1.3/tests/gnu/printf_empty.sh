bfs_diff basic -printf ''
