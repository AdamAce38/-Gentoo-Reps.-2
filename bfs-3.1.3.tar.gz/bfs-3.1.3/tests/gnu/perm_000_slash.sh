bfs_diff perms -perm /000
