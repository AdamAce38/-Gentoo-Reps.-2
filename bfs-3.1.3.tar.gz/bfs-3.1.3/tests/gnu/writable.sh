bfs_diff perms -writable
