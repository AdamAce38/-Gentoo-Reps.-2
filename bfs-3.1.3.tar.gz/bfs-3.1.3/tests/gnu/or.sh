bfs_diff basic -name foo -or -type d
