bfs_diff basic -gid "$(id -g)"
