# Regression test: don't segfault on missing command
! invoke_bfs basic -ok \;
