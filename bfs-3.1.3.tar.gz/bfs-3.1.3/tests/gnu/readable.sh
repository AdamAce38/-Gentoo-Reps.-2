bfs_diff perms -readable
