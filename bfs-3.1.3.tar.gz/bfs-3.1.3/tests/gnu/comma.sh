bfs_diff basic -name '*f*' -print , -print
