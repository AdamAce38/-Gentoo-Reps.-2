bfs_diff basic -uid "$(id -u)"
