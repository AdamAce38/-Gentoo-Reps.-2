printf "" | bfs_diff -files0-from -
