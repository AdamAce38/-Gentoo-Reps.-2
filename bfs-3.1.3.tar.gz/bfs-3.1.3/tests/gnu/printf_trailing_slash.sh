bfs_diff basic/ -printf '(%h)/(%f)\n'
