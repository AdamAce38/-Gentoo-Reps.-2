bfs_diff basic -daystart -mtime 0
