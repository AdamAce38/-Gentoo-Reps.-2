! invoke_bfs -files0-from basic
