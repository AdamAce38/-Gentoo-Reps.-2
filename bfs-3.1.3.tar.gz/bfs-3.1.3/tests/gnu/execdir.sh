bfs_diff basic -execdir echo {} \;
