bfs_diff basic -printf '|%- 10.10p| %+03d %#4m\n'
