bfs_diff basic -d
