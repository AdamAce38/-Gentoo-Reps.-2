bfs_diff basic \( -name foo -type d -o -name bar -a -type f \) -print , \! -empty -type f -print
