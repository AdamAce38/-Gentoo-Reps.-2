! bfs_diff -L loops
