invoke_bfs rainbow -fls "$OUT"
