# Test (, lhs(always_false) -false) <==> lhs
bfs_diff basic -print -not -prune , -false
