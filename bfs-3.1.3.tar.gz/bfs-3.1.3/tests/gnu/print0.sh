invoke_bfs basic/a basic/b -print0 >"$OUT"
diff_output
