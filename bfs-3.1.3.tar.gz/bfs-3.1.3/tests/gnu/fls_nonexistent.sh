! invoke_bfs rainbow -fls nonexistent/path
