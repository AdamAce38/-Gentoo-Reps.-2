invoke_bfs basic -fprint "$OUT"
sort_output
diff_output
