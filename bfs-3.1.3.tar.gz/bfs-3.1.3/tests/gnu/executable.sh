bfs_diff perms -executable
