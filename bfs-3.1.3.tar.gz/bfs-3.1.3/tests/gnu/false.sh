bfs_diff basic -false
