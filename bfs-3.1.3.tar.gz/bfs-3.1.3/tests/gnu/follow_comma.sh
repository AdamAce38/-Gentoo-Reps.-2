# , is an operator after a non-flag is seen
cd weirdnames
bfs_diff -follow ',' -print
