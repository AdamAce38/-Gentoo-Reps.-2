bfs_diff loops -printf '(%p) (%l) %y %Y\n'
