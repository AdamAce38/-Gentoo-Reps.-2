bfs_diff links -xtype l
