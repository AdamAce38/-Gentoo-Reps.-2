bfs_diff basic -empty
