cd weirdnames
bfs_diff -regextype sed -regex '\./\((\)'
