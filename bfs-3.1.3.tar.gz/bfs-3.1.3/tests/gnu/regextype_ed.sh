cd weirdnames
bfs_diff -regextype ed -regex '\./\((\)'
