invoke_bfs basic/a basic/b -fprint0 "$OUT"
diff_output
