# Memory leak regression test
bfs_diff basic -maxdepth 0 -printf '%p'
