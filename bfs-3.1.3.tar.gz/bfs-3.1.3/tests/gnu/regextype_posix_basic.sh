cd weirdnames
bfs_diff -regextype posix-basic -regex '\./\((\)'
