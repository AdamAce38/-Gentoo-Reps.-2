bfs_diff basic -name foo -type d
