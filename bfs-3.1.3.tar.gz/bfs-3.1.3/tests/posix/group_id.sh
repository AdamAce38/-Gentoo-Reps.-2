bfs_diff basic -group "$(id -g)"
