bfs_diff basic -exec echo {} \;
