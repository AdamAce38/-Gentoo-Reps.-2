bfs_diff basic -name '[e-g][!a-n][!p-z]'
