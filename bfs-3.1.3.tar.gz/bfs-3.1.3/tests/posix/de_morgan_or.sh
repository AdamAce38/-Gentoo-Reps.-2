bfs_diff basic \( \! -name 'foo' -o \! -type f \)
