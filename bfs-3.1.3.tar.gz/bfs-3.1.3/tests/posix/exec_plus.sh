bfs_diff basic -exec "$TESTS/sort-args.sh" {} +
