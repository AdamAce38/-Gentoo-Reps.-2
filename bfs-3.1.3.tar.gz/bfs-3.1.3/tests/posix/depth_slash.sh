bfs_diff basic/ -depth
