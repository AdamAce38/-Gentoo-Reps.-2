bfs_diff -H links/skip -type l
