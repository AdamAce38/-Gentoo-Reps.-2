# An unescaped \ doesn't match
bfs_diff weirdnames -name '\'
