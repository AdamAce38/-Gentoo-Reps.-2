bfs_diff -L links/skip -type l
