# Regression test: don't look OOB for {} +
! invoke_bfs basic -exec +
