bfs_diff -H links/notdir
