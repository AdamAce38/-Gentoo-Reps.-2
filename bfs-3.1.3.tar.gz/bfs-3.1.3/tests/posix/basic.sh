bfs_diff basic
