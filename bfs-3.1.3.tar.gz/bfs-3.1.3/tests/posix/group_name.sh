bfs_diff basic -group "$(id -gn)"
