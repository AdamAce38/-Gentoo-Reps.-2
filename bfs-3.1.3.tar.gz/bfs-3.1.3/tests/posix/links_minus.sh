bfs_diff links -type f -links -2
