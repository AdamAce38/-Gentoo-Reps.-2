bfs_diff basic \! \( -type f -o \! -type f \)
