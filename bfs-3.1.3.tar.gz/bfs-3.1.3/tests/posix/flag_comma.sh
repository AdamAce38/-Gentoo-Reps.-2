# , is a filename until a non-flag is seen
cd weirdnames
bfs_diff -L ',' -print
