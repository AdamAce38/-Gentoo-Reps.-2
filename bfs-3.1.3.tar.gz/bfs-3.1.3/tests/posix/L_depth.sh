bfs_diff -L links -depth
