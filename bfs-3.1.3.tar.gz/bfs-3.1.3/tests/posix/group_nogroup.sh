# Regression test: this was wrongly optimized to -false
bfs_diff basic -group "$(id -g)" \! -nogroup
