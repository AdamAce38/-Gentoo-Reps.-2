bfs_diff basic \( \! -name 'foo' -a \! -type f \)
