bfs_diff -H links/broken
