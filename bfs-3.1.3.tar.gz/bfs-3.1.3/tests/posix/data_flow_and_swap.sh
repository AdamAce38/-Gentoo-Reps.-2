bfs_diff basic \! -type f -a -type d
