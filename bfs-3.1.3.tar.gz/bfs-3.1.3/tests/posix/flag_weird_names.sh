cd weirdnames
bfs_diff -L '-' '(-' '!-' ',' ')' './(' './!' \( \! -print -o -print \)
