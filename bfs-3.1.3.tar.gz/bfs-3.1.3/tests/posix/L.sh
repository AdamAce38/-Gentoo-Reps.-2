bfs_diff -L links
