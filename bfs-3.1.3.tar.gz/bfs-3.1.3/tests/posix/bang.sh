bfs_diff basic \! -name foo
