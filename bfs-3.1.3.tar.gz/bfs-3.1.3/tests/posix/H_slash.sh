bfs_diff -H links/deeply/nested/dir/
