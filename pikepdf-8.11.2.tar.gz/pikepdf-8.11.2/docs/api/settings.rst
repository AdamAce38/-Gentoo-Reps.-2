Settings
********

Some of pikepdf's global parameters can be tuned.

.. autoapifunction:: pikepdf.settings.get_decimal_precision

.. autoapifunction:: pikepdf.settings.set_decimal_precision

.. autoapifunction:: pikepdf.settings.set_flate_compression_level