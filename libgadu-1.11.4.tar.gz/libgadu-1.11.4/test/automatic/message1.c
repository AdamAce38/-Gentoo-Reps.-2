// Tutaj będziemy testować "metody" "klasy" gg_message_t.

int main(void)
{
	return 0;
}
