#ifndef HMAC_SHA1_H
#define HMAC_SHA1_H

void gg_hmac_sha1(unsigned char *text, int text_len, unsigned char *key, int key_len, unsigned char *digest);

#endif /* HMAC_SHA1_H */
