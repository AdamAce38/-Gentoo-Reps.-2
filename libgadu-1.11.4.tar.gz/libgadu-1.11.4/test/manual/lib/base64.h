#ifndef BASE64_H
#define BASE64_H

char *gg_base64_encode(const char *buf, ssize_t len);
char *gg_base64_decode(const char *buf);

#endif /* BASE64_H */
