[@@@deprecated "[since 2022-04] Use [Time_float_unix] instead"]
(* In the immortal words of MC Hammer: "Stop ... (using) unix time!" *)

include Time_float_unix
