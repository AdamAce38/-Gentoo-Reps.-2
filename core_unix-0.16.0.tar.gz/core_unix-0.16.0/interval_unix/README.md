# Interval_unix

A single module library that defines `Interval_lib.Interval.t`
interval types and functions for Unix specific types, like
`Time_unix` and `Time_ns_unix`.
