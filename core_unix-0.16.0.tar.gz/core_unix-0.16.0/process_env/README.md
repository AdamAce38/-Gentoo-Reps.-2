# Process_env

A small library with utility functions for dealing with the Unix
process environment.
