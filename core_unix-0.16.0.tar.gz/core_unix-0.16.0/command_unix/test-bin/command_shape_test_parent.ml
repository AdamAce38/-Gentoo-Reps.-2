let () = Command_shape_test_shared.in_parent ()
