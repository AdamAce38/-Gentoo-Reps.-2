# Syslog

A single-module library for sending log messages via the Unix Syslog
interface.
