# ocaml_c_utils

`Ocaml_c_utils` is a library with no OCaml, only C utility functions
for dealing with OCaml. Code that wants to use these C functions
should declare a dependency on the corresponding ocaml library.
