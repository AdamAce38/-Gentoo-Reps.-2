(** This library does not contain any OCaml code; it only contains C code. *)
