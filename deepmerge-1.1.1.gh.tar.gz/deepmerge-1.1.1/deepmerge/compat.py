try:
    string_type = basestring
except:
    string_type = str
