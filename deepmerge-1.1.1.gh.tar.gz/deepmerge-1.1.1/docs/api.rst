=============
API Reference
=============

.. autoclass:: deepmerge.merger.Merger
    :members:


.. automodule:: deepmerge.exception
    :members:
    :undoc-members:
