﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Nake.Tests")]