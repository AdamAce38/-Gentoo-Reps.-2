﻿using System.Reflection;

[assembly: AssemblyTitle("Nake.Tests")]
[assembly: AssemblyProduct("Nake.Tests")]
[assembly: AssemblyCopyright("Copyright ©  2013")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]