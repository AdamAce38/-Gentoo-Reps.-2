﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Nake")]
[assembly: InternalsVisibleTo("Nake.Tests")]
[assembly: InternalsVisibleTo("Nake.Utility.Tests")]
