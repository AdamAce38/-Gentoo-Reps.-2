#define APSW_VERSION "3.45.1.0"
