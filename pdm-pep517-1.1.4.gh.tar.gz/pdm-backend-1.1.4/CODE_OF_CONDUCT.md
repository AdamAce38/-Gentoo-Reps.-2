Everyone interacting in the PDM project's codebases and issue trackers is expected to
follow the [PyPA Code of Conduct](https://www.pypa.io/en/latest/code-of-conduct/).
