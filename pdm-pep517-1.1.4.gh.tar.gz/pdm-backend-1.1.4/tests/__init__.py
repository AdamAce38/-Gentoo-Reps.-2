from pathlib import Path

FIXTURES = Path(__file__).parent / "fixtures"
