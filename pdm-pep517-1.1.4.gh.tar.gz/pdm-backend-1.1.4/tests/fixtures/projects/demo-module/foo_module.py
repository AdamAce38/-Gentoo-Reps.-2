__version__ = "0.1.0"  # don't edit this line
foo = "hello"
