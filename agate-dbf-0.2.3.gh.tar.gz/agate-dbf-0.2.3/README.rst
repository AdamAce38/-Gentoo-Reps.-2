.. image:: https://github.com/wireservice/agate-dbf/workflows/CI/badge.svg
    :target: https://github.com/wireservice/agate-dbf/actions
    :alt: Build status

.. image:: https://coveralls.io/repos/wireservice/agate-dbf/badge.svg?branch=master
    :target: https://coveralls.io/r/wireservice/agate-dbf
    :alt: Coverage status

.. image:: https://img.shields.io/pypi/dw/agate-dbf.svg
    :target: https://pypi.python.org/pypi/agate-dbf
    :alt: PyPI downloads

.. image:: https://img.shields.io/pypi/v/agate-dbf.svg
    :target: https://pypi.python.org/pypi/agate-dbf
    :alt: Version

.. image:: https://img.shields.io/pypi/l/agate-dbf.svg
    :target: https://pypi.python.org/pypi/agate-dbf
    :alt: License

.. image:: https://img.shields.io/pypi/pyversions/agate-dbf.svg
    :target: https://pypi.python.org/pypi/agate-dbf
    :alt: Support Python versions

agate-dbf adds read support for dbf files to `agate <https://github.com/wireservice/agate>`_.

Important links:

* agate             https://agate.rtfd.org
* Documentation:    https://agate-dbf.rtfd.org
* Repository:       https://github.com/wireservice/agate-dbf
* Issues:           https://github.com/wireservice/agate-dbf/issues
