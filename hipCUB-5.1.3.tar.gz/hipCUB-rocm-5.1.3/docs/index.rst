.. hipCUBs documentation master file

Welcome to hipCUB's documentation!
==================================

.. toctree::
   :maxdepth: 3 
   :caption: Contents:

   introduction
   api/library_root
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
