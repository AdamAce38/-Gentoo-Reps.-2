module Foo where

-- $setup
-- >>> x
-- 23

-- |
-- >>> foo
-- 42
foo :: Int
foo = 42

-- |
-- >>> y
-- 42
bar :: Int
bar = 42
