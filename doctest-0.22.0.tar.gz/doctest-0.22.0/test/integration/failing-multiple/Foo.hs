module Foo where

-- | A failing example
--
-- >>> 23
-- 23
--
-- >>> 23
-- 42
--
-- >>> 23
-- 23
-- >>> 23
-- 23
test :: a
test = undefined
