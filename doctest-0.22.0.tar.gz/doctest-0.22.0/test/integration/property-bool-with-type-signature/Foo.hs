module Foo where

-- |
-- prop> True :: Bool
foo = undefined
