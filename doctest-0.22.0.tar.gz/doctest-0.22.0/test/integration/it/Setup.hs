module Setup where

-- $setup
-- >>> :t 'a'
-- 'a' :: Char
--
-- >>> 42 :: Int
-- 42
--
-- >>> it
-- 42

-- |
--
-- >>> it * it
-- 1764
foo = undefined

-- |
--
-- >>> it * it
-- 1764
bar = undefined
