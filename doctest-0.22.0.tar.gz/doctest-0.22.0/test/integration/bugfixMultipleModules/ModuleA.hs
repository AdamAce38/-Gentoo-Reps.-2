-- |
-- >>> fib 10
-- 55
module ModuleA where

import ModuleB
