module Foo where

-- |
-- prop> abs x == x
foo = undefined
