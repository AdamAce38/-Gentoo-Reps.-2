module Foo where

-- $setup
-- >>> let x = 23 :: Int

-- |
-- >>> x + foo
-- 65
foo :: Int
foo = 42
