module Foo where

-- | A failing example
--
-- >>> 23
-- 42
test :: a
test = undefined
