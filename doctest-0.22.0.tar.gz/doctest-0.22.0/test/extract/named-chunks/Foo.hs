module Foo (
  foo
, bar
) where

-- $foo named chunk foo

-- $bar
-- named chunk bar

foo :: Int
foo = 23

bar :: Int
bar = 23
