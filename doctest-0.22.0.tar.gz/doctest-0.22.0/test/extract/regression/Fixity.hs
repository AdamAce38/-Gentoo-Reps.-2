module Fixity where

foo :: Int
foo = 23 + 42
