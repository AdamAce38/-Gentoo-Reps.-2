module Foo where


class Foo a where

  bar :: a    -- ^ foo
      -> Int  -- ^ bar
      -> String
