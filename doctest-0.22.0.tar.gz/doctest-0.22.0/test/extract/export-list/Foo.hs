module Foo (
-- * some heading
-- | documentation from export list
  foo
, bar
) where

foo :: Int
foo = 23

bar :: Int
bar = 23
