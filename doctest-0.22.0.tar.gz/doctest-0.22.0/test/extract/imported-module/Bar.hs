module Bar where

import Baz

-- | documentation for bar
bar :: Int
bar = 23
