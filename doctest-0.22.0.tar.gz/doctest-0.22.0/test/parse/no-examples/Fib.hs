module Fib where

-- | Calculate Fibonacci numbers.
-- @
-- some code
-- @
--
-- foobar 23
fib :: Int -> Int -> Int
fib _ = undefined
