module Foo where

-- $setup
-- >>> foo
-- 23

-- | some documentation
foo :: Int
foo = 23
