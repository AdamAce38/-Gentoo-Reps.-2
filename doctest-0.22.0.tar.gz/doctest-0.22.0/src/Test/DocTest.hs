module Test.DocTest (
  doctest
) where
import Test.DocTest.Internal.Run
