module Test.DocTest.Internal.Extract (
  module Extract
) where
import Extract
