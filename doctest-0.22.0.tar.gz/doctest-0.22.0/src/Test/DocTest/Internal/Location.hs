module Test.DocTest.Internal.Location (
  module Location
) where
import Location
