.. include:: ../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   intro
   install
   tutorial
   reference
