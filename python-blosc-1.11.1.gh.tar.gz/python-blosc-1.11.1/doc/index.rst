.. toctree::
   :hidden:

   python-blosc
