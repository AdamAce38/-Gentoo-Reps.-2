-- |
-- Deprecated\: Use "Test.Hspec.Core.Formatters.V1" instead.
module Test.Hspec.Formatters
-- {-# DEPRECATED "Use \"Test.Hspec.Core.Formatters.V1\" instead." #-}
(module Test.Hspec.Core.Formatters.V1)
where
import           Test.Hspec.Core.Formatters.V1
