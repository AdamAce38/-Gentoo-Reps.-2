## Release v0.16.0

* Added `Bright` versions of colors to `Config.color`.

* Refer to `Stdlib` instead of `Caml`.
