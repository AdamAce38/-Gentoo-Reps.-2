"""
This is a docstring.
"""

def abc(d,
        a11):
    ''' this is a docstring '''
    d = 2
    a = """
    this is not
    a docstring
    """
    def xyz(d):
        """
        this is a docstring
        """
        x = 1
        a = """ this is not a docstring
        """

class Abc():
    ''' this is a docstring '''
    d = 2
    a = """
    this is not
    a docstring
    """
    def Xyz(d):
        """
        this is a docstring
        """
        x = 1
        a = """
        this is not a docstring """

