-- single line comment  issue #371

--[[
multi 
line 
comment
]]

--[[
also a comment
--]]

print("hello, world")
print([[not a comment]])

--[===[
multi 
line 
comment
--[==[
still comment
--[=[
still comment
--[[
still comment
--]]
--]=]
--]==]
--]===]
