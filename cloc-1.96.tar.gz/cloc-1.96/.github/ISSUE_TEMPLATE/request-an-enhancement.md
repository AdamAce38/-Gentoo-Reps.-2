---
name: request an enhancement
about: request support for additional languages or new capabilities
title: ''
labels: ''
assignees: ''

---

**If you want an unsupported language added, provide:**
 - language name:
 - file extension(s):
 - method(s) of commenting text:
 - location of sample code:

**For other enhancements:**
Give a concise description of what you want cloc to be able to do.
