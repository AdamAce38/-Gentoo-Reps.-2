# This work is licensed under the GNU GPLv2 or later.
# See the COPYING file in the top-level directory.

# This class needs to live in rhbugzilla.py to preserve historical
# 'bugzilla.rhbugzilla' import compat

from .oldclasses import RHBugzilla  # pylint: disable=unused-import
