# internal/pkg

This folder contains packages that are not specific to this application.
These packages could theoretically be extracted into standalone public
packages if they provide utility.
