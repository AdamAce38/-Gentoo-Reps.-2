// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: BUSL-1.1

// Package serverclient contains helpers for the server API client.
package serverclient
