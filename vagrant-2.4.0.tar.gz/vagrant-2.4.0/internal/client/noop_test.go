// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: BUSL-1.1

package client

// import (
// 	"context"
// 	"testing"

// 	"github.com/hashicorp/go-hclog"
// 	"github.com/stretchr/testify/require"
// )

// func init() {
// 	hclog.L().SetLevel(hclog.Trace)
// }

// func TestProjectNoop(t *testing.T) {
// 	ctx := context.Background()
// 	require := require.New(t)

// 	// Build our client
// 	tp := TestBasis(t)

// 	// Noop
// 	require.NoError(tp.Noop(ctx))
// }
