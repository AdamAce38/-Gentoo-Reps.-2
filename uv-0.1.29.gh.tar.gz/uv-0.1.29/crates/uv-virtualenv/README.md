# uv-virtualenv

`uv-virtualenv` is a rust library to create Python virtual environments. It also has a CLI.
