from .deptry_reproducer import *


__doc__ = deptry_reproducer.__doc__
if hasattr(deptry_reproducer, "__all__"):
    __all__ = deptry_reproducer.__all__
