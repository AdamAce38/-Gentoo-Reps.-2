from setuptools import setup

setup(
    name="setup-py-editable",
    version="0.0.1",
    install_requires=[
        "httpx",
    ],
)
