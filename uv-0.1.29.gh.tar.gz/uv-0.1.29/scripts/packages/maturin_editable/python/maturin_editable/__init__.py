from .maturin_editable import *

version = 1
