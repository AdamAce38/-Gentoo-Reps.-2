# tmuxp shell - `tmuxp.cli.shell`

```{eval-rst}
.. automodule:: tmuxp.cli.shell
   :members:
   :show-inheritance:
   :undoc-members:
```
