# Plugin - `tmuxp.plugin`

```{eval-rst}
.. automodule:: tmuxp.plugin
   :members:
   :show-inheritance:
   :undoc-members:
```
