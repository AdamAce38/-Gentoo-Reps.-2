"""Example tmuxp plugin that runs after window creation completions."""
