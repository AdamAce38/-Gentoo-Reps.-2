"""Tmuxinator data fixtures for import_tmuxinator tests."""

from . import test1, test2, test3
