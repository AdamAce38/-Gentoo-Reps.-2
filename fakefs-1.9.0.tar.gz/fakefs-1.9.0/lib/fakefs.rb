require 'fakefs/safe'

FakeFS.activate!
