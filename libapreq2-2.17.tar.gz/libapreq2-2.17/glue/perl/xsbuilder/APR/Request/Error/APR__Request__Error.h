MP_STATIC XS(XS_APR__Request__Error_nil)
{
    dXSARGS;
    (void)items;
    XSRETURN_EMPTY;
}
