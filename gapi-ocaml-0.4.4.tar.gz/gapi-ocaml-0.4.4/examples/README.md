Google APIs Examples
====================

In this directory you can find samples of how to use the library to interact
with various services. These samples are ported from Google documentation. In
each subdirectory named like a service, there are 2 files:

* `samples.ml`: developer's guide samples
* `monadic.ml`: developer's guide samples using monadic style

See `auth/README.md` for details about the authorization process.

