## wai-app-static

WAI application for static serving

Also provides some helper functions and datatypes for use outside of WAI.
