let%expect_test _ =
  print_string "hello";
  [%expect "goodbye"]
;;
