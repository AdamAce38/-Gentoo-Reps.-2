module M () = struct
  let%expect_test _ = ()
end
