# Testing

    cd tests
    ../test.py *.dot
    ../test.py graphs/*.gv
