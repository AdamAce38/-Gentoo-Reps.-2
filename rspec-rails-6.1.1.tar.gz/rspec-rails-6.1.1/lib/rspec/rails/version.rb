module RSpec
  module Rails
    # Version information for RSpec Rails.
    module Version
      # Current version of RSpec Rails, in semantic versioning format.
      STRING = '6.1.1'
    end
  end
end
