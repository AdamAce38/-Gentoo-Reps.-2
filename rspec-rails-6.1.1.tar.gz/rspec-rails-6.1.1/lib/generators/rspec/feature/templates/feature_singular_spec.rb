require 'rails_helper'

RSpec.feature "<%= class_name.singularize %>", <%= type_metatag(:feature) %> do
  pending "add some scenarios (or delete) #{__FILE__}"
end
