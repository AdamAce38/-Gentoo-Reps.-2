require 'rails_helper'

RSpec.feature "<%= class_name.pluralize %>", <%= type_metatag(:feature) %> do
  pending "add some scenarios (or delete) #{__FILE__}"
end
