require 'rails_helper'

RSpec.describe "<%= class_name.pluralize %>", <%= type_metatag(:generator) %> do

  pending "add some scenarios (or delete) #{__FILE__}"
end
