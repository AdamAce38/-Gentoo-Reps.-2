class Timecop
  VERSION = "0.9.8"
end
