module Aws.Ses
    ( module Aws.Ses.Commands
    , module Aws.Ses.Core
    ) where

import Aws.Ses.Commands
import Aws.Ses.Core
