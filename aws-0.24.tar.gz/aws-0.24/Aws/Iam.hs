module Aws.Iam
    ( module Aws.Iam.Commands
    , module Aws.Iam.Core
    ) where

import           Aws.Iam.Commands
import           Aws.Iam.Core
