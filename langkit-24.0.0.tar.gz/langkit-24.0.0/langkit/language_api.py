class AbstractAPISettings:
    """
    Abstract class that defines an interface for the settings for a language we
    want to generate bindings for.
    """
    pass
