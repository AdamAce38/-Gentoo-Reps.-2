(* The naming convention is [Gen_] + the module where we use those helpers. *)

module Gen_automaton_state = Gen_automaton_state
module Gen_automaton_tables = Gen_automaton_tables
module Gen_parse_error = Gen_parse_error
