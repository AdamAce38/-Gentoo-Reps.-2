open! Base
include Parse_error_reason_intf
include Parse_error_reason_intf.T

let to_string = Variants.to_name
