# tktable
TKTable Widget. Tcl/Tk 8.5/8.6 TEA compatible. Full support for MacOSX and Windows. Based on Tktable version 2.10 by Jeffrey Hobbs.
