module Magick
  VERSION = '4.3.0'
  MIN_RUBY_VERSION = '2.3.0'
  MIN_IM_VERSION = '6.7.7'
end
