require 'rmagick_internal.rb'
