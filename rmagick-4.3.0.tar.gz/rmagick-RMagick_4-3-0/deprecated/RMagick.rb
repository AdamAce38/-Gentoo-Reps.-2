# This file is added to the require_paths in rmagick.gemspec
# That should be removed as well when this file is removed

warn '[DEPRECATION] requiring "RMagick" is deprecated. Use "rmagick" instead'

require 'rmagick_internal'
