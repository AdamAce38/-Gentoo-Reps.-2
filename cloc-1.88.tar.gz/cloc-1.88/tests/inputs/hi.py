#/usr/bin/env python
# Works with both 2.x and 3.x versions of Python.

# pound comment

import time
print('Hello.  The time is %f Unix epoch.' % (time.time()))  # inline comment

"""
Docstring,
  also counted as comment.
"""

'''
Single
  Quoted
    Docstring'''