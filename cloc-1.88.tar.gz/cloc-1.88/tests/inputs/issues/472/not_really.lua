-- single line comment

X

print("hello, world")
print([[not a comment]])
