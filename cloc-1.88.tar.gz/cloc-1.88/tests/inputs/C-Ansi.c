/* Hello World in C, Ansi-style */
/* from http://www.roesler-ac.de/wolfram/hello.htm */

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
  puts("Hello World!");
  return EXIT_SUCCESS;
}
