/* hello.java */
import java.io.*;
class Hi {
  static public void main( String args[] ) {
    System.out.println( "Hello World!" );  /*
                                              insert comment here
                                            */
  }
}
