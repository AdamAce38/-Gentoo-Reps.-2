#!/bin/sh

python3 test.py && echo "Finished!"