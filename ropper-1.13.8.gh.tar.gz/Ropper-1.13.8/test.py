from testcases.test_general import *
from testcases.test_x86_64 import *
from testcases.test_x86 import *
from testcases.test_arm import *
from testcases.test_arm64 import *
from testcases.test_mips import *
from testcases.test_ppc import *
import unittest

unittest.main()
