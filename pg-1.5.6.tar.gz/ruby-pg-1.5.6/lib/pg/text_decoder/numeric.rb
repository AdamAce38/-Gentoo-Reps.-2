# -*- ruby -*-
# frozen_string_literal: true

module PG
	module TextDecoder
		# Init C part of the decoder
		init_numeric
	end
end # module PG
