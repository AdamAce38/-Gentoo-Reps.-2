# -*- ruby -*-
# frozen_string_literal: true

module PG
	module BinaryDecoder
		# Init C part of the decoder
		init_date
	end
end # module PG
