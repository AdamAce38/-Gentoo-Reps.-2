module PG
	# Library version
	VERSION = '1.5.6'
end
