= postgres

* https://github.com/ged/ruby-pg

== Description

This is an old, deprecated version of the Ruby PostgreSQL driver that hasn't
been maintained or supported since early 2008.

You should install/require 'pg' instead.

If you need the 'postgres' gem for legacy code that can't be converted, you can
still install it using an explicit version, like so:

  gem install postgres -v '0.7.9.2008.01.28'
  gem uninstall postgres -v '>0.7.9.2008.01.28'

If you have any questions, the nice folks in the Google group can help:

  http://goo.gl/OjOPP / ruby-pg@googlegroups.com

