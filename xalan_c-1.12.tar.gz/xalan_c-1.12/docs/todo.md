# To-do tasks for future releases

* Update the documentation
* Performance improvements
* Add a more complete set of EXSLT functions
* Add support for extension elements
* Fix any conformance bugs we or our users find
* Fix compiler and platform support issues
* Add XPath2 support
