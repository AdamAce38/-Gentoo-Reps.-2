require 'puppet/indirector_testing'
require 'puppet/indirector/json'

class Puppet::IndirectorTesting::JSON < Puppet::Indirector::JSON
  desc "Testing the JSON indirector"
end
