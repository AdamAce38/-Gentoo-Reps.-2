Puppet::Functions.create_function(:rb_func_a) do
  def rb_func_a()
    "I am rb_func_a()"
  end
end