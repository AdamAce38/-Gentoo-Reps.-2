Puppet::Functions.create_function(:'modulea::rb_func_a') do
  def rb_func_a()
    "I am modulea::rb_func_a()"
  end
end