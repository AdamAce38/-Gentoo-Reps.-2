Facter.add(:agent_spec_role) do
  setcode { 'web' }
end
