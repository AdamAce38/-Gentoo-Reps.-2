from .ethtool import Ethtool

__all__ = [Ethtool]
