from .common import NLAKeyTransform


class NetNSFieldFilter(NLAKeyTransform):
    _nla_prefix = 'NSINFO_'
