from pyroute2 import lab

lab.use_mock = True
lab.registry = []
