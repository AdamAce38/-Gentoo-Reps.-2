Create an `IPRoute` object and list addresses.

Conditions:

* create exactly on `IPRoute()` object
* run `get_addr()` at least once
* run `close()` exactly once
