apt-get install \
    build-essential automake autoconf pkg-config \
    libgtk-3-dev libpulse-dev libpulse-mainloop-glib0 \
    libnotify-dev libavahi-glib-dev libappindicator3-dev
