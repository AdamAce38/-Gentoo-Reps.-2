[![Build Status](https://travis-ci.org/brndnmtthws/toluapp.svg?branch=master)](https://travis-ci.org/brndnmtthws/toluapp)

# tolua++

## What is tolua++?

tolua++ is an extension of toLua, a tool to integrate C/C++ code with
Lua. tolua++ includes new features oriented to c++, such as class
templates.

tolua is a tool that greatly simplifies the integration of C/C++ code
with Lua. Based on a "cleaned" header file, tolua automatically generates
the binding code to access C/C++ features from Lua. Using Lua-5.0 API and
metamethod facilities, the current version automatically maps C/C++
constants, external variables, functions, namespace, classes, and methods
to Lua. It also provides facilities to create Lua modules.

## Availability

tolua++ is freely available for both academic and commercial purposes.
See COPYRIGHT for details.

tolua++ can be downloaded from the sites below:
http://www.codenix.com/~tolua/

## Installation

See INSTALL.

Contacting the author
tolua has been designed and implemented by Waldemar Celes.
tolua++ is maintained by Ariel Manzur.
Send your comments, bug reports and anything else to
tolua@codenix.com
