#ifndef SOLARIS_H_
#define SOLARIS_H_

int get_entropy_avail(unsigned int *);
int get_entropy_poolsize(unsigned int *);

#endif /*SOLARIS_H_*/
