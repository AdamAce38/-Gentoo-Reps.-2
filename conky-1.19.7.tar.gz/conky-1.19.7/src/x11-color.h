/* from xorg-server's oscolor.c */
int OsLookupColor(int screen, const char *name, unsigned int len,
                  unsigned short *pred, unsigned short *pgreen,
                  unsigned short *pblue);
