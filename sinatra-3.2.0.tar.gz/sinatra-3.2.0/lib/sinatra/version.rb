# frozen_string_literal: true

module Sinatra
  VERSION = '3.2.0'
end
