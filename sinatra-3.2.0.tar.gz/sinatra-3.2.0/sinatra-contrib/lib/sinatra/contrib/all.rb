# frozen_string_literal: true

require 'sinatra/contrib'
Sinatra.register Sinatra::Contrib::All
