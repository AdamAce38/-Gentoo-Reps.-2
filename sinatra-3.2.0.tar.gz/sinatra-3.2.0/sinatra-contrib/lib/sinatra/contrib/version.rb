# frozen_string_literal: true

module Sinatra
  module Contrib
    VERSION = '3.2.0'
  end
end
