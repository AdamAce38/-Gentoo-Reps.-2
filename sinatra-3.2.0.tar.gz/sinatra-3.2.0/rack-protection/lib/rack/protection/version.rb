# frozen_string_literal: true

module Rack
  module Protection
    VERSION = '3.2.0'
  end
end
