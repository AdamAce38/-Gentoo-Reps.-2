JACK Audio Connection Kit (JACK) Client for Python
==================================================

This Python module (named ``jack``) provides bindings for the JACK_ library.

Documentation:
   https://jackclient-python.readthedocs.io/

Source code and issue tracker:
   https://github.com/spatialaudio/jackclient-python/

License:
   MIT -- see the file ``LICENSE`` for details.

.. _JACK: https://jackaudio.org/
