.. include:: ../README.rst

----

.. toctree::

   installation
   usage
   examples
   api
   contributing
   version-history
   other-modules

.. only:: html

   :ref:`genindex`
