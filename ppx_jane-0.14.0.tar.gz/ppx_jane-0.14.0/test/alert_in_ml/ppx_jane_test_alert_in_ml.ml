[@@@alert implementation "This structure contains an alert."]

let x = 0
