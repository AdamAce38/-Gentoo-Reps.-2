"""initial

Revision ID: 059
Revises: (none)
Create Date: 2021-09-07 20:00:00.000000

This empty Alembic revision is used as a placeholder revision for upgrades from older versions
of the database.
"""

# revision identifiers, used by Alembic.
revision = '059'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
