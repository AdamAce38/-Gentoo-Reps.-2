# Contributors

We would like to thanks official ejabberd source code contributors:

- Sergey Abramyan
- Badlop
- Ludovic Bocquet
- Emilio Bustos
- Thiago Camargo
- Juan Pablo Carlino
- Paweł Chmielowski
- Gabriel Gatu
- Tsukasa Hamano
- Konstantinos Kallas
- Evgeny Khramtsov
- Ben Langfeld
- Peter Lemenkov
- Anna Mukharram
- Johan Oudinet
- Pablo Polvorin
- Mickaël Rémond
- Matthias Rieber
- Rafael Roemhild
- Christophe Romain
- Jérôme Sautret
- Sonny Scroggin
- Alexey Shchepin
- Shelley Shyan
- Radoslaw Szymczyszyn
- Stu Tomlinson
- Christian Ulrich
- Holger Weiß

Please, if you think we are missing your contribution, do not hesitate to contact us at ProcessOne.
In case you do not want to appear in this list, please, let us know as well.

Thanks !
