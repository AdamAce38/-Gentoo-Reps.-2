-module(configure_deps).
-export(['configure-deps'/2]).

'configure-deps'(Config, Vals) ->
  {ok, Config}.
