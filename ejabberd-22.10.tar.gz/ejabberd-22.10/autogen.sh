# generate a new autoconf
aclocal -I m4
autoconf -f
