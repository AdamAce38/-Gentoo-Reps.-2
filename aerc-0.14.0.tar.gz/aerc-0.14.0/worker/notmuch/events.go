//go:build notmuch
// +build notmuch

package notmuch

type eventType interface{}

type updateDirCounts struct{}
