//go:build notmuch
// +build notmuch

package worker

import _ "git.sr.ht/~rjarry/aerc/worker/notmuch"
