// Copyright Contributors to the OpenVDB Project
// SPDX-License-Identifier: MPL-2.0
///
/// @file PlatformConfig.h
/// @note PlatformConfig.h will be marked as deprecated in the future

#include "Platform.h"

