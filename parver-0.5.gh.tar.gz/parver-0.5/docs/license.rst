=======
License
=======

.. include:: ../LICENSE
