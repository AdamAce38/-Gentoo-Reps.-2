************
Installation
************

parver is available from PyPI_:

.. code:: bash

  pip install parver

.. _PyPI: https://pypi.org/project/parver
