# frozen_string_literal: true

module MemoWise
  VERSION = "1.8.0"
end
