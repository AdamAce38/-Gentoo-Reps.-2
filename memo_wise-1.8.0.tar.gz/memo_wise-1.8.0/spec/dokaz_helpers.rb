# frozen_string_literal: true

# See: https://github.com/zverok/dokaz

require "memo_wise"

# Enable the example RSpec `after` call in README.md to execute successfully
def after(scope, &)
  # Do nothing
end
