# frozen_string_literal: true

# See: https://github.com/p0deje/yard-doctest

require "memo_wise"
