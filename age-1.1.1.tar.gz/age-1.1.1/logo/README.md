The logos available in this folder are Copyright 2021 Filippo Valsorda.

Permission is granted to use the logos as long as they are unaltered, are not
combined with other text or graphic, and are not used to imply your project is
endorsed by or affiliated with the age project.

This permission can be revoked or rescinded for any reason and at any time,
selectively or otherwise.

If you require different terms, please email age-logo@filippo.io.

The logos were designed by [Studiovagante](https://www.studiovagante.it).
