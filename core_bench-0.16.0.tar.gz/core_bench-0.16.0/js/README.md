# Js_bench

A clone of core\_bench, built for javascript perf testing.

