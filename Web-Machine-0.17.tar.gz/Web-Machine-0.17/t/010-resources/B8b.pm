package B8b;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub is_authorized { \500 }

1;