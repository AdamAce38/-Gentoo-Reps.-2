package B9;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub malformed_request { 1 }

1;