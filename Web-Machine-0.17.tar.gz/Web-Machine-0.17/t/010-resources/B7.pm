package B7;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub forbidden { 1 }

1;