package B13;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub service_available { 0 }

1;