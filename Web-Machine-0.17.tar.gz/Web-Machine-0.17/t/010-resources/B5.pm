package B5;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub known_content_type { 0 }

1;