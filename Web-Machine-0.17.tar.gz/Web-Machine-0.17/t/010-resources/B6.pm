package B6;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub valid_content_headers { 0 }

1;