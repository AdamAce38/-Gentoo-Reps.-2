package B8d;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub is_authorized { undef }

1;
