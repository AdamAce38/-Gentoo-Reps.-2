package B8c;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub is_authorized { '' }

1;