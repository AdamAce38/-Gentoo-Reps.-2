package B4;
use strict;
use warnings;

use parent 'Web::Machine::Resource';

sub valid_entity_length { 0 }

1;