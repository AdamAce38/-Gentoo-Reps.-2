<?php

/* Icinga DB Web | (c) 2020 Icinga GmbH | GPLv2 */

namespace Icinga\Module\Icingadb\Widget;

/** @deprecated Use {@see \ipl\Web\Widget\StateBadge} instead */
class StateBadge extends \ipl\Web\Widget\StateBadge
{
}
