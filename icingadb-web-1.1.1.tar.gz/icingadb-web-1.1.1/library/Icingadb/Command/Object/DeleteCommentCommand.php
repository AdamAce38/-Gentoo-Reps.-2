<?php

/* Icinga DB Web | (c) 2021 Icinga GmbH | GPLv2 */

namespace Icinga\Module\Icingadb\Command\Object;

/**
 * Delete a host or service comment
 */
class DeleteCommentCommand extends ObjectsCommand
{
    use CommandAuthor;
}
