<?php

/* Icinga DB Web | (c) 2021 Icinga GmbH | GPLv2 */

namespace Icinga\Module\Icingadb\Command\Renderer;

/**
 * Interface for Icinga command renderer
 */
interface IcingaCommandRendererInterface
{
}
