<?php

/* Icinga DB Web | (c) 2020 Icinga GmbH | GPLv2 */

namespace Icinga\Module\Icingadb\Common;

/**
 * @deprecated Use {@see \ipl\Stdlib\BaseFilter} instead. This will be removed with version 1.1
 */
trait BaseFilter
{
    use \ipl\Stdlib\BaseFilter;
}
