<?php

/* Icinga DB Web | (c) 2023 Icinga GmbH | GPLv2 */

namespace Tests\Icinga\Module\Icingadb\Lib;

use Icinga\Module\Icingadb\Util\PerfDataSet;

class PerfdataSetWithPublicData extends PerfdataSet
{
    public $perfdata = [];
}
