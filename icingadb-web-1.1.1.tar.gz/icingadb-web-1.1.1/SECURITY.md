# Security Policy

## Supported Versions

The latest two minors. If it's a critical threat and the latest minor is just a few weeks old, the third latest minor may also get an update.

## Reporting a Vulnerability

Please head [here](https://icinga.com/company/contact/security-issues/).
