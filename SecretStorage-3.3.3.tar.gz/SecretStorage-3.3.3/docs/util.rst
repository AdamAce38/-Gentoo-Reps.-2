============================
Additional utility functions
============================

.. automodule:: secretstorage.util
   :members:
      format_secret,
      exec_prompt,
      unlock_objects
