The Trio code of conduct applies to this project. See:
    https://trio.readthedocs.io/en/latest/code-of-conduct.html
