This is an official Trio project. For the Trio contributing guide,
see:
    https://trio.readthedocs.io/en/latest/contributing.html
