module Moneta
  # Moneta version number
  # @api public
  VERSION = '1.6.0'.freeze
end
