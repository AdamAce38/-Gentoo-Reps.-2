Changelog
=========

0.4.1
-----
**release date:** 2013-11-05

* Fix parsing nested SeekHead elements
* Make parsing nested SeekHead elements optional


0.4.0
-----
**release date:** 2013-10-30

* Import exceptions under enzyme namespace
* Change repr format
* Rename base exception
* Remove test file


0.3.1
-----
**release date:** 2013-10-20

* Fix package distribution


0.3
---
**release date:** 2013-05-18

* Complete refactoring, for the old enzyme see https://github.com/Diaoul/enzyme-old
