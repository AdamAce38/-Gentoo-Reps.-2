int func2_in_obj(void) {
    return 0;
}
