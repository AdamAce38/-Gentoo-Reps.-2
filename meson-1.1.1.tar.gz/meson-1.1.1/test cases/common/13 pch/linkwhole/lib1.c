void func1() {
    printf("Calling func2.");
    func2();
}
