#pragma once

#define CPY_TEST_STR_3 "CopyFile"
