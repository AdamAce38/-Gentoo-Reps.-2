# frozen_string_literal: true

# Released under the MIT License.
# Copyright, 2017-2023, by Samuel Williams.

module Async
	module IO
		VERSION = "1.38.1"
	end
end
