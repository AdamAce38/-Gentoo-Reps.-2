"""misc. utility functions"""
