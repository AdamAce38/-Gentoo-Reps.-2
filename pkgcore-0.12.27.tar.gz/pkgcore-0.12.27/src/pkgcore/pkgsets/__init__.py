"""
restriction generaters representing sets of packages
"""
