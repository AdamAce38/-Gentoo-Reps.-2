"""
gentoo ebuild support
"""
