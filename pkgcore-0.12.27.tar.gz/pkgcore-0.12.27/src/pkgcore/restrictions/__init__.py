"""restriction subsystem, used both for depencies and general package queries"""
