__title__ = "pkgcore"
__version__ = "0.12.27"
