"""pkgcore plugins package."""

from ..plugin import extend_path

extend_path(__path__, __name__)
