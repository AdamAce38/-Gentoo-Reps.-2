"""
filesystem abstractions, and select operations
"""
