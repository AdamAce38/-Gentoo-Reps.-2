"""
gentoo binpkg support, specifically tbz2
"""
