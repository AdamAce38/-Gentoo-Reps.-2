nonfatal() { PKGCORE_NONFATAL=true "$@"; }

:
