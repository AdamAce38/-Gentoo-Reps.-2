# moved to src_configure
unset -f econf

default_src_compile() { __phase_src_compile; }
