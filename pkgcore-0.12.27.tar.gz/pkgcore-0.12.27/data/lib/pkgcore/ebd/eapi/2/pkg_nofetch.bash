default_pkg_nofetch() { __phase_pkg_nofetch; }
