default_src_prepare() { __phase_src_prepare; }
