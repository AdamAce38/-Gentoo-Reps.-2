in_iuse() { [[ $1 =~ ${PKGCORE_IUSE_EFFECTIVE} ]]; }

get_libdir() { __get_libdir lib; }

:
