from snakeoil.test.eq_hash_inheritance import Test


class Test_Eq_Hash(Test):
    target_namespace = "pkgcore"
    ignore_all_import_failures = True
