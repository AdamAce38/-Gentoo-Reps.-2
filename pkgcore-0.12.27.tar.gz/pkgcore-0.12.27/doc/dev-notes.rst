Developer Notes
===============

These are the original docs written for pkgcore, detailing some of it's
architecture, intentions, and reasons behind certain designs.

Currently, the docs aren't accurate- this will be corrected moving forward.

Right now they're primarily useful from a background-info standpoint.

Content
-------

.. toctree::
    :glob:
    :maxdepth: 2

    dev-notes/*
    dev-notes/*/*
