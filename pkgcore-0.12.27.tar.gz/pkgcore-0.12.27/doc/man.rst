Man Pages
=========

pkgcore provides a set of man pages relating to its tools (e.g. pmerge) as well
as ones detailing configuration, development, and other general information.

.. toctree::
    :glob:
    :maxdepth: 2

    man/*
