
char *base_name (char const *name);
