__version__ = "@NETGEN_VERSION_PYTHON@"
__package_name__ = "@NETGEN_PYTHON_PACKAGE_NAME@"
