/**************************************************************************/
/* File:   parthreads.cpp                                                 */
/* Author: Joachim Schoeberl                                              */
/* Date:   01. Jun. 95                                                    */
/**************************************************************************/


#include <mystdlib.h>
#include <myadt.hpp>

/*

namespace netgen
{
  using namespace netgen;

#ifdef WIN32

  NgLock :: NgLock (NgMutex & mut)
    : sl(&mut.cs)
  {
    ;
  }

  void NgLock :: Lock ()
  {
    sl.Lock();
  }
  void NgLock :: UnLock ()
  {
    sl.Unlock();
  }


#else

#endif
}

*/
