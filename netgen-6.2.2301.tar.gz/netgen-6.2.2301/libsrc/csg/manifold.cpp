#include <csg.hpp>

namespace netgen
{
Manifold :: Manifold () 
{
  ;
}

Manifold :: ~Manifold () 
{
  ;
}
}
