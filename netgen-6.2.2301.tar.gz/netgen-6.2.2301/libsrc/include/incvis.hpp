// libraries for User interface:

nicht mehr verwendet

#include "inctcl.hpp"
#include "incopengl.hpp"
