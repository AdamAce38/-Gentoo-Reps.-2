# frozen_string_literal: true
# $Id$

require 'test/unit'
require 'fileutils'
require_relative 'visibility_tests'

class TestFileUtilsVerbose < Test::Unit::TestCase

  include FileUtils::Verbose
  include TestFileUtilsIncVisibility

  def setup
    super
    @fu_module = FileUtils::Verbose
  end

end
