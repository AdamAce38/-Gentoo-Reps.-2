// stringname=deminJS
// Use this as a stub if you don't need deminimization, and are not including demin.js

Object.defineProperty(Object.prototype, "constructor",{enumerable:false,writable:false,configurable:false});
// Mark the master window as irrevocably compiled.
Object.defineProperty( this, "compiled", {value:true, writable:false, configurable:false, enumerable:true});
