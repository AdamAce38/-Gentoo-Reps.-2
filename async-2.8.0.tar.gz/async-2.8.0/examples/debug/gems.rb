# frozen_string_literal: true

# Released under the MIT License.
# Copyright, 2023, by Samuel Williams.

source "https://rubygems.org"

gem "debug", path: "/Users/samuel/Developer/ruby/debug"
gem "async", path: "../.."
