from slixmpp.plugins.base import register_plugin

from slixmpp.plugins.xep_0100.gateway import XEP_0100, LegacyError


register_plugin(XEP_0100)
