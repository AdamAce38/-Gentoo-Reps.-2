
# Slixmpp: The Slick XMPP Library
# Copyright (C) 2011 Nathanael C. Fritz, Lance J.T. Stout
# This file is part of Slixmpp.
# See the file LICENSE for copying permission.
from slixmpp.plugins.xep_0004.stanza.field import FormField, FieldOption
from slixmpp.plugins.xep_0004.stanza.form import Form
