from slixmpp.plugins.base import register_plugin

from .search import XEP_0055


register_plugin(XEP_0055)
