Tutorials, FAQs, and How To Guides
----------------------------------

.. toctree::
    :maxdepth: 2

    stanzas
    create_plugin
    internal_api
    features
    sasl
    remove_process
    handlersmatchers
    guide_xep_0030
    xmpp_tdg
