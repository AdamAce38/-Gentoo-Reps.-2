Root Stanza
===========

.. module:: slixmpp.stanza.rootstanza

.. autoclass:: RootStanza
    :members:

