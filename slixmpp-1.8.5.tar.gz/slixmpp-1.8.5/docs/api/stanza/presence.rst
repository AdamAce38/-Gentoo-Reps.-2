Presence Stanza
===============

.. module:: slixmpp.stanza

.. autoclass:: Presence
    :members:

