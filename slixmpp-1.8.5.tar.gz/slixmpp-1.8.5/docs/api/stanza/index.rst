
Core Stanzas
------------

.. toctree::
    :maxdepth: 2

    rootstanza
    message
    presence
    iq
