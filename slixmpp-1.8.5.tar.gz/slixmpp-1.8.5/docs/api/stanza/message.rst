Message Stanza
==============

.. module:: slixmpp.stanza
    :noindex:

.. autoclass:: Message
    :members:
