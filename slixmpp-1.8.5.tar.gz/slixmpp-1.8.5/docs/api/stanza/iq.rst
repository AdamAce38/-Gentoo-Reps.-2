IQ Stanza
=========

.. module:: slixmpp.stanza
    :noindex:

.. autoclass:: Iq
    :members:

