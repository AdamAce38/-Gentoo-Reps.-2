==========
ClientXMPP
==========

.. module:: slixmpp.clientxmpp

.. autoclass:: ClientXMPP
    :members:
