========
BaseXMPP
========

.. module:: slixmpp.basexmpp

.. autoclass:: BaseXMPP
    :members:
