=============
ComponentXMPP
=============

.. module:: slixmpp.componentxmpp

.. autoclass:: ComponentXMPP
    :members:
