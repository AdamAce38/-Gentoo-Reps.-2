Exceptions
==========

.. module:: slixmpp.exceptions


.. autoexception:: XMPPError
    :members:

.. autoexception:: IqError
    :members:

.. autoexception:: IqTimeout
    :members:
