==========
XML Stream
==========

.. module:: slixmpp.xmlstream.xmlstream

.. autoclass:: XMLStream
    :members:
