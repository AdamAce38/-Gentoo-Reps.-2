Stanza Handlers
===============

The Basic Handler
-----------------
.. module:: slixmpp.xmlstream.handler.base

.. autoclass:: BaseHandler
    :members:

Callback
--------
.. module:: slixmpp.xmlstream.handler

.. autoclass:: Callback
    :members:

CoroutineCallback
-----------------

.. autoclass:: CoroutineCallback
    :members:

Waiter
------

.. autoclass:: Waiter
    :members:
