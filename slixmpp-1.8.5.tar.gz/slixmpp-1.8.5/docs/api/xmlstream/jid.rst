Jabber IDs (JID)
=================

.. module:: slixmpp.jid

.. autoclass:: JID
    :members:
