API Reference
-------------

.. toctree::
    :maxdepth: 3

    clientxmpp
    componentxmpp
    basexmpp
    exceptions
    xmlstream/jid
    xmlstream/stanzabase
    xmlstream/handler
    xmlstream/matcher
    xmlstream/xmlstream
    xmlstream/tostring
    api
