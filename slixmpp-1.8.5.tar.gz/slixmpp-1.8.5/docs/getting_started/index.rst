Getting Started (with examples)
-------------------------------

.. toctree::
    :maxdepth: 3

    echobot
    sendlogout
    component
    presence
    muc
    scheduler
    iq
