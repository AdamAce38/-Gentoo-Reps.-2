Coming from SleekXMPP
---------------------

.. toctree::
    :maxdepth: 2

    differences
    using_asyncio
