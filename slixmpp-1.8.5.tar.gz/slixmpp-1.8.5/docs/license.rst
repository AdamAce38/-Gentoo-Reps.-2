.. _license:

License (MIT)
=============

.. literalinclude:: ../LICENSE
