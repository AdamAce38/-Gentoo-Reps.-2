# frozen_string_literal: true

require 'capybara'
require 'capybara/rails'
require 'capybara/cucumber'
require 'capybara/session'
require 'cucumber/rails/capybara/javascript_emulation'
require 'cucumber/rails/capybara/select_dates_and_times'
