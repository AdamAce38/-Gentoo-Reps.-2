# frozen_string_literal: true

require 'cucumber/rails/hooks/active_record'
require 'cucumber/rails/hooks/database_cleaner'
require 'cucumber/rails/hooks/allow_rescue'
require 'cucumber/rails/hooks/mail'
