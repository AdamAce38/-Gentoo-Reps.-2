/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _DIREDITOR_H_
#define _DIREDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>

#include "ui_diredit.h"
#include "version.h"
#include "debug.h"


/** Handles global settings */
class dirWidget : public QWidget, private Ui::dirUI {

Q_OBJECT

public:
	dirWidget(QWidget *parent=0);
	~dirWidget() {}

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

private slots:
	void getNewWorkDir();
	void getNewTexDir();

private:
	void updDirWid();

	/** Private settings stuff */
	void readSettings();
	void writeSettings();
};

/** _DIREDITOR_H_ */
#endif
