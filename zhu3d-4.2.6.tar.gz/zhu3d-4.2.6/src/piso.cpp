/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <string>
#include <cmath>
#include <ctime>
#include <cstdio>
#include "piso.h"
#include "qadran.h"


extern QList<QString> isoList;
static QADRAN ran;


/** *************************************************************************
 ** Local default function stuff used in every parser
****************************************************************************/
inline static FPFLOAT sig(const FPFLOAT *p) {
	if(p[0]>0.0f) return 1.0f;
	if(p[0]<0.0f) return -1.0f;
	return 0.0f;
}

inline static FPFLOAT frac(const FPFLOAT *p) {
	FPFLOAT tmp=p[0];
	return tmp-=(FPFLOAT)((int)tmp);
}

inline static FPFLOAT log2(const FPFLOAT *p) {
	return log10f(p[0])/log10f(2.0f);
}

inline static FPFLOAT power(const FPFLOAT *p) {
	return powf(p[0], p[1]);
}

inline static FPFLOAT modul(const FPFLOAT *p) {
	return (FPFLOAT)((int)p[0]%(int)p[1]);
}

inline static FPFLOAT gamma(const FPFLOAT *p) {
	return tgammaf(p[0]);
}

inline static FPFLOAT rand(const FPFLOAT *p) {
	return ((float)ran.frand()*2.0f-1.0f)*p[0];
}


#define IFPOPTIMIZER
/** Each instance sets up a full parser-set */
PISO::PISO() {
	int i, err;
	funpCount=0;

	/** Add all default constants */
	addParserConstant("_pi",(FPFLOAT)3.1415926535897932384);
	addParserConstant("_e", (FPFLOAT)2.7182818284590452354);
	addParserConstant("_c", (FPFLOAT)299792458.0);

	/** Add all default functions */
	addDefParserFunction("sig",   sig,    1);
	addDefParserFunction("rnd",   rand,   1);
	addDefParserFunction("frac",  frac,   1);
	addDefParserFunction("log2",  log2,   1);
	addDefParserFunction("pow",   power,  2);
	addDefParserFunction("mod",   modul,  2);
	addDefParserFunction("gamma", gamma,  1);

	/** Fetch user items */
	for(i=0; i<lastUsrEntry; i++)
		if((err=fetchItem(usr[i])) != FunctionParser::FP_NO_ERROR)
			fprintf(stderr, "Error in PISO fetch=%d which NEVER should occur\n", err);

	/** Update */
	for(i=0; i<3; i++) {
		p[i].Parse(iso[i].str, "x,y,z");
		if((err=p[i].GetParseErrorType()) != FunctionParser::FP_NO_ERROR) {
			fprintf(stderr, "Error in PISO update=%d which NEVER should occur\n", err);
		}
		#ifdef IFPOPTIMIZER
			p[i].Optimize();
		#endif
	}
}


/** *************************************************************************
 ** Adding stuff
****************************************************************************/

/** Add a constant to all parsers */
bool PISO::addParserConstant(const std::string &name, FPFLOAT val) {
	long i;

	if(!conp.AddConstant(name, val))
		return false;

	for(i=0; i<lastUsrEntry; i++)
		if(!funp[i].AddConstant(name, val))
			return false;

	for(i=0; i<3; i++)
		if(!p[i].AddConstant(name, val))
			return false;

	return true;
}

/** Add a default function to all parsers */
bool PISO::addDefParserFunction(const std::string &name, FPFLOAT (*funPtr)(const FPFLOAT*), int parAmount) {
	long i;

	for(i=0; i<3; i++)
		if(!p[i].AddFunction(name, funPtr, (unsigned)parAmount))
			return false;

	for(i=0; i<lastUsrEntry; i++)
		if(!funp[i].AddFunction(name, funPtr, (unsigned)parAmount))
			return false;

	return true;
}

/** Add a new function to all parsers */
bool PISO::addNewParserFunction(const std::string &name, FunctionParser &toAdd) {
	long i;

	if(!conp.AddFunction(name, toAdd))
		return false;

	for(i=funpCount+1; i<lastUsrEntry; i++)
		if(!funp[i].AddFunction(name, toAdd))
			return false;

	for(i=0; i<3; i++)
		if(!p[i].AddFunction(name, toAdd))
			return false;

	return true;
}


/** *************************************************************************
 ** New user defined constants and functions
****************************************************************************/

/** Fetch constant */
int PISO::fetchNewConstant(const QString &s) {

	const QString name(s.section('=',0,0));
	const QString vals(s.section('=',1,1));
	FPFLOAT vars[1], fval;
	int err;

	/** Never redefine built in constants */
	//"ERROR 13: Adding new constant failed",
	if(name=="_pi" || name=="_e" || name=="_c")
		return 13;

	/** Extract value */
	conp.Parse(q2cstrcpy(vals), "");
	if((err=conp.GetParseErrorType()) != FunctionParser::FP_NO_ERROR)
		return err;
	fval=conp.Eval(vars);

	//"ERROR 13: Adding new constant failed",
	if(!addParserConstant(q2cstrcpy(name), fval))
		return 13;

	/** Everything was ok so far */
	return FunctionParser::FP_NO_ERROR;
}

/** Fetch function */
int PISO::fetchNewFunction(const QString &s) {

	const QString name(s.section('=',0,0).section('(',0,0));
	const QString pars(s.section(')',0,0).section('(',1,1));
	const QString funs(s.section('=',1,1));
	char cfuns[funs.length()+1];
	int err;

	/** "ERROR 14: Adding new function failed"
	 ** Too much user entries made so far */
	if(funpCount==(MAXUSR-1))
		return 14;

	/** Check syntax for new entry */
	q2cstrcpy(cfuns, funs);
	funp[funpCount].Parse(cfuns, q2cstrcpy(pars));
	if((err=funp[funpCount].GetParseErrorType()) != FunctionParser::FP_NO_ERROR)
		return err;

	/** "ERROR 14: Adding new function failed" */
	if(!addNewParserFunction(q2cstrcpy(name), funp[funpCount]))
		return 14;

	/** Everything was ok so far */
	funpCount++;
	return FunctionParser::FP_NO_ERROR;
}

/** Fetch item */
int PISO::fetchItem(const QString &s) {
	QString tmp;

	/** Check comment or empty string */
	if(s[0]==QChar('#') || s.isEmpty())
		return FunctionParser::FP_NO_ERROR;

	//"ERROR 12: Missing equal sign" */
	if(!s.contains(QChar('=')))
		return 12;
	else
		tmp=prepareInput(s);

	/** Check for constant first */
	if(!tmp.contains(")="))
		return fetchNewConstant(tmp);

	/** Else item must be a function */
	return fetchNewFunction(tmp);
}
