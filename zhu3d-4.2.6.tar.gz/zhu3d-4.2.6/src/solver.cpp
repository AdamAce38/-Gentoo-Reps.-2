/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <QApplication>
#include <QObject>
#include <cfloat>
#include <cmath>
#include "solver.h"
#include "pinterface.h"     // For error messages only
#include "ppinterface.h"    // Accuracy parser stuff
#include "qadran.h"
#include "timers.h"


/** NOTE: For accuracy reasons this module assumes, that PFPFLOAT = long double */


/** The three functions */
static PFPFLOAT pfxy0(const PFPFLOAT xpar, const PFPFLOAT ypar) {
	PFPFLOAT vars[2];
	vars[0] = xpar * sta.sx;
	vars[1] = ypar * sta.sy;
	return pfpGL[0].Eval(vars) * sta.sz;
}

static PFPFLOAT pfxy1(const PFPFLOAT xpar, const PFPFLOAT ypar) {
	PFPFLOAT vars[2];
	vars[0] = xpar * sta.sx;
	vars[1] = ypar * sta.sy;
	return pfpGL[1].Eval(vars) * sta.sz;
}

static PFPFLOAT pfxy2(const PFPFLOAT xpar, const PFPFLOAT ypar) {
	PFPFLOAT vars[2];
	vars[0] = xpar * sta.sx;
	vars[1] = ypar * sta.sy;
	return pfpGL[2].Eval(vars) * sta.sz;
}


/** The solver finally */
QString solve() {
	QADRAN ran;
	float msecs;
	int err;

	/** Rebuild all parsers with error check */
	if((err=pinitAllParsers()) != pFunctionParser::FP_NO_ERROR) {
		QString message=fpError::getQtMessage(err)+"\n";
		QMessageBox::critical(
			0,
			QObject::tr("Alert"),
			message
		);
		return (QString)"";
	}

	/** Maximum number of random guesses */
	const long maxstep=150000;

	/** Adjust precision near to theoretical maximum  */
	const int dig = ((solverPrec+6)<=LDBL_DIG) ? (solverPrec+6) : LDBL_DIG;
	const PFPFLOAT eps = 1.0L / powl(10.0L, (PFPFLOAT)(dig-1));

	/** Miscellaneous */
	long steps=0;
	PFPFLOAT x, y, z, dx, dy, hz;
	bool ready=false;

	/** Calculate sum of differences of the Z-values from X,Y-cross-value */
	QApplication::setOverrideCursor(Qt::WaitCursor);
	x  = (PFPFLOAT) sta.crossX;
	y  = (PFPFLOAT) sta.crossY;
	z  = fabsl(pfxy1(x,y) - pfxy0(x,y));
	z += fabsl(pfxy2(x,y) - pfxy0(x,y));
	z += fabsl(pfxy2(x,y) - pfxy1(x,y));

	/** Start searching ... */
	TIMERS t;
	do {

		/** Generate a new random-vector with length eps */
		dx = (ran.frand53()*2.0-1.0) * eps;
		dy = (ran.frand53()*2.0-1.0) * eps;

		/** Calculate sum of Z-differences to it */
		hz  = fabsl(pfxy1(x+dx,y+dy) - pfxy0(x+dx,y+dy));
		hz += fabsl(pfxy2(x+dx,y+dy) - pfxy0(x+dx,y+dy));
		hz += fabsl(pfxy2(x+dx,y+dy) - pfxy1(x+dx,y+dy));

		while(hz<z) {
			if(++steps > maxstep)
				break;
			if(hz<eps) {
				ready = true;
				break;
			}
			z = hz;

			/** Resize random-vector dynamically */
			dx *= 2.0L;
			dy *= 2.0L;

			/** Add random vector to current x,y */
			x+=dx;
			y+=dy;

			/** Calculate new sum of Z-differences to it */
			hz  = fabsl(pfxy1(x+dx,y+dy) - pfxy0(x+dx,y+dy));
			hz += fabsl(pfxy2(x+dx,y+dy) - pfxy0(x+dx,y+dy));
			hz += fabsl(pfxy2(x+dx,y+dy) - pfxy1(x+dx,y+dy));
		}

		if(ready)
			break;

		/** Last random-search wasn't successfull! So take back one step */
		x -= dx;
		y -= dy;
		z  = fabsl(pfxy1(x,y) - pfxy0(x,y));
		z += fabsl(pfxy2(x,y) - pfxy0(x,y));
		z += fabsl(pfxy2(x,y) - pfxy1(x,y));

	} while (steps++ < maxstep);
	msecs=t.stop()*1000.0f;
	QApplication::restoreOverrideCursor();


	/** Generate info-strings for maiWin */
	QString result;
	QString tmp;
	QString qsx, qsy, qsp, qsi, qst, qsxr, qsyr, qszr;
	result=QObject::tr(
		"Search started at:  X=%1  Y=%2\n"
		"Time needed for %3 iterations: %4 ms\n"
		"The result is %5realiable.\n\n"
		"Solution:  X=%6  Y=%7  Z=%8"
	)
	.arg(qsx.setNum(sta.crossX*sta.sx, 'f', 6))    // Full float precision
	.arg(qsy.setNum(sta.crossY*sta.sy, 'f', 6))    // Full float precision
	.arg(qsi.setNum((int)(steps-1)))
	.arg(qst.setNum(msecs, 'f', 1))
	.arg((ready) ? "" : QObject::tr("NOT "))
	.arg(qsxr.setNum((double)(x*sta.sx), 'f', solverPrec))
	.arg(qsyr.setNum((double)(y*sta.sy), 'f', solverPrec))
	.arg(qszr.setNum((double)(pfxy0(x,y)/sta.sz), 'f', solverPrec));

	/** Extra alert on unreliable solution */
	if(!ready)
		QMessageBox::critical(
			0,
			QObject::tr("Solver"),
			QObject::tr("Result is NOT reliable")
		);
	/** Set cross to reliable coordinates; */
	else {
		sta.crossX=(float)x;
		sta.crossY=(float)y;
	}

	return result;
}
