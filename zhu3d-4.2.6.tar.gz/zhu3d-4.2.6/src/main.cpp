/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

/** Includes */
#include <QApplication>
#include <QIcon>
#include <QMessageBox>
#include <QObject>
#include <QTranslator>
#include <QtGlobal>

#include "debug.h"
#include "property.h"
#include "mainwindow.h"
#include "glwidget.h"
#include "ligedit.h"
#include "matedit.h"
#include "entedit.h"
#include "aniedit.h"
#include "moredit.h"
#include "picedit.h"
#include "fntedit.h"
#include "demedit.h"
#include "funedit.h"
#include "speedit.h"
#include "diredit.h"
#include "usredit.h"
#include "legedit.h"
#include "sysinfo.h"
#include "cpuinfo.h"


/** Miscellaneous globals */
QString appPath;       // Path where Zhu3D was actually started from
QString argStr("");    // Saves file argument from bash or window-manager
float MHz = 0.0f;      // Stays zero only, when no supported hardware timer is found


/** Denotes the number of existing CPU-cores. The file property.cpp additionally
 ** provides numCPUset, which holds the core number according to actual user settings */
int numCPU;


/** Global widgets */
MaiWindow *maiWin;    // The central main window widget
OGLWidget *oglWid;    // OpenGL viewer window
usrWidget *usrEdi;    // User defined functions/constants editor
ligWidget *ligEdi;    // Light editor
matWidget *matEdi;    // Material editor
entWidget *entEdi;    // Entire editor for global OpenGL effects like background settings, ...
aniWidget *aniEdi;    // Animation editor
morWidget *morEdi;    // Morphing editor
picWidget *picEdi;    // Picture editor for grabbing png, jpg, ... pics
fntWidget *fntEdi;    // General appeareance/system settings like fonts, languages, guy-style, ...
demWidget *demEdi;    // Demo mode for one-click browsing through examples
funWidget *funEdi;    // Function/parameter/iso input editor
speWidget *speEdi;    // Special OpenGL settings like textures, fog, ...
dirWidget *dirEdi;    // Directory settings for current work-dir and texture-dir
legWidget *legEdi;    // Legends editor for applying text labels
#ifdef ZHUDEBUG
errWidget *errEdi;    // Error messages redirected to own output window
#endif


/** Localization-infos, loading help-files and other stuff
 ** Used later on externally in modules maiWin, fntEdi and usrEdi */
QString zhuLocale;
QTranslator zhuTranslator;


/** Install own message handler, when debugging is enabled.
 ** Normal stderr and Qt4-messages are redirected to own error window */
#ifdef ZHUDEBUG
void myMessageHandler(QtMsgType type, const char *msg) {
	switch (type) {
		case QtDebugMsg:
			PRINT((QString)"Debug: "+msg); break;
		case QtWarningMsg:
			PRINT((QString)"Warning: "+msg); break;
		case QtCriticalMsg:
			PRINT((QString)"Critical: "+msg); break;
		case QtFatalMsg:
			PRINT((QString)"Fatal: "+msg); break;
		abort();
	}
}
#endif


/** *************************************************************************
 ** USAGE: zhu3d [foozhufile]
****************************************************************************/
int main(int argc, char *argv[]) {

	/** Very basic initializations */
	#ifdef ZHUDEBUG
	qInstallMsgHandler(myMessageHandler);
	#endif
	QApplication app(argc, argv);

	/** Very first widget, maybe needed from others */
	#ifdef ZHUDEBUG
	errEdi = new errWidget;
	errEdi->show();
	#endif

	/** Detect the number of real CPU-cores
	 ** Default numCPUset=numCPU, what may be altered from module fntEdi later */
	numCPU = CPUINFO::cores();
	if(numCPU<1 || numCPU>MAXCPU)
		numCPU=1;
	numCPUset=numCPU;

	/** Check clock frequency. Hardware dependent CPU timer has to be implemented in
	 ** ticks.h for this. If not, this does no harm and frequency is just "unknown"
	 ** For wacky Windows this is disabled automatically because of bad timer-granularity */
#if (defined(__i386__) || defined(__i486__) || defined(__i586__) || defined(__i686__) || \
     defined(__x86__) || defined(__x86_64__) || \
     defined(__powerpc__) || \
    (defined(__mips__) && (defined(MIPSEL) || defined (__MIPSEL__))) )
    MHz = CPUINFO::MHz();
#endif

	/** Initialize logo and application-path */
	QIcon appIcon(":/images/icon.png");
	app.setWindowIcon(appIcon);
	appPath = QCoreApplication::applicationDirPath();

	/** General internationalization stuff */
	QTranslator qtTranslator;
	qtTranslator.load("qt_"+zhuLocale);
	app.installTranslator(&qtTranslator);

	/** Set Zhu3D languages */
	zhuLocale = QLocale::system().name();
	zhuLocale.resize(zhuLocale.lastIndexOf('_'));
	zhuTranslator.load(MYLANDIR+"zhu3d_"+zhuLocale);
	app.installTranslator(&zhuTranslator);

	/** Set LC_NUMERIC to force using the dot as decimal delimiter according to C-standard.
	 ** This locale-behavior changed in between Qt4 .0 and Qt 4.5 sometimes. With this it
	 ** should be independent of the QT-version/locale used */
	setlocale(LC_NUMERIC, "C");

	/** Got file argument from command line? This cares for seamless Gui-integration too */
	if(argc==2)
		argStr=argv[1];

	/** Some more basic initializations */
	initSysInfo();              // Inits QStrings (for translations only)
	fpError::initParserQt();    // Inits QStrings (for translations only)
	if(!initAllParsers()) {     // Parser sanity checks
		QMessageBox::critical(
					0,
					QObject::tr("Program start")+"\n",
					fpError::getQtMessage(11)
		);
		return -1;
	}

	/** The format variable for basic OpenGL inits/defaults */
	QGLFormat fmt;

	/** Not even software OpenGL available? Ooops, then it's time to quit immediately */
	if(!fmt.hasOpenGL()) {
		QMessageBox::critical(
					0,
					QObject::tr("Program start")+"\n",
					QObject::tr("Missing OpenGL! Terminating now")
		);
		return -1;
	}

	/**  Enable motion blur through accumulation buffer as default */
	fmt.setAccum(true);
	fmt.setAlpha(true);

	/** Multisampling is costly and mostly not worth the effort. So disabled as default */
	// fmt.setSampleBuffers(true);

	/** Set OpenGL defaults. Availablity of hardware rendering is checked in maiWin later on */
	QGLFormat::setDefaultFormat(fmt);

	/** Create "key" global widgets now in exactly this order */
	oglWid = new OGLWidget;    // OpenGL viewer very first. Some very basic OpenGL inits done here!
	usrEdi = new usrWidget;    // User defined functions editor next! Needed from fntEdi later on

	/** Create remaining global widgets. No special ordering demands here any more */
	ligEdi = new ligWidget;    // Light editor. Nomen est omen
	matEdi = new matWidget;    // Material editor for surface properties
	entEdi = new entWidget;    // Entire editor for global OpenGL effects like background settings, ...
	aniEdi = new aniWidget;    // Animation editor
	morEdi = new morWidget;    // Morphing editor
	picEdi = new picWidget;    // Picture editor for grabbing png, jpg, ... pics
	funEdi = new funWidget;    // Function/parameter/iso input editor
	fntEdi = new fntWidget;    // General appeareance/system settings like fonts, languages, guy-style, ...
	demEdi = new demWidget;    // Demo mode for one-click browsing through examples
	speEdi = new speWidget;    // Special OpenGL settings like textures, fog, ...
	dirEdi = new dirWidget;    // Directory settings for current work-dir and texture-dir
	legEdi = new legWidget;    // Legends editor for applying text labels

	/** All init's done now. Create and bring up the central mainwindow finally */
	maiWin = new MaiWindow;    // Checks HW-OpenGL availability at - and only at - the very 1.st program start
	maiWin->show();            // Everything done. Bring it on

	return app.exec();
}
