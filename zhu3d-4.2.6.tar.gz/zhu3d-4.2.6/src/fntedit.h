/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _FNTEDITOR_H_
#define _FNTEDITOR_H_

#include <QWidget>
#include <QComboBox>
#include <QLabel>
#include <QSpinBox>
#include <QCloseEvent>
#include <QSettings>
#include <QFontDatabase>
#include <cfloat>     // Needed just for double precision in digits

#include "paths.h"    // Get doc/lang/app-paths
#include "property.h"
#include "version.h"
#include "debug.h"


/** General application appearance */
class fntWidget : public QWidget {

Q_OBJECT

public:
	fntWidget(QWidget *parent=0);
	~fntWidget() {}

	QSize getIcoSize() { return QSize(actIcoSize, actIcoSize); }

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

signals:
	/** Inform The MainWindow-Widget to repaint itself
	 ** Needed, because menu-drawing results in odd width otherwise
	 ** Like menu-redrawing, toolbars need strange workaround too */
	void repaintMain();
	void iconSize(const int newSize);

	/** Inform viewer about complete update after change of triangulation mode */
	void gotNewFile();

private slots:
    void setLang(const int index);
    void setFnt(const QString &fntFamily);
    void setFntStyle(const QString &fntStyle);
	void setFntSize(const int size);
	void setIcoSize(const int size) { actIcoSize=size; emit iconSize(size); }
	void setPrec(const int prec) { solverPrec=actPrec=prec; }
	void findStyles();
	void setGui(const QString &gui);
	void setBrowser(const int browser);
	void setTriMod(const int triMod);
	void setThreads(const int n) { actNumCPU=numCPUset=n; iniITL(); }

	/** Are parsers tainted? */
	void lockIsoMode(const bool b) { txt16->setEnabled(!b); com17->setEnabled(!b); }

private:
	QFontDatabase fntDatabase;

	/** Current font/toolbar/Gui... properties */
	int actLang;
	QString actFnt;
	QString actFntStyle;
	QString actGui;
	int actFntSize;
	int actIcoSize;
	int actPrec;
	QStringList guiList;    // Holds Gui's available at start + "Default"
	int actBrowser;         // 0=internal 1=external
	int actTriMod;
	int actNumCPU;

	/** Utility stuff font related */
    void findFnts();        // Build font-database for combos
	QString getSysFnt();
	int getSysFntSize();

	/** Utility stuff localization related */
	void addLanguages();    // Fill language combobox
	void reTranslate();
	void setLangComboIndex();
	int zhuLocaleSupported();

	/** 1.st row of a grid layout; more may follow */
	QLabel    *txt00;
	QComboBox *com01;
	QLabel    *txt02;
	QComboBox *com03;
	QLabel    *txt04;
	QComboBox *com05;
	QLabel    *txt06;
	QSpinBox  *spi07;
	QLabel    *txt08;
	QSpinBox  *spi09;
	QLabel    *txt10;
	QComboBox *com11;
	QLabel    *txt12;
	QComboBox *com13;
	QLabel    *txt14;
	QSpinBox  *spi15;
	QLabel    *txt16;
	QComboBox *com17;
	QLabel    *txt18;
	QSpinBox  *spi19;

	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _FNTEDITOR_H_ */
#endif
