/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _QADRAN_H
#define _QADRAN_H

#include "ctime"


/** NOTE: Quick and dirty random number generator
 ** Do NEVER use this for critical simulations or even crypto purposes
 ** Cycle length = 2^32 in best cases
 **
 ** Merits:
 ** Around 5-6 times faster than system rand()
 ** True 64-bit ints
 ** Full double resolution for frand53() */

class QADRAN {

public:
	QADRAN() { seed=(unsigned int)time(NULL); }
	QADRAN(unsigned int s) : seed(s) {}
	~QADRAN() {}

	/** int [0,2^32-1]-interval */
	unsigned int rand() { return seed=(214013U*seed+2531011U); }

	/** double in [0,1]-interval */
	double frand() { return rand()*(1.0/4294967296.0); }

	/** ULL in [0,2^64-1]-interval */
	unsigned long long rand64() { return rand() | ((unsigned long long)rand() << 32); }

	/** double in [0,1]-interval with a full 53 bit mantissa */
	double frand53() { return rand64()*(1.0/18446744073709551616.0); }

private:
	unsigned int seed;
};

/** _QADRAN_H */
#endif
