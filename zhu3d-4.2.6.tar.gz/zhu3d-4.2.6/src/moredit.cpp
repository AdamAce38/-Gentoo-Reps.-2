/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <cmath>
#include "moredit.h"
#include "glwidget.h"
#include "timers.h"


/** Extern globals */
extern OGLWidget *oglWid;
extern bool oglBusy;


/** Constructor */
morWidget::morWidget(QWidget *parent) : QWidget(parent) {

	/** Set up entire editor */
	Ui_morUI::setupUi(this);
	setMinimumSize(170, 240);
	setWindowTitle(tr("Morphing"));
	timer=new QTimer(this);

	/** Setting/updates */
	readSettings();
	updMorWid();

	/** Lower/upper bounds and steps in between */
	connect(from,  SIGNAL(valueChanged(double)), this, SLOT(fromSlot(double)));
	connect(to,    SIGNAL(valueChanged(double)), this, SLOT(toSlot(double)));
	connect(steps, SIGNAL(valueChanged(int)),    this, SLOT(stepsSlot(int)));

	/** Start/stop morphing */
	connect(pushMorph, SIGNAL(clicked()), this, SLOT(pushMorphSlot()));
	connect(this, SIGNAL(gotNewMorph()), oglWid, SLOT(updateOnMorph()));

	/** Timer stuff */
	connect(frames, SIGNAL(valueChanged(int)), this, SLOT(fpsSlot(int)));
	connect(timer, SIGNAL(timeout()), this, SLOT(workSlot()));
}


/** *************************************************************************
 ** MORPHING-STUFF. The heavy worker slot
****************************************************************************/
void morWidget::workSlot() {
	const int upTo=10;
	static int n=1, avg=0;

	/** For Windows only to avoid crashes */
	if(oglBusy) {
		PROC_EVENT;
		return;
	}

	float tmp;
	static bool rUp=false, rLo=false;
	static bool sUp=false, sLo=false;

	/** Calculate step width */
	tmp=(fabsf(mor.lower)+fabsf(mor.upper))/mor.steps;
	if(mor.val>mor.upper && !sUp) {
		rUp=true;
		rLo=false;
	}
	if(mor.val<mor.lower && !sLo) {
		rLo=true;
		rUp=false;
	}
	if(rUp) {
		tmp*=-1.0f;
		sUp=true;
		sLo=false;
		rLo=false;
	}
	if(rLo) {
		sLo=true;
		sUp=false;
		rUp=false;
	}

	PROC_EVENT;
	mor.val+=tmp;
	emit gotNewMorph();

	/** Prepare averaging */
	load=(int)(100.0f*(mor.fps*msecs));
	avg+=load;

	/** Is averaging load-bar senseful? */
	if(mor.fps<20) {
		if(load>100)
			load=100;
			loadBar->setValue(load);
	}
	else
		if(n++==upTo) {
			load=avg/upTo;
			if(load>100)
				load=100;
			loadBar->setValue(load);
			n=1;
			avg=0;
		}
}

/** Frames per second */
void morWidget::fpsSlot(const int fps) {
	mor.fps=fps;
	updMorWid();
	if(mor.active) {
		timer->stop();
		timer->start(1000/mor.fps);
	}
}

/** Start/stop morphing */
void morWidget::pushMorphSlot() {
	mor.active=!mor.active;
	updMorWid();
	morph(mor.active);
	emit updMaiWid();
}


/** *************************************************************************
 ** UPDATE SLIDER-VALUES IN ANIMATION-EDITOR
****************************************************************************/
void morWidget::updMorWid() {
	QString tmp;

	Ui_morUI::from->setValue((double)mor.lower);
	Ui_morUI::to->setValue((double)mor.upper);
	Ui_morUI::steps->setValue(mor.steps);
	Ui_morUI::steps->setToolTip(tmp.setNum(mor.steps));
	Ui_morUI::frames->setValue(mor.fps);
	Ui_morUI::frames->setToolTip(tmp.setNum(mor.fps));
	if(mor.active)
		Ui_morUI::pushMorph->setText(tr("Stop"));
	else {
		Ui_morUI::pushMorph->setText(tr("Morph"));
		loadBar->setValue(0);
	}
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void morWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_morUI::retranslateUi(this);
		updMorWid();
		setWindowTitle(tr("Morphing"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void morWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void morWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("MorWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("MorWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(200, 280));
		move(QPoint(205, 350));
	}
}

void morWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("MorWindowPos", pos());
	settings.setValue("MorWindowSize", size());
}
