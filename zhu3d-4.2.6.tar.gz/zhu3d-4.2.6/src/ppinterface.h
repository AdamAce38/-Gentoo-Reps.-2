/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _PPINTERFACE_H_
#define _PPINTERFACE_H_

#include <QObject>
#include <QString>

#include "./warp/pwarp/pfparser.h"
#include "debug.h"


/** This module is more or less a plain copy of pinteface.h
 ** The only difference is that the precision is set to long double
 ** Just 3 parsers needed here */
#define PPCOUNT 3


/** Global parsers */
extern pFunctionParser pfpGL[PPCOUNT];


/** Global functions */
int pinitAllParsers(void);


/** _PPINTERFACE_H_ */
#endif
