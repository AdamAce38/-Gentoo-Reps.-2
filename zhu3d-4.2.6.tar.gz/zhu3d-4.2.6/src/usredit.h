/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _USREDITOR_H_
#define _USREDITOR_H_

#include <QWidget>
#include <QTableWidget>
#include <QCloseEvent>
#include <QSettings>
#include <QMenu>
#include <QAction>
#include <QContextMenuEvent>

#include "property.h"
#include "pinterface.h"
#include "version.h"
#include "debug.h"


/** Table of user defined items */
class usrWidget : public QWidget {

Q_OBJECT

public:
	usrWidget(QWidget *parent=0);
	~usrWidget() {}
	void updUsrWid() { for(int i=0; i<MAXUSR; i++) usrTable->item(i, 0)->setText(usr[i]); usrTable->setCurrentCell(0,0); }

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);
	void createActions();
	void contextMenuEvent(QContextMenuEvent *event);

signals:
	void parsersTainted(bool b);

private slots:
	void entryChanged(const int r, const int c);
	void lockUsrSlot(bool b) { this->setEnabled(!b); }
	void delActionSlot();
	void insActionSlot();

private:

	/** Table stuff */
	QTableWidget *usrTable;
	void createUsrTable();

	/** Delete/insert blank rows */
	QAction *delAction;
	QAction *insAction;
	bool rebuild;
	bool blockinsdel;

	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _USREDITOR_H_ */
#endif
