/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "legedit.h"
#include "glwidget.h"


/** Avoid possible recursions */
static bool deleting=false;
static bool creating=false;


/** Extern globals */
extern OGLWidget *oglWid;
extern QFont labelFont;


/** Constructor */
legWidget::legWidget(QWidget *parent) : QWidget(parent) {

	/** Set up entire editor */
	Ui_legUI::setupUi(this);
	setMinimumSize(220,220);
	setWindowTitle(tr("Legends"));
	readSettings();

	/** Populate table */
	createAxesTable();
	axesTable->setCurrentCell(0,0);

	/** Pushbuttons */
	QSize s(22,22);
	leg.locMou=false;
	sync->setIcon(QIcon(":/images/material.png"));
	movMou->setIcon(QIcon(":/images/unlock.png"));
	sync->setIconSize(s);
	movMou->setIconSize(s);

	/** Table connections */
	connect(axesTable, SIGNAL(cellChanged(int, int)), this, SLOT(axesEntryChanged(const int , const int)));
	connect(axesTable, SIGNAL(cellClicked(int, int)), this, SLOT(axesEntryClicked(const int , const int)));

	/** Legend colours */
	connect(LLR, SIGNAL(valueChanged(int)), this, SLOT(llred(int)));
	connect(LLG, SIGNAL(valueChanged(int)), this, SLOT(llgreen(int)));
	connect(LLB, SIGNAL(valueChanged(int)), this, SLOT(llblue(int)));
	connect(locLeg, SIGNAL(clicked()), this, SLOT(legLocked()));
	connect(sync, SIGNAL(clicked()), this, SLOT(syncSlot()));

	/** Move with mouse */
	connect(movMou, SIGNAL(clicked()), this, SLOT(movMouSlot()));

	/** Remember current window dimensions */
	bakWidth=actWidth;
	bakHeight=actHeight;
}


/** *************************************************************************
 ** Table stuff
****************************************************************************/
void legWidget::deleteAxesTable() {
	deleting=true;
	for(int i=0; i<axesTable->rowCount(); i++)
		for(int j=0; j<axesTable->columnCount(); j++)
			delete axesTable->item(i,j);
	deleting=false;
}

void legWidget::createAxesTable() {
	creating=true;
	QStringList columnLabels;
	columnLabels << tr("Item") << tr("Size") << "" << "" << "" << "" << "";

	axesTable->setRowCount(9);
	axesTable->setColumnCount(7);

	axesTable->setHorizontalHeaderLabels(columnLabels);
	axesTable->horizontalHeader()->setResizeMode(0, QHeaderView::Interactive);
	axesTable->horizontalHeader()->setResizeMode(1, QHeaderView::Interactive);
	axesTable->horizontalHeader()->setResizeMode(2, QHeaderView::Fixed);
	axesTable->horizontalHeader()->setResizeMode(3, QHeaderView::Fixed);
	axesTable->horizontalHeader()->setResizeMode(4, QHeaderView::Fixed);
	axesTable->horizontalHeader()->setResizeMode(5, QHeaderView::Fixed);
	axesTable->horizontalHeader()->setResizeMode(6, QHeaderView::Fixed);
	axesTable->verticalHeader()->show();
	axesTable->setShowGrid(true);

	axesTable->setColumnWidth(0,cw0);
	axesTable->setColumnWidth(1,cw1);
	axesTable->setColumnWidth(2,23);
	axesTable->setColumnWidth(3,23);
	axesTable->setColumnWidth(4,23);
	axesTable->setColumnWidth(5,23);
	axesTable->setColumnWidth(6,23);

	for(int row=0; row<9; row++) {
		QTableWidgetItem *item0 = new QTableWidgetItem(leg.label[row]);
		QTableWidgetItem *item1 = new QTableWidgetItem;
		QTableWidgetItem *item2 = new QTableWidgetItem;
		QTableWidgetItem *item3 = new QTableWidgetItem;
		QTableWidgetItem *item4 = new QTableWidgetItem;
		QTableWidgetItem *item5 = new QTableWidgetItem;
		QTableWidgetItem *item6 = new QTableWidgetItem;

		item1->setData(Qt::DisplayRole, qVariantFromValue((int)leg.rfsize[row]));

		item2->setData(Qt::DecorationRole, qVariantFromValue(QIcon(":/images/left.png")));
		item3->setData(Qt::DecorationRole, qVariantFromValue(QIcon(":/images/right.png")));
		item4->setData(Qt::DecorationRole, qVariantFromValue(QIcon(":/images/up.png")));
		item5->setData(Qt::DecorationRole, qVariantFromValue(QIcon(":/images/down.png")));

		if(leg.enabled[row])
			item6->setData(Qt::DecorationRole, qVariantFromValue(QIcon(":/images/ok.png")));
		else
			item6->setData(Qt::DecorationRole, qVariantFromValue(QIcon(":/images/cancel.png")));

		axesTable->setItem(row, 0, item0);
		axesTable->setItem(row, 1, item1);
		axesTable->setItem(row, 2, item2);
		axesTable->setItem(row, 3, item3);
		axesTable->setItem(row, 4, item4);
		axesTable->setItem(row, 5, item5);
		axesTable->setItem(row, 6, item6);
	}

	/** Any static legends to generate? */
	leg.genLeg=false;
	for(int i=3; i<9; i++)
		if(leg.enabled[i])
			leg.genLeg=true;

	if(leg.locMou)
		movMou->setIcon(QIcon(":/images/lock.png"));
	else
		movMou->setIcon(QIcon(":/images/unlock.png"));
	creating=false;
}

/** Entry changed */
void legWidget::axesEntryChanged(const int r, const int c) {
	if(deleting || creating)
		return;

	leg.curRow=r;

	/** Consider columns "Item" and "Size" only */
	switch(c) {
		case 0:
			leg.label[r]=axesTable->item(r,c)->text();
			oglWid->updateGLonly();
			break;
		case 1:
			leg.rfsize[r]=axesTable->item(r,c)->text().toInt();
			if(leg.rfsize[r]<MINFON) {
				leg.rfsize[r]=MINFON;
				cw0=axesTable->columnWidth(0);
				cw1=axesTable->columnWidth(1);
				deleteAxesTable();
				createAxesTable();
			}
			leg.prop[r]=leg.rfsize[r]/(float)actWidth;
			oglWid->updateGLonly();
			break;
	}
}

/** Cell clicked */
void legWidget::axesEntryClicked(const int r, const int c) {
	const long tmp=leg.curRow=r;

	updSli();

	/** Item or size? */
	if(c<2)
		return;

	switch(c) {
		// Move left
		case 2: leg.xOffs[r]-=leg.offs; break;

		// Move right
		case 3: leg.xOffs[r]+=leg.offs; break;

		// Move up
		case 4: leg.yOffs[r]+=leg.offs; break;

		// Move down
		case 5: leg.yOffs[r]-=leg.offs; break;

		// Not kidding. Rebuild all when on/off was clicked
		case 6: leg.enabled[r]=!leg.enabled[r];
				cw0=axesTable->columnWidth(0);
				cw1=axesTable->columnWidth(1);
				deleteAxesTable();
				createAxesTable();
				break;
	}

	leg.genLeg=false;
	for(int i=3; i<9; i++)
		if(leg.enabled[i])
			leg.genLeg=true;

	leg.curRow=tmp;
	oglWid->updateGLonly();
}

/** Lock mouse */
void legWidget::movMouSlot() {
	leg.locMou=!leg.locMou;
	if(leg.locMou)
		movMou->setIcon(QIcon(":/images/lock.png"));
	else
		movMou->setIcon(QIcon(":/images/unlock.png"));
}

/** Sync colours */
void legWidget::syncSlot() {

	/** Axes labels? */
	if(leg.curRow<3)
		return;

	/** Sync all other labels */
	for(int i=0; i<6; i++) {
		for(int j=0; j<4; j++)
			leg.ligLeg[i][j]=leg.ligLeg[leg.curRow-3][j];
		leg.locLeg[i+3]=leg.locLeg[leg.curRow];
	}

	oglWid->updateGLonly();
}


/** *************************************************************************
 ** COLOUR SLIDERS
****************************************************************************/
void legWidget::llall(const int channel, const int intensity) {
	int i;

	if(leg.curRow<3) {
		if(leg.locLeg[leg.curRow]) {
			for(i=0; i<3; i++)
				sta.axisCol[i]=intensity/255.0f;
			updSli();
		}
		else
			sta.axisCol[channel]=intensity/255.0f;

		/** Reset lock-flags too */
		for(i=0; i<3; i++)
			leg.locLeg[i]=leg.locLeg[leg.curRow];
	}

	if(leg.curRow>2) {
		if(leg.locLeg[leg.curRow]) {
			for(i=0; i<3; i++)
				leg.ligLeg[leg.curRow-3][i]=intensity/255.0f;
			updSli();
		}
		else
			leg.ligLeg[leg.curRow-3][channel]=intensity/255.0f;
	}

	oglWid->updateGLonly();
}

void legWidget::legLocked() {
	leg.locLeg[leg.curRow]=!leg.locLeg[leg.curRow];
	if(leg.curRow<3)
		for(int i=0; i<3; i++)
			leg.locLeg[i]=leg.locLeg[leg.curRow];
}

void legWidget::updSli() {
	locLeg->setChecked(leg.locLeg[leg.curRow]);

	if(leg.curRow<3) {
		LLR->setValue((int)(sta.axisCol[0]*255.0f));
		LLG->setValue((int)(sta.axisCol[1]*255.0f));
		LLB->setValue((int)(sta.axisCol[2]*255.0f));
	}
	else {
		LLR->setValue((int)(leg.ligLeg[leg.curRow-3][0]*255.0f));
		LLG->setValue((int)(leg.ligLeg[leg.curRow-3][1]*255.0f));
		LLB->setValue((int)(leg.ligLeg[leg.curRow-3][2]*255.0f));
	}
}


/** *************************************************************************
 ** UPDATE WIDGET
****************************************************************************/
void legWidget::updLegWid() {
	const long tmp=leg.curRow;

	/** Window dimensions changed from OpenGL viewer? */
	if(bakWidth!=actWidth || bakHeight!=actHeight) {
		for(int i=0; i<9; i++) {
			leg.rfsize[i]=rf2i(actHeight*leg.prop[i]);
			if(leg.rfsize[i]<MINFON)
				leg.rfsize[i]=MINFON;
		}
		bakWidth=leg.savWidth=actWidth;
		bakHeight=leg.savHeight=actHeight;
	}

	/** Table stuff */
	cw0=axesTable->columnWidth(0);
	cw1=axesTable->columnWidth(1);
	deleteAxesTable();
	createAxesTable();

	/** Sliders */
	axesTable->setCurrentCell(leg.curRow=tmp,0);
	updTru=false;
	updSli();
	updTru=true;
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void legWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_legUI::retranslateUi(this);
		setWindowTitle(tr("Legends"));
		updLegWid();
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void legWidget::closeEvent(QCloseEvent *event) {
	leg.curRow=0;
	leg.locMou=false;
	writeSettings();
	event->accept();
}

void legWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("LegWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("LegWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
		cw0=settings.value("cw0").toInt();
		cw1=settings.value("cw1").toInt();
	}
	else {
		resize(QSize(480, 370));
		move(QPoint(70, 190));
		cw0=120;
		cw1=60;
	}
}

void legWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("LegWindowPos", pos());
	settings.setValue("LegWindowSize", size());

	settings.setValue("cw0", axesTable->columnWidth(0));
	settings.setValue("cw1", axesTable->columnWidth(1));
}
