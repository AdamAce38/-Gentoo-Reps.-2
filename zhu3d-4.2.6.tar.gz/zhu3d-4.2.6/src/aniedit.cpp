/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <cmath>
#include "aniedit.h"
#include "glwidget.h"


/** Extern global from OpenGL-viewer */
extern OGLWidget *oglWid;


const float aniWidget::offset = 1.0f;


/** Constructor */
aniWidget::aniWidget(QWidget *parent) : QWidget(parent) {

	/** Set up entire editor */
	Ui_aniUI::setupUi(this);
	setMinimumSize(100, 240);
	setWindowTitle(tr("Film"));
	readSettings();

	/** Init timer stuff */
	load=0;
	timer=new QTimer(this);

	/** Connections */
	connect(xOff, SIGNAL(valueChanged(int)), this, SLOT(xSlot(int)));
	connect(yOff, SIGNAL(valueChanged(int)), this, SLOT(ySlot(int)));
	connect(zOff, SIGNAL(valueChanged(int)), this, SLOT(zSlot(int)));

	connect(pushAni, SIGNAL(clicked()), this, SLOT(pushAniSlot()));
	connect(locXYZ,  SIGNAL(clicked()), this, SLOT(aniXYZLocked()));
	connect(frames,  SIGNAL(valueChanged(int)), this, SLOT(fpsSlot(int)));

	/** Call for OpenGL-update & local timer */
	connect(this, SIGNAL(gotNewAni()), oglWid, SLOT(updateGLonly()));
	connect(timer, SIGNAL(timeout()), this, SLOT(workSlot()));
}


/** *************************************************************************
 ** GO
****************************************************************************/
void aniWidget::workSlot() {
	const int upTo=10;
	static int n=1, avg=0;

	/** Calculate offsets */
	sta.rotX += (ani.xFac/50.0f) * offset;
	sta.rotY += (ani.yFac/50.0f) * offset;
	sta.rotZ += (ani.zFac/50.0f) * offset;

	/** Renormalize to slider range -360..360 */
	if(fabsf(sta.rotX)>360.0f) sta.rotX = fmodf(sta.rotX, 360.0f);
	if(fabsf(sta.rotY)>360.0f) sta.rotY = fmodf(sta.rotY, 360.0f);
	if(fabsf(sta.rotZ)>360.0f) sta.rotZ = fmodf(sta.rotZ, 360.0f);

	/** Inform eveybody */
	emit gotNewAni();
	emit xRotationChanged((int)sta.rotX);
	emit yRotationChanged((int)sta.rotY);
	emit zRotationChanged((int)sta.rotZ);

	/** Prepare averaging */
	load=(int)(100.0f*(ani.fps*asecs));
	avg+=load;

	/** Is averaging load-bar senseful? */
	if(ani.fps<20) {
		if(load>100)
			load=100;
		loadBar->setValue(load);
	}
	else
		if(n++==upTo) {
			load=avg/upTo;
			if(load>100)
				load=100;
			loadBar->setValue(load);
			n=1;
			avg=0;
		}
}

/** Start/stop animation */
void aniWidget::pushAniSlot() {

	ani.active = !ani.active;
	if(ani.active)
		this->animate(true);
	else
		this->animate(false);

	updAniWid();
	emit updMaiWid();
}

void aniWidget::animate(const bool mode) {
	if(mode)
		timer->start(1000/ani.fps);
	else {
		timer->stop();
		loadBar->setValue(0);
	}
	emit updMaiWid();
}

/** Change frames per second */
void aniWidget::fpsSlot(const int fps) {
	ani.fps=fps;
	updAniWid();
	if(ani.active)
		timer->start(1000/ani.fps);
	
}


/** *************************************************************************
 ** SET OFFSETS
****************************************************************************/
void aniWidget::xSlot(const int xVal) {
	ani.xFac=xVal;
	if(ani.locXYZ) {
		ani.yFac=ani.zFac=ani.xFac;
		updAniWid();
	}
}

void aniWidget::ySlot(const int yVal) {
	ani.yFac=yVal;
	if(ani.locXYZ) {
		ani.xFac=ani.zFac=ani.yFac;
		updAniWid();
	}
}

void aniWidget::zSlot(const int zVal) {
	ani.zFac=zVal;
	if(ani.locXYZ) {
		ani.xFac=ani.yFac=ani.zFac;
		updAniWid();
	}
}


/** *************************************************************************
 ** UPDATE SLIDER-VALUES IN ANIMATION-EDITOR
****************************************************************************/
void aniWidget::updAniWid() {
	QString tmp;

	xOff->setValue(ani.xFac);
	yOff->setValue(ani.yFac);
	zOff->setValue(ani.zFac);
	locXYZ->setChecked(ani.locXYZ);
	frames->setValue(ani.fps);
	frames->setToolTip(tmp.setNum(ani.fps));

	if(ani.active) {
		loadBar->setValue(load);
		Ui_aniUI::pushAni->setText(tr("Stop"));
	}
	else {
		loadBar->setValue(0);
		Ui_aniUI::pushAni->setText(tr("Animate"));
	}
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void aniWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_aniUI::retranslateUi(this);
		updAniWid();
		setWindowTitle(tr("Film"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void aniWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void aniWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("AniWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("AniWindowSize", QSize(0, 0)).toSize();

	// Ensure to start with defaults on 1st program-start ever
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(150, 280));
		move(QPoint(40, 350));
	}
}

void aniWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("AniWindowPos", pos());
	settings.setValue("AniWindowSize", size());
}
