/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _GLDRAW_H_
#define _GLDRAW_H_

#include <QApplication>
#include "property.h"
#include "debug.h"


/** Global access */
extern bool listUp[MAXFUN+1];     // Update for OpenGL-lists needed?
extern bool drawFunGL[MAXFUN];    // Select functions/implicite functions to draw


/** Comfort functions for parser calling needed from mainwidget */
float fxy0(const float xpar, const float ypar);
float fxy1(const float xpar, const float ypar);
float fxy2(const float xpar, const float ypar);


/** List-generation/drawing routines */
void Draw_Points(void);
void Draw_Quads(void);
void Draw_Triangles(void);


/** Set correct function/implicte function to draw */
void Draw_Which(void);

/** _GLDRAW_H_ */
#endif
