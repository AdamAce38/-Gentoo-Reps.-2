/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _ERROREDITOR_H_
#define _ERROREDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>
#include <QTextEdit>

#include "ui_error.h"
#include "version.h"


/** Error handling */
class errWidget : public QWidget, private Ui::errUI {

Q_OBJECT

public:
	errWidget(QWidget *parent=0);
	~errWidget() {}

	void print(const QString message);
	void print(const char *message);
	void print(const unsigned char *message);

	void print(const char message);
	void print(const unsigned char message);

	void print(const int message);
	void print(const unsigned int message);

	void print(const long message);
	void print(const unsigned long message);

	void print(const long long message);
	void print(const unsigned long long message);

	void print(const float message);
	void print(const double message);
	void print(const long double message);

protected:
	void closeEvent(QCloseEvent *event);

private:
	void readSettings();
	void writeSettings();
};

/** _ERROREDITOR_H_ */
#endif
