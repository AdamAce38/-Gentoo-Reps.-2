/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <GL/gl.h>
#include "cpuinfo.h"
#include "sysinfo.h"


/** Defines */
#if (defined(WINDOWS) || defined(WIN32) || defined(WIN64))
	#define OS "OS"
	#define CPU "PROCESSOR_ARCHITECTURE"    // x86
#else
	#define OS "OSTYPE"
	#define CPU "CPU"    // i686
	extern char **environ;
#endif


/** Extern globals */
extern OGLWidget *oglWid;    // OpenGL-viewer window
extern float MHz;            // CPU clock was calculated in main
extern int numCPU;           // Number of CPU's/cores calculated in main


/** Localization stuff */
static QString yes;
static QString no;


/** Needed, because a "pure" QObject is not translated!. Initialized from main() */
void initSysInfo() {
	yes = QObject::tr("Yes");
	no = QObject::tr("No");
}


/** Maximum texture size available */
static int maxTex() {
	int max;
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &max);
	return max;
}


/** Check system out */
QString systemInfo() {
	QString tmp, tmp1, numStr;

	/** Check OS and CPU */
	tmp = "OS = ";
	#if (defined(WINDOWS) || defined(WIN32) || defined(WIN64))
		tmp1 = getenv(OS);
		if(!tmp1.isEmpty()) {
			tmp += tmp1 + "\n";
			tmp1 = getenv(CPU);
			if(!tmp1.isEmpty())
				tmp += "CPU = " + tmp1 + "\n";
			else
				tmp += "CPU = ?\n";
		}
		else {
			tmp += "Windows < XP\n";
			tmp += "CPU = ?\n";
		}
	// *nix, Mac OS
	#else
		tmp1 = getenv(OS);
		if(!tmp1.isEmpty())
			tmp += tmp1 + "\n";
		else
			tmp += "?\n";

		tmp1 = getenv(CPU);
		if(!tmp1.isEmpty())
			tmp += "CPU = " + tmp1 + "\n";
		else
			tmp += "CPU = ?\n";
	#endif

	/** Endianess */
	tmp += "Byte order = ";
	if(CPUINFO::isBigEndian())
		tmp += "Big-endian\n";
	else
		tmp += "Little-endian\n";

	/** Number of CPU's/cores was calculated in main at program-start */
	tmp += "Cores = ";
	tmp += numStr.number(numCPU) + "\n";

	/** MHz was calculated in main at program-start */
	#if !(defined(WINDOWS) || defined(WIN32) || defined(WIN64))
	tmp += "MHz = ";
	if(MHz>0.0f && MHz<10000.0f)
		tmp += numStr.number(MHz, 'f', 2) + "\n";
	else
		tmp += "?\n";
	#endif

	/** $MACHTYPE holds machine type */
	tmp1 = getenv("MACHTYPE");
	if(!tmp1.isEmpty())
		tmp += "MACHTYPE = " + tmp1 + "\n";
	else
		tmp += "MACHTYPE = ?\n";

	/** SSE3 */
	tmp+="SSE3 enabled : ";
	#ifdef USE_SSE3
		tmp+=yes+"\n";
	#else
		tmp+=no+"\n";
	#endif

	/** OpenGL hardware support */
	tmp+="Hardware OpenGL : ";
	if(oglWid->format().directRendering())
		tmp+=yes+"\n\n";
	else
		tmp+=no+"\n\n";

	/** Check miscellaneous OpenGL properties */
	tmp+="Double buffering : ";
	if(oglWid->format().doubleBuffer()) tmp+=yes+"\n"; else tmp+=no+"\n";

	tmp+="RGBA mode : ";
	if(oglWid->format().rgba()) tmp+=yes+"\n"; else tmp+=no+"\n";

	tmp+="Overlay support : ";
	if(oglWid->format().hasOpenGLOverlays()) tmp+=yes+"\n"; else tmp+=no+"\n";

	tmp+="Multisample support : ";
	if(oglWid->format().sampleBuffers()) tmp+=yes+"\n"; else tmp+=no+"\n";

	tmp+="Depth buffer : ";
	if(oglWid->format().depth()) tmp+=yes+"\n"; else tmp+=no+"\n";
	tmp+="Depth buffer size = ";
	if(oglWid->format().depth())
		tmp += numStr.number(oglWid->format().depthBufferSize()) + " KB\n";
	else
		tmp+="?\n";

	tmp+="Stencil buffer : ";
	if(oglWid->format().stencil()) tmp+=yes+"\n"; else tmp+=no+"\n";
	tmp+="Stencil buffer size = ";
	if(oglWid->format().stencil())
		tmp += numStr.number(oglWid->format().stencilBufferSize()) + " KB\n";
	else
		tmp+="?\n";

	tmp+="Alpha buffer : ";
	if(oglWid->format().alpha()) tmp+=yes+"\n"; else tmp+=no+"\n";
	tmp+="Alpha buffer size = ";
	if(oglWid->format().alpha())
		tmp += numStr.number(oglWid->format().alphaBufferSize()) + " KB\n";
	else
		tmp+="?\n";

	tmp+="Accumulation buffer : ";
	if(oglWid->format().accum()) tmp+=yes+"\n"; else tmp+=no+"\n";
	tmp+="Accumulation buffer size = ";
	if(oglWid->format().accum())
		tmp += numStr.number(oglWid->format().accumBufferSize()) + " KB\n";
	else
		tmp+="?\n";

	tmp+="Max. texture size = ";
	tmp+=numStr.number(maxTex())+"\n";

	return tmp;
}

