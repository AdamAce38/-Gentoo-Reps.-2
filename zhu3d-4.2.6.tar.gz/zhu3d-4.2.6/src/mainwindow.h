/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _MAINWINDOW_H_
#define _MAINWINDOW_H_

#include <QMainWindow>
#include <QWidget>
#include <QString>
#include <QTimer>
#include <QDesktopServices>
#include <QUrl>
#include <QPushButton>

#include "ui_mainwindow.h"
#include "glwidget.h"
#include "ligedit.h"
#include "matedit.h"
#include "entedit.h"
#include "aniedit.h"
#include "moredit.h"
#include "picedit.h"
#include "fntedit.h"
#include "demedit.h"
#include "funedit.h"
#include "speedit.h"
#include "diredit.h"
#include "usredit.h"
#include "legedit.h"
#include "gldraw.h"
#include "solver.h"
#include "fileio.h"
#include "sysinfo.h"    // Check out system
#include "version.h"    // Name and version
#include "debug.h"      // Turn on/off debugging there


/** Miscellaneous */
extern QString argStr;       // File to open from command-line?


/** Viewer and widgets */
extern OGLWidget *oglWid;    // OpenGL-Viewer
extern ligWidget *ligEdi;    // Light editor
extern matWidget *matEdi;    // Material editor
extern entWidget *entEdi;    // Entire editor
extern aniWidget *aniEdi;    // Animation editor
extern morWidget *morEdi;    // Morphing editor
extern picWidget *picEdi;    // Pic-dimension editor
extern fntWidget *fntEdi;    // Font editor
extern demWidget *demEdi;    // Demo mode
extern funWidget *funEdi;    // Function editor
extern speWidget *speEdi;    // Special settings
extern dirWidget *dirEdi;    // Directory settings
extern usrWidget *usrEdi;    // User defined functions/constants editor
extern legWidget *legEdi;    // Legends editor


/** *************************************************************************
 ** MAINWINDOW-CLASS; Ui::name=Objectname from Designer
****************************************************************************/
class MaiWindow : public QMainWindow, private Ui::mainCtrl {

	Q_OBJECT

public:
	MaiWindow();

	/** Public for demo mode only */
	void loadFile(const QString &fileName);
	void performOGLUpdate() { Draw_Which(); initAllParsers(); emit gotNewFile(); }

protected:
	void closeEvent(QCloseEvent *event) { event->accept(); exitSlot(); };
	void changeEvent(QEvent* event);

private slots:
	void newSlot();
	void openSlot();
	void saveAsSlot();
	void exitSlot();
	void systemSlot();
	void helpSlot();
	void aboutSlot();

	void wireModeSlot();
	void solveSlot();
	void saveSolSlot();

	/** Editor menus */
	void lightSlot();       // Show light editor
	void materialSlot();    // Show material editor
	void entireSlot();      // Show entire editor
	void userSlot();        // Show user table editor
	void legendsSlot();     // Show legends editor
	void solverSlot();      // Show solver editor
	void functionSlot();    // Show function editor

	/** Special menus */
	void animateSlot();     // Show animation editor
	void morphSlot();       // Show morph editor
	void specialSlot();     // Show special settings

	/** Settings menus */
	void pictureSlot();     // Show pic-dimension editor
	void sfineScale();      // Set scaling
	void fineScale();
	void normalScale();
	void coarseScale();
	void resetViewSlot();   // Handle resets
	void resetScaleSlot();
	void resetLightSlot();
	void resetAllSlot();
	void fontSlot();        // Show appfont-editor
	void directorySlot();   // Show directory settings

	/** Window menus */
	void toFrontSlot();    // Bring all minimized editors to front
	void toBackSlot();     // Hide/minimize all open editors
	void showAllSlot();    // Show all editors

	/** Timer utilizing stuff */
	void runStopAnimationSlot();    // Toggle animation on/off
	void runStopMorphSlot();        // Toggle morphing on/off
	void demoSlot();
	void benchmarkSlot();
	void benchTimerSlot() { benchReady=true; }

	/** Adjust size, when sysFnt is changed in fntEdi
	 ** Resizing only leaves quite odd menu-entries */
	void repaintSlot() { const QSize tmp=size(); adjustSize(); resize(tmp); }
	void iconSizeSlot(const int newSize);

	/** Update */
	void updMaiWid();    // Update main-widget
	void updMaiInf();    // Update info/cross-section only

	/** Lock elements */
	void lockMainSlot(bool b) { this->setEnabled(!b); }
	void lockBenchSlot(bool b) { benchmarkAction->setEnabled(!b); }

signals:
	void gotNewFile();    // Inform OpenGL viewer about new file loaded
	void gotNewView();    // Inform OpenGL viewer to update view only

private:
	void createMenus();
	void createActions();
	void createToolBars();
	void reTranslate();

	/** File-stuff */
	void setCurrentFile(const QString &fileName);
	QString currentFile;
	QString currentWindowName;

	QWidget *controlCenter;    // Main controls
	QTextBrowser *hlpEdi;      // Help editor
	QTextEdit *solEdi;         // Solver editor

	/** Menus */
	QMenu *fileMenu;
	QMenu *editorMenu;
	QMenu *specialMenu;
	QMenu *settingsMenu;
	QMenu *scaleMenu;    // Submenu from Settings
	QMenu *resetMenu;    // Submenu from Settings
	QMenu *windowsMenu;
	QMenu *helpMenu;

	/** Actions for menus */
	QToolBar *fileToolBar;
	QToolBar *zoomToolBar;
	QToolBar *transToolBar;
	QToolBar *extraToolBar;

	QAction *newAction;
	QAction *openAction;
	QAction *saveSolAction;
	QAction *saveAsAction;
	QAction *printAction;
	QAction *exitAction;

	QAction *lightAction;
	QAction *materialAction;
	QAction *animateAction;
	QAction *morphAction;
	QAction *entireAction;
	QAction *solEdiAction;
	QAction *funEdiAction;
	QAction *usrEdiAction;
	QAction *legEdiAction;
	QAction *speEdiAction;
	QAction *dirEdiAction;
	QAction *toFrontAction;
	QAction *toBackAction;
	QAction *showAllAction;

	QAction *pictureAction;
	QAction *savePicAction;
	QAction *sfineAction;
	QAction *fineAction;
	QAction *normalAction;
	QAction *coarseAction;
	QAction *fontAction;

	QAction *runStopAnimationAction;
	QAction *runStopMorphAction;
	QAction *benchmarkAction;

	QAction *helpAction;
	QAction *demoAction;
	QAction *systemAction;
	QAction *aboutAction;
	QAction *aboutQtAction;

	/** Actions for toolbars */
	QAction *zoomInAction;
	QAction *zoomOutAction;

	QAction *transLeftAction;
	QAction *transRightAction;
	QAction *transUpAction;
	QAction *transDownAction;

	QAction *resetViewAction;
	QAction *resetScaleAction;
	QAction *resetLightAction;
	QAction *resetAllAction;
	QAction *solveAction;

	/** Booleans for settings menu */
	bool sfineChecked;
	bool fineChecked;
	bool normalChecked;
	bool coarseChecked;

	bool benchReady;    // Flag for singleshot-timer

	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _MAINWINDOW_H_ */
#endif
