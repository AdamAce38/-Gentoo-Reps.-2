/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <cmath>
#include <ctime>
#include "ppinterface.h"
#include "property.h"
#include "qadran.h"


/** NOTE: For accuracy reasons this module assumes, that PFPFLOAT = long double */


#define PMAXUSR MAXUSR


/** Global parsers. Use 0..2 here only */
pFunctionParser pfpGL[PPCOUNT];


/** Parser for new constants and functions */
static pFunctionParser pvirp;             // A "virgin" parser used for initializing
static pFunctionParser pconp;             // The parser holding user defined constants
static pFunctionParser pfunp[PMAXUSR];    // The parsers holding user defined functions
static int pfunpCount=0;                  // Counter gets 0..PMAXUSR-1 during execution


/** Fetch entries from user item table */
static int pfetchNewConstant(const QString &s);
static int pfetchNewFunction(const QString &s);
static int pfetchItem(const QString &s);


/** Local functions */
static bool paddParserConstant(const std::string &name, PFPFLOAT val);
static bool paddDefParserFunction(const std::string &name, PFPFLOAT (*funPtr)(const PFPFLOAT*), int parAmount);
static bool paddNewParserFunction(const std::string &name, pFunctionParser &toAdd);
static int pupdateAllParsers(void);
static QADRAN ran;


/** *************************************************************************
 ** Local default function stuff used in every parser
****************************************************************************/
inline static PFPFLOAT psig(const PFPFLOAT *p) {
	if(p[0]>0.0L) return 1.0L;
	if(p[0]<0.0L) return -1.0L;
	return 0.0L;
}

inline static PFPFLOAT pfrac(const PFPFLOAT *p) {
	PFPFLOAT tmp=p[0];
	return tmp-=(PFPFLOAT)((int)tmp);
}

inline static PFPFLOAT plog2(const PFPFLOAT *p) {
	return log10l(p[0])/log10l(2.0L);
}

inline static PFPFLOAT ppower(const PFPFLOAT *p) {
	return powl(p[0], p[1]);
}

inline static PFPFLOAT pmodul(const PFPFLOAT *p) {
	return (PFPFLOAT)((int)p[0]%(int)p[1]);
}

inline static PFPFLOAT pgamma(const PFPFLOAT *p) {
	return tgammal(p[0]);
}

inline static PFPFLOAT prand(const PFPFLOAT *p) {
	return (ran.frand()*2.0-1.0)*p[0];
}


/** *************************************************************************
 ** New user defined constants and functions
****************************************************************************/

/** Fetch constant; name=vals */
static int pfetchNewConstant(const QString &s) {

	const QString name(s.section('=',0,0));
	const QString vals(s.section('=',1,1));
	PFPFLOAT vars[1], fval;
	int err;

	/** Extract value */
	pconp.Parse(q2cstrcpy(vals), "");
	if((err=pconp.GetParseErrorType()) != pFunctionParser::FP_NO_ERROR)
		return err;
	fval=pconp.Eval(vars);

	/** "ERROR 13: Adding new constant failed" */
	if(!paddParserConstant(q2cstrcpy(name), fval))
		return 13;

	/** Everything was ok so far */
	return pFunctionParser::FP_NO_ERROR;
}

/** Fetch function; ame(pars,...)=funs */
static int pfetchNewFunction(const QString &s) {

	const QString name(s.section('=',0,0).section('(',0,0));
	const QString pars(s.section(')',0,0).section('(',1,1));
	const QString funs(s.section('=',1,1));
	char cfuns[funs.length()+1];
	int err;

	/** "ERROR 14: Adding new function failed"
	 ** Too much user entries made so far */
	if(pfunpCount==(PMAXUSR-1))
		return 14;

	/** Check syntax for new entry */
	q2cstrcpy(cfuns, funs);
	pfunp[pfunpCount].Parse(cfuns, q2cstrcpy(pars));
	if((err=pfunp[pfunpCount].GetParseErrorType()) != pFunctionParser::FP_NO_ERROR) {
		pfunp[pfunpCount].Parse("0", "");
		return err;
	}

	/** "ERROR 14: Adding new function failed" */
	if(!paddNewParserFunction(q2cstrcpy(name), pfunp[pfunpCount]))
		return 14;

	/** Everything was ok so far */
	pfunpCount++;
	return pFunctionParser::FP_NO_ERROR;
}

/** Returns pFunctionParser::FP_NO_ERROR on success, error number else */
static int pfetchItem(const QString &s) {
	QString tmp;

	/** Check comment or empty string */
	if(s[0]==QChar('#') || s.isEmpty())
		return pFunctionParser::FP_NO_ERROR;

	/** "ERROR 12: Missing equal sign" */
	if(!s.contains(QChar('=')))
		return 12;
	else
		tmp=prepareInput(s);

	/** Check for constant first */
	if(!tmp.contains(")="))
		return pfetchNewConstant(tmp);

	/** Else item must be a function */
	return pfetchNewFunction(tmp);
}


/** *************************************************************************
 ** Adding stuff
****************************************************************************/

/** Add a constant to all parsers */
static bool paddParserConstant(const std::string &name, PFPFLOAT val) {
	long i;

	if(!pconp.AddConstant(name, val))
		return false;

	for(i=0; i<PMAXUSR; i++)
		if(!pfunp[i].AddConstant(name, val))
			return false;

	for(i=0; i<PPCOUNT; i++)
		if(!pfpGL[i].AddConstant(name, val))
			return false;

	return true;
}

/** Add a default function to all parsers */
static bool paddDefParserFunction(const std::string &name, PFPFLOAT (*funPtr)(const PFPFLOAT*), int parAmount) {
	long i;

	for(i=0; i<PPCOUNT; i++)
		if(!pfpGL[i].AddFunction(name, funPtr, (unsigned)parAmount))
			return false;

	for(i=0; i<PMAXUSR; i++)
		if(!pfunp[i].AddFunction(name, funPtr, (unsigned)parAmount))
			return false;

	return true;
}

/** Add a new function to all parsers */
static bool paddNewParserFunction(const std::string &name, pFunctionParser &toAdd) {
	long i;

	if(!pconp.AddFunction(name, toAdd))
		return false;

	for(i=pfunpCount+1; i<PMAXUSR; i++)
		if(!pfunp[i].AddFunction(name, toAdd))
			return false;

	for(i=0; i<PPCOUNT; i++)
		if(!pfpGL[i].AddFunction(name, toAdd))
			return false;

	return true;
}


/** *************************************************************************
 ** Central parser stuff
****************************************************************************/

/** Called when loading a new file or when making user defined entries */
int pinitAllParsers(void) {
	int i, err;

	/** Care for a reasonable starting point with "virgin" parsers */
	for(i=0; i<PPCOUNT; i++) pfpGL[i]=pvirp;
	for(i=0; i<PMAXUSR; i++) pfunp[i]=pvirp;
	pconp=pvirp;
	pfunpCount=0;

	/** Add all default constants */
	if(!paddParserConstant("_pi",(PFPFLOAT)3.1415926535897932384)) return 11;
	if(!paddParserConstant("_e", (PFPFLOAT)2.7182818284590452354)) return 11;
	if(!paddParserConstant("_c", (PFPFLOAT)299792458.0)) return 11;

	/** Add all default functions */
	if(!paddDefParserFunction("sig",   psig,    1)) return 11;
	if(!paddDefParserFunction("rnd",   prand,   1)) return 11;
	if(!paddDefParserFunction("frac",  pfrac,   1)) return 11;
	if(!paddDefParserFunction("log2",  plog2,   1)) return 11;
	if(!paddDefParserFunction("pow",   ppower,  2)) return 11;
	if(!paddDefParserFunction("mod",   pmodul,  2)) return 11;
	if(!paddDefParserFunction("gamma", pgamma,  1)) return 11;

	/** Fetch user items */
	for(i=0; i<PMAXUSR; i++)
		if((err=pfetchItem(usr[i])) != pFunctionParser::FP_NO_ERROR)
			return err;

	/** Update at last */
	if((err=pupdateAllParsers()) != pFunctionParser::FP_NO_ERROR)
		return err;

	/** Everything was ok */
	return pFunctionParser::FP_NO_ERROR;
}


#define PFPOPTIMIZER
/** *************************************************************************
 ** Needed for opening new files or entering new functions/constants and is
 ** evaluated only once there. Time needed is some ms even for complicated
 ** calculations. So not fiddling arround and update all together
****************************************************************************/
static int pupdateAllParsers(void) {

	int i, err;

	/** Functions */
	for(i=0; i<3; i++) {
		pfpGL[i].Parse(fun[i].str, "x,y");
		if((err=pfpGL[i].GetParseErrorType()) != pFunctionParser::FP_NO_ERROR) {
			fun[i].str[0]='\0';
			return err;
		}
		#ifdef PFPOPTIMIZER
		else
			pfpGL[i].Optimize();
		#endif
	}

	return pFunctionParser::FP_NO_ERROR;
}
