/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _SPECIAL_H_
#define _SPECIAL_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>

#include "glwidget.h"
#include "ui_speedit.h"
#include "property.h"
#include "version.h"
#include "debug.h"


/** Handles special settings */
class speWidget : public QWidget, private Ui::speUI {

Q_OBJECT

public:
	speWidget(QWidget *parent=0);
	void updSpeWid() { updTex(); updFog(); updMot(); }
	bool loadTexture(const QString fileName, const int n);
	~speWidget() {}

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

signals:
	void gotNewFile();    // Inform viewer about complete update
	void gotNewView();    // Update view only

private slots:

	/** Texture part */
	void getF0()  { getTexture(0); }
	void getF1()  { getTexture(1); }
	void getF2()  { getTexture(2); }
	void getPar() { getTexture(3); }

	void delF0()  { delTexture(0); }
	void delF1()  { delTexture(1); }
	void delF2()  { delTexture(2); }
	void delPar() { delTexture(3); }

	void checkedF0()  { checkTexture(0); updTex(); };
	void checkedF1()  { checkTexture(1); updTex(); };
	void checkedF2()  { checkTexture(2); updTex(); };
	void checkedPar() { checkTexture(3); updTex(); };

	void flipPressedF0()  { flipPressed(0); }
	void flipPressedF1()  { flipPressed(1); }
	void flipPressedF2()  { flipPressed(2); }
	void flipPressedPar() { flipPressed(3); }

	void spanSlot(int span) { texSpan=span; emit gotNewFile(); }

	/** Fog part */
	void togFog(bool b) { fog.enabled=b; setFog(); }

	void fogred  (const int intensity) { fogall(0, intensity); }
	void foggreen(const int intensity) { fogall(1, intensity); }
	void fogblue (const int intensity) { fogall(2, intensity); }
	void fogalpha(const int intensity) { fogall(3, intensity); }
	void fogall(const int channel, const int intensity);
	void locFogSlot() { fog.fogLigLoc = !fog.fogLigLoc; }
	void syncFogSlot();

	void expSlot();
	void exp2Slot();
	void linSlot();

	void fint(const int i) { fog.intensity=i; setFog(); emit gotNewView(); }
	void fstart(int i);
	void fend(int i);

	/** Motion blur part */
	void togMot(bool b)        { mot.enabled=b; emit gotNewView(); }
	void motFac(const int f)   { mot.fac=f/100.0f; emit gotNewView(); }
	void motSteps(const int s) { mot.steps=s; emit gotNewView(); }
	void motTrans(const int t) { mot.trans=t/10000.0f; emit gotNewView(); }

private:

	/** Texture */
	void getTexture(const int n);
	void delTexture(const int n);
	void checkTexture(const int n)  { tex[n].enabled=!tex[n].enabled; emit gotNewFile(); }
	void flipPressed(const int n);
	bool flipTexture(const int n);
	void upload(const int texnr);     // Upload texture to graphic card
	bool checkPower2(const int n);    // Check if texture dimensions are a power of 2
	QImage texPic;                    // Holds currently loaded texture
	QRgb rgb;                         // For conversion to raw RGB-format

	/** Fog */
	void setFog();

	/** Updates */
	void updTex();       // Texture part
	void updFog();       // Entire fog part
	void updFogLig();    // Prevent flickering; fog lights only
	void updMot();       // Motion blur part

	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _SPECIAL_H_ */
#endif
