/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _PISO_H_
#define _PISO_H_

#include <QObject>
#include <QString>

#include "property.h"
#include "./warp/fparser.h"
#include "debug.h"


/** *************************************************************************
 **
 ** Some comments on what happens in this piso-class:
 **
 ** This module builds up completely new parsers using data from pinterface.cpp.
 ** The reason for doing so is to make the user defined function/constant-stuff
 ** from fparser thread-safe, which was not granted before. All error handling
 ** is done in pinterface, so here is no need for extensive checks any more.
 **
 ** This module was written before fparser 2.83 was released. This new version
 ** supplies a ForceDeepCoppy function eg, which makes this module obsolete. At
 ** least in theory:-) Using the new possibilities in 2.83 makes the iso-stuff
 ** threadsafe indeed, but causes some dramatic speed-penalties in my tests. No
 ** idea why this happens, because all my other thread handling-stuff stayed
 ** completely unchanged.
 **
 ** As a conclusion I discarded the new fparser thread-stuff and decided to
 ** keep this piso module. With piso all the iso-related stuff scales near to
 ** 100% perfect with your physical CPU-cores.
****************************************************************************/


/** Minimal class. Build up new parser instances derived from pinterface.cpp
 ** ALL error handling is done there. Here NEVER should occure any error
 ** therefore. If an error happens however, Zhu3D will immediately exit with
 ** an regarding message on the command line. This is the only part where
 ** Zhu3D brutally exits without further error handling in the gui
****************************************************************************/
class PISO {

	public:

	PISO();
	~PISO() {};

	FunctionParser p[3];            // Three main parsers for is0..iso2

	private:

	FunctionParser conp;            // The parser holding user defined constants
	FunctionParser funp[MAXUSR];    // The parsers holding user defined functions

	/** Adding stuff */
	bool addParserConstant(const std::string &name, FPFLOAT val);
	bool addDefParserFunction(const std::string &name, FPFLOAT (*funPtr)(const FPFLOAT*), int parAmount);
	bool addNewParserFunction(const std::string &name, FunctionParser &toAdd);

	/** Fetch items */
	int fetchNewConstant(const QString &s);
	int fetchNewFunction(const QString &s);
	int fetchItem(const QString &s);

	int funpCount;
};

/** _PISO_H_ */
#endif
