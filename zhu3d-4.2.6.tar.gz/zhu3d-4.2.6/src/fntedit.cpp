/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "fntedit.h"
#include "sysinfo.h"
#include "pinterface.h"
#include "usredit.h"


/** *************************************************************************
 ** Remarks:
 **
 ** This module caused some headache. I stopped layouting with the
 ** designer, because font-comboboxes showed some problems - depending
 ** on fill-strategy (string or lists) and on starting index. It
 ** crashed predictionable between 10 and 70 entries. Qt-Windows
 ** does not show this phenomenon. I guess, this is some memory
 ** allocation problem. Anyhow, the implicite version works without
 ** oddities on both OS.
 **
 ** Not enough, the redrawing of menu-entries and toolbar-icons after
 ** font-resizing is somehow messy. The mainwindow has to be readjusted
 ** for menus, the toolbars to be deleted and recreated.
 **
****************************************************************************/


/** Be aware of localzations set in main.cpp */
extern QString zhuLocale;
extern QTranslator zhuTranslator;


/** Viewer update, parser checks and thread count */
extern OGLWidget *oglWid;
extern usrWidget *usrEdi;
extern int numCPU;


/** Inform mainwidget on current browser mode */
bool extBrowser;


/** Constructor */
fntWidget::fntWidget(QWidget *parent) : QWidget(parent) {

	/** Basics */
	setMinimumSize(180, 180);
	setWindowTitle(tr("General"));

	/** Internal/external browser */
	actBrowser=0;
	extBrowser=false;

	/** Create widget content */
	txt00 = new QLabel();    // Language
	com01 = new QComboBox;
	txt02 = new QLabel();    // Font
	com03 = new QComboBox;
	txt04 = new QLabel();    // Font style
	com05 = new QComboBox;
	txt06 = new QLabel();    // Font size
	spi07 = new QSpinBox;
	txt08 = new QLabel();    // Icon size
	spi09 = new QSpinBox;
	txt10 = new QLabel();    // Help browser
	com11 = new QComboBox;
	txt12 = new QLabel();    // Gui style
	com13 = new QComboBox;
	txt14 = new QLabel();    // Precision
	spi15 = new QSpinBox;
	txt16 = new QLabel();    // Isosurfaces
	com17 = new QComboBox;
	txt18 = new QLabel;      // Threads
	spi19 = new QSpinBox;

	/** Give everything a name */
	reTranslate();

	/** Make grid-layout */
	QGridLayout *grid = new QGridLayout;
	grid->addWidget(txt00, 0, 0);    // Language
	grid->addWidget(com01, 0, 1);
	grid->addWidget(txt02, 1, 0);    // Font
	grid->addWidget(com03, 1, 1);
	grid->addWidget(txt04, 2, 0);    // Font style
	grid->addWidget(com05, 2, 1);
	grid->addWidget(txt06, 3, 0);    // Font size
	grid->addWidget(spi07, 3, 1);
	grid->addWidget(txt08, 4, 0);    // Icon size
	grid->addWidget(spi09, 4, 1);
	grid->addWidget(txt10, 5, 0);    // Help browser
	grid->addWidget(com11, 5, 1);
	grid->addWidget(txt12, 6, 0);    // Gui style
	grid->addWidget(com13, 6, 1);
	grid->addWidget(txt14, 7, 0);    // Precision
	grid->addWidget(spi15, 7, 1);
	grid->addWidget(txt16, 8, 0);    // Isosurfaces
	grid->addWidget(com17, 8, 1);
	grid->addWidget(txt18, 9, 0);    // Threads
	grid->addWidget(spi19, 9, 1);
	setLayout(grid);

	/** Get settings and set actual font/iconsize */
	readSettings();
	setFnt(actFnt);
	setFntStyle(actFntStyle);
	setFntSize(actFntSize);
	setIcoSize(actIcoSize);

	/** Create font-database for font-combo */
	findFnts();

	/** Set combo/spinboxes */
	com03->setCurrentIndex(com03->findText(actFnt));
	spi07->setRange(MINFON, 48);
	spi07->setValue(actFntSize);
	spi09->setRange(10, 48);
	spi09->setValue(actIcoSize);
	#if !(defined(WINDOWS) || defined(WIN32) || defined(WIN64))
	// Max. double prec. in digits
	spi15->setRange(1, DBL_DIG);
	#else
	// Windows is not capable of more
	spi15->setRange(1, 11);
	#endif
	// Set global property too!
	spi15->setValue(solverPrec=actPrec);
	spi19->setRange(1, 2*numCPU);
	spi19->setValue(actNumCPU);

	/** Set right style-combo */
	findStyles();

	/** Fill language-combo */
	addLanguages();
	setLangComboIndex();

	/** Initialize the Gui-combo */
	guiList=QStyleFactory::keys();
	guiList.sort();
	com13->addItems(guiList);
	setGui(actGui);

	/** Initialize browser-combo */
	com11->clear();
	com11->addItem(tr("internal"));
	com11->addItem(tr("external"));
	setBrowser(actBrowser);
	txt10->setEnabled(true);
	com11->setEnabled(true);

	/** Initialize triangulation-combo */
	com17->clear();
	com17->addItem("Marching Cubes");
	com17->addItem("Marching Tetrahedras");
	setTriMod(actTriMod);

	/** Connections */
	connect(com01, SIGNAL(currentIndexChanged(const int)), this, SLOT(setLang(const int)));
	connect(com03, SIGNAL(currentIndexChanged(const QString &)), this, SLOT(setFnt(const QString &)));
	connect(com03, SIGNAL(currentIndexChanged(const QString &)), this, SLOT(findStyles()));
	connect(com05, SIGNAL(currentIndexChanged(const QString &)), this, SLOT(setFntStyle(const QString &)));
	connect(spi07, SIGNAL(valueChanged(int)), this, SLOT(setFntSize(const int)));
	connect(spi09, SIGNAL(valueChanged(int)), this, SLOT(setIcoSize(const int)));
	connect(com11, SIGNAL(currentIndexChanged(const int)), this, SLOT(setBrowser(const int)));
	connect(com13, SIGNAL(activated(const QString &)), this, SLOT(setGui(const QString &)));
	connect(spi15, SIGNAL(valueChanged(int)), this, SLOT(setPrec(const int)));
	connect(com17, SIGNAL(currentIndexChanged(const int)), this, SLOT(setTriMod(const int)));
	connect(spi19, SIGNAL(valueChanged(int)), this, SLOT(setThreads(const int)));

	/** Inform OpenGL viewer to update */
	connect(this, SIGNAL(gotNewFile()), oglWid, SLOT(newFileOpened()));

	/** Block iso-mode change when parsers are tainted */
	connect(usrEdi, SIGNAL(parsersTainted(bool)), this, SLOT(lockIsoMode(bool)));
	connect(oglWid, SIGNAL(parsersTainted(bool)), this, SLOT(lockIsoMode(bool)));
}


/** *************************************************************************
 ** SET-SLOTS
****************************************************************************/

/** Set language */
void fntWidget::setLang(const int index) {

	if(index==0) { actLang=0; zhuLocale="de"; }
	if(index==1) { actLang=1; zhuLocale="en"; }
	if(index==2) { actLang=2; zhuLocale="es"; }
	if(index==3) { actLang=3; zhuLocale="fr"; }
	if(index==4) { actLang=4; zhuLocale="zh"; }
	if(index==5) { actLang=5; zhuLocale="cs"; }
	setLangComboIndex();

	QCoreApplication::removeTranslator(&zhuTranslator);
	zhuTranslator.load(MYLANDIR+"zhu3d_"+zhuLocale);
	qApp->installTranslator(&zhuTranslator);
}

/** Set font */
void fntWidget::setFnt(const QString &fntFamily) {
	QFont sysFnt;

	sysFnt.setFamily(fntFamily);
	sysFnt.setPixelSize(actFntSize);
	QApplication::setFont(sysFnt);
	actFnt=fntFamily;

	/** Redraw menus because new fontfamily results in wrong width!!! */
	emit repaintMain();

	/** Consider legends */
	oglWid->newFont(actFnt);
}

/** Set font style */
void fntWidget::setFntStyle(const QString &fntStyle) {
	QFont sysFnt;
	const int dummy=6;

    sysFnt=fntDatabase.font(QApplication::font().family(), fntStyle, dummy);
	sysFnt.setPixelSize(actFntSize);
	QApplication::setFont(sysFnt);
	actFntStyle=fntStyle;

	/** Redraw menus because new fontstyle may result in wrong width!!! */
	emit repaintMain();
}

/** Set font size */
void fntWidget::setFntSize(const int newSize) {
	QFont sysFnt=QApplication::font();

	sysFnt.setFamily(actFnt);
	sysFnt.setPixelSize(newSize);
	QApplication::setFont(sysFnt);
	actFntSize=newSize;

	/** Redraw menus because new fontsize result in wrong width!!! */
	emit repaintMain();
}

/** Set Gui style */
void fntWidget::setGui(const QString &gui)  {
	QApplication::setStyle(QStyleFactory::create(gui));
	com13->setCurrentIndex(com13->findText(gui));
	actGui=gui;
}

/** Set browser 0=internal 1=external */
void fntWidget::setBrowser(const int browser)  {
	com11->setCurrentIndex(browser);
	actBrowser=browser;
	extBrowser=actBrowser;
}

/** Set triangulation mode for iso surfaces */
void fntWidget::setTriMod(const int triMod)  {

	com17->setCurrentIndex(triMod);
	actTriMod=triMod;
	sta.triMod=triMod;
	emit gotNewFile();
}


/** *************************************************************************
 ** UTILITY-STUFF
****************************************************************************/

/** Get current systemfont size */
int fntWidget::getSysFntSize() {
	QFont sysFnt=QApplication::font();
	QFontInfo fntInfo=QFontInfo(sysFnt);
	return fntInfo.pixelSize();
}

/** Get current stystemfont name */
QString fntWidget::getSysFnt() {
	QFont sysFnt=QApplication::font();
	QFontInfo fntInfo=QFontInfo(sysFnt);
	return fntInfo.family();
}

/** Fill language-combo */
void fntWidget::addLanguages() {
	com01->clear();

	/** Ordering is according to time of introduction! */
	com01->addItem(tr("German"));
	com01->addItem(tr("English"));
	com01->addItem(tr("Spanish"));
	com01->addItem(tr("French"));
	com01->addItem(tr("Chinese"));
	com01->addItem(tr("Czech"));
}

/** Set actual combo-index depending on language */
void fntWidget::setLangComboIndex() {

	/** Check for existing locales */
	if(zhuLocale=="de") { com01->setCurrentIndex(0); return; }
	if(zhuLocale=="en") { com01->setCurrentIndex(1); return; }
	if(zhuLocale=="es") { com01->setCurrentIndex(2); return; }
	if(zhuLocale=="fr") { com01->setCurrentIndex(3); return; }
	if(zhuLocale=="zh") { com01->setCurrentIndex(4); return; }
	if(zhuLocale=="cs") { com01->setCurrentIndex(5); return; }

	/** Set default else */
	zhuLocale="en";
	com01->setCurrentIndex(1);
}

/** Set actual combo-index depending on language */
int fntWidget::zhuLocaleSupported() {

	if(zhuLocale=="de") { return 0; }
	if(zhuLocale=="en") { return 1; }
	if(zhuLocale=="es") { return 2; }
	if(zhuLocale=="fr") { return 3; }
	if(zhuLocale=="zh") { return 4; }
	if(zhuLocale=="cs") { return 5; }

	/** No supported language found? Then return english */
	return 1;
}


/** *************************************************************************
 ** FINDING-STUFF
****************************************************************************/

/** Build fontdatabase and font-combo */
void fntWidget::findFnts() {
	QString family;
	com03->clear();

	foreach(family, fntDatabase.families())
		com03->addItem(family);
}

/** Build style-combo */
void fntWidget::findStyles() {
	QString style;
	com05->clear();

	foreach(style, fntDatabase.styles(com03->currentText()))
		com05->addItem(style);

	int styleIndex=com05->findText(actFntStyle);

	if(styleIndex==-1)
		com05->setCurrentIndex(0);
	else
		com05->setCurrentIndex(styleIndex);
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void fntWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		setWindowTitle(tr("General"));
		reTranslate();
	}
	else
		QWidget::changeEvent(event);
}

/** Somehow a facet of tricky selfrep:-) */
void fntWidget::reTranslate() {

	/** Widgets */
	txt00->setText(tr("Language")+" ");
	txt02->setText(tr("Font")+" ");
	txt04->setText(tr("Font style")+" ");
	txt06->setText(tr("Font size")+" ");
	txt08->setText(tr("Icon size")+" ");
	txt10->setText(tr("Help browser")+" ");
	txt12->setText(tr("GUI style")+" ");
	txt14->setText(tr("Precision")+" ");
	txt16->setText(tr("Isosurfaces")+" ");
	txt18->setText(tr("Threads")+" ");

	/** Rebuild browser combo */
	int cur=com11->currentIndex();
	com11->clear();
	com11->addItem(tr("internal"));
	com11->addItem(tr("external"));
	com11->setCurrentIndex(actBrowser=cur);

	/** Tooltipps */
	txt00->setToolTip(tr("Application language"));
	com01->setToolTip(tr("Application language"));
	txt10->setToolTip(tr("Choose internal or external help browser"));
	com11->setToolTip(tr("Choose internal or external help browser"));
	txt14->setToolTip(tr("Precision for solver report in digits"));
	spi15->setToolTip(tr("Precision for solver report in digits"));
	txt16->setToolTip(tr("Choose triangulation method"));
	com17->setToolTip(tr("Choose triangulation method"));
	txt18->setToolTip(tr("Threads for isosurface-triangulation"));
	spi19->setToolTip(tr("Threads for isosurface-triangulation"));

	/** Don't forget the system info & parser error messages */
	initSysInfo();
	fpError::initParserQt();

	/** Retranslate combo-entries itself */
	com01->setItemText(0,tr("German"));
	com01->setItemText(1,tr("English"));
	com01->setItemText(2,tr("Spanish"));
	com01->setItemText(3,tr("French"));
	com01->setItemText(4,tr("Chinese"));
	com01->setItemText(5,tr("Czech"));
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW/FONT-PROPERTIES
****************************************************************************/
void fntWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void fntWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("FntWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("FntWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
		setLang(settings.value("NewLang").toInt());
		actFnt=settings.value("NewFont").toString();
		actFntStyle=settings.value("NewStyle").toString();
		actFntSize=settings.value("NewFontSize").toInt();
		actIcoSize=settings.value("NewIconSize").toInt();
		actPrec=settings.value("NewPrec").toInt();
		actGui=settings.value("NewGui").toString();
		actBrowser=settings.value("NewBrowser").toInt();
		extBrowser=actBrowser;
		actTriMod=settings.value("NewTriMode").toInt();
		sta.triMod=actTriMod;
		actNumCPU=numCPUset=settings.value("NewNumCPU").toInt();
		if((actNumCPU<1) || (actNumCPU>MAXCPU))
			actNumCPU=numCPUset=1;
	}
	else {
		resize(QSize(260, 300));
		move(QPoint(340, 250));
		setLang(zhuLocaleSupported());
		actFnt=getSysFnt();
		actFntStyle="Normal";
		actFntSize=getSysFntSize();
		actIcoSize=19;
		actPrec=6;
		actGui=MYDEFGUI;
		actBrowser=0;
		extBrowser=false;
		actTriMod=sta.triMod;
		actNumCPU=numCPU;
	}
}

void fntWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);

	/** Windows stuff */
	settings.setValue("FntWindowPos", pos());
	settings.setValue("FntWindowSize", size());

	/** Language/font/icon-stuff */
	settings.setValue("NewLang", actLang);
	settings.setValue("NewFont", actFnt);
	settings.setValue("NewStyle", actFntStyle);
	settings.setValue("NewFontSize", actFntSize);
	settings.setValue("NewIconSize", actIcoSize);

	/** Solver precison */
	settings.setValue("NewPrec", actPrec);

	/** Current Gui style */
	settings.setValue("NewGui", actGui);

	/** Current browser */
	settings.setValue("NewBrowser", actBrowser);

	/** Current triangulation mode */
	settings.setValue("NewTriMode", actTriMod);

	/** Threads */
	settings.setValue("NewNumCPU", actNumCPU);
}
