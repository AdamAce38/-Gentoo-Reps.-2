/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _FUNEDITOR_H_
#define _FUNEDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>

#include "ui_funedit.h"
#include "property.h"
#include "version.h"
#include "debug.h"


/** Red background */
#define BRED "background: rgb(255,127,127);"


/** Handles global settings */
class funWidget : public QWidget, private Ui::funUI {

Q_OBJECT

public:
	funWidget(QWidget *parent=0);
	~funWidget() {};

	/** Used from main widget when saving zhu-files */
	QString getCom() { return textEdit->toPlainText(); }
	void updFunWid();

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

private slots:

	/** Deliver new function entries */
	void deliverF0Slot();
	void deliverF1Slot();
	void deliverF2Slot();

	/** Error handling */
	void errorF0Slot() { F0->setStyleSheet(BRED); F1->setEnabled(false); F2->setEnabled(false); }
	void errorF1Slot() { F1->setStyleSheet(BRED); F0->setEnabled(false); F2->setEnabled(false); }
	void errorF2Slot() { F2->setStyleSheet(BRED); F0->setEnabled(false); F1->setEnabled(false); }

	void lockFunSlot(const bool b) { this->setEnabled(!b); }
	void unlockSlot(const bool b) { if(!b) { F0->setEnabled(true); F1->setEnabled(true); F2->setEnabled(true); } }

signals:
	// Update OGL-viewer after new function input
	void F0changed();
	void F1changed();
	void F2changed();

private:

	/** Settings-stuff */
	void readSettings();
	void writeSettings();
};

/** _FUNEDITOR_H_ */
#endif
