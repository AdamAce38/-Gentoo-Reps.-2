/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "mainwindow.h"
#include "timers.h"        // CPU-specific timer code
#include "paths.h"         // Get doc/lang/app-paths
#include "pinterface.h"    // Interface to parsers


/** When 0.0f after main(), CPU counter is not implemented
 ** readSettings() gives a message during 1.st start then */
extern float MHz;

/** Be aware of current localzations */
extern QString zhuLocale;

/** Current default directories fetched from dirEdi */
extern QString texDir;
extern QString workDir;

/** Current state for internal/external browser from fntEdi */
extern bool extBrowser;


/** *************************************************************************
 ** MAINWINDOW CLASS
****************************************************************************/
MaiWindow::MaiWindow() {

	/** Set up the main control-center */
	controlCenter = new QWidget;
	Ui_mainCtrl::setupUi(controlCenter);
	this->setMinimumSize(260, 340);
	setCentralWidget(controlCenter);

	/** Initialize the mode-button */
	Parameter->setIcon(QPixmap(QString(":/images/player_fwd.png")));
	Parameter->setIconSize(QSize(18,18));

	/** Create help/solver widgets */
	hlpEdi = new QTextBrowser();
	solEdi = new QTextEdit();
	solEdi->setWindowTitle(tr("Solver report"));
	solEdi->setMinimumSize(270, 150);

	/** Get stored settings like size, pos, ... */
	readSettings();

	/** Create actions. Done now, because of immediate file loading */
	createActions();
	createMenus();
	createToolBars();

	/** Done now, because of immediate file loading */
	connect(this, SIGNAL(gotNewFile()), oglWid, SLOT(newFileOpened()));
	connect(this, SIGNAL(gotNewView()), oglWid, SLOT(updateGLonly()));

	/** OpenGL now, because texture-size check may need it */
	oglWid->show();
	sfineChecked=false;
	fineChecked=false;
	normalChecked=true;
	coarseChecked=false;

	/** Load file argument or startup-file */
	if(!argStr.isEmpty())
		loadFile(argStr);
	else
		loadFile(MYSYSDIR+"startup.zhu");

	/** More updates */
	updMaiWid();            // Update MaiWindow-widget
	updMaiInf();            // Update MaiWindow-info-messages
	speEdi->updSpeWid();    // Texture/fog/motion blur stuff

	/** Slider-signals and rotations-slots */
	connect(xSlider, SIGNAL(valueChanged(int)), oglWid, SLOT(setXRotation(int)));
	connect(ySlider, SIGNAL(valueChanged(int)), oglWid, SLOT(setYRotation(int)));
	connect(zSlider, SIGNAL(valueChanged(int)), oglWid, SLOT(setZRotation(int)));

	/** Correct slider-positions after mouse-signals and animation */
	connect(oglWid, SIGNAL(xRotationChanged(int)), xSlider, SLOT(setValue(int)));
	connect(oglWid, SIGNAL(yRotationChanged(int)), ySlider, SLOT(setValue(int)));
	connect(aniEdi, SIGNAL(xRotationChanged(int)), xSlider, SLOT(setValue(int)));
	connect(aniEdi, SIGNAL(yRotationChanged(int)), ySlider, SLOT(setValue(int)));
	connect(aniEdi, SIGNAL(zRotationChanged(int)), zSlider, SLOT(setValue(int)));

	/** Set modes */
	connect(Point,     SIGNAL(clicked()), oglWid, SLOT(drawModePoint()));
	connect(Triangle,  SIGNAL(clicked()), oglWid, SLOT(drawModeTriangle()));
	connect(Quad,      SIGNAL(clicked()), oglWid, SLOT(drawModeQuad()));
	connect(Parameter, SIGNAL(clicked()), oglWid, SLOT(drawModeParameter()));
	connect(Point,     SIGNAL(clicked()), this, SLOT(wireModeSlot()));
	connect(Triangle,  SIGNAL(clicked()), this, SLOT(wireModeSlot()));
	connect(Quad,      SIGNAL(clicked()), this, SLOT(wireModeSlot()));
	connect(Parameter, SIGNAL(clicked()), this, SLOT(wireModeSlot()));

	/** Enable/disable functions, cross ... */
	connect(Function0, SIGNAL(clicked()), oglWid, SLOT(toggleF0()));    // Functions
	connect(Function1, SIGNAL(clicked()), oglWid, SLOT(toggleF1()));
	connect(Function2, SIGNAL(clicked()), oglWid, SLOT(toggleF2()));
	connect(Function3, SIGNAL(clicked()), oglWid, SLOT(toggleF3()));    // Parameters

	connect(Cross, SIGNAL(clicked()), oglWid, SLOT(toggleCross()));
	connect(Axes,  SIGNAL(clicked()), oglWid, SLOT(toggleAxes()));
	connect(Wired, SIGNAL(clicked()), oglWid, SLOT(togglePolygon()));

	/** Handle scaling */
	connect(xPlus,     SIGNAL(clicked()), oglWid, SLOT(scaleXplus()));
	connect(xMinus,    SIGNAL(clicked()), oglWid, SLOT(scaleXminus()));
	connect(yPlus,     SIGNAL(clicked()), oglWid, SLOT(scaleYplus()));
	connect(yMinus,    SIGNAL(clicked()), oglWid, SLOT(scaleYminus()));
	connect(zPlus,     SIGNAL(clicked()), oglWid, SLOT(scaleZplus()));
	connect(zMinus,    SIGNAL(clicked()), oglWid, SLOT(scaleZminus()));
	connect(xyzPlus,   SIGNAL(clicked()), oglWid, SLOT(scaleXYZplus()));
	connect(xyzMinus,  SIGNAL(clicked()), oglWid, SLOT(scaleXYZminus()));
	connect(gridPlus,  SIGNAL(clicked()), oglWid, SLOT(scaleGridplus()));
	connect(gridMinus, SIGNAL(clicked()), oglWid, SLOT(scaleGridminus()));

	/** Close MaiWindow too, when OpenGL-viewer is closed */
	connect(oglWid, SIGNAL(killAll()), this, SLOT(close()));

	/** Some more commands from other widgets */
	connect(oglWid, SIGNAL(updMaiWid()), this, SLOT(updMaiWid()));
	connect(oglWid, SIGNAL(updMaiInf()), this, SLOT(updMaiInf()));
	connect(aniEdi, SIGNAL(updMaiWid()), this, SLOT(updMaiWid()));
	connect(aniEdi, SIGNAL(updMaiInf()), this, SLOT(updMaiInf()));
	connect(aniEdi, SIGNAL(saveFromAni()), this, SLOT(saveAsSlot()));
	connect(morEdi, SIGNAL(updMaiWid()),   this, SLOT(updMaiWid()));
	connect(fntEdi, SIGNAL(repaintMain()), this, SLOT(repaintSlot()));
	connect(fntEdi, SIGNAL(iconSize(const int)), this, SLOT(iconSizeSlot(const int)));

	/** Parsers tainted, slide show running */
	connect(usrEdi, SIGNAL(parsersTainted(bool)), this, SLOT(lockMainSlot(bool)));
	connect(oglWid, SIGNAL(parsersTainted(bool)), this, SLOT(lockMainSlot(bool)));
	connect(demEdi, SIGNAL(slideshowOn(bool)), this, SLOT(lockBenchSlot(bool)));

	/** Bring on function editor finally */
	functionSlot();
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void MaiWindow::changeEvent(QEvent* event) {

	/** Check for language event */
	if(event->type() == QEvent::LanguageChange) {

		/** Main stuff */
		Ui_mainCtrl::retranslateUi(this);
		reTranslate();
		setWindowTitle(currentWindowName);

		/** Help */
		if(hlpEdi->isVisible()) {
			hlpEdi->close();
			helpSlot();
		}

		/** Solver editor */
		if(solEdi->isVisible())
			solEdi->setWindowTitle(tr("Solver report"));
	}
	else
		QMainWindow::changeEvent(event);
}


/** *************************************************************************
 ** ACTIONS FOR MAINWINDOW-MENUS
****************************************************************************/
void MaiWindow::newSlot() {

	oglWid->iniAll();
	for(int i=0; i<MAXFUN; i++) {
		q2cstrcpy(fun[i].str, "\0"); ofun[i]="\0";
		q2cstrcpy(iso[i].str, "\0"); oiso[i]="\0";
		q2cstrcpy(par.str[i], "\0"); opar[i]="\0";
	}

	Draw_Which();
	lastUsrEntry=0;
	initAllParsers();
	updMaiWid();
	updMaiInf();

	funEdi->updFunWid();
	ligEdi->updLigWid();
	matEdi->updMatWid();
	entEdi->updEntWid();
	aniEdi->animate(false);
	aniEdi->updAniWid();
	morEdi->morph(false);
	morEdi->updMorWid();
	speEdi->updSpeWid();
	usrEdi->updUsrWid();
	legEdi->updLegWid();

	setCurrentFile("");    // Window name = untitled
	emit gotNewFile();     // Draw z=0 finally
}

void MaiWindow::openSlot() {

	/** File selector */
	QString fileName=QFileDialog::getOpenFileName(
					this,
					tr("Open")+" "+NAME+"-"+tr("file"),
					workDir,
					"Images (*.zhu)");

	/** Got file or canceled file-selector? */
	if(fileName.isEmpty())
		return;

	/** Check ending first */
	if(!fileName.endsWith(".zhu"))
		fileName+=".zhu";

	/** Load file then */
	loadFile(fileName);

	/** Show function editor & viewer anyhow */
	funEdi->showNormal();
	funEdi->raise();
	funEdi->activateWindow();
	oglWid->showNormal();
	oglWid->raise();
	oglWid->activateWindow();

	/** Check animation-state at last */
	oglWid->updWinTit();
}

void MaiWindow::saveAsSlot() {

	/** File selector */
	QString fileName=QFileDialog::getSaveFileName(
					this,
					tr("Save")+" "+NAME+"-"+tr("file"),
					workDir,
					"Images (*.zhu)");

	/** Got file or canceled file-selector? */
	if(fileName.isEmpty())
		return;

	/** Check ending */
	if(!fileName.endsWith(".zhu"))
		fileName+=".zhu";

	zhuFile zhu;
	const int err = zhu.save(fileName);
	setCurrentFile(fileName);

	/** Error checks */
	if(err==0)
		QMessageBox::critical(
			this,
			tr("Save"),
			tr("Error saving file:") + " " + fileName
		);

}

/** Save content of solver editor */
void MaiWindow::saveSolSlot() {
	const QString tmp=solEdi->toPlainText();

	/** Something to save? */
	if(tmp=="") {
		QMessageBox::information(
			this,
			tr("Solver report"),
			tr("Currently there is nothing to save!")
		);
		return;
	}

	/** File selector */
	QString fileName = QFileDialog::getSaveFileName(
		this,
		tr("Save solutions"),
		workDir,
		"Images (*.txt)"
	);

	/** Got file or canceled file-selector? */
	if(fileName.isEmpty())
		return;

	/** Check ending */
	if(!fileName.endsWith(".txt"))
		fileName+=".txt";

	/** Check success */
	QFile file(fileName);
	if(!file.open(QFile::WriteOnly | QFile::Text)) {
		QMessageBox::critical(
			this,
			tr("Save"),
			tr("Error saving file:")+" "+fileName
		);
		return;
	}

	/** Write and close */
	QTextStream out(&file);
	out << tmp;
	file.close();
}

/** Consider localized help-files too */
void MaiWindow::helpSlot() {

	/** Yet activated? */
	if(hlpEdi->isVisible()) {
		hlpEdi->showNormal();
		hlpEdi->raise();
		hlpEdi->activateWindow();
	}

	/** Extract localized html-filename */
	QString tmp=NAME;
	tmp=tmp.toLower()+"_"+zhuLocale;
	tmp=MYDOCDIR+tmp+".html";
	QFile file(tmp);

	/** Try to find localized help-version */
	if(!file.exists()) {

		/** Not found. Try the english zhu3d_en.html instead */
		tmp=NAME;
		tmp=MYDOCDIR+tmp.toLower()+"_en.html";
		file.setFileName(tmp);

		/** Oops. No help-file at all */
		if(!file.exists()) {
			QMessageBox::warning(
				this,
				NAME,
				tr("Cannot find any helpfile")
			);
			return;
		}
	}

	#if (defined(WINDOWS) || defined(WIN32) || defined(WIN64))
	QUrl url(QString("file:///")+tmp);
	#else
	QUrl url(QString("file://")+tmp);
	#endif

	/** Use external browser ? */
	if(extBrowser) {
		if(hlpEdi->isVisible())
			hlpEdi->close();
		QDesktopServices::openUrl(url);
		return;
	}

	/** Else use internal browser */
	hlpEdi->setWindowTitle((QString)NAME+" "+tr("Help"));
	hlpEdi->setSource(url);
	hlpEdi->show();
	return;
}

/** Close all windows on exit */
void MaiWindow::exitSlot() {
	writeSettings();
	oglWid->close();
	ligEdi->close();
	matEdi->close();
	entEdi->close();
	aniEdi->close();
	morEdi->close();
	picEdi->close();
	fntEdi->close();
	demEdi->close();
	hlpEdi->close();
	solEdi->close();
	funEdi->close();
	speEdi->close();
	dirEdi->close();
	usrEdi->close();
	legEdi->close();
	close();
}


/** *************************************************************************
 ** SYSTEM INFO
****************************************************************************/
void MaiWindow::systemSlot() {
	QMessageBox::information(
		this,
		tr("System information"),
		systemInfo()
	);
}

void MaiWindow::aboutSlot() {

	/** Get compilation date */
	const QString tmp = (QString)(__DATE__);

	QMessageBox::about(
		this,
		tr("About") + " " + NAME,

		/** This is never translated */
		QString("<b>") + NAME + QString("</b> ") +
        QString("is an OpenGL-based function-viewer and solver.") +
		QString("<p>Version ")+VERS+QString("  compiled ")+tmp+QString("</p>") +
        QString("<p>Check updates on: "
		"<a href=\"http://www.kde-apps.org/content/show.php?content=43071/\""
		">www.kde-apps.org</a><BR>"

        "Contact address: "
		"<a href=\"mailto:zhu3d@aon.at?subject=Zhu3D\""
		">zhu3d@aon.at</a><BR>"

        "Software license: "
		"<a href=\"http://www.gnu.org/licenses/gpl-3.0-standalone.html\""
		">GPL v3</a></p>") +

		QString("<p>(c) 2012 Heinz van Saanen</p>"));
}


/** *************************************************************************
 ** SHOW/HIDE EDITORS
****************************************************************************/
void MaiWindow::lightSlot() {

	/** Not yet activated? */
	if(!ligEdi->isVisible())
		ligEdi->show();
	else
		ligEdi->showNormal();

	/** Update and bring to foreground */
	ligEdi->updLigWid();
	ligEdi->raise();
	ligEdi->activateWindow();
}

void MaiWindow::materialSlot() {

	/** Not yet activated? */
	if(!matEdi->isVisible())
		matEdi->show();
	else
		matEdi->showNormal();

	/** Update and bring to foreground */
	matEdi->updMatWid();
	matEdi->raise();
	matEdi->activateWindow();
}

void MaiWindow::animateSlot() {

	/** Not yet activated? */
	if(!aniEdi->isVisible())
		aniEdi->show();
	else
		aniEdi->showNormal();

	/** Update and bring to foreground */
	aniEdi->updAniWid();
	aniEdi->raise();
	aniEdi->activateWindow();
}

void MaiWindow::morphSlot() {

	/** Not yet activated? */
	if(!morEdi->isVisible())
		morEdi->show();
	else
		morEdi->showNormal();

	/** Update and bring to foreground */
	morEdi->updMorWid();
	morEdi->raise();
	morEdi->activateWindow();
}

void MaiWindow::entireSlot() {

	/** Not yet activated? */
	if(!entEdi->isVisible())
		entEdi->show();
	else
		entEdi->showNormal();

	/** Update and bring to foreground */
	entEdi->updEntWid();
	entEdi->raise();
	entEdi->activateWindow();
}

void MaiWindow::solverSlot() {

	/** Not yet activated? */
	if(!solEdi->isVisible())
		solEdi->show();
	else
		solEdi->showNormal();

	/** Update and bring to foreground */
	solEdi->raise();
	solEdi->activateWindow();
}

void MaiWindow::functionSlot() {

	/** Not yet activated? */
	if(!funEdi->isVisible())
		funEdi->show();
	else
		funEdi->showNormal();

	/** Update and bring to foreground */
	funEdi->updFunWid();
	funEdi->raise();
	funEdi->activateWindow();
}

void MaiWindow::pictureSlot() {

	/** Not yet activated? */
	if(!picEdi->isVisible()) {
		picEdi->show();
		picEdi->updPicWid();
	}
	else
		picEdi->showNormal();

	/** Update and bring to foreground */
	picEdi->raise();
	picEdi->activateWindow();
}

void MaiWindow::fontSlot() {

	/** Not yet activated? */
	if(!fntEdi->isVisible())
		fntEdi->show();
	else
		fntEdi->showNormal();

	/** Update and bring to foreground */
	fntEdi->raise();
	fntEdi->activateWindow();
}

void MaiWindow::demoSlot() {

	/** Not yet activated? */
	if(!demEdi->isVisible()) {
		demEdi->initDirList();
		demEdi->show();
	}
	else {
		demEdi->initDirList();
		demEdi->showNormal();
	}

	/** Update and bring to foreground */
	demEdi->raise();
	demEdi->activateWindow();
}

void MaiWindow::specialSlot() {

	/** Not yet activated? */
	if(!speEdi->isVisible())
		speEdi->show();
	else
		speEdi->showNormal();

	/** Update and bring to foreground */
	speEdi->raise();
	speEdi->activateWindow();
}

void MaiWindow::directorySlot() {

	/** Not yet activated? */
	if(!dirEdi->isVisible())
		dirEdi->show();
	else
		dirEdi->showNormal();

	/** Update and bring to foreground */
	dirEdi->raise();
	dirEdi->activateWindow();
}

void MaiWindow::userSlot() {

	/** Not yet activated? */
	if(!usrEdi->isVisible())
		usrEdi->show();
	else
		usrEdi->showNormal();

	/** Update and bring to foreground */
	usrEdi->raise();
	usrEdi->activateWindow();
}

void MaiWindow::legendsSlot() {

	/** Not yet activated? */
	if(!legEdi->isVisible())
		legEdi->show();
	else
		legEdi->showNormal();

	/** Update and bring to foreground */
	legEdi->updLegWid();
	legEdi->raise();
	legEdi->activateWindow();
}

/** Bring all opened/minimized editors to front */
void MaiWindow::toFrontSlot() {

	/** Viewer first for not overlapping the rest */
	oglWid->showNormal();
	oglWid->raise();
	oglWid->activateWindow();

	/** Lights */
	if(ligEdi->isVisible()) {
		ligEdi->showNormal();
		ligEdi->raise();
		ligEdi->activateWindow();
	}

	/** Materials */
	if(matEdi->isVisible()) {
		matEdi->showNormal();
		matEdi->raise();
		matEdi->activateWindow();
	}

	/** Global light */
	if(entEdi->isVisible()) {
		entEdi->showNormal();
		entEdi->raise();
		entEdi->activateWindow();
	}

	/** Animation */
	if(aniEdi->isVisible()) {
		aniEdi->showNormal();
		aniEdi->raise();
		aniEdi->activateWindow();
	}

	/** Morphing */
	if(morEdi->isVisible()) {
		morEdi->showNormal();
		morEdi->raise();
		morEdi->activateWindow();
	}

	/** Special */
	if(speEdi->isVisible()) {
		speEdi->showNormal();
		speEdi->raise();
		speEdi->activateWindow();
	}

	/** Solver report */
	if(solEdi->isVisible()) {
		solEdi->showNormal();
		solEdi->raise();
		solEdi->activateWindow();
	}

	/** Function editor */
	if(funEdi->isVisible()) {
		funEdi->showNormal();
		funEdi->raise();
		funEdi->activateWindow();
	}

	/** User table */
	if(usrEdi->isVisible()) {
		usrEdi->showNormal();
		usrEdi->raise();
		usrEdi->activateWindow();
	}

	/** Legends */
	if(legEdi->isVisible()) {
		legEdi->showNormal();
		legEdi->raise();
		legEdi->activateWindow();
	}

	/** Help */
	if(hlpEdi->isVisible()) {
		hlpEdi->showNormal();
		hlpEdi->raise();
		hlpEdi->activateWindow();
	}
}

/** Hide/minimize all opened editors */
void MaiWindow::toBackSlot() {

	/** Lights */
	if(ligEdi->isVisible())
		ligEdi->showMinimized();

	/** Materials */
	if(matEdi->isVisible())
		matEdi->showMinimized();

	/** Global light */
	if(entEdi->isVisible())
		entEdi->showMinimized();

	/** Animation */
	if(aniEdi->isVisible())
		aniEdi->showMinimized();

	/** Morphing */
	if(morEdi->isVisible())
		morEdi->showMinimized();

	/** Special */
	if(speEdi->isVisible())
		speEdi->showMinimized();

	/** Solver report */
	if(solEdi->isVisible())
		solEdi->showMinimized();

	/** Function editor */
	if(funEdi->isVisible())
		funEdi->showMinimized();

	/** User table */
	if(usrEdi->isVisible())
		usrEdi->showMinimized();

	/** Legends */
	if(legEdi->isVisible())
		legEdi->showMinimized();

	/** Help */
	if(hlpEdi->isVisible())
		hlpEdi->showMinimized();
}

/** Open all editors */
void MaiWindow::showAllSlot() {

	/** Lights */
	ligEdi->showNormal();
	ligEdi->raise();
	ligEdi->activateWindow();

	/** Materials */
	matEdi->showNormal();
	matEdi->raise();
	matEdi->activateWindow();

	/** Global light */
	entEdi->showNormal();
	entEdi->raise();
	entEdi->activateWindow();

	/** Animation */
	aniEdi->showNormal();
	aniEdi->raise();
	aniEdi->activateWindow();

	/** Morphing */
	morEdi->showNormal();
	morEdi->raise();
	morEdi->activateWindow();

	/** Special */
	speEdi->showNormal();
	speEdi->raise();
	speEdi->activateWindow();

	/** Solver report */
	solEdi->showNormal();
	solEdi->raise();
	solEdi->activateWindow();

	/** Function editor */
	funEdi->showNormal();
	funEdi->raise();
	funEdi->activateWindow();

	/** User table */
	usrEdi->showNormal();
	usrEdi->raise();
	usrEdi->activateWindow();

	/** Legends */
	legEdi->showNormal();
	legEdi->raise();
	legEdi->activateWindow();
}


/** *************************************************************************
 ** INITIALIZATIONS
****************************************************************************/
void MaiWindow::resetViewSlot() {

	sta.angle=35.0f;
	sta.rotX=sta.rotY=sta.rotZ=0.0f;
	sta.transX=sta.transY=0.0f;
	sta.transZ=-5.0f;
	sta.crossX=sta.crossY=0.5f;

	updMaiWid();          // Update MaiWindow widget
	updMaiInf();          // Update cross-section
	emit gotNewFile();    // Update viewer
}

/** Initialize default scaling values */
void MaiWindow::resetScaleSlot() {

	sta.sa=sta.sx=sta.sy=sta.sz=1.0f;
	sta.spx=sta.spy=sta.spz=1.0f;

	updMaiWid();          // Update MaiWindow widget
	updMaiInf();          // Update cross-section
	emit gotNewFile();    // Update viewer
}

/** Initialize default light values */
void MaiWindow::resetLightSlot() {

	iniLig();

	updMaiWid();            // Update MaiWindow widget
	updMaiInf();            // Update cross-section
	ligEdi->updLigWid();    // Update light editor
	emit gotNewFile();      // Update viewer
}

/** Initialize default scaling and viewing values */
void MaiWindow::resetAllSlot() {

	resetViewSlot();
	resetScaleSlot();
	resetLightSlot();
}

/** Toggle animation on/off */
void MaiWindow::runStopAnimationSlot() {

	ani.active = !ani.active;

	if(ani.active) {
		runStopAnimationAction->setIcon(QIcon(":/images/stop.png"));
		runStopAnimationAction->setToolTip(tr("Stop animation"));
		aniEdi->animate(true);
	}
	else {
		runStopAnimationAction->setIcon(QIcon(":/images/animation.png"));
		runStopAnimationAction->setToolTip(tr("Start animation"));
		aniEdi->animate(false);
	}

	/** Update OpenGL window title and ani-Widget */
	oglWid->updWinTit();
	aniEdi->updAniWid();
}


/** Toggle morphing on/off */
void MaiWindow::runStopMorphSlot() {

	mor.active = !mor.active;

	if(mor.active) {
		runStopMorphAction->setIcon(QIcon(":/images/stop.png"));
		runStopMorphAction->setToolTip(tr("Stop morphing"));
		morEdi->morph(true);
	}
	else {
		runStopMorphAction->setIcon(QIcon(":/images/morph.png"));
		runStopMorphAction->setToolTip(tr("Start morphing"));
		morEdi->morph(false);
	}

	/** Update OpenGL window title and ani-Widget */
	oglWid->updWinTit();
	morEdi->updMorWid();
}


/** *************************************************************************
 ** CREATE ACTIONS
****************************************************************************/
void MaiWindow::createActions() {

	/** FILE */
	newAction = new QAction(QIcon(":/images/new.png"), tr("&New"), this);
	newAction->setShortcut(tr("Ctrl+N"));
	connect(newAction, SIGNAL(triggered()), this, SLOT(newSlot()));

	openAction = new QAction(QIcon(":/images/open.png"), tr("&Open ..."), this);
	openAction->setShortcut(tr("Ctrl+O"));
	connect(openAction, SIGNAL(triggered()), this, SLOT(openSlot()));

	saveAsAction = new QAction(QIcon(":/images/saveas.png"), tr("&Save as"), this);
	saveAsAction->setShortcut(tr("Ctrl+S"));
	connect(saveAsAction, SIGNAL(triggered()), this, SLOT(saveAsSlot()));

	saveSolAction = new QAction(QIcon(":/images/solve.png"), tr("Save solutions"), this);
	connect(saveSolAction, SIGNAL(triggered()), this, SLOT(saveSolSlot()));

	savePicAction = new QAction(QIcon(":/images/savepic.png"), tr("Save picture"), this);
	connect(savePicAction, SIGNAL(triggered()), oglWid, SLOT(savePic()));

	printAction = new QAction(QIcon(":/images/print.png"), tr("Print picture"), this);
	connect(printAction, SIGNAL(triggered()), oglWid, SLOT(printPic()));

	exitAction = new QAction(QIcon(":/images/exit.png"), tr("&Exit"), this);
	exitAction->setShortcut(tr("Ctrl+E"));
	connect(exitAction, SIGNAL(triggered()), this, SLOT(exitSlot()));


	/** EDITORS */
	lightAction = new QAction(QIcon(":/images/light.png"), tr("Lights"), this);
	connect(lightAction, SIGNAL(triggered()), this, SLOT(lightSlot()));

	materialAction = new QAction(QIcon(":/images/material.png"), tr("Surfaces"), this);
	connect(materialAction, SIGNAL(triggered()), this, SLOT(materialSlot()));

	entireAction = new QAction(QIcon(":/images/entire.png"), tr("Global"), this);
	connect(entireAction, SIGNAL(triggered()), this, SLOT(entireSlot()));

	usrEdiAction = new QAction(QIcon(":/images/user.png"), tr("User defined"), this);
	connect(usrEdiAction, SIGNAL(triggered()), this, SLOT(userSlot()));

	legEdiAction = new QAction(QIcon(":/images/legends.png"), tr("Legends"), this);
	connect(legEdiAction, SIGNAL(triggered()), this, SLOT(legendsSlot()));

	solEdiAction = new QAction(QIcon(":/images/solve.png"), tr("Solver report"), this);
	connect(solEdiAction, SIGNAL(triggered()), this, SLOT(solverSlot()));

	funEdiAction = new QAction(QIcon(":/images/edit.png"), tr("Functions"), this);
	connect(funEdiAction, SIGNAL(triggered()), this, SLOT(functionSlot()));


	/** Special */
	animateAction = new QAction(QIcon(":/images/animate.png"), tr("Animation"), this);
	connect(animateAction, SIGNAL(triggered()), this, SLOT(animateSlot()));

	morphAction = new QAction(QIcon(":/images/morph.png"), tr("Morphing"), this);
	connect(morphAction, SIGNAL(triggered()), this, SLOT(morphSlot()));

	speEdiAction = new QAction(QIcon(":/images/special.png"), tr("OpenGL"), this);
	connect(speEdiAction, SIGNAL(triggered()), this, SLOT(specialSlot()));


	/** SETTINGS */
	pictureAction = new QAction(QIcon(":/images/savepic.png"), tr("Picture"), this);
	connect(pictureAction, SIGNAL(triggered()), this, SLOT(pictureSlot()));

	sfineAction = new QAction(tr("micro"), this);
	sfineAction->setCheckable(true);
	sfineAction->setChecked(false);
	connect(sfineAction, SIGNAL(triggered()), oglWid, SLOT(sfineScale()));
	connect(sfineAction, SIGNAL(triggered()), this,  SLOT(sfineScale()));

	fineAction = new QAction(tr("fine"), this);
	fineAction->setCheckable(true);
	fineAction->setChecked(false);
	connect(fineAction, SIGNAL(triggered()), oglWid, SLOT(fineScale()));
	connect(fineAction, SIGNAL(triggered()), this,  SLOT(fineScale()));

	normalAction = new QAction(tr("normal"), this);
	normalAction->setCheckable(true);
	normalAction->setChecked(true);
	connect(normalAction, SIGNAL(triggered()), oglWid, SLOT(normalScale()));
	connect(normalAction, SIGNAL(triggered()), this,  SLOT(normalScale()));

	coarseAction = new QAction(tr("coarse"), this);
	coarseAction->setCheckable(true);
	coarseAction->setChecked(false);
	connect(coarseAction, SIGNAL(triggered()), oglWid, SLOT(coarseScale()));
	connect(coarseAction, SIGNAL(triggered()), this,  SLOT(coarseScale()));

	resetViewAction = new QAction(QIcon(":/images/viewonly.png"), tr("View only"), this);
	connect(resetViewAction, SIGNAL(triggered()), this, SLOT(resetViewSlot()));

	resetScaleAction = new QAction(QIcon(":/images/scale.png"), tr("Scaling only"), this);
	connect(resetScaleAction, SIGNAL(triggered()), this, SLOT(resetScaleSlot()));

	resetLightAction = new QAction(QIcon(":/images/light.png"), tr("Lights only"), this);
	connect(resetLightAction, SIGNAL(triggered()), this, SLOT(resetLightSlot()));

	resetAllAction = new QAction(QIcon(":/images/reset.png"), tr("All together"), this);
	connect(resetAllAction, SIGNAL(triggered()), this, SLOT(resetAllSlot()));

	fontAction = new QAction(QIcon(":/images/icon.png"), tr("General"), this);
	connect(fontAction, SIGNAL(triggered()), this, SLOT(fontSlot()));

	dirEdiAction = new QAction(QIcon(":/images/open.png"), tr("Directories"), this);
	connect(dirEdiAction, SIGNAL(triggered()), this, SLOT(directorySlot()));


	/** WINDOWS */
	toFrontAction = new QAction(QIcon(":/images/tofront.png"), tr("Show open editors"), this);
	connect(toFrontAction, SIGNAL(triggered()), this, SLOT(toFrontSlot()));

	toBackAction = new QAction(QIcon(":/images/toback.png"), tr("Hide open editors"), this);
	connect(toBackAction, SIGNAL(triggered()), this, SLOT(toBackSlot()));

	showAllAction = new QAction(QIcon(":/images/edit.png"), tr("Open all editors"), this);
	connect(showAllAction, SIGNAL(triggered()), this, SLOT(showAllSlot()));


	/** HELP */
	helpAction = new QAction(QIcon(":/images/help.png"), tr("Help"), this);
	helpAction->setShortcut(tr("F1"));
	connect(helpAction, SIGNAL(triggered()), this, SLOT(helpSlot()));

	systemAction = new QAction(QIcon(":/images/system.png"), tr("System"), this);
	connect(systemAction, SIGNAL(triggered()), this, SLOT(systemSlot()));

	demoAction = new QAction(QIcon(":/images/demo.png"), tr("Demo"), this);
	connect(demoAction, SIGNAL(triggered()), this, SLOT(demoSlot()));

	benchmarkAction = new QAction(QIcon(":/images/bench.png"), tr("Benchmark"), this);
	connect(benchmarkAction, SIGNAL(triggered()), this, SLOT(benchmarkSlot()));

	aboutAction = new QAction(QIcon(":/images/icon.png"), tr("About Zhu3D"), this);
	connect(aboutAction, SIGNAL(triggered()), this, SLOT(aboutSlot()));

	aboutQtAction = new QAction(QIcon(":/images/qt-logo.png"), tr("About Qt"), this);
	connect(aboutQtAction, SIGNAL(triggered()), qApp, SLOT(aboutQt()));


	/** TOOLBARS */
	zoomInAction = new QAction(QIcon(":/images/zoomin.png"), tr("Zoom in"), this);
	zoomInAction->setShortcut(tr("Ctrl++"));
	connect(zoomInAction, SIGNAL(triggered()), oglWid, SLOT(zoomIn()));

	zoomOutAction = new QAction(QIcon(":/images/zoomout.png"), tr("Zoom out"), this);
	zoomOutAction->setShortcut(tr("Ctrl+-"));
	connect(zoomOutAction, SIGNAL(triggered()), oglWid, SLOT(zoomOut()));

	transLeftAction = new QAction(QIcon(":/images/left.png"), tr("Move left"), this);
	transLeftAction->setShortcut(tr("Ctrl+L"));
	connect(transLeftAction, SIGNAL(triggered()), oglWid, SLOT(transLeft()));

	transRightAction = new QAction(QIcon(":/images/right.png"), tr("Move right"), this);
	transRightAction->setShortcut(tr("Ctrl+R"));
	connect(transRightAction, SIGNAL(triggered()), oglWid, SLOT(transRight()));

	transUpAction = new QAction(QIcon(":/images/up.png"), tr("Move up"), this);
	transUpAction->setShortcut(tr("Ctrl+U"));
	connect(transUpAction, SIGNAL(triggered()), oglWid, SLOT(transUp()));

	transDownAction = new QAction(QIcon(":/images/down.png"), tr("Move down"), this);
	transDownAction->setShortcut(tr("Ctrl+D"));
	connect(transDownAction, SIGNAL(triggered()), oglWid, SLOT(transDown()));

	solveAction = new QAction(QIcon(":/images/solve.png"), tr("Solve system"), this);
	connect(solveAction, SIGNAL(triggered()), this, SLOT(solveSlot()));

	runStopAnimationAction = new QAction(QIcon(":/images/animate.png"), tr("Start/stop animation"), this);
	connect(runStopAnimationAction, SIGNAL(triggered()), this, SLOT(runStopAnimationSlot()));

	runStopMorphAction = new QAction(QIcon(":/images/morph.png"), tr("Start/stop morphing"), this);
	connect(runStopMorphAction, SIGNAL(triggered()), this, SLOT(runStopMorphSlot()));
}


/** *************************************************************************
 ** CREATE/DELETE MENUS
****************************************************************************/
void MaiWindow::createMenus() {

	/** File */
	fileMenu = menuBar()->addMenu(tr("File"));
	fileMenu->addAction(newAction);
	fileMenu->addAction(openAction);
	fileMenu->addAction(saveAsAction);
	fileMenu->addSeparator();
	fileMenu->addAction(saveSolAction);
	fileMenu->addAction(savePicAction);
	fileMenu->addSeparator();
	fileMenu->addAction(printAction);
	fileMenu->addSeparator();
	fileMenu->addAction(exitAction);

	/** Editors */
	editorMenu = menuBar()->addMenu(tr("Editors"));
	editorMenu->addAction(lightAction);
	editorMenu->addAction(materialAction);
	editorMenu->addAction(entireAction);
	editorMenu->addSeparator();

	editorMenu->addAction(usrEdiAction);
	editorMenu->addAction(legEdiAction);
	editorMenu->addAction(solEdiAction);
	editorMenu->addSeparator();
	editorMenu->addAction(funEdiAction);

	/** Special */
	specialMenu = menuBar()->addMenu(tr("Special"));
	specialMenu->addAction(animateAction);
	specialMenu->addAction(morphAction);
	specialMenu->addSeparator();
	specialMenu->addAction(speEdiAction);

	/** Settings with submenus */
	settingsMenu = menuBar()->addMenu(tr("Settings"));

	scaleMenu = settingsMenu->addMenu(QIcon(":/images/scale.png"), tr("Scaling"));
	scaleMenu->addAction(sfineAction);
	scaleMenu->addAction(fineAction);
	scaleMenu->addAction(normalAction);
	scaleMenu->addAction(coarseAction);

	resetMenu = settingsMenu->addMenu(QIcon(":/images/reset.png"), tr("Reset"));
	resetMenu->addAction(resetViewAction);
	resetMenu->addAction(resetScaleAction);
	resetMenu->addAction(resetLightAction);
	resetMenu->addSeparator();
	resetMenu->addAction(resetAllAction);
	settingsMenu->addSeparator();

	settingsMenu->addAction(pictureAction);
	settingsMenu->addSeparator();

	settingsMenu->addAction(dirEdiAction);
	settingsMenu->addAction(fontAction);

	/** Windows */
	windowsMenu = menuBar()->addMenu(tr("Windows"));
	windowsMenu->addAction(toFrontAction);
	windowsMenu->addAction(toBackAction);
	windowsMenu->addSeparator();
	windowsMenu->addAction(showAllAction);

	/** Help */
	helpMenu = menuBar()->addMenu(tr("Help"));
	helpMenu->addAction(helpAction);
	helpMenu->addAction(demoAction);
	helpMenu->addSeparator();
	helpMenu->addAction(benchmarkAction);
	helpMenu->addAction(systemAction);
	helpMenu->addSeparator();
	helpMenu->addAction(aboutAction);
	helpMenu->addAction(aboutQtAction);
}


/** *************************************************************************
 ** CREATE TOOLBARS
****************************************************************************/
void MaiWindow::createToolBars() {

	/** Get current iconsize from fntEdi */
	QSize iconSize=fntEdi->getIcoSize();

	fileToolBar = addToolBar(tr("File"));
	fileToolBar->addAction(openAction);
	fileToolBar->addAction(saveAsAction);
	fileToolBar->setIconSize(iconSize);

	zoomToolBar = addToolBar(tr("Zoom"));
	zoomToolBar->addAction(zoomInAction);
	zoomToolBar->addAction(zoomOutAction);
	zoomToolBar->setIconSize(iconSize);

	transToolBar = addToolBar(tr("Move"));
	transToolBar->addAction(transLeftAction);
	transToolBar->addAction(transRightAction);
	transToolBar->addAction(transUpAction);
	transToolBar->addAction(transDownAction);
	transToolBar->setIconSize(iconSize);

	extraToolBar = addToolBar(tr("Extras"));
	extraToolBar->addAction(solveAction);
	extraToolBar->addAction(runStopAnimationAction);
	extraToolBar->addAction(runStopMorphAction);
	extraToolBar->setIconSize(iconSize);
}

/** Like in menu-redrawing, again strange workaround is needed!!! */
void MaiWindow::iconSizeSlot(const int newSize) {
	QSize iconSize(QSize(newSize, newSize));

	/** Destroy/recreate toolbars for QT versions < 4.5.0 */
	#if (QT_VERSION < 0x040500)
	delete fileToolBar;
	delete zoomToolBar;
	delete transToolBar;
	delete extraToolBar;
	createToolBars();
	#endif

	/** And now resize them! */
	fileToolBar->setIconSize(iconSize);
	zoomToolBar->setIconSize(iconSize);
	transToolBar->setIconSize(iconSize);
	extraToolBar->setIconSize(iconSize);
}


/** *************************************************************************
 ** MISCELLANEOUS GOODIES
****************************************************************************/
void MaiWindow::readSettings() {

	QSettings settings("Zhu3D", NAME);
	QPoint pos = settings.value("MainWindowPos", QPoint(0, 0)).toPoint();
	QSize size = settings.value("MainWindowSize", QSize(0, 0)).toSize();
	QPoint solpos = settings.value("SolverEditPos", QPoint(200, 200)).toPoint();
	QSize solsize = settings.value("SolverEditSize", QSize(400, 400)).toSize();
	QPoint hlppos = settings.value("HelpEditPos", QPoint(200, 200)).toPoint();
	QSize hlpsize = settings.value("HelpEditSize", QSize(400, 400)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
		solEdi->resize(solsize);
		solEdi->move(solpos);
		hlpEdi->resize(hlpsize);
		hlpEdi->move(hlppos);
	}
	else {
		/** Check clockcounter */
		if(MHz==0.0f)
			QMessageBox::information(
				0,
				QObject::tr("Program start") + "\n",
				QObject::tr("CPU clockcounter is not supported!") + "\n\n" +
				QObject::tr("System info cannot provide MHz-values")
			);

		/** Check hardware acceleration */
		if(!oglWid->format().directRendering())
			QMessageBox::information(
				0,
				QObject::tr("Program start") + "\n",
				QObject::tr("Missing OpenGL acceleration!") + "\n\n" +
				QObject::tr("Framerates will be very low")
			);

		resize(QSize(400,450));
		move(QPoint(0, 0));
		solEdi->resize(QSize(460, 250));
		solEdi->move(QPoint(300, 350));
		hlpEdi->resize(QSize(550, 660));
		hlpEdi->move(QPoint(40, 50));
	}
}

void MaiWindow::writeSettings() {
	QSettings settings("Zhu3D", NAME);

	/** Save actual settings */
	settings.setValue("MainWindowPos", pos());
	settings.setValue("MainWindowSize", size());
	settings.setValue("SolverEditPos", solEdi->pos());
	settings.setValue("SolverEditSize", solEdi->size());
	settings.setValue("HelpEditPos", hlpEdi->pos());
	settings.setValue("HelpEditSize", hlpEdi->size());
}

/** Wire-mode+Points is not sensefull, so test if wired is checkable */
void MaiWindow::wireModeSlot() {

	/** mode==point ? */
	if(sta.draw==2) {
		Wired->setChecked(false);
		Wired->setEnabled(false);
		return;
	}

	Wired->setChecked(sta.wired);
	Wired->setEnabled(true);
}

/** Solver in oglWid has done his work */
void MaiWindow::solveSlot() {
	const QDate date=QDate::currentDate();
	const QTime time=QTime::currentTime();
	const QString tmp=solve();

	/** Solver successful? */
	if(tmp.isEmpty())
		return;

	/** Fill solver editor */
	solEdi->append("********************************************************************************");
	solEdi->append(tr("Creation date:")+"  "+date.toString()+"  "+time.toString());
	solEdi->append("********************************************************************************");
	if(!ofun[0].startsWith("#") && !ofun[0].isEmpty())
		solEdi->append("F0(X,Y) = " + ofun[0]);
	else
		solEdi->append("F0(X,Y) = 0");
	if(!ofun[1].startsWith("#") && !ofun[1].isEmpty())
		solEdi->append("F1(X,Y) = " + ofun[1]);
	else
		solEdi->append("F1(X,Y) = 0");
	if(!ofun[2].startsWith("#") && !ofun[2].isEmpty())
		solEdi->append("F2(X,Y) = " + ofun[2]);
	else
		solEdi->append("F2(X,Y) = 0");
	solEdi->append("");
	solEdi->append(tmp);
	solEdi->append("********************************************************************************");
	solEdi->append("\n");

	/** Update cross-positions */
	updMaiInf();
	emit gotNewView();

	/** Set cursor at end */
	QTextCursor textCursor;
	textCursor=solEdi->textCursor();
	textCursor.movePosition(QTextCursor::End);
	solEdi->setTextCursor(textCursor);

	/** Solver editor to foreground */
	solverSlot();
}

/** Show cross statistics */
void MaiWindow::updMaiInf() {
	QString message;
	QString tmp;
	const int crossPrec=6;
	float val, f;

	/** Prepare */
	infoTextEdit->clear();
	infoTextEdit->setFontItalic(false);
	infoTextEdit->setTextColor(QColor(0,0,0));

	/** Current xy-value for actual cross-position */
	if(sta.funMod!=PARAMETER) {

		val=fabsf(f=sta.crossX*sta.sx);
		if(val>100000.0f || val<0.00001f)
			message=tr("Cross")+" X = "+tmp.setNum(f, 'e', crossPrec);
		else
			message=tr("Cross")+" X = "+tmp.setNum(f, 'f', crossPrec);
		infoTextEdit->append(message);

		val=fabsf(f=sta.crossY*sta.sy);
		if(val>100000.0f || val<0.00001f)
			message=tr("Cross")+" Y = "+tmp.setNum(f, 'e', crossPrec);
		else
			message=tr("Cross")+" Y = "+tmp.setNum(f, 'f', crossPrec);
		message+="\n---------------------------------";
		}
	else {

		val=fabsf(f=sta.crossX*sta.spx/3.141596f/sta.spz);
		if(val>100000.0f || val<0.00001f)
			message=tr("Cross")+" X = "+tmp.setNum(f, 'e', crossPrec);
		else
			message=tr("Cross")+" X = "+tmp.setNum(f, 'f', crossPrec);
		infoTextEdit->append(message);

		val=fabsf(f=sta.crossY*sta.spy/3.141596f/sta.spz);
		if(val>100000.0f || val<0.00001f)
			message=tr("Cross")+" Y = "+tmp.setNum(f, 'e', crossPrec);
		else
			message=tr("Cross")+" Y = "+tmp.setNum(f, 'f', crossPrec);
		message+="\n---------------------------------";
	}
	infoTextEdit->append(message);

	/** Change according to mode */
	if(sta.funMod!=FUNCTION) {
		infoTextEdit->setFontItalic(true);
		infoTextEdit->setTextColor(QColor(210,210,210));
	}

	/** Calculate and show function values at cross-position */
	sta.crossZ=fxy0(sta.crossX, sta.crossY)/sta.sz;
	if(fabs(sta.crossZ*sta.sx)>100000.0f || fabs(sta.crossZ*sta.sx)<0.00001f)
		message="F0(X,Y) = "+tmp.setNum(sta.crossZ, 'e', crossPrec);
	else
		message="F0(X,Y) = "+tmp.setNum(sta.crossZ, 'f', crossPrec);
	infoTextEdit->append(message);

	sta.crossZ=fxy1(sta.crossX, sta.crossY)/sta.sz;
	if(fabs(sta.crossZ*sta.sx)>100000.0f || fabs(sta.crossZ*sta.sx)<0.00001f)
		message="F1(X,Y) = "+tmp.setNum(sta.crossZ, 'e', crossPrec);
	else
		message="F1(X,Y) = "+tmp.setNum(sta.crossZ, 'f', crossPrec);
	infoTextEdit->append(message);

	sta.crossZ=fxy2(sta.crossX, sta.crossY)/sta.sz;
	if(fabs(sta.crossZ*sta.sx)>100000.0f || fabs(sta.crossZ*sta.sx)<0.00001f)
		message="F2(X,Y) = "+tmp.setNum(sta.crossZ, 'e', crossPrec);
	else
		message="F2(X,Y) = "+tmp.setNum(sta.crossZ, 'f', crossPrec);
	infoTextEdit->append(message);
}


/** *************************************************************************
 ** FILE STUFF
****************************************************************************/

/** Load */
void MaiWindow::loadFile(const QString &fileName) {

	/** Stop running animations/morphing */
	if(ani.active)
		aniEdi->animate(false);
	if(mor.active)
		morEdi->morph(false);

	/** Clean up whole screen before loading new data */
	for(long i=0; i<MAXFUN; i++)
		fun[i].drawFun=false;
	par.drawPar=sta.axes=sta.cross=false;
	sta.funMod=FUNCTION;
	Draw_Which();
	emit gotNewView();

	/** Init tables/error/morph/legends */
	iniErr();
	iniUsr();
	iniMor();
	iniLeg();

	zhuFile zhu;
	int err=zhu.load(fileName);

	/** Error checks */
	if(err==1) {
		QMessageBox::critical(
			this,
			tr("Open"),
			tr("Error loading file:") + " " + fileName
		);
		newSlot();
	}

	if(err==2) {
		QMessageBox::warning(
			this,
			tr("Open"),
			tr("Error loading file:") + " " + fileName + "\n" +
			tr("Zhu3D file is too old or not valid!")
		);
		newSlot();
	}

	if(err==3) {
		QMessageBox::warning(
			this,
			tr("Open"),
			tr("Error loading file:") + " " + fileName + "\n" +
			tr("XML parser error")
		);
		newSlot();
	}

	/** Everthing loaded. Check parser sanity now */
	if((err=initAllParsers())!=FunctionParser::FP_NO_ERROR) {
		QMessageBox::warning(
			this,
			tr("Open")+"\n",
			tr("Error loading file:") + " " + fileName + "\n" +
			fpError::getQtMessage(err)
		);
		newSlot();
	}

	/** Perform updates */
	updMaiWid();
	updMaiInf();
	funEdi->updFunWid();
	ligEdi->updLigWid();
	matEdi->updMatWid();
	entEdi->updEntWid();
	aniEdi->updAniWid();
	morEdi->updMorWid();
	speEdi->updSpeWid();
	usrEdi->updUsrWid();
	legEdi->updLegWid();

	/** Don't forget */
	iniITL();                       // Recalculate iso thread list before morphing!
	setCurrentFile(fileName);       // New window name
	aniEdi->animate(ani.active);    // Set animation mode
	morEdi->morph(mor.active);      // Set morphing mode

	/** Finish */
	PROC_EVENT;
	performOGLUpdate();
}

/** Prepare filename as current window-name */
void MaiWindow::setCurrentFile(const QString &fileName) {

	if(fileName.isEmpty())
		currentWindowName=tr("untitled");
	else
		currentWindowName=QFileInfo(fileName).fileName();

	currentWindowName=currentWindowName+" - "+NAME;
	setWindowTitle(currentWindowName);
}


/** *************************************************************************
 ** HANDLE CHECKBOXES FOR SUBMENUS FILEFORMAT AND SCALING
****************************************************************************/
void MaiWindow::sfineScale() {
	if(sfineChecked) {
		sfineAction->setChecked(true);
		return;
	}
	sfineChecked=true;
	sfineAction->setChecked(true);
	fineChecked=false;
	fineAction->setChecked(false);
	normalChecked=false;
	normalAction->setChecked(false);
	coarseChecked=false;
	coarseAction->setChecked(false);
}

void MaiWindow::fineScale() {
	if(fineChecked) {
		fineAction->setChecked(true);
		return;
	}
	sfineChecked=false;
	sfineAction->setChecked(false);
	fineChecked=true;
	fineAction->setChecked(true);
	normalChecked=false;
	normalAction->setChecked(false);
	coarseChecked=false;
	coarseAction->setChecked(false);
}

void MaiWindow::normalScale() {
	if(normalChecked) {
		normalAction->setChecked(true);
		return;
	}
	sfineChecked=false;
	sfineAction->setChecked(false);
	fineChecked=false;
	fineAction->setChecked(false);
	normalChecked=true;
	normalAction->setChecked(true);
	coarseChecked=false;
	coarseAction->setChecked(false);
}

void MaiWindow::coarseScale() {
	if(coarseChecked) {
		coarseAction->setChecked(true);
		return;
	}
	sfineChecked=false;
	sfineAction->setChecked(false);
	fineChecked=false;
	fineAction->setChecked(false);
	normalChecked=false;
	normalAction->setChecked(false);
	coarseChecked=true;
	coarseAction->setChecked(true);
}


/** *************************************************************************
 ** HANDLE MAIN-WIDGET REDRAW WHEN NEW FILE IS LOADED
****************************************************************************/
void MaiWindow::updMaiWid() {

	QString tmp;

	/** Show */
	Function3->setChecked(par.drawPar);
	Cross->setChecked(sta.cross);
	Axes->setChecked(sta.axes);

	/** Mode */
	Point->setChecked(sta.draw==2?1:0);
	Triangle->setChecked(sta.draw==0?1:0);
	Quad->setChecked(sta.draw==1?1:0);
	wireModeSlot();

	/** Rotation-sliders */
	Ui_mainCtrl::xSlider->setValue((int)sta.rotX);
	Ui_mainCtrl::ySlider->setValue((int)sta.rotY);
	Ui_mainCtrl::zSlider->setValue((int)sta.rotZ);

	/** Scale box */
	xscaleLabel->setToolTip(tr("X-values"));
	yscaleLabel->setToolTip(tr("Y-values"));
	zscaleLabel->setToolTip(tr("Z-values"));
	xyzscaleLabel->setText(tr(" A"));
	xyzscaleLabel->setToolTip(tr("All XYZ-values together"));

	/** Are we in function-mode? */
	if(sta.funMod==FUNCTION) {

		Function0->setText("F0");
		Function1->setText("F1");
		Function2->setText("F2");
		Function0->setChecked(fun[0].drawFun);
		Function1->setChecked(fun[1].drawFun);
		Function2->setChecked(fun[2].drawFun);
		Function0->setEnabled(true);
		Function1->setEnabled(true);
		Function2->setEnabled(true);

		ScaleBox->setToolTip(tr("Scale functions"));
		zPlus->setEnabled(true);
		zMinus->setEnabled(true);
		zscaleLabel->setEnabled(true);

		solveAction->setText(tr("Solve system"));
		solveAction->setEnabled(true);
		funEdi->setWindowTitle(tr("Function editor"));
		funEdiAction->setText(tr("Functions"));
		infoTextEdit->setEnabled(true);
		statusLabel->setText(tr("Edit: Functions")+"   "+tr("Grid:")+" "+tmp.setNum(sta.fgrids));

		Point->setEnabled(true);
		Triangle->setEnabled(true);
		Quad->setEnabled(true);

	}

	/** Are we in implicite function mode? */
	if(sta.funMod==IMPLICITE) {
		Function0->setText("I0");
		Function1->setText("I1");
		Function2->setText("I2");
		Function0->setChecked(iso[0].drawIso);
		Function1->setChecked(iso[1].drawIso);
		Function2->setChecked(iso[2].drawIso);
		Function0->setEnabled(true);
		Function1->setEnabled(true);
		Function2->setEnabled(true);

		ScaleBox->setToolTip(tr("Scale iso functions"));
		zPlus->setEnabled(true);
		zMinus->setEnabled(true);
		zscaleLabel->setEnabled(true);

		solveAction->setText(tr("For solving switch to function-mode"));
		solveAction->setEnabled(false);
		funEdi->setWindowTitle(tr("Iso editor"));
		funEdiAction->setText(tr("Iso functions"));
		infoTextEdit->setEnabled(false);
		statusLabel->setText(tr("Edit: Isosurfaces")+"   "+tr("Grid:")+" "+tmp.setNum(sta.tgrids));

		Point->setEnabled(true);
		Triangle->setEnabled(true);
		Quad->setEnabled(false);
	}

	/** Or in parameter mode? */
	if(sta.funMod==PARAMETER) {

		Function0->setEnabled(false);
		Function1->setEnabled(false);
		Function2->setEnabled(false);

		Function0->setChecked(iso[0].drawIso);
		Function1->setChecked(iso[1].drawIso);
		Function2->setChecked(iso[2].drawIso);

		ScaleBox->setToolTip(tr("Scale parametric system"));
		zPlus->setEnabled(false);
		zMinus->setEnabled(false);
		zscaleLabel->setEnabled(false);

		solveAction->setText(tr("For solving switch to function-mode"));
		solveAction->setEnabled(false);
		funEdi->setWindowTitle(tr("Parameter editor"));
		funEdiAction->setText(tr("Parameters"));
		infoTextEdit->setEnabled(false);
		statusLabel->setText(tr("Edit: Parameter")+"   "+tr("Grid:")+" "+tmp.setNum(sta.fgrids));

		Point->setEnabled(true);
		Triangle->setEnabled(true);
		Quad->setEnabled(true);
	}

	//Toggle labels on animation
	if(!ani.active) {
		if(sta.funMod==FUNCTION)
			infoTextEdit->setEnabled(true);
		runStopAnimationAction->setIcon(QIcon(":/images/animate.png"));
		runStopAnimationAction->setToolTip(tr("Start animation"));
	}
	else {
		infoTextEdit->setEnabled(false);
		runStopAnimationAction->setIcon(QIcon(":/images/stop.png"));
		runStopAnimationAction->setToolTip(tr("Stop animation"));
	}

	//Toggle labels on morphing
	if(!mor.active) {
		if(sta.funMod==FUNCTION)
			infoTextEdit->setEnabled(true);
		runStopMorphAction->setIcon(QIcon(":/images/morph.png"));
		runStopMorphAction->setToolTip(tr("Start morphing"));
	}
	else {
		infoTextEdit->setEnabled(false);
		runStopMorphAction->setIcon(QIcon(":/images/stop.png"));
		runStopMorphAction->setToolTip(tr("Stop morphing"));
	}
}


/** *************************************************************************
 ** BENCHMARK
****************************************************************************/
void MaiWindow::benchmarkSlot() {

	const float roffset=0.15f;
	const int mSec=3000;
	long frames=0;

	QString result, tmp;
	QString currentTitle=this->windowTitle();

	/** Backup and load benchmark-file */
	saveToRam();
	loadFile(MYSYSDIR+"benchmark.zhu");

	/** Initialize benchmark-viewer */
	QApplication::setOverrideCursor(Qt::WaitCursor);
	aniEdi->animate((ani.active=false));
	oglWid->writeSettings();
	oglWid->move(QPoint(0,0));
	oglWid->resize(QSize(700,700));
	oglWid->setWindowTitle(tr("Benchmarking now ..."));
	oglWid->raise();
	oglWid->activateWindow();

	/** Perform benchmark */
	benchReady=false;
	QTimer::singleShot(mSec, this, SLOT(benchTimerSlot()));
	while(!benchReady) {
			sta.rotX += roffset;
			sta.rotY += 3*roffset;
			sta.rotZ += 4*roffset;
			emit gotNewView();
			frames++;
			QApplication::processEvents();    // Give timer a chance!
	}
	QApplication::restoreOverrideCursor();

	/** Prepare result-string */
	result="GPU  =  ";
	tmp.setNum(((int)frames)/(mSec/1000.0), 'f', 1);
	result+=tmp;
	result+="  FPS\nCPU  =  ";
	zsecs=1.0/zsecs*100.0;
	tmp.setNum(zsecs, 'f', 1);
	result+=tmp+"  Isomarks";

	/** Show benchmark-info */
	QMessageBox::information(
		this,
		tr("Benchmark"),
		result.toAscii().data()
		);

	/** Restore and perform updates */
	restoreFromRam();
	aniEdi->animate(ani.active);
	morEdi->morph(mor.active);
	oglWid->updWinTit();
	oglWid->readSettings();
	this->setWindowTitle(currentTitle);
	this->raise();
	this->activateWindow();

	/** Update MaiWindow stuff */
	updMaiWid();
	updMaiInf();

	/** Reload textures */
	for(int i=0; i<MAXFUN+1; i++)
		speEdi->loadTexture(texDir+tex[i].name, i);

	/** Update other widgets */
	funEdi->updFunWid();
	ligEdi->updLigWid();
	matEdi->updMatWid();
	entEdi->updEntWid();
	aniEdi->updAniWid();
	speEdi->updSpeWid();
	usrEdi->updUsrWid();
	legEdi->updLegWid();

	/** Dont forget multithreaded OpenGL lists */
	iniITL();

	/** Update OpenGL finally */
	PROC_EVENT;
	performOGLUpdate();
}


/** Retranslate mainwidget */
void MaiWindow::reTranslate() {

	/** Menus */
	fileMenu->setTitle(tr("File"));
	editorMenu->setTitle(tr("Editors"));
	specialMenu->setTitle(tr("Special"));
	settingsMenu->setTitle(tr("Settings"));
	scaleMenu->setTitle(tr("Scaling"));
	resetMenu->setTitle(tr("Reset"));
	windowsMenu->setTitle(tr("Windows"));
	helpMenu->setTitle(tr("Help"));

	/** File */
	newAction->setText(tr("&New"));
	newAction->setShortcut(tr("Ctrl+N"));
	openAction->setText(tr("&Open ..."));
	openAction->setShortcut(tr("Ctrl+O"));
	saveAsAction->setText(tr("&Save as"));
	saveAsAction->setShortcut(tr("Ctrl+S"));
	saveSolAction->setText(tr("Save solutions"));
	savePicAction->setText(tr("Save picture"));
	printAction->setText(tr("Print picture"));
	exitAction->setText(tr("&Exit"));
	exitAction->setShortcut(tr("Ctrl+E"));

	/** Editors */
	lightAction->setText(tr("Lights"));
	materialAction->setText(tr("Surfaces"));
	entireAction->setText(tr("Global"));
	solEdiAction->setText(tr("Solver report"));
	usrEdiAction->setText(tr("User defined"));
	legEdiAction->setText(tr("Legends"));
	funEdiAction->setText(tr("Functions"));

	/** Special */
	animateAction->setText(tr("Animation"));
	morphAction->setText(tr("Morphing"));
	speEdiAction->setText(tr("OpenGL"));

	/** Settings */
	pictureAction->setText(tr("Picture"));
	sfineAction->setText(tr("micro"));
	fineAction->setText(tr("fine"));
	normalAction->setText(tr("normal"));
	coarseAction->setText(tr("coarse"));
	resetViewAction->setText(tr("View only"));
	resetScaleAction->setText(tr("Scaling only"));
	resetLightAction->setText(tr("Lights only"));
	resetAllAction->setText(tr("All together"));
	fontAction->setText(tr("General"));
	dirEdiAction->setText(tr("Directories"));

	/** Windows */
	toFrontAction->setText(tr("Show open editors"));
	toBackAction->setText(tr("Hide open editors"));
	showAllAction->setText(tr("Open all editors"));

	/** Help */
	helpAction->setText(tr("Help"));
	demoAction->setText(tr("Demo"));
	helpAction->setShortcut(tr("F1"));
	systemAction->setText(tr("System"));
	benchmarkAction->setText(tr("Benchmark"));
	aboutAction->setText(tr("About Zhu3D"));
	aboutQtAction->setText(tr("About Qt"));

	/** Destroy/recreate toolbars for QT versions < 4.5.0 */
	#if (QT_VERSION < 0x040500)
	delete fileToolBar;
	delete zoomToolBar;
	delete transToolBar;
	delete extraToolBar;
	createToolBars();
	#endif

	/** Dynamic stuff; renew all instead of fiddling around */
	updMaiWid();
	updMaiInf();
}
