/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "entedit.h"


/** Constructor */
entWidget::entWidget(QWidget *parent) : QWidget(parent) {

	/** Set up entire editor */
	Ui_entUI::setupUi(this);
	setMinimumSize(180, 200);
	setWindowTitle(tr("Global"));
	readSettings();

	/** Global ambient light */
	connect(LMAR, SIGNAL(valueChanged(int)), oglWid, SLOT(lmared(int)));
	connect(LMAG, SIGNAL(valueChanged(int)), oglWid, SLOT(lmagreen(int)));
	connect(LMAB, SIGNAL(valueChanged(int)), oglWid, SLOT(lmablue(int)));
	connect(LMAA, SIGNAL(valueChanged(int)), oglWid, SLOT(lmaalpha(int)));

	/** Global background light */
	connect(LMBR, SIGNAL(valueChanged(int)), oglWid, SLOT(lmbred(int)));
	connect(LMBG, SIGNAL(valueChanged(int)), oglWid, SLOT(lmbgreen(int)));
	connect(LMBB, SIGNAL(valueChanged(int)), oglWid, SLOT(lmbblue(int)));
	connect(LMBA, SIGNAL(valueChanged(int)), oglWid, SLOT(lmbalpha(int)));

	/** OpenGL model-modes */
	connect(LMInf, SIGNAL(clicked()), oglWid, SLOT(modInf()));
	connect(LMLoc, SIGNAL(clicked()), oglWid, SLOT(modLoc()));
	connect(LMOne, SIGNAL(clicked()), oglWid, SLOT(modOne()));
	connect(LMTwo, SIGNAL(clicked()), oglWid, SLOT(modTwo()));

	/** RGB-locking & update */
	connect(locAmb, SIGNAL(clicked()), oglWid, SLOT(entAmbLocked()));
	connect(locBac, SIGNAL(clicked()), oglWid, SLOT(entBacLocked()));
	connect(oglWid, SIGNAL(updEntWid()), this, SLOT(updEntWid()));
}


/** *************************************************************************
 ** UPDATE SLIDER-VALUES IN LIGHT-EDITOR
****************************************************************************/
void entWidget::updEntWid() {
	locAmb->setChecked(ent.ambEntLoc);
	locBac->setChecked(ent.bacEntLoc);

	LMAR->setValue((int)(ent.modLig[0]*255.0f));
	LMAG->setValue((int)(ent.modLig[1]*255.0f));
	LMAB->setValue((int)(ent.modLig[2]*255.0f));
	LMAA->setValue((int)(ent.modLig[3]*255.0f));

	LMBR->setValue((int)(ent.bacLig[0]*255.0f));
	LMBG->setValue((int)(ent.bacLig[1]*255.0f));
	LMBB->setValue((int)(ent.bacLig[2]*255.0f));
	LMBA->setValue((int)(ent.bacLig[3]*255.0f));

	LMInf->setChecked(ent.modInf==0.0f);
	LMLoc->setChecked(ent.modInf==1.0f);
	LMOne->setChecked(ent.modOne==0.0f);
	LMTwo->setChecked(ent.modOne==1.0f);
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void entWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_entUI::retranslateUi(this);
		setWindowTitle(tr("Global"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void entWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void entWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("EntWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("EntWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(230, 270));
		move(QPoint(20, 320));
	}
}

void entWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("EntWindowPos", pos());
	settings.setValue("EntWindowSize", size());
}
