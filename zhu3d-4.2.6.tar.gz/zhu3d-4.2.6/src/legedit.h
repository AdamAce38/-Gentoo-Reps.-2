/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _LEGEDITOR_H_
#define _LEGEDITOR_H_

#include <QWidget>
#include <QTableWidget>
#include <QHeaderView>
#include <QIcon>
#include <QCloseEvent>
#include <QSettings>
#include <QFontInfo>

#include "ui_legedit.h"
#include "property.h"
#include "version.h"
#include "debug.h"


/** Handles legends settings */
class legWidget : public QWidget, private Ui::legUI {

Q_OBJECT

public:
	legWidget(QWidget *parent=0);
	~legWidget() {}

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

public slots:
	void updLegWid();

private slots:
	void axesEntryChanged(const int r, const int c);
	void axesEntryClicked(const int r, const int c);
	void syncSlot();
	void movMouSlot();

	/** LEGENDS COLOURS */
	void llred  (const int intensity) { if(updTru) llall(0, intensity); }
	void llgreen(const int intensity) { if(updTru) llall(1, intensity); }
	void llblue (const int intensity) { if(updTru) llall(2, intensity); }
	void llall(const int channel, const int intensity);
	void legLocked();

private:
	/** Table stuff */
	void createAxesTable();
	void deleteAxesTable();

	/** Sliders update */
	void updSli();
	bool updTru;

	/** Remember table column withs for items and size */
	int cw0, cw1;

	/** Remember width and height to check window update */
	int bakWidth;
	int bakHeight;

	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _LEGEDITOR_H_ */
#endif
