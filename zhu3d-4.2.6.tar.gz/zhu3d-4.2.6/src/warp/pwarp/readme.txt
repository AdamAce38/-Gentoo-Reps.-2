  Function parser for C++  v2.83 by Warp.
  =====================================

  Optimization code contributed by Bisqwit (http://iki.fi/bisqwit/)


  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  This is a precision version of the Warp parser adapted for Zhu3D.
  The whole and original fparser.txt file is located in the directory ../warp
  There you can find the licence and the full technical details.
  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
