/***************************************************************************\
|* Function parser v2.83 by Warp                                           *|
|* -----------------------------                                           *|
|* Parses and evaluates the given function with the given variable values. *|
|* See fparser.txt for details.                                            *|
|*                                                                         *|
\***************************************************************************/

#ifndef _PONCE_FPARSER_H_
#define _PONCE_FPARSER_H_

#include <string>
#include <map>
#include <vector>

#ifdef PFUNCTIONPARSER_SUPPORT_DEBUG_OUTPUT
#include <iostream>
#endif


/** *************************************************************************
 ** Zhu3D only. This fp-version is still 2.83 as an optimizing bug does NOT
 ** interfere here at all.
 **
 ** The main changes/additions I made for Zhu3D are due to performance:
 ** Optimizing may be sometetimes slightly slower, mostly a lot faster
 **
 ** Added a choice for float types, float is ~15% faster than double
 ** Added detection of # which starts a comment and returns 0.0
 ** Added dedetction of Null string which return 0.0
 ** Replaced int's with long due to 64-bit performance
 ** Changed MY_PI to (long double)PMY_PI for accuracy reasons
 ** Changed FP_EPSILON in fpconfig.h from 1e-14 to 1.1e-19L for accuracy
 ** Enabled built in hyperbolic functions
 ** Disabled optimizer to shrink executable size
 **
 ** NOTE: this precision version is transparent for pf-format choice
 **
****************************************************************************/

// #define PFPOPTIMIZE
#define PFPFLOAT long double


class pFunctionParser
{
public:
    enum ParseErrorType
    {
        SYNTAX_ERROR=0, MISM_PARENTH, MISSING_PARENTH, EMPTY_PARENTH,
        EXPECT_OPERATOR, OUT_OF_MEMORY, UNEXPECTED_ERROR, INVALID_VARS,
        ILL_PARAMS_AMOUNT, PREMATURE_EOS, EXPECT_PARENTH_FUNC,
        FP_NO_ERROR
    };


    long Parse(const std::string& Function, const std::string& Vars,
              bool useDegrees = false);
    const char* ErrorMsg() const;
    inline ParseErrorType GetParseErrorType() const { return parseErrorType; }

    PFPFLOAT Eval(const PFPFLOAT* Vars);
    inline long EvalError() const { return evalErrorType; }

    bool AddConstant(const std::string& name, PFPFLOAT value);
    bool AddUnit(const std::string& name, PFPFLOAT value);

    typedef PFPFLOAT (*FunctionPtr)(const PFPFLOAT*);

    bool AddFunction(const std::string& name,
                     FunctionPtr, unsigned long paramsAmount);
    bool AddFunction(const std::string& name, pFunctionParser&);

    void Optimize();


    pFunctionParser();
    ~pFunctionParser();

    // Copy constructor and assignment operator (implemented using the
    // copy-on-write technique for efficiency):
    pFunctionParser(const pFunctionParser&);
    pFunctionParser& operator=(const pFunctionParser&);
    void ForceDeepCopy();


#ifdef FUNCTIONPARSER_SUPPORT_DEBUG_OUTPUT
    // For debugging purposes only:
    void PrintByteCode(std::ostream& dest) const;
#endif


//========================================================================
private:
//========================================================================

// Private data:
// ------------
    ParseErrorType parseErrorType;
    long evalErrorType;

    struct Data
    {
        unsigned long referenceCounter;

        long varAmount;
        bool useDegreeConversion;

        typedef std::map<std::string, unsigned long> VarMap_t;
        VarMap_t Variables;

        typedef std::map<std::string, PFPFLOAT> ConstMap_t;
        ConstMap_t Constants;
        ConstMap_t Units;

        VarMap_t FuncPtrNames;
        struct FuncPtrData
        {
            FunctionPtr ptr; unsigned long params;
            FuncPtrData(FunctionPtr p, unsigned long par): ptr(p), params(par) {}
        };
        std::vector<FuncPtrData> FuncPtrs;

        VarMap_t FuncParserNames;
        std::vector<pFunctionParser*> FuncParsers;

        unsigned long* ByteCode;
        unsigned long ByteCodeSize;
        PFPFLOAT* Immed;
        unsigned long ImmedSize;
        PFPFLOAT* Stack;
        unsigned long StackSize;

        Data();
        ~Data();
        Data(const Data&);

        Data& operator=(const Data&); // not implemented on purpose
    };

    Data* data;
    unsigned long evalRecursionLevel;

    // Temp data needed in Compile():
    unsigned long StackPtr;
    std::vector<unsigned long>* tempByteCode;
    std::vector<PFPFLOAT>* tempImmed;


// Private methods:
// ---------------
    void CopyOnWrite();
    bool CheckRecursiveLinking(const pFunctionParser*) const;

    bool ParseVars(const std::string& Vars, std::map<std::string, unsigned long>& dest);
    long VarNameType(const std::string&) const;
    Data::VarMap_t::const_iterator
    FindVariable(const char*, const Data::VarMap_t&) const;
    Data::ConstMap_t::const_iterator
    FindConstant(const char*, const Data::ConstMap_t&) const;
    long CheckForUnit(const char*, long) const;
    long CheckSyntax(const char*);
    long Compile(const char*);
    bool IsVariable(long);
    void AddCompiledByte(unsigned long);
    void AddImmediate(PFPFLOAT);
    void AddFunctionOpcode(unsigned long);
    inline void incStackPtr();
    long CompileIf(const char*, long);
    long CompileFunctionParams(const char*, long, unsigned long);
    long CompileElement(const char*, long);
    long CompilePossibleUnit(const char*, long);
    long CompilePow(const char*, long);
    long CompileUnaryMinus(const char*, long);
    long CompileMult(const char*, long);
    long CompileAddition(const char*, long);
    long CompileComparison(const char*, long);
    long CompileAnd(const char*, long);
    long CompileOr(const char*, long);
    long CompileExpression(const char*, long, bool=false);

    void MakeTree(void*) const;
};

// _PONCE_FPARSER_H_
#endif
