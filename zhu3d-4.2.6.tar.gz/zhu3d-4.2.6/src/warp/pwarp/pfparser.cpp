//===============================
// Function parser v2.83 by Warp
//===============================

#include "pfpconfig.h"
#include "pfparser.h"
#include "pfptypes.h"
using namespace PFUNCTIONPARSERTYPES;

#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>

using namespace std;

#ifdef PFP_USE_THREAD_SAFE_EVAL_WITH_ALLOCA
#ifndef PFP_USE_THREAD_SAFE_EVAL
#define PFP_USE_THREAD_SAFE_EVAL
#endif
#endif

// Original setting:
// #ifndef M_PI
// #define M_PI 3.1415926535897932384626433832795
// #endif

#define PMY_PI 3.1415926535897932384626433832795L


namespace
{
    const unsigned long FUNC_AMOUNT = sizeof(Functions)/sizeof(Functions[0]);


    // BCB4 does not implement the standard lower_bound function.
    // This is used instead:
    const FuncDefinition* fp_lower_bound(const FuncDefinition* first,
                                         const FuncDefinition* last,
                                         const FuncDefinition& value)
    {
        while(first < last)
        {
            const FuncDefinition* middle = first+(last-first)/2;
            if(*middle < value) first = middle+1;
            else last = middle;
        }
        return last;
    }


    // Returns a pointer to the FuncDefinition instance which 'name' is
    // the same as the one given by 'F'. If no such function name exists,
    // returns 0.
    inline const FuncDefinition* FindFunction(const char* F)
    {
        FuncDefinition func = { F, 0, 0, 0 };
        while(isalnum(F[func.nameLength])) ++func.nameLength;
        if(func.nameLength)
        {
            const FuncDefinition* found =
                fp_lower_bound(Functions, Functions+FUNC_AMOUNT, func);
            if(found == Functions+FUNC_AMOUNT || func < *found)
                return 0;
            return found;
        }
        return 0;
    }
}


//---------------------------------------------------------------------------
// Copy-on-write method
//---------------------------------------------------------------------------
void pFunctionParser::CopyOnWrite()
{
    if(data->referenceCounter > 1)
    {
        Data* oldData = data;
        data = new Data(*oldData);
        --(oldData->referenceCounter);
        data->referenceCounter = 1;
    }
}


//---------------------------------------------------------------------------
// Constructors and destructors
//---------------------------------------------------------------------------
//===========================================================================
pFunctionParser::pFunctionParser():
    parseErrorType(FP_NO_ERROR), evalErrorType(0),
    data(new Data),
    evalRecursionLevel(0)
{
    data->referenceCounter = 1;
}

pFunctionParser::~pFunctionParser()
{
    if(--(data->referenceCounter) == 0)
    {
        delete data;
    }
}

pFunctionParser::pFunctionParser(const pFunctionParser& cpy):
    parseErrorType(cpy.parseErrorType),
    evalErrorType(cpy.evalErrorType),
    data(cpy.data),
    evalRecursionLevel(0)
{
    ++(data->referenceCounter);
}

pFunctionParser& pFunctionParser::operator=(const pFunctionParser& cpy)
{
    if(data != cpy.data)
    {
        if(--(data->referenceCounter) == 0) delete data;

        parseErrorType = cpy.parseErrorType;
        evalErrorType = cpy.evalErrorType;
        data = cpy.data;
        evalRecursionLevel = cpy.evalRecursionLevel;

        ++(data->referenceCounter);
    }

    return *this;
}

void pFunctionParser::ForceDeepCopy()
{
    CopyOnWrite();
}

pFunctionParser::Data::Data():
    useDegreeConversion(false),
    ByteCode(0), ByteCodeSize(0),
    Immed(0), ImmedSize(0),
    Stack(0), StackSize(0)
{}

pFunctionParser::Data::~Data()
{
    if(ByteCode) { delete[] ByteCode; ByteCode=0; }
    if(Immed) { delete[] Immed; Immed=0; }
    if(Stack) { delete[] Stack; Stack=0; }
}

// Makes a deep-copy of Data:
pFunctionParser::Data::Data(const Data& cpy):
    varAmount(cpy.varAmount), useDegreeConversion(cpy.useDegreeConversion),
    Variables(cpy.Variables), Constants(cpy.Constants), Units(cpy.Units),
    FuncPtrNames(cpy.FuncPtrNames), FuncPtrs(cpy.FuncPtrs),
    FuncParserNames(cpy.FuncParserNames), FuncParsers(cpy.FuncParsers),
    ByteCode(0), ByteCodeSize(cpy.ByteCodeSize),
    Immed(0), ImmedSize(cpy.ImmedSize),
    Stack(0), StackSize(cpy.StackSize)
{
    if(ByteCodeSize) ByteCode = new unsigned long[ByteCodeSize];
    if(ImmedSize) Immed = new PFPFLOAT[ImmedSize];
    if(StackSize) Stack = new PFPFLOAT[StackSize];

    for(unsigned long i=0; i<ByteCodeSize; ++i) ByteCode[i] = cpy.ByteCode[i];
    for(unsigned long i=0; i<ImmedSize; ++i) Immed[i] = cpy.Immed[i];

    // No need to copy the stack contents because it's obsolete outside Eval()
}


//---------------------------------------------------------------------------
// Function parsing
//---------------------------------------------------------------------------
//===========================================================================
namespace
{
    // Error messages returned by ErrorMsg():
    const char* ParseErrorMessage[]=
    {
        "Syntax error",                             // 0
        "Mismatched parenthesis",                   // 1
        "Missing closing parenthesis",              // 2
        "Empty parentheses",                        // 3
        "Operator expected",                        // 4
        "Out of memory",                            // 5
        "Unexpected error",                         // 6
        "Unknown parameter",                        // 7
        "Illegal number of function parameters",    // 8
        "Premature end of string",                  // 9
        "Expecting parenthesis after function",     // 10
        ""
    };


    enum VarNameType
    { NOT_VALID_NAME, VALID_NEW_NAME, RESERVED_FUNCTION,
      USER_DEF_CONST, USER_DEF_UNIT,
      USER_DEF_FUNC_PTR, USER_DEF_FUNC_PARSER
    };
}


// Parse variables
bool pFunctionParser::ParseVars(const string& Vars, map<string, unsigned long>& dest)
{
    unsigned long varNumber = VarBegin;
    unsigned long ind1 = 0, ind2;

    while(ind1 < Vars.size())
    {
        if(!isalpha(Vars[ind1]) && Vars[ind1]!='_') return false;
        for(ind2=ind1+1; ind2<Vars.size() && Vars[ind2]!=','; ++ind2)
            if(!isalnum(Vars[ind2]) && Vars[ind2]!='_') return false;
        const string varName = Vars.substr(ind1, ind2-ind1);
        if(VarNameType(varName) != VALID_NEW_NAME) return false;

        if(dest.insert(make_pair(varName, varNumber++)).second == false)
            return false;

        ind1 = ind2+1;
    }
    return true;
}

namespace
{
    bool varNameHasOnlyValidChars(const std::string& name)
    {
        if(name.empty() || (!isalpha(name[0]) && name[0] != '_'))
            return false;
        for(unsigned long i=0; i<name.size(); ++i)
            if(!isalnum(name[i]) && name[i] != '_')
                return false;
        return true;
    }
}

long pFunctionParser::VarNameType(const std::string& name) const
{
    if(!varNameHasOnlyValidChars(name)) return NOT_VALID_NAME;

    const char* n = name.c_str();
    if(FindFunction(n)) return RESERVED_FUNCTION;
    if(FindConstant(n, data->Constants) != data->Constants.end())
        return USER_DEF_CONST;

    // Units are independent from the rest and thus the following check
    // is actually not needed:
    //if(FindConstant(n, data->Units) != data->Units.end())
    //    return USER_DEF_UNIT;

    if(FindVariable(n, data->FuncParserNames) != data->FuncParserNames.end())
        return USER_DEF_FUNC_PARSER;
    if(FindVariable(n, data->FuncPtrNames) != data->FuncPtrNames.end())
        return USER_DEF_FUNC_PTR;

    return VALID_NEW_NAME;
}


// Constants:
bool pFunctionParser::AddConstant(const string& name, PFPFLOAT value)
{
    long nameType = VarNameType(name);
    if(nameType == VALID_NEW_NAME || nameType == USER_DEF_CONST)
    {
        CopyOnWrite();
        data->Constants[name] = value;
        return true;
    }
    return false;
}

// Units:
bool pFunctionParser::AddUnit(const std::string& name, PFPFLOAT value)
{
    if(!varNameHasOnlyValidChars(name)) return false;
    CopyOnWrite();
    data->Units[name] = value;
    return true;
}

// Function pointers
bool pFunctionParser::AddFunction(const std::string& name,
                                 FunctionPtr func, unsigned long paramsAmount)
{
    long nameType = VarNameType(name);
    if(nameType == VALID_NEW_NAME)
    {
        CopyOnWrite();
        data->FuncPtrNames[name] = data->FuncPtrs.size();
        data->FuncPtrs.push_back(Data::FuncPtrData(func, paramsAmount));
        return true;
    }
    return false;
}

bool pFunctionParser::CheckRecursiveLinking(const pFunctionParser* fp) const
{
    if(fp == this) return true;
    for(unsigned long i=0; i<fp->data->FuncParsers.size(); ++i)
        if(CheckRecursiveLinking(fp->data->FuncParsers[i])) return true;
    return false;
}

bool pFunctionParser::AddFunction(const std::string& name,
                                 pFunctionParser& parser)
{
    long nameType = VarNameType(name);
    if(nameType == VALID_NEW_NAME)
    {
        if(CheckRecursiveLinking(&parser)) return false;

        CopyOnWrite();

        data->FuncParserNames[name] = data->FuncParsers.size();
        data->FuncParsers.push_back(&parser);
        return true;
    }
    return false;
}



// Main parsing function
// ---------------------
long pFunctionParser::Parse(const std::string& Function,
                           const std::string& Vars,
                           bool useDegrees)
{
    CopyOnWrite();

    data->Variables.clear();

    if(!ParseVars(Vars, data->Variables))
    {
        parseErrorType = INVALID_VARS;
        return Function.size();
    }
    data->varAmount = data->Variables.size(); // this is for Eval()

	// Added detection of comment sign # and Null string
    // const char* Func = Function.c_str();
    const char* Func = (((Function[0]=='#') || (Function[0]=='\0')) ? "0" : Function.c_str());


    parseErrorType = FP_NO_ERROR;

    long Result = CheckSyntax(Func);
    if(Result >= 0) return Result;

    data->useDegreeConversion = useDegrees;
    Result = Compile(Func);
    if(Result >= 0) return Result;

    data->Variables.clear();

    parseErrorType = FP_NO_ERROR;
    return -1;
}

namespace
{
    const char* const fpOperators[] =
    {
        "+", "-", "*", "/", "%", "^",
        "=", "!=", "<=", "<", ">=", ">", "&", "|",
        0
    };

    // Is given char an operator?
    // (Returns 0 if not, else the size of the operator)
    inline long IsOperator(const char* F)
    {
        for(unsigned long opInd = 0; fpOperators[opInd]; ++opInd)
        {
            const char* op = fpOperators[opInd];
            for(unsigned long n = 0; F[n] == *op; ++n)
            {
                ++op;
                if(*op == 0) return op-fpOperators[opInd];
            }
        }
        return 0;
    }

    // skip whitespace
    inline void sws(const char* F, long& Ind)
    {
        while(F[Ind] && isspace(F[Ind])) ++Ind;
    }
}

// Returns an iterator to the variable with the same name as 'F', or to
// Variables.end() if no such variable exists:
inline pFunctionParser::Data::VarMap_t::const_iterator
pFunctionParser::FindVariable(const char* F, const Data::VarMap_t& vars) const
{
    if(vars.size())
    {
        unsigned long ind = 0;
        while(isalnum(F[ind]) || F[ind] == '_') ++ind;
        if(ind)
        {
            string name(F, ind);
            return vars.find(name);
        }
    }
    return vars.end();
}

inline pFunctionParser::Data::ConstMap_t::const_iterator
pFunctionParser::FindConstant(const char* F,
                             const Data::ConstMap_t& consts) const
{
    if(consts.size())
    {
        unsigned long ind = 0;
        while(isalnum(F[ind]) || F[ind] == '_') ++ind;
        if(ind)
        {
            string name(F, ind);
            return consts.find(name);
        }
    }
    return consts.end();
}

long pFunctionParser::CheckForUnit(const char* Function, long Ind) const
{
    long c = Function[Ind];
    if(isalpha(c) || c == '_')
    {
        Data::ConstMap_t::const_iterator uIter =
            FindConstant(&Function[Ind], data->Units);
        if(uIter != data->Units.end())
        {
            Ind += uIter->first.size();
            sws(Function, Ind);
        }
    }
    return Ind;
}

//---------------------------------------------------------------------------
// Check function string syntax
// ----------------------------
long pFunctionParser::CheckSyntax(const char* Function)
{
    const Data::VarMap_t& Variables = data->Variables;
    const Data::ConstMap_t& Constants = data->Constants;
    const Data::VarMap_t& FuncPtrNames = data->FuncPtrNames;
    const Data::VarMap_t& FuncParserNames = data->FuncParserNames;

    vector<long> functionParenthDepth;

    long Ind=0, ParenthCnt=0, c;
    char* Ptr;

    while(true)
    {
        sws(Function, Ind);
        c=Function[Ind];

// Check for valid operand (must appear)

        // Check for leading - or !
        if(c=='-' || c=='!') { sws(Function, ++Ind); c=Function[Ind]; }
        if(c==0) { parseErrorType=PREMATURE_EOS; return Ind; }

        // Check for math function
        bool foundFunc = false;
        const FuncDefinition* fptr = FindFunction(&Function[Ind]);
        if(fptr)
        {
            Ind += fptr->nameLength;
            foundFunc = true;
        }
        else
        {
            // Check for user-defined function
            Data::VarMap_t::const_iterator fIter =
                FindVariable(&Function[Ind], FuncPtrNames);
            if(fIter != FuncPtrNames.end())
            {
                Ind += fIter->first.size();
                foundFunc = true;
            }
            else
            {
                Data::VarMap_t::const_iterator pIter =
                    FindVariable(&Function[Ind], FuncParserNames);
                if(pIter != FuncParserNames.end())
                {
                    Ind += pIter->first.size();
                    foundFunc = true;
                }
            }
        }

        if(foundFunc)
        {
            sws(Function, Ind);
            c = Function[Ind];
            if(c!='(') { parseErrorType=EXPECT_PARENTH_FUNC; return Ind; }

            long Ind2 = Ind+1;
            sws(Function, Ind2);
            if(Function[Ind2] == ')')
            {
                Ind = Ind2+1;
                sws(Function, Ind);
                c = Function[Ind];
                // Ugly, but other methods would just be uglier...
                goto CheckOperator;
            }

            functionParenthDepth.push_back(ParenthCnt+1);
        }

        // Check for opening parenthesis
        if(c=='(')
        {
            ++ParenthCnt;
            sws(Function, ++Ind);
            if(Function[Ind]==')') { parseErrorType=EMPTY_PARENTH; return Ind;}
            continue;
        }

        // Check for number
        if(isdigit(c) || (c=='.' && isdigit(Function[Ind+1])))
        {
            strtod(&Function[Ind], &Ptr);
            Ind += long(Ptr-&Function[Ind]);
            sws(Function, Ind);
            c = Function[Ind];
        }
        else
        { // Check for variable
            Data::VarMap_t::const_iterator vIter =
                FindVariable(&Function[Ind], Variables);
            if(vIter != Variables.end())
                Ind += vIter->first.size();
            else
            {
                // Check for constant
                Data::ConstMap_t::const_iterator cIter =
                    FindConstant(&Function[Ind], Constants);
                if(cIter != Constants.end())
                    Ind += cIter->first.size();
                else
                { parseErrorType=SYNTAX_ERROR; return Ind; }
            }
            sws(Function, Ind);
            c = Function[Ind];
        }

        // Check for unit
        Ind = CheckForUnit(Function, Ind);
        c = Function[Ind];

        // Check for closing parenthesis
        while(c==')')
        {
            if(functionParenthDepth.size() &&
               functionParenthDepth.back() == ParenthCnt)
                functionParenthDepth.pop_back();
            if((--ParenthCnt)<0) { parseErrorType=MISM_PARENTH; return Ind; }
            sws(Function, ++Ind);
            c=Function[Ind];
        }

    CheckOperator:
// If we get here, we have a legal operand and now a legal unit, operator or
// end of string must follow

        // Check for unit
        Ind = CheckForUnit(Function, Ind);
        c = Function[Ind];

        // Check for EOS
        if(c==0) break; // The only way to end the checking loop without error

        // Check for operator
        long opSize = 0;
        if(c == ',' && !functionParenthDepth.empty() &&
           functionParenthDepth.back() == ParenthCnt)
            opSize = 1;
        else
            opSize = IsOperator(Function+Ind);
        if(opSize == 0)
        { parseErrorType=EXPECT_OPERATOR; return Ind; }

// If we get here, we have an operand and an operator; the next loop will
// check for another operand (must appear)
        Ind += opSize;
    } // while

    // Check that all opened parentheses are also closed
    if(ParenthCnt>0) { parseErrorType=MISSING_PARENTH; return Ind; }

// The string is ok
    parseErrorType=FP_NO_ERROR;
    return -1;
}


// Compile function string to bytecode
// -----------------------------------
long pFunctionParser::Compile(const char* Function)
{
    if(data->ByteCode) { delete[] data->ByteCode; data->ByteCode=0; }
    if(data->Immed) { delete[] data->Immed; data->Immed=0; }
    if(data->Stack) { delete[] data->Stack; data->Stack=0; }

    vector<unsigned long> byteCode; byteCode.reserve(1024);
    tempByteCode = &byteCode;

    vector<PFPFLOAT> immed; immed.reserve(1024);
    tempImmed = &immed;

    data->StackSize = StackPtr = 0;

    long ind = CompileExpression(Function, 0);
    if(parseErrorType != FP_NO_ERROR) return ind;

    data->ByteCodeSize = byteCode.size();
    data->ImmedSize = immed.size();

    if(data->ByteCodeSize)
    {
        data->ByteCode = new unsigned long[data->ByteCodeSize];
        memcpy(data->ByteCode, &byteCode[0],
               sizeof(unsigned long)*data->ByteCodeSize);
    }
    if(data->ImmedSize)
    {
        data->Immed = new PFPFLOAT[data->ImmedSize];
        memcpy(data->Immed, &immed[0],
               sizeof(PFPFLOAT)*data->ImmedSize);
    }
#ifndef PFP_USE_THREAD_SAFE_EVAL
    if(data->StackSize)
        data->Stack = new PFPFLOAT[data->StackSize];
#endif

    return -1;
}


inline void pFunctionParser::AddCompiledByte(unsigned long c)
{
    tempByteCode->push_back(c);
}

inline void pFunctionParser::AddImmediate(PFPFLOAT i)
{
    tempImmed->push_back(i);
}

inline void pFunctionParser::AddFunctionOpcode(unsigned long opcode)
{
    if(data->useDegreeConversion)
        switch(opcode)
        {
          case cCos:
          case cCosh:
          case cCot:
          case cCsc:
          case cSec:
          case cSin:
          case cSinh:
          case cTan:
          case cTanh:
              AddCompiledByte(cRad);
        }

    AddCompiledByte(opcode);

    if(data->useDegreeConversion)
        switch(opcode)
        {
          case cAcos:
#ifndef NO_ASINH
          case cAcosh:
          case cAsinh:
          case cAtanh:
#endif
          case cAsin:
          case cAtan:
          case cAtan2:
              AddCompiledByte(cDeg);
        }
}

inline void pFunctionParser::incStackPtr()
{
    if(++StackPtr > data->StackSize) ++(data->StackSize);
}


// Compile if()
long pFunctionParser::CompileIf(const char* F, long ind)
{
    long ind2 = CompileExpression(F, ind, true); // condition
    sws(F, ind2);
    if(F[ind2] != ',') { parseErrorType=ILL_PARAMS_AMOUNT; return ind2; }
    AddCompiledByte(cIf);
    unsigned long curByteCodeSize = tempByteCode->size();
    AddCompiledByte(0); // Jump index; to be set later
    AddCompiledByte(0); // Immed jump index; to be set later

    --StackPtr;

    ind2 = CompileExpression(F, ind2+1, true); // then
    sws(F, ind2);
    if(F[ind2] != ',') { parseErrorType=ILL_PARAMS_AMOUNT; return ind2; }
    AddCompiledByte(cJump);
    unsigned long curByteCodeSize2 = tempByteCode->size();
    unsigned long curImmedSize2 = tempImmed->size();
    AddCompiledByte(0); // Jump index; to be set later
    AddCompiledByte(0); // Immed jump index; to be set later

    --StackPtr;

    ind2 = CompileExpression(F, ind2+1, true); // else
    sws(F, ind2);
    if(F[ind2] != ')') { parseErrorType=ILL_PARAMS_AMOUNT; return ind2; }

    // Set jump indices
    (*tempByteCode)[curByteCodeSize] = curByteCodeSize2+1;
    (*tempByteCode)[curByteCodeSize+1] = curImmedSize2;
    (*tempByteCode)[curByteCodeSize2] = tempByteCode->size()-1;
    (*tempByteCode)[curByteCodeSize2+1] = tempImmed->size();

    return ind2+1;
}

long pFunctionParser::CompileFunctionParams(const char* F, long ind,
                                          unsigned long requiredParams)
{
    long ind2 = ind;
    if(requiredParams > 0)
    {
        unsigned long curStackPtr = StackPtr;
        ind2 = CompileExpression(F, ind);

        if(StackPtr != curStackPtr+requiredParams)
        { parseErrorType=ILL_PARAMS_AMOUNT; return ind; }

        StackPtr -= requiredParams - 1;
    }
    else
    {
        incStackPtr();
    }

    sws(F, ind2);
    return ind2+1; // F[ind2] is ')'
}

// Compiles element
long pFunctionParser::CompileElement(const char* F, long ind)
{
    sws(F, ind);
    char c = F[ind];

    if(c == '(')
    {
        ind = CompileExpression(F, ind+1);
        sws(F, ind);
        return ind+1; // F[ind] is ')'
    }

    if(isdigit(c) || c=='.' /*|| c=='-'*/) // Number
    {
        const char* startPtr = &F[ind];
        char* endPtr;
        PFPFLOAT val = strtod(startPtr, &endPtr);
        AddImmediate(val);
        AddCompiledByte(cImmed);
        incStackPtr();
        return ind+(endPtr-startPtr);
    }

    if(isalpha(c) || c == '_') // Function, variable or constant
    {
        const FuncDefinition* func = FindFunction(F+ind);
        if(func) // is function
        {
            long ind2 = ind + func->nameLength;
            sws(F, ind2); // F[ind2] is '('
            if(strcmp(func->name, "if") == 0) // "if" is a special case
            {
                return CompileIf(F, ind2+1);
            }

#ifndef DISABLE_EVAL
            unsigned long requiredParams =
                strcmp(func->name, "eval") == 0 ?
                data->Variables.size() : func->params;
#else
            unsigned long requiredParams = func->params;
#endif
            ind2 = CompileFunctionParams(F, ind2+1, requiredParams);
            AddFunctionOpcode(func->opcode);
            return ind2; // F[ind2-1] is ')'
        }

        Data::VarMap_t::const_iterator vIter =
            FindVariable(F+ind, data->Variables);
        if(vIter != data->Variables.end()) // is variable
        {
            AddCompiledByte(vIter->second);
            incStackPtr();
            return ind + vIter->first.size();
        }

        Data::ConstMap_t::const_iterator cIter =
            FindConstant(F+ind, data->Constants);
        if(cIter != data->Constants.end()) // is constant
        {
            AddImmediate(cIter->second);
            AddCompiledByte(cImmed);
            incStackPtr();
            return ind + cIter->first.size();
        }

        Data::VarMap_t::const_iterator fIter =
            FindVariable(F+ind, data->FuncPtrNames);
        if(fIter != data->FuncPtrNames.end()) // is user-defined func pointer
        {
            unsigned long index = fIter->second;

            long ind2 = ind + fIter->first.length();
            sws(F, ind2); // F[ind2] is '('

            ind2 = CompileFunctionParams(F, ind2+1,
                                         data->FuncPtrs[index].params);

            AddCompiledByte(cFCall);
            AddCompiledByte(index);
            return ind2;
        }

        Data::VarMap_t::const_iterator pIter =
            FindVariable(F+ind, data->FuncParserNames);
        if(pIter != data->FuncParserNames.end()) // is user-defined func parser
        {
            unsigned long index = pIter->second;

            long ind2 = ind + pIter->first.length();
            sws(F, ind2); // F[ind2] is '('

            ind2 = CompileFunctionParams
                (F, ind2+1, data->FuncParsers[index]->data->varAmount);

            AddCompiledByte(cPCall);
            AddCompiledByte(index);
            return ind2;
        }
    }

    parseErrorType = UNEXPECTED_ERROR;
    return ind;
}

// Compiles a unit factor possibly appearing after an element
long pFunctionParser::CompilePossibleUnit(const char* F, long ind)
{
    if(isalpha(F[ind]) || F[ind] == '_')
    {
        // If the syntax checker is bug-free, this should always work:
        Data::ConstMap_t::const_iterator uIter =
            FindConstant(F+ind, data->Units);

        AddImmediate(uIter->second);
        AddCompiledByte(cImmed);
        incStackPtr();
        AddCompiledByte(cMul);
        --StackPtr;
        ind += uIter->first.size();
        sws(F, ind);
    }
    return ind;
}

// Compiles '^'
long pFunctionParser::CompilePow(const char* F, long ind)
{
    long ind2 = CompileElement(F, ind);
    if(parseErrorType != FP_NO_ERROR) return ind2;
    sws(F, ind2);
    ind2 = CompilePossibleUnit(F, ind2);

    while(F[ind2] == '^')
    {
        ind2 = CompileUnaryMinus(F, ind2+1);
        if(parseErrorType != FP_NO_ERROR) return ind2;
        sws(F, ind2);
        AddCompiledByte(cPow);
        --StackPtr;
    }

    return ind2;
}

// Compiles unary '-'
long pFunctionParser::CompileUnaryMinus(const char* F, long ind)
{
    sws(F, ind);
    if(F[ind] == '-' || F[ind] == '!')
    {
        long ind2 = ind+1;
        sws(F, ind2);
        ind2 = CompilePow(F, ind2);
        if(parseErrorType != FP_NO_ERROR) return ind2;
        sws(F, ind2);

        // if we are negating a constant, negate the constant itself:
        if(F[ind] == '-' && tempByteCode->back() == cImmed)
            tempImmed->back() = -tempImmed->back();

        // if we are negating a negation, we can remove both:
        else if((F[ind] == '-' && tempByteCode->back() == cNeg))
            tempByteCode->pop_back();

        else
            AddCompiledByte(F[ind] == '-' ? cNeg : cNot);

        return ind2;
    }

    long ind2 = CompilePow(F, ind);
    if(parseErrorType != FP_NO_ERROR) return ind2;
    sws(F, ind2);
    return ind2;
}

// Compiles '*', '/' and '%'
long pFunctionParser::CompileMult(const char* F, long ind)
{
    long ind2 = CompileUnaryMinus(F, ind);
    if(parseErrorType != FP_NO_ERROR) return ind2;
    sws(F, ind2);
    char op;

    while((op = F[ind2]) == '*' || op == '/' || op == '%')
    {
        ind2 = CompileUnaryMinus(F, ind2+1);
        if(parseErrorType != FP_NO_ERROR) return ind2;
        sws(F, ind2);
        switch(op)
        {
          case '*': AddCompiledByte(cMul); break;
          case '/': AddCompiledByte(cDiv); break;
          case '%': AddCompiledByte(cMod); break;
        }
        --StackPtr;
    }

    return ind2;
}

// Compiles '+' and '-'
long pFunctionParser::CompileAddition(const char* F, long ind)
{
    long ind2 = CompileMult(F, ind);
    if(parseErrorType != FP_NO_ERROR) return ind2;
    sws(F, ind2);
    char op;

    while((op = F[ind2]) == '+' || op == '-')
    {
        ind2 = CompileMult(F, ind2+1);
        if(parseErrorType != FP_NO_ERROR) return ind2;
        sws(F, ind2);
        AddCompiledByte(op=='+' ? cAdd : cSub);
        --StackPtr;
    }

    return ind2;
}

// Compiles '=', '<' and '>'
long pFunctionParser::CompileComparison(const char* F, long ind)
{
    long ind2 = CompileAddition(F, ind);
    if(parseErrorType != FP_NO_ERROR) return ind2;
    sws(F, ind2);
    char op;

    while((op = F[ind2]) == '=' || op == '<' || op == '>' || op == '!')
    {
        long opSize = (F[ind2+1] == '=' ? 2 : 1);
        ind2 = CompileAddition(F, ind2+opSize);
        if(parseErrorType != FP_NO_ERROR) return ind2;
        sws(F, ind2);
        switch(op)
        {
          case '=':
              AddCompiledByte(cEqual); break;
          case '<':
              AddCompiledByte(opSize == 1 ? cLess : cLessOrEq); break;
          case '>':
              AddCompiledByte(opSize == 1 ? cGreater : cGreaterOrEq); break;
          case '!':
              AddCompiledByte(cNEqual); break;
        }
        --StackPtr;
    }

    return ind2;
}

// Compiles '&'
long pFunctionParser::CompileAnd(const char* F, long ind)
{
    long ind2 = CompileComparison(F, ind);
    if(parseErrorType != FP_NO_ERROR) return ind2;
    sws(F, ind2);

    while(F[ind2] == '&')
    {
        ind2 = CompileComparison(F, ind2+1);
        if(parseErrorType != FP_NO_ERROR) return ind2;
        sws(F, ind2);
        AddCompiledByte(cAnd);
        --StackPtr;
    }

    return ind2;
}

// Compiles '|'
long pFunctionParser::CompileOr(const char* F, long ind)
{
    long ind2 = CompileAnd(F, ind);
    if(parseErrorType != FP_NO_ERROR) return ind2;
    sws(F, ind2);

    while(F[ind2] == '|')
    {
        ind2 = CompileAnd(F, ind2+1);
        if(parseErrorType != FP_NO_ERROR) return ind2;
        sws(F, ind2);
        AddCompiledByte(cOr);
        --StackPtr;
    }

    return ind2;
}

// Compiles ','
long pFunctionParser::CompileExpression(const char* F, long ind, bool stopAtComma)
{
    long ind2 = CompileOr(F, ind);
    if(parseErrorType != FP_NO_ERROR) return ind2;
    sws(F, ind2);

    if(stopAtComma) return ind2;

    while(F[ind2] == ',')
    {
        ind2 = CompileOr(F, ind2+1);
        if(parseErrorType != FP_NO_ERROR) return ind2;
        sws(F, ind2);
    }

    return ind2;
}


// Return parse error message
// --------------------------
const char* pFunctionParser::ErrorMsg() const
{
    if(parseErrorType != FP_NO_ERROR) return ParseErrorMessage[parseErrorType];
    return 0;
}

//---------------------------------------------------------------------------
// Function evaluation
//---------------------------------------------------------------------------
//===========================================================================
namespace
{
    inline long doubleToInt(PFPFLOAT d)
    {
        return d<0.0L ? -long((-d)+0.5L) : long(d+0.5L);
    }

    inline PFPFLOAT Min(PFPFLOAT d1, PFPFLOAT d2)
    {
        return d1<d2 ? d1 : d2;
    }
    inline PFPFLOAT Max(PFPFLOAT d1, PFPFLOAT d2)
    {
        return d1>d2 ? d1 : d2;
    }


    inline PFPFLOAT DegreesToRadians(PFPFLOAT degrees)
    {
        return degrees*(PMY_PI/180.0L);
    }
    inline PFPFLOAT RadiansToDegrees(PFPFLOAT radians)
    {
        return radians*(180.0L/PMY_PI);
    }
}

PFPFLOAT pFunctionParser::Eval(const PFPFLOAT* Vars)
{
    const unsigned long* const ByteCode = data->ByteCode;
    const PFPFLOAT* const Immed = data->Immed;
    const unsigned long ByteCodeSize = data->ByteCodeSize;
    unsigned long IP, DP=0;
    long SP=-1;

#ifdef PFP_USE_THREAD_SAFE_EVAL
#ifdef PFP_USE_THREAD_SAFE_EVAL_WITH_ALLOCA
    PFPFLOAT* const Stack = (PFPFLOAT*)alloca(data->StackSize*sizeof(PFPFLOAT));
#else
    std::vector<PFPFLOAT> Stack(data->StackSize);
#endif
#else
    PFPFLOAT* const Stack = data->Stack;
#endif

    for(IP=0; IP<ByteCodeSize; ++IP)
    {
        switch(ByteCode[IP])
        {
// Functions:
          case   cAbs: Stack[SP] = fabsl(Stack[SP]); break;
          case  cAcos: if(Stack[SP] < -1.0L || Stack[SP] > 1.0L)
                       { evalErrorType=4; return 0.0L; }
                       Stack[SP] = acosl(Stack[SP]); break;
#ifndef NO_ASINH
          #if (defined(WINDOWS) || defined(WIN32) || defined(WIN64))
          case cAcosh: Stack[SP] = (PFPFLOAT) acosh(Stack[SP]); break;
          #else
          case cAcosh: Stack[SP] = acoshl(Stack[SP]); break;
          #endif
#endif
          case  cAsin: if(Stack[SP] < -1.0L || Stack[SP] > 1.0L)
                       { evalErrorType=4; return 0.0L; }
                       Stack[SP] = asinl(Stack[SP]); break;
#ifndef NO_ASINH
          #if (defined(WINDOWS) || defined(WIN32) || defined(WIN64))
          case cAsinh: Stack[SP] = (PFPFLOAT) asinh(Stack[SP]); break;
          #else
          case cAsinh: Stack[SP] = asinhl(Stack[SP]); break;
          #endif
#endif
          case  cAtan: Stack[SP] = atanl(Stack[SP]); break;
          case cAtan2: Stack[SP-1] = atan2l(Stack[SP-1], Stack[SP]);
                       --SP; break;
#ifndef NO_ASINH
          #if (defined(WINDOWS) || defined(WIN32) || defined(WIN64))
          case cAtanh: Stack[SP] = (PFPFLOAT) atanh(Stack[SP]); break;
          #else
          case cAtanh: Stack[SP] = atanhl(Stack[SP]); break;
          #endif
#endif
          case  cCeil: Stack[SP] = ceill(Stack[SP]); break;
          case   cCos: Stack[SP] = cosl(Stack[SP]); break;
          case  cCosh: Stack[SP] = coshl(Stack[SP]); break;

          case   cCot:
              {
                  PFPFLOAT t = tanl(Stack[SP]);
                  if(t == 0.0L) { evalErrorType=1; return 0.0L; }
                  Stack[SP] = 1.0L/t; break;
              }
          case   cCsc:
              {
                  PFPFLOAT s = sinl(Stack[SP]);
                  if(s == 0.0L) { evalErrorType=1; return 0.0L; }
                  Stack[SP] = 1.0L/s; break;
              }


#ifndef DISABLE_EVAL
          case  cEval:
              {
                  PFPFLOAT retVal = 0.0L;
                  if(evalRecursionLevel == PEVAL_MAX_REC_LEVEL)
                  {
                      evalErrorType = 5;
                  }
                  else
                  {
#ifndef PFP_USE_THREAD_SAFE_EVAL
                      data->Stack = new PFPFLOAT[data->StackSize];
#endif
                      ++evalRecursionLevel;
                      retVal = Eval(&Stack[SP-data->varAmount+1]);
                      --evalRecursionLevel;
#ifndef PFP_USE_THREAD_SAFE_EVAL
                      delete[] data->Stack;
                      data->Stack = Stack;
#endif
                  }
                  SP -= data->varAmount-1;
                  Stack[SP] = retVal;
                  break;
              }
#endif

          case   cExp: Stack[SP] = exp(Stack[SP]); break;
          case cFloor: Stack[SP] = floor(Stack[SP]); break;

          case    cIf:
              {
                  unsigned long jumpAddr = ByteCode[++IP];
                  unsigned long immedAddr = ByteCode[++IP];
                  if(doubleToInt(Stack[SP]) == 0)
                  {
                      IP = jumpAddr;
                      DP = immedAddr;
                  }
                  --SP; break;
              }

          case   cInt: Stack[SP] = floorl(Stack[SP]+0.5L); break;
          case   cLog: if(Stack[SP] <= 0.0L) { evalErrorType=3; return 0.0L; }
                       Stack[SP] = logl(Stack[SP]); break;
          case cLog10: if(Stack[SP] <= 0.0L) { evalErrorType=3; return 0.0L; }
                       Stack[SP] = log10l(Stack[SP]); break;
          case   cMax: Stack[SP-1] = Max(Stack[SP-1], Stack[SP]);
                       --SP; break;
          case   cMin: Stack[SP-1] = Min(Stack[SP-1], Stack[SP]);
                       --SP; break;
          case   cSec:
              {
                  PFPFLOAT c = cosl(Stack[SP]);
                  if(c == 0.0L) { evalErrorType=1; return 0.0L; }
                  Stack[SP] = 1.0L/c; break;
              }
          case   cSin: Stack[SP] = sinl(Stack[SP]); break;
          case  cSinh: Stack[SP] = sinhl(Stack[SP]); break;
          case  cSqrt: if(Stack[SP] < 0.0L) { evalErrorType=2; return 0.0L; }
                       Stack[SP] = sqrtl(Stack[SP]); break;
          case   cTan: Stack[SP] = tanl(Stack[SP]); break;
          case  cTanh: Stack[SP] = tanhl(Stack[SP]); break;


// Misc:
          case cImmed: Stack[++SP] = Immed[DP++]; break;
          case  cJump: DP = ByteCode[IP+2];
                       IP = ByteCode[IP+1];
                       break;

// Operators:
          case   cNeg: Stack[SP] = -Stack[SP]; break;
          case   cAdd: Stack[SP-1] += Stack[SP]; --SP; break;
          case   cSub: Stack[SP-1] -= Stack[SP]; --SP; break;
          case   cMul: Stack[SP-1] *= Stack[SP]; --SP; break;
          case   cDiv: if(Stack[SP] == 0.0L) { evalErrorType=1; return 0.0L; }
                       Stack[SP-1] /= Stack[SP]; --SP; break;
          case   cMod: if(Stack[SP] == 0.0L) { evalErrorType=1; return 0.0L; }
                       Stack[SP-1] = fmodl(Stack[SP-1], Stack[SP]);
                       --SP; break;
          //case   cPow: Stack[SP-1] = powl(Stack[SP-1], Stack[SP]);
          case   cPow: if(Stack[SP]==2.0L)
                          Stack[SP-1] *= Stack[SP-1];
                       else if(Stack[SP]==3.0L)
                          Stack[SP-1] *= Stack[SP-1] * Stack[SP-1];
                       else
                          Stack[SP-1] = powf(Stack[SP-1], Stack[SP]);
                       --SP; break;

#ifdef FP_EPSILON
          case cEqual: Stack[SP-1] =
                           (fabs(Stack[SP-1]-Stack[SP]) <= FP_EPSILON);
                       --SP; break;
          case cNEqual: Stack[SP-1] =
                            (fabs(Stack[SP-1] - Stack[SP]) >= FP_EPSILON);
                       --SP; break;
          case  cLess: Stack[SP-1] = (Stack[SP-1] < Stack[SP]-FP_EPSILON);
                       --SP; break;
          case  cLessOrEq: Stack[SP-1] = (Stack[SP-1] <= Stack[SP]+FP_EPSILON);
                       --SP; break;
          case cGreater: Stack[SP-1] = (Stack[SP-1]-FP_EPSILON > Stack[SP]);
                         --SP; break;
          case cGreaterOrEq: Stack[SP-1] =
                                 (Stack[SP-1]+FP_EPSILON >= Stack[SP]);
                         --SP; break;
#else
          case cEqual: Stack[SP-1] = (Stack[SP-1] == Stack[SP]);
                       --SP; break;
          case cNEqual: Stack[SP-1] = (Stack[SP-1] != Stack[SP]);
                       --SP; break;
          case  cLess: Stack[SP-1] = (Stack[SP-1] < Stack[SP]);
                       --SP; break;
          case  cLessOrEq: Stack[SP-1] = (Stack[SP-1] <= Stack[SP]);
                       --SP; break;
          case cGreater: Stack[SP-1] = (Stack[SP-1] > Stack[SP]);
                         --SP; break;
          case cGreaterOrEq: Stack[SP-1] = (Stack[SP-1] >= Stack[SP]);
                         --SP; break;
#endif

          case   cAnd: Stack[SP-1] =
                           (doubleToInt(Stack[SP-1]) &&
                            doubleToInt(Stack[SP]));
                       --SP; break;
          case    cOr: Stack[SP-1] =
                           (doubleToInt(Stack[SP-1]) ||
                            doubleToInt(Stack[SP]));
                       --SP; break;
          case   cNot: Stack[SP] = !doubleToInt(Stack[SP]); break;

// Degrees-radians conversion:
          case   cDeg: Stack[SP] = RadiansToDegrees(Stack[SP]); break;
          case   cRad: Stack[SP] = DegreesToRadians(Stack[SP]); break;

// User-defined function calls:
          case cFCall:
              {
                  unsigned long index = ByteCode[++IP];
                  unsigned long params = data->FuncPtrs[index].params;
                  PFPFLOAT retVal =
                      data->FuncPtrs[index].ptr(&Stack[SP-params+1]);
                  SP -= long(params)-1;
                  Stack[SP] = retVal;
                  break;
              }

          case cPCall:
              {
                  unsigned long index = ByteCode[++IP];
                  unsigned long params = data->FuncParsers[index]->data->varAmount;
                  PFPFLOAT retVal =
                      data->FuncParsers[index]->Eval(&Stack[SP-params+1]);
                  SP -= long(params)-1;
                  Stack[SP] = retVal;
                  break;
              }


#ifdef SUPPORT_OPTIMIZER
          case   cVar: break; // Paranoia. These should never exist
          case   cDup: Stack[SP+1] = Stack[SP]; ++SP; break;
          case   cInv:
              if(Stack[SP] == 0.0L) { evalErrorType=1; return 0.0L; }
              Stack[SP] = 1.0L/Stack[SP];
              break;
#endif

// Variables:
          default:
              Stack[++SP] = Vars[ByteCode[IP]-VarBegin];
        }
    }

    evalErrorType=0;
    return Stack[SP];
}


#ifdef FUNCTIONPARSER_SUPPORT_DEBUG_OUTPUT
#include <iomanip>
namespace
{
    inline void printHex(std::ostream& dest, unsigned long n)
    {
        dest.width(8); dest.fill('0'); std::hex(dest); //uppercase(dest);
        dest << n;
    }
}

void pFunctionParser::PrintByteCode(std::ostream& dest) const
{
    dest << "Size of stack: " << data->StackSize << "\n";

    const unsigned long* const ByteCode = data->ByteCode;
    const PFPFLOAT* const Immed = data->Immed;

    for(unsigned long IP=0, DP=0; IP<data->ByteCodeSize; ++IP)
    {
        printHex(dest, IP);
        dest << ": ";

        unsigned long opcode = ByteCode[IP];

        switch(opcode)
        {
          case cIf:
              dest << "jz\t";
              printHex(dest, ByteCode[IP+1]+1);
              dest << endl;
              IP += 2;
              break;

          case cJump:
              dest << "jump\t";
              printHex(dest, ByteCode[IP+1]+1);
              dest << endl;
              IP += 2;
              break;
          case cImmed:
              dest.precision(10);
              dest << "push\t" << Immed[DP++] << endl;
              break;

          case cFCall:
              {
                  unsigned long index = ByteCode[++IP];
                  Data::VarMap_t::const_iterator iter =
                      data->FuncPtrNames.begin();
                  while(iter->second != index) ++iter;
                  dest << "fcall\t" << iter->first
                       << " (" << data->FuncPtrs[index].params << ")" << endl;
                  break;
              }

          case cPCall:
              {
                  unsigned long index = ByteCode[++IP];
                  Data::VarMap_t::const_iterator iter =
                      data->FuncParserNames.begin();
                  while(iter->second != index) ++iter;
                  dest << "pcall\t" << iter->first
                       << " (" << data->FuncParsers[index]->data->varAmount
                       << ")" << endl;
                  break;
              }

          default:
              if(opcode < VarBegin)
              {
                  string n;
                  unsigned long params = 1;
                  switch(opcode)
                  {
                    case cNeg: n = "neg"; break;
                    case cAdd: n = "add"; break;
                    case cSub: n = "sub"; break;
                    case cMul: n = "mul"; break;
                    case cDiv: n = "div"; break;
                    case cMod: n = "mod"; break;
                    case cPow: n = "pow"; break;
                    case cEqual: n = "eq"; break;
                    case cNEqual: n = "neq"; break;
                    case cLess: n = "lt"; break;
                    case cLessOrEq: n = "le"; break;
                    case cGreater: n = "gt"; break;
                    case cGreaterOrEq: n = "ge"; break;
                    case cAnd: n = "and"; break;
                    case cOr: n = "or"; break;
                    case cNot: n = "not"; break;
                    case cDeg: n = "deg"; break;
                    case cRad: n = "rad"; break;

#ifndef DISABLE_EVAL
                    case cEval: n = "call\t0"; break;
#endif

#ifdef SUPPORT_OPTIMIZER
                    case cVar: n = "(var)"; break;
                    case cDup: n = "dup"; break;
                    case cInv: n = "inv"; break;
#endif

                    default:
                        n = Functions[opcode-cAbs].name;
                        params = Functions[opcode-cAbs].params;
                  }
                  dest << n;
                  if(params != 1) dest << " (" << params << ")";
                  dest << endl;
              }
              else
              {
                  dest << "push\tVar" << opcode-VarBegin << endl;
              }
        }
    }
}
#endif


#ifndef SUPPORT_OPTIMIZER
void pFunctionParser::MakeTree(void *) const {}
void pFunctionParser::Optimize()
{
    // Do nothing if no optimizations are supported.
}
#endif
