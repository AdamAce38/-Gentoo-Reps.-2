/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
 ** *************************************************************************/

#ifndef _TSC_H_
#define _TSC_H_


/** Taming the monster a little bit */
typedef unsigned long long TSC_UINT;


/** *************************************************************************
 ** CPU-timestamp counters implemented for: x86, x86_64, PowerPC and Mips
 **
 ** Calibrates itself with an correction factor when instanciated
 ** Corrects negative resuls which could occure through optimizing/caching
 ** For maximum precision the x86-stuff serializes instructions additionally
 **
 ** CPU's, OS's and compilers proofed so far:
 **
 ** x86_64 and *nix              :  gcc 4.5.1
 ** x86 and *nix                 :  gcc 4.0.2
 ** x86 and Windows XP           :  MinGW 3.4.2
 ** x86_64 and Windows Vista 32  :  MSVC 2008 Version 9.0
 **
 ** No idea about Mips/PowerPC. But surely a minimum of some 35.000 copies are
 ** out there and there never was any complaint from distributors/users :-)
 ** *************************************************************************/
class TSC {

public:
	/** Automatic correction and start on every instantiation */
	TSC() { calc_min_ovh(); start(); }

	/** Start/stop functions */
	void start() { tsc=fetch(); }
	TSC_UINT stop() { if((tsc=fetch()-tsc)>ovh) return tsc-=ovh; return tsc=0; }

	/** Return correction-cycles for conveniance */
	TSC_UINT min_ovh() { return ovh; }

private:
	TSC_UINT tsc, ovh;
	inline TSC_UINT fetch();

	/** Find minimum tsc-overhead */
	void calc_min_ovh() {
		ovh = 1<<16;
		for(long i=0; i<8; ++i) {
			tsc=fetch(); tsc=fetch()-tsc; if(tsc<ovh) ovh=tsc;
			tsc=fetch(); tsc=fetch()-tsc; if(tsc<ovh) ovh=tsc;
			tsc=fetch(); tsc=fetch()-tsc; if(tsc<ovh) ovh=tsc;
			tsc=fetch(); tsc=fetch()-tsc; if(tsc<ovh) ovh=tsc;
		}
		if(ovh==(1<<16)) ovh=0;
	}
};


/** Hardware dependent CPU-cycle-counters
 ** *************************************************************************/

/** x86 or x86_64 CPU's */
#if (defined(__i386__) || defined(__x86_64__) || defined(WINDOWS) || defined(WIN32) || defined(WIN64))
inline TSC_UINT TSC::fetch() {

	/** GCC on any x86 system */
	#if (defined(__GNUC__))

	unsigned int hi, lo;
	__asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
	return ((TSC_UINT)hi << 32) | lo;

	/** Else compiler must be MSVC on any x86 system */
	#else

	unsigned int res[2];
	__asm {
		xor eax, eax               // Null eax for cpuid call
		cpuid                      // Serialize
		rdtsc                      // Read TSC
		mov dword ptr res, eax     // Store low dword in res[0]
		mov dword ptr res+4, edx   // Store high dword in res[1]
		xor eax, eax               // Null eax
		cpuid                      // Serialize again
	}
	return ((TSC_UINT)res[1] << 32) | (res[0]);

	#endif
}


/** Check for Mips CPU's. Compiler = GCC */
#elif (defined(__mips__) && (defined(MIPSEL) || defined (__MIPSEL__)))
inline TSC_UINT TSC::fetch() {
	TSC_UINT tmp;
	__asm__ __volatile__("mfc0 %0,$9; nop" : "=r" (tmp));
	return tmp;
}


/** Check for PowerPC CPU's. Compiler = GCC */
#elif defined(__powerpc__)
inline TSC_UINT TSC::fetch(void) {
	unsigned int high, low, tmp;
	__asm__ volatile(
		"loop:           \n\t"
		"mftbu   %0      \n\t"
		"mftb    %1      \n\t"
		"mftbu   %2      \n\t"
		"cmpw    %2,%0   \n\t"
		"bne     loop    \n\t"
		: "=r"(high), "=r"(low), "=r"(tmp)
	);
	return ((TSC_UINT)high << 32) | low;
}
#endif


/** _TSC_H_ */
#endif
