/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _FILEIO_H_
#define _FILEIO_H_

#include <QString>
#include <QFile>
#include <QTextStream>
#include <iostream>

#include "property.h"
#include "speedit.h"
#include "funedit.h"
#include "pinterface.h"
#include "paths.h"
#include "version.h"
#include "debug.h"


/** What happens: load/save are called from the maiWindow-widget only and both
 ** return error codes. All error messages are evaluated in maiWindow, where
 ** the parser sanity is checked too
 **
 ** Return codes for load:
 ** 0 = success
 ** 1 = "Error loading file" unspecified
 ** 2 = "Zhu3D file is too old or not valid"
 ** 3 = "XML parser error"
 **
 ** Return codes for save are interpreted as booleans:
 ** 0 = failed
 ** 1 = success
****************************************************************************/

/** Minimalistic class */
class zhuFile {

public:
	zhuFile() {};
	~zhuFile() {};

	int load(const QString &fileName);
	int save(const QString &fileName);

private:
	int version;
	int getVersion(const QString &header);
	int  load400(const QString &fileName);
};


/** _FILEIO_H_ */
#endif
