/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _DEMEDITOR_H_
#define _DEMEDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QPushButton>
#include <QGridLayout>
#include <QDir>
#include <QFileInfo>
#include <QSettings>
#include <QTimer>

#include "glwidget.h"
#include "version.h"
#include "debug.h"


/** Demo mode */
class demWidget : public QWidget {

Q_OBJECT

public:
	demWidget(QWidget *parent=0);
	~demWidget() {}
	void initDirList();    // Used from mainwindow & diredit
protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

signals:
	void slideshowOn(bool);

private slots:
	void slidesSlot();
	void backwardSlot();
	void forwardSlot();

private:
	QFileInfoList list;
	QPushButton *slides;
	QPushButton *backward;
	QPushButton *forward;
	int curListPos;
	bool listOk;

	/** Timer stuff */
	QTimer *demTimer;
	bool timerMode;

	/** Settings */
	void reTranslate();
	void readSettings();
	void writeSettings();
};

/** _DEMEDITOR_H_ */
#endif
