/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _LIGHTEDITOR_H_
#define _LIGHTEDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>

#include "ui_ligedit.h"
#include "property.h"
#include "version.h"
#include "debug.h"


/** Light editor */
class ligWidget : public QWidget, private Ui::ligUI {

Q_OBJECT

public:
	ligWidget(QWidget *parent=0);
	~ligWidget() {}

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

public slots:
	void updLigWid();    // Update whole light widget
	void updLigAmb();    // When locked, update ambient section only
	void updLigDif();    // When locked, update diffuse section only
	void updLigSpe();    // When locked, update specular section only

private:
	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _LIGHTEDITOR_H_ */
#endif
