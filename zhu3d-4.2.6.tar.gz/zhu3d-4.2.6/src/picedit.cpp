/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "picedit.h"
#include "paths.h"


/** Constructor */
picWidget::picWidget(QWidget *parent) : QWidget(parent) {

	/** Set up entire editor */
	Ui_picUI::setupUi(this);
	setMinimumSize(340, 80);
	setWindowTitle(tr("Picture"));
	readSettings();
	locked->setIcon(QPixmap(QString(":/images/locked.png")));

	/** Current OpenGL-Window-size */
	pic.xDim=actWidth;
	pic.yDim=actHeight;

	/** Update remembered values */
	qual->setValue(pic.quality);
	dpi->setValue(pic.dpi);
	switchBox();

	/** Avoid painful recursions */
	xset=yset=true;	

	/** Connections */
	connect(xDim, SIGNAL(valueChanged(int)), this, SLOT(xDimSlot(int)));
	connect(yDim, SIGNAL(valueChanged(int)), this, SLOT(yDimSlot(int)));
	connect(qual, SIGNAL(valueChanged(int)), this, SLOT(qualSlot(int)));
	connect(dpi,  SIGNAL(valueChanged(int)), this, SLOT(dpiSlot(int)));
	connect(locked, SIGNAL(clicked()), this, SLOT(picXYLocked()));
	connect(pngFmt, SIGNAL(clicked()), this, SLOT(pngSlot()));
	connect(jpgFmt, SIGNAL(clicked()), this, SLOT(jpgSlot()));
	connect(pdfFmt, SIGNAL(clicked()), this, SLOT(pdfSlot()));
	connect(psFmt,  SIGNAL(clicked()), this, SLOT(psSlot()));
}


/** Swich en-disabled checkboxes */
void picWidget::switchBox() {
	switch(pic.fmt) {
		case PNG:
				pngFmt->setChecked(true);
				qual->setEnabled(true);
				dpi->setEnabled(false);
				break;
		case JPG:
				jpgFmt->setChecked(true);
				qual->setEnabled(true);
				dpi->setEnabled(false);
				break;
		case PDF:
				pdfFmt->setChecked(true);
				qual->setEnabled(false);
				dpi->setEnabled(false);
				break;
		case PS:
				psFmt->setChecked(true);
				qual->setEnabled(false);
				dpi->setEnabled(true);
				break;
	}
}


/** *************************************************************************
 ** SET DIMENSIONS
****************************************************************************/
void picWidget::xDimSlot(const int xVal) {
	const float rel=actWidth/(float)actHeight;

	pic.xDim=xVal;
	if(pic.locXY && xset) {
		pic.yDim=(int)((float)pic.xDim/rel);
		yset=false;
		yDim->setValue(pic.yDim);
	}
	yset=true;
}

void picWidget::yDimSlot(const int yVal) {
	const float rel=actWidth/(float)actHeight;

	pic.yDim=yVal;
	if(pic.locXY && yset) {
		pic.xDim=(int)((float)pic.yDim*rel);
		xset=false;
		xDim->setValue(pic.xDim);
	}
	xset=true;
}


/** *************************************************************************
 ** UPDATE SLIDER-VALUES IN PIC-DIM-EDITOR
****************************************************************************/
void picWidget::updPicWid() {

	/** Update window */
	xDim->setValue(pic.xDim=actWidth);
	yDim->setValue(pic.yDim=actHeight);
	if(pic.locXY)
		locked->setIcon(QPixmap(QString(":/images/lock.png")));
	else
		locked->setIcon(QPixmap(QString(":/images/unlock.png")));
	qual->setValue(pic.quality);
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void picWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_picUI::retranslateUi(this);
		setWindowTitle(tr("Picture"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void picWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void picWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("PicWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("PicWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		pic.fmt = settings.value("PicFormat").toInt();
		pic.quality = settings.value("Quality").toInt();
		pic.dpi = settings.value("DPI").toInt();
		resize(size);
		move(pos);	
	}
	else {
		resize(QSize(430, 110));
		move(QPoint(200, 610));
	}
}

void picWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("PicWindowPos", pos());
	settings.setValue("PicWindowSize", size());
	settings.setValue("PicFormat", (int) pic.fmt);
	settings.setValue("Quality", (int) pic.quality);
	settings.setValue("DPI", (int) pic.dpi);
}
