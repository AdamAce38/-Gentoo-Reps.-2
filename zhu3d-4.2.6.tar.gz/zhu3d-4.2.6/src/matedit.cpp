/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "matedit.h"
#include "glwidget.h"


/** Extern globals */
extern OGLWidget  *oglWid;


/** Constructor */
matWidget::matWidget(QWidget *parent) : QWidget(parent) {

	/** Set up light-editor */
	Ui_matUI::setupUi(this);
	setMinimumSize(195, 410);
	setWindowTitle(tr("Surfaces"));
	readSettings();

	/** Edit material number */
	connect(edit0, SIGNAL(clicked()), oglWid, SLOT(ediMat0()));
	connect(edit1, SIGNAL(clicked()), oglWid, SLOT(ediMat1()));
	connect(edit2, SIGNAL(clicked()), oglWid, SLOT(ediMat2()));
	connect(edit3, SIGNAL(clicked()), oglWid, SLOT(ediMat3()));

	/** Ambient material */
	connect(MAR, SIGNAL(valueChanged(int)), oglWid, SLOT(mared(int)));
	connect(MAG, SIGNAL(valueChanged(int)), oglWid, SLOT(magreen(int)));
	connect(MAB, SIGNAL(valueChanged(int)), oglWid, SLOT(mablue(int)));
	connect(MAA, SIGNAL(valueChanged(int)), oglWid, SLOT(maalpha(int)));

	/** Diffuse material */
	connect(MDR, SIGNAL(valueChanged(int)), oglWid, SLOT(mdred(int)));
	connect(MDG, SIGNAL(valueChanged(int)), oglWid, SLOT(mdgreen(int)));
	connect(MDB, SIGNAL(valueChanged(int)), oglWid, SLOT(mdblue(int)));
	connect(MDA, SIGNAL(valueChanged(int)), oglWid, SLOT(mdalpha(int)));

	/** Specular material */
	connect(MSR, SIGNAL(valueChanged(int)), oglWid, SLOT(msred(int)));
	connect(MSG, SIGNAL(valueChanged(int)), oglWid, SLOT(msgreen(int)));
	connect(MSB, SIGNAL(valueChanged(int)), oglWid, SLOT(msblue(int)));
	connect(MSA, SIGNAL(valueChanged(int)), oglWid, SLOT(msalpha(int)));

	/** Emission material */
	connect(MER, SIGNAL(valueChanged(int)), oglWid, SLOT(mered(int)));
	connect(MEG, SIGNAL(valueChanged(int)), oglWid, SLOT(megreen(int)));
	connect(MEB, SIGNAL(valueChanged(int)), oglWid, SLOT(meblue(int)));
	connect(MEA, SIGNAL(valueChanged(int)), oglWid, SLOT(mealpha(int)));

	/** Material misc. */
	connect(shin, SIGNAL(valueChanged(int)), oglWid, SLOT(matexp(int)));
	connect(locAmb, SIGNAL(clicked()), oglWid, SLOT(matAmbLocked()));
	connect(locDif, SIGNAL(clicked()), oglWid, SLOT(matDifLocked()));
	connect(locSpe, SIGNAL(clicked()), oglWid, SLOT(matSpeLocked()));
	connect(locEmi, SIGNAL(clicked()), oglWid, SLOT(matEmiLocked()));
	connect(backSide, SIGNAL(clicked()), oglWid, SLOT(toggleBackSide()));
	connect(sync, SIGNAL(clicked()), oglWid, SLOT(syncSides()));
	connect(oglWid, SIGNAL(updMatWid()), this, SLOT(updMatWid()));
}


/** *************************************************************************
 ** UPDATE SLIDER-VALUES IN LIGHT-EDITOR
****************************************************************************/
void matWidget::updMatWid() {

	/** Check setting-section */
	edit0->setChecked(false);
	edit1->setChecked(false);
	edit2->setChecked(false);
	edit3->setChecked(false);

	switch(sta.ediMat) {
		case(0): edit0->setChecked(true); break;
		case(1): edit1->setChecked(true); break;
		case(2): edit2->setChecked(true); break;
		case(3): edit3->setChecked(true); break;
	}

	/** RGB-sliders and backside-button */
	locAmb->setChecked(mat[sta.ediMat].ambMatLoc[mat[sta.ediMat].twoSid]);
	locDif->setChecked(mat[sta.ediMat].difMatLoc[mat[sta.ediMat].twoSid]);
	locSpe->setChecked(mat[sta.ediMat].speMatLoc[mat[sta.ediMat].twoSid]);
	locEmi->setChecked(mat[sta.ediMat].emiMatLoc[mat[sta.ediMat].twoSid]);
	backSide->setChecked(mat[sta.ediMat].twoSid);

	/** Ambient material */
	MAR->setValue((int)(mat[sta.ediMat].ambMat[mat[sta.ediMat].twoSid][0]*255.0f));
	MAG->setValue((int)(mat[sta.ediMat].ambMat[mat[sta.ediMat].twoSid][1]*255.0f));
	MAB->setValue((int)(mat[sta.ediMat].ambMat[mat[sta.ediMat].twoSid][2]*255.0f));
	MAA->setValue((int)(mat[sta.ediMat].ambMat[mat[sta.ediMat].twoSid][3]*255.0f));

	/** Diffuse material */
	MDR->setValue((int)(mat[sta.ediMat].difMat[mat[sta.ediMat].twoSid][0]*255.0f));
	MDG->setValue((int)(mat[sta.ediMat].difMat[mat[sta.ediMat].twoSid][1]*255.0f));
	MDB->setValue((int)(mat[sta.ediMat].difMat[mat[sta.ediMat].twoSid][2]*255.0f));
	MDA->setValue((int)(mat[sta.ediMat].difMat[mat[sta.ediMat].twoSid][3]*255.0f));

	/** Specular material */
	MSR->setValue((int)(mat[sta.ediMat].speMat[mat[sta.ediMat].twoSid][0]*255.0f));
	MSG->setValue((int)(mat[sta.ediMat].speMat[mat[sta.ediMat].twoSid][1]*255.0f));
	MSB->setValue((int)(mat[sta.ediMat].speMat[mat[sta.ediMat].twoSid][2]*255.0f));
	MSA->setValue((int)(mat[sta.ediMat].speMat[mat[sta.ediMat].twoSid][3]*255.0f));

	/** Emission material */
	MER->setValue((int)(mat[sta.ediMat].emiMat[mat[sta.ediMat].twoSid][0]*255.0f));
	MEG->setValue((int)(mat[sta.ediMat].emiMat[mat[sta.ediMat].twoSid][1]*255.0f));
	MEB->setValue((int)(mat[sta.ediMat].emiMat[mat[sta.ediMat].twoSid][2]*255.0f));
	MEA->setValue((int)(mat[sta.ediMat].emiMat[mat[sta.ediMat].twoSid][3]*255.0f));

	/** Shininess */
	shin->setValue((int)mat[sta.ediMat].shiMat[mat[sta.ediMat].twoSid]);
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void matWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_matUI::retranslateUi(this);
		setWindowTitle(tr("Surfaces"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void matWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void matWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("MaterialWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("MaterialWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(225, 500));
		move(QPoint(0, 60));
	}
}

void matWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("MaterialWindowPos", pos());
	settings.setValue("MaterialWindowSize", size());
}
