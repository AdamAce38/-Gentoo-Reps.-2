/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <GL/gl.h>
#include <GL/glu.h>

#include "glwidget.h"
#include "aniedit.h"
#include "moredit.h"
#include "picedit.h"
#include "funedit.h"
#include "speedit.h"
#include "legedit.h"
#include "fntedit.h"
#include "paths.h"
#include "pinterface.h"


/** Extern globals */
extern aniWidget *aniEdi;    // Animation currently running?
extern morWidget *morEdi;    // Morphing currently running?
extern picWidget *picEdi;    // For pic-dimensions
extern funWidget *funEdi;    // Notify, when parameter-mode switches
extern speWidget *speEdi;    // Notify, when parameter-mode switches
extern QString workDir;      // Where to save pics as default?


/** Legends relevant */
extern legWidget *legEdi;    // Legends editor
extern fntWidget *fntEdi;    // Font editor


/** Global */
const int lightBase=GL_LIGHT0;    // Holds GLenum for first light source
unsigned int texID[4];            // Texture ID's
bool oglBusy=false;               // Indicate current rendering state; needed from demo, morph, ...
QFont labelFont;                  // Legends


/** Private */
// Save current drawing mode when entering ISO and provide a no-spotlight setting
static int saveDrawMode;
static const float noSpot[3] = { 180.0f, 180.0f, 180.0f };


/** *************************************************************************
 ** INITIALIZATIONS
****************************************************************************/
OGLWidget::OGLWidget(QWidget *parent) : QGLWidget(parent) {
	setMinimumSize(32, 32);
	updWinTit();
	readSettings();
	iniAll();
}

/** Initialize default values */
void OGLWidget::iniAll() {

	scaleFac=con.normalFac;     // Scalefactor; normal is default
	sta.ediLig=sta.ediMat=0;    // Light stuff

	/** Initialize parsers */
	iniFun();    // Functions, iso and parametric system
	iniUsr();    // User items

	/** Initialize OpenGL relevant stuff */
	iniLig();    // Lights
	iniMat();    // Materials
	iniEnt();    // Entire light
	iniAni();    // Animation
	iniMor();    // Morphing
	iniSta();    // Status
	iniPic();    // Dimensions/lock for snapshot
	iniTex();    // Textures
	iniFog();    // Fog
	iniMot();    // Motion blur
	iniErr();    // Error handling
	iniLeg();    // Legends

	/** More legends stuff */
	labelFont.setFamily(leg.font[0]);
	labelFont.setPointSize(11);
	labelFont.setStyleStrategy(QFont::OpenGLCompatible);
}

/** Called from fntEdit. Works but is experimental so far */
void OGLWidget::newFont(QString font) {
	labelFont.setFamily(font);
	labelFont.setStyleStrategy(QFont::OpenGLCompatible);
	for(int i=0; i<9; i++)
		leg.font[i]=font;
}

/** Initial OpenGL-settings */
void OGLWidget::initializeGL() {
	int i;

	/** Some basic initializations */
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	/** Quality settings */
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);

	/** Still (2008-08) causes troubles with ATI drivers in Linux/Windows !!! */
	// #if !(defined(WINDOWS) || defined(WIN32) || defined(WIN64))
	// glEnable(GL_POLYGON_SMOOTH);
	// #endif

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	glHint(GL_FOG_HINT, GL_NICEST);

	/** Texture stuff */
	glGenTextures(4, texID);
	for(i=0; i<4; i++) {
		glBindTexture(GL_TEXTURE_2D, texID[i]);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tex[i].hSize, tex[i].vSize, \
					 0, GL_RGB, GL_UNSIGNED_BYTE, tex[i].data);
	}
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &maxTex);

	/** Specular texture-lights do not work with ATI drivers in Windows */
	#if !(defined(WINDOWS) || defined(WIN32) || defined(WIN64))
	glLightModelf(GL_LIGHT_MODEL_COLOR_CONTROL, GL_SEPARATE_SPECULAR_COLOR);
	#endif

	/** Entire light-model */
	glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, ent.modInf);
	glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, ent.modOne);

	/** Setup initial light sources; spotlights are off */
	for(i=0; i<MAXLIG; i++) {
		glLightfv(lightBase+i, GL_POSITION, &lig[i].ligPos[0]);
		glLightfv(lightBase+i, GL_AMBIENT,  &lig[i].ambLig[0]);
		glLightfv(lightBase+i, GL_DIFFUSE,  &lig[i].difLig[0]);
		glLightfv(lightBase+i, GL_SPECULAR, &lig[i].speLig[0]);

		glLightfv(lightBase+i, GL_CONSTANT_ATTENUATION,  &lig[i].conAtt);
		glLightfv(lightBase+i, GL_LINEAR_ATTENUATION,    &lig[i].linAtt);
		glLightfv(lightBase+i, GL_QUADRATIC_ATTENUATION, &lig[i].quaAtt);

		glLightfv(lightBase+i, GL_SPOT_DIRECTION, &lig[i].spoDir[0]);
		glLightfv(lightBase+i, GL_SPOT_CUTOFF,    &noSpot[0]);
		glLightfv(lightBase+i, GL_SPOT_EXPONENT,  &lig[i].spoExp);
	}

	/** Enable/disable default lights */
	for(i=0; i<MAXLIG; i++)
		if(lig[i].setLig)
			glEnable(lightBase+i);
		else
			glDisable(lightBase+i);

	/** Set standard background colour */
	glClearColor(ent.bacLig[0], ent.bacLig[1], ent.bacLig[2], ent.bacLig[3]);

	/** Get a correctly initialized OpenGL-context for rendering into pic-files
	 ** of arbitrary size-dimensions */
	listUpAll;
	if(sta.draw==0) Draw_Triangles();
	if(sta.draw==1) Draw_Quads();
	if(sta.draw==2) Draw_Points();
}

/** Equivalent to Glut-reshape. Widht & height is passed automatically
 ** Resizing is neccessary too, when changing angles */
void OGLWidget::resizeGL(int width, int height) {
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(sta.angle, (double)width/(double)height, 3.0, 10.0);
	glMatrixMode(GL_MODELVIEW);

	/** Save actual dimensions for changing angle */
	actWidth=width;
	actHeight=height;

	/** Update window title and some editors at last */
	updWinTit();
	picEdi->updPicWid();
	legEdi->updLegWid();
}

/** Update window title. Access is global for this */
void OGLWidget::updWinTit() {
	QString w, h;
	setWindowTitle(tr("Viewer")+" - "+w.setNum(actWidth)+" x "+h.setNum(actHeight));
}


/** *************************************************************************
 ** ROTATIONS;    x = value from xSlider or mouse
****************************************************************************/
void OGLWidget::setXRotation(const int newx) {
	if(newx!=sta.rotX) {
		sta.rotX=newx%361;
		emit xRotationChanged(newx);
		updateGL();
	}
}

void OGLWidget::setYRotation(const int newy) {
	if(newy!=sta.rotY) {
		sta.rotY=newy%361;
		emit yRotationChanged(newy);
		updateGL();
	}
}

void OGLWidget::setZRotation(const int newz) {
	if(newz!=sta.rotZ) {
		sta.rotZ=newz;
		updateGL();
	}
}


/** *************************************************************************
 ** GOT NEW FUNCTIONS
****************************************************************************/
bool OGLWidget::errorNewF0(int p) {
	QString message=tr("Parser message from F0/I0/X")+":\n\n";
	int err;

	if((err=fpGL[p].GetParseErrorType()) != FunctionParser::FP_NO_ERROR) {
		message+=fpError::getQtMessage(err)+"\n";
		QMessageBox::critical(
			this,
			tr("Alert"),
			message
		);
		emit F0error();
		emit parsersTainted(true);
		funErr[0]=true;
		initAllParsers();
		return true;
	}

	return false;
}

void OGLWidget::setNewF0() {

	/** Check validity of usr-tables first */
	if(fetchUsrError())
		return;

	/** Not fiddle around and make it for all parsers at once: */
	initAllParsers();

	/** Convert and check for correctness */
	if(sta.funMod==FUNCTION)  if(errorNewF0(0)) return;
	if(sta.funMod==PARAMETER) if(errorNewF0(3)) return;
	if(sta.funMod==IMPLICITE) if(errorNewF0(6)) return;
	funErr[0]=false;

	/** Check out OpenGL list */
	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE)
		listUp[0]=true;
	if(sta.funMod==PARAMETER)
		listUp[3]=true;

	/** Update */
	emit parsersTainted(false);
	emit updMaiInf();
	updateGL();
}

bool OGLWidget::errorNewF1(int p) {
	QString message=tr("Parser message from F1/I1/Y")+":\n\n";
	int err;

	if((err=fpGL[p].GetParseErrorType()) != FunctionParser::FP_NO_ERROR) {
		message+=fpError::getQtMessage(err)+"\n";
		QMessageBox::critical(
			this,
			tr("Alert"),
			message
		);
		emit F1error();
		emit parsersTainted(true);
		funErr[1]=true;
		initAllParsers();
		return true;
	}

	return false;
}

void OGLWidget::setNewF1() {

	/** Check validity of usr-tables first */
	if(fetchUsrError())
		return;

	/** Not fiddle around and make it for all parsers at once: */
	initAllParsers();

	/** Convert and check for correctness */
	if(sta.funMod==FUNCTION)  if(errorNewF1(1)) return;
	if(sta.funMod==PARAMETER) if(errorNewF1(4)) return;
	if(sta.funMod==IMPLICITE) if(errorNewF1(7)) return;
	funErr[1]=false;

	/** Check out OpenGL list */
	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE)
		listUp[1]=true;
	if(sta.funMod==PARAMETER)
		listUp[3]=true;

	/** Update */
	emit parsersTainted(false);
	emit updMaiInf();
	updateGL();
}

bool OGLWidget::errorNewF2(int p) {
	QString message=tr("Parser message from F2/I2/Z")+":\n\n";
	int err;

	if((err=fpGL[p].GetParseErrorType()) != FunctionParser::FP_NO_ERROR) {
		message+=fpError::getQtMessage(err)+"\n";
		QMessageBox::critical(
			this,
			tr("Alert"),
			message
		);
		emit F2error();
		emit parsersTainted(true);
		funErr[2]=true;
		initAllParsers();
		return true;
	}

	return false;
}

void OGLWidget::setNewF2() {

	/** Check validity of usr-tables first */
	if(fetchUsrError())
		return;

	/** Not fiddle around and make it for all parsers at once: */
	initAllParsers();

	/** Convert and check for correctness */
	if(sta.funMod==FUNCTION)  if(errorNewF2(2)) return;
	if(sta.funMod==PARAMETER) if(errorNewF2(5)) return;
	if(sta.funMod==IMPLICITE) if(errorNewF2(8)) return;
	funErr[2]=false;

	/** Check out OpenGL list */
	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE)
		listUp[2]=true;
	if(sta.funMod==PARAMETER)
		listUp[3]=true;

	/** Update */
	emit parsersTainted(false);
	emit updMaiInf();
	updateGL();
}


/** *************************************************************************
 ** HANDLE POLYGON-MODE
****************************************************************************/
void OGLWidget::togglePolygon() {

	/** Points? Then do nothing */
	if(sta.draw==2)
		return;

	sta.wired = !sta.wired;
	updateGL();
}


/** *************************************************************************
 ** MODE/FUNCTION VIEW CHANGED
****************************************************************************/
void OGLWidget::drawModeParameter() {

	/** Advance mode */
	if(++sta.funMod>PARAMETER)
		sta.funMod=FUNCTION;

	/** Check impossible quads+iso and draw triangles then */
	if(sta.funMod==IMPLICITE)
		if(sta.draw==1)
			sta.draw=0;

	/** Check out which function/implicite function is really to draw */
	Draw_Which();

	/** Perform all updates */
	emit updMaiInf();
	emit updMaiWid();
	funEdi->updFunWid();
	speEdi->updSpeWid();
	listUpAll;
	updateGL();
}

void OGLWidget::toggleF0() {

	if(sta.funMod==FUNCTION) {
		fun[0].drawFun=!fun[0].drawFun;
		Draw_Which();
	}

	if(sta.funMod==IMPLICITE) {
		iso[0].drawIso=!iso[0].drawIso;
		Draw_Which();
	}

	updateGL();
}

void OGLWidget::toggleF1() {

	if(sta.funMod==FUNCTION) {
		fun[1].drawFun=!fun[1].drawFun;
		Draw_Which();
	}

	if(sta.funMod==IMPLICITE) {
		iso[1].drawIso=!iso[1].drawIso;
		Draw_Which();
	}

	updateGL();
}

void OGLWidget::toggleF2() {

	if(sta.funMod==FUNCTION) {
		fun[2].drawFun=!fun[2].drawFun;
		Draw_Which();
	}

	if(sta.funMod==IMPLICITE) {
		iso[2].drawIso=!iso[2].drawIso;
		Draw_Which();
	}

	updateGL();
}

void OGLWidget::toggleF3() {

	par.drawPar=!par.drawPar;

	/** Consider if checked, when ISO is on */
	if(par.drawPar)
		if(sta.funMod==IMPLICITE)
			sta.draw=saveDrawMode;

	updateGL();

	/** Reset triangle mode */
	if(sta.funMod==IMPLICITE)
		sta.draw=0;
}


/** *************************************************************************
 ** PERFORM SCALINGS
****************************************************************************/

/** Scale x */
void OGLWidget::scaleXplus()  {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE) {
		sta.sx*=scaleFac;
		listUpFun;
	}

	if(sta.funMod==PARAMETER) {
		sta.spx*=scaleFac;
		listUpPar;
	}

	emit updMaiInf();
	updateGL();
}

void OGLWidget::scaleXminus() {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE) {
		sta.sx/=scaleFac;
		listUpFun;
	}

	if(sta.funMod==PARAMETER) {
		sta.spx/=scaleFac;
		listUpPar;
	}

	emit updMaiInf();
	updateGL();
}

/** Scale y */
void OGLWidget::scaleYplus()  {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE) {
		sta.sy*=scaleFac;
		listUpFun;
	}

	if(sta.funMod==PARAMETER) {
		sta.spy*=scaleFac;
		listUpPar;
	}

	emit updMaiInf();
	updateGL();
}

void OGLWidget::scaleYminus() {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE) {
		sta.sy/=scaleFac;
		listUpFun;
	}

	if(sta.funMod==PARAMETER) {
		sta.spy/=scaleFac;
		listUpPar;
	}

	emit updMaiInf();
	updateGL();
}

/** Scale z */
void OGLWidget::scaleZplus()  {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE) {
		sta.sz*=scaleFac;
		listUpFun;
		emit updMaiInf();
		updateGL();
	}
}

void OGLWidget::scaleZminus() {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE) {
		sta.sz/=scaleFac;
		listUpFun;
		emit updMaiInf();
		updateGL();
	}
}

/** Scale xyz */
void OGLWidget::scaleXYZplus()  {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE) {
		sta.sx=sta.sy=sta.sz=sta.sa*=scaleFac;
		listUpFun;
	}

	if(sta.funMod==PARAMETER) {
		sta.spz*=scaleFac;
		listUpPar;
	}

	emit updMaiInf();
	updateGL();
}

void OGLWidget::scaleXYZminus() {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==IMPLICITE) {
		sta.sx=sta.sy=sta.sz=sta.sa/=scaleFac;
		listUpFun;
	}

	if(sta.funMod==PARAMETER) {
		sta.spz/=scaleFac;
		listUpPar;
	}

	emit updMaiInf();
	updateGL();
}

/** Scale grid */
void OGLWidget::scaleGridplus() {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==PARAMETER) {
		if(sta.fgrids>=320)
			return;
		if(sta.fgrids<32)
			sta.fgrids+=2;
		else if(sta.fgrids<64)
			sta.fgrids+=4;
		else if(sta.fgrids<128)
			sta.fgrids+=8;
		else
			sta.fgrids+=16;
		sta.tessWidth=2.0f/sta.fgrids;
	}

	if(sta.funMod==IMPLICITE) {
		if(sta.tgrids>=128)
			return;
		sta.tgrids+=4;
		iniITL();
	}

	emit updMaiWid();
	listUpAll;
	updateGL();
}

void OGLWidget::scaleGridminus() {
	if(oglBusy) return;

	if(sta.funMod==FUNCTION || sta.funMod==PARAMETER) {
		if(sta.fgrids<=4)
			return;
		if(sta.fgrids<=32)
			sta.fgrids-=2;
		else if(sta.fgrids<=64)
			sta.fgrids-=4;
		else if(sta.fgrids<=128)
			sta.fgrids-=8;
		else
			sta.fgrids-=16;
		sta.tessWidth=2.0f/sta.fgrids;
	}

	if(sta.funMod==IMPLICITE) {
		if(sta.tgrids<=4)
			return;
		sta.tgrids-=4;
		iniITL();
	}

	emit updMaiWid();
	listUpAll;
	updateGL();
}


/** *************************************************************************
 ** MOUSE-HANDLING
****************************************************************************/

/** Qt4 is missing this. Quite a pitty:-) */
static bool LeftAndRightButtons(QMouseEvent *event) {
	if(event->buttons() & Qt::LeftButton)
		if(event->buttons() & Qt::RightButton)
			return true;
	if(event->buttons() & Qt::RightButton)
		if(event->buttons() & Qt::LeftButton)
			return true;
	return false;
}

void OGLWidget::mousePressEvent(QMouseEvent *event) {

	/** Reset mouse-lock in legends-editor via right click */
	if(leg.locMou && (event->buttons() & Qt::RightButton)) {
		leg.locMou=!leg.locMou;
		legEdi->updLegWid();
		return;
	}

	if(event->buttons() & LeftAndRightButtons(event))
		setCursor(Qt::SizeAllCursor);
	else if(event->buttons() & Qt::MidButton)
			setCursor(Qt::SizeVerCursor);
	else if(event->buttons() & Qt::LeftButton)
			setCursor(Qt::PointingHandCursor);
	else if(event->buttons() & Qt::RightButton)
			setCursor(Qt::CrossCursor);
	lastPos=event->pos();
}

void OGLWidget::mouseReleaseEvent(QMouseEvent *event) {
	setCursor(Qt::ArrowCursor);
	lastPos=event->pos();
}

void OGLWidget::mouseMoveEvent(QMouseEvent *event) {

	const float delta=1.0f/(float)sta.fgrids;
	int dx = event->x()-lastPos.x();
	int dy = event->y()-lastPos.y();

	if(fetchUsrError() || fetchFunError())
		return;

	/** Move legends only? */
	if(leg.locMou && (event->buttons() & Qt::LeftButton)) {
		if(event->x() < lastPos.x()) leg.xOffs[leg.curRow]-=leg.offs;
		if(event->x() > lastPos.x()) leg.xOffs[leg.curRow]+=leg.offs;
		if(event->y() < lastPos.y()) leg.yOffs[leg.curRow]+=leg.offs;
		if(event->y() > lastPos.y()) leg.yOffs[leg.curRow]-=leg.offs;
		updateGL();
		return;
	}

	/** Zoom in/out with MidButton */
	if(event->buttons() & Qt::MidButton) {
		if(dy>0)
			zoomOut();
		else
			zoomIn();
		lastPos = event->pos();
		return;
	}

	/** Translate with LeftAndRightButtons */
	if(event->buttons() & LeftAndRightButtons(event)) {
		if(dx>0)
			transRight();
 		else if(dx<0)
			transLeft();

		if(dy>0)
			transDown();
		else if(dy<0)
			transUp();

		lastPos = event->pos();
		return;
	}

	/** Rotate view with left button */
	if(event->buttons() & Qt::LeftButton) {
		setXRotation((int)sta.rotX+1*dy);
		setYRotation((int)sta.rotY+1*dx);
		updateGL();
		lastPos = event->pos();
		return;
	}

	/** Move cross with right button */
	if(event->buttons() & Qt::RightButton) {
		if(dx>0) {
			sta.crossX+=delta;
			if(sta.crossX>1.0f) sta.crossX=1.0f;
		}
 		else if(dx<0) {
			sta.crossX-=delta;
			if(sta.crossX<-1.0f) sta.crossX=-1.0f;
		}

		if(dy>0) {
			sta.crossY-=delta;
			if(sta.crossY<-1.0f) sta.crossY=-1.0f;
		}
		else if(dy<0) {
			sta.crossY+=delta;
			if(sta.crossY>1.0f) sta.crossY=1.0f;
		}
	}

	updateGL();
	emit updMaiInf();
	lastPos = event->pos();
}


/** *************************************************************************
 ** SAVE PICTURE
****************************************************************************/
void OGLWidget::savePic() {

	QString fileName;
	QString title, x, y;
	const bool aniFlag=ani.active;    // Remember if animation was on
	const bool morFlag=mor.active;    // Remember if morphing was on
	const int bakWidth=actWidth;      // Remember actual OGL-width
	const int bakHeight=actHeight;    // Remember actual OGL-height

	/** Adjust some temporary settings */
	aniEdi->animate(false);
	morEdi->morph(false);
	x.setNum(pic.xDim);
	y.setNum(pic.yDim);
	title=tr("Rendering")+" "+x+"x"+y+" "+tr("picture ...");
	setWindowTitle(title);

	/** Render into pixmap & restore original view */
	QApplication::setOverrideCursor(Qt::WaitCursor);
	QPixmap pixmap = this->renderPixmap(pic.xDim, pic.yDim);
	resizeGL(bakWidth, bakHeight);
	QApplication::restoreOverrideCursor();

	/** Restore settings */
	if(aniFlag) aniEdi->animate(true);
	if(morFlag) morEdi->morph(true);
	updWinTit();

	/** Save pixmap */
	switch(pic.fmt) {
		case PNG: {
			fileName=QFileDialog::getSaveFileName(
					this,
					tr("Save as *.png"),
					workDir,
					"Images (*.png)");

			if(fileName.isEmpty())
				return;

			/** Complete filename */
			if(!fileName.toUpper().endsWith(".PNG"))
				fileName+=".png";

			QApplication::setOverrideCursor(Qt::WaitCursor);
			pixmap.save(fileName, "PNG", pic.quality);
			QApplication::restoreOverrideCursor();
			break;
		}

		case JPG: {
			fileName=QFileDialog::getSaveFileName(
					this,
					tr("Save as *.jpg"),
					workDir,
					"Images (*.jpg)");

			if(fileName.isEmpty())
				return;

			/** Complete filename */
			if(!fileName.toUpper().endsWith(".JPG"))
				fileName+=".jpg";

			QApplication::setOverrideCursor(Qt::WaitCursor);
			pixmap.save(fileName, "JPG", pic.quality);
			QApplication::restoreOverrideCursor();
			break;
		}

		case PDF: {
			fileName=QFileDialog::getSaveFileName(
					this,
					tr("Save as *.pdf"),
					workDir,
					"Images (*.pdf)");

			if(fileName.isEmpty())
				return;

			/** Complete filename */
			if(!fileName.toUpper().endsWith(".PDF"))
				fileName+=".pdf";

			/** Set up printer */
			QApplication::setOverrideCursor(Qt::WaitCursor);
			QPrinter printer(QPrinter::ScreenResolution);
			printer.setOutputFormat(QPrinter::PdfFormat);
			printer.setOutputFileName(fileName);    // Enables toFile automatically
			printer.setFullPage(true);

			/** "Print" over painter */
			QImage image=pixmap.toImage();
			QPainter painter(&printer);
			QRect rect=painter.viewport();
			QSize size=image.size();
			size.scale(rect.size(), Qt::KeepAspectRatio);
			painter.setViewport(0, 0, size.width(), size.height());
			painter.setWindow(image.rect());
			painter.drawImage(0, 0, image);
			QApplication::restoreOverrideCursor();
			break;
		}

		case PS: {
			fileName=QFileDialog::getSaveFileName(
					this,
					tr("Save as *.ps"),
					workDir,
					"Images (*.ps)");

			if(fileName.isEmpty())
				return;

			/** Complete filename */
			if(!fileName.toUpper().endsWith(".PS"))
				fileName+=".ps";

			/** Set up printer */
			QApplication::setOverrideCursor(Qt::WaitCursor);
			QPrinter printer(QPrinter::HighResolution);
			printer.setOutputFormat(QPrinter::PostScriptFormat);
			printer.setResolution(pic.dpi);
			printer.setOutputFileName(fileName);    // Enables toFile automatically
			printer.setFullPage(true);

			/** "Print" over painter */
			QImage image=pixmap.toImage();
			QPainter painter(&printer);
			QRect rect=painter.viewport();
			QSize size=image.size();
			size.scale(rect.size(), Qt::KeepAspectRatio);
			painter.setViewport(0, 0, size.width(), size.height());
			painter.setWindow(image.rect());
			painter.drawImage(0, 0, image);
			QApplication::restoreOverrideCursor();
			break;
		}
	}
}


/** *************************************************************************
 ** PRINT PICTURE
****************************************************************************/
void OGLWidget::printPic() {

	QString fileName;
	QString title, x, y;
	int bakWidth=actWidth;      // Remember actual OGL-width
	int bakHeight=actHeight;    // Remember actual OGL-height

	/** Adjust some temporary settings */
	x.setNum(pic.xDim);
	y.setNum(pic.yDim);
	title=tr("Rendering")+" "+x+"x"+y+" "+tr("picture ...");
	setWindowTitle(title);

	/** Render into pixmap & restore original view */
	QApplication::setOverrideCursor(Qt::WaitCursor);
	QImage image=this->renderPixmap(pic.xDim, pic.yDim).toImage();
	resizeGL(bakWidth, bakHeight);
	QApplication::restoreOverrideCursor();
	updWinTit();

	/** Set up printer */
	QPrinter printer(QPrinter::HighResolution);
	printer.setOutputFormat(QPrinter::NativeFormat);

	/** Show box with printing only available */
	QPrintDialog printDialog(&printer, this);
	printDialog.setEnabledOptions(QAbstractPrintDialog::None);

	/** And print finally. Linux Max <= 10000x10000 with 1200 Dpi on my configuration */
	if(printDialog.exec() == QDialog::Accepted) {
		QApplication::setOverrideCursor(Qt::WaitCursor);
		QPainter painter(&printer);
		QRect rect=painter.viewport();
		QSize size=image.size();
		size.scale(rect.size(), Qt::KeepAspectRatio);
		painter.setViewport(rect.x(), rect.y(), size.width(), size.height());
		painter.setWindow(image.rect());
		painter.drawImage(0, 0, image);
		QApplication::restoreOverrideCursor();
	}
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS + SETTINGS
****************************************************************************/
void OGLWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange)
		updWinTit();
	else
		QWidget::changeEvent(event);
}

/** When oglWid is killed, close MainWindow too
 ** Using qApp->closeAllWindows() instead freezes application ! */
void OGLWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	emit killAll();
	event->accept();
}

void OGLWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("oglWidPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("oglWidSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
		actWidth=size.width();
		actHeight=size.height();
	}
	else {
		resize(QSize(570, 570));
		move(QPoint(420, 0));
		actWidth=570;
		actHeight=570;
	}
}

void OGLWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("oglWidPos", pos());
	settings.setValue("oglWidSize", size());
}


/** *************************************************************************
 ** LIGHT STUFF
****************************************************************************/

/** Distance from origin */
void OGLWidget::lightDistance(const int d) {
	const float offset = d/10.0f;
	switch(sta.ediLig) {
		case 0:	lig[0].ligPos[0] = -offset;
				lig[0].ligPos[1] =  offset;
				lig[0].ligPos[2] =  offset;
				break;
		case 1:	lig[1].ligPos[0] = -offset;
				lig[1].ligPos[1] = -offset;
				lig[1].ligPos[2] =  offset;
				break;
		case 2:	lig[2].ligPos[0] =  offset;
				lig[2].ligPos[1] = -offset;
				lig[2].ligPos[2] =  offset;
				break;
		case 3:	lig[3].ligPos[0] =  offset;
				lig[3].ligPos[1] =  offset;
				lig[3].ligPos[2] =  offset;
				break;
		case 4:	lig[4].ligPos[0] = -offset;
				lig[4].ligPos[1] =  offset;
				lig[4].ligPos[2] = -offset;
				break;
		case 5:	lig[5].ligPos[0] = -offset;
				lig[5].ligPos[1] = -offset;
				lig[5].ligPos[2] = -offset;
				break;
		case 6:	lig[6].ligPos[0] =  offset;
				lig[6].ligPos[1] = -offset;
				lig[6].ligPos[2] = -offset;
				break;
		case 7:	lig[7].ligPos[0] =  offset;
				lig[7].ligPos[1] =  offset;
				lig[7].ligPos[2] = -offset;
				break;
	}
	lig[sta.ediLig].ligDis=d;
	updateGL();
}

/** Ambient light intensity */
void OGLWidget::laall(const int channel, const int intensity) {
	if(lig[sta.ediLig].ambLigLoc && channel<3) {
		for(int i=0; i<3; i++)
				lig[sta.ediLig].ambLig[i]=intensity/255.0f;
		emit updLigAmb();
	}
	else
		lig[sta.ediLig].ambLig[channel]=intensity/255.0f;
	glLightfv(lightBase+sta.ediLig, GL_AMBIENT, &lig[sta.ediLig].ambLig[0]);
	updateGL();
}

/** Diffuse light intensity */
void OGLWidget::ldall(const int channel, const int intensity) {
	if(lig[sta.ediLig].difLigLoc && channel<3) {
		for(int i=0; i<3; i++)
				lig[sta.ediLig].difLig[i]=intensity/255.0f;
		emit updLigDif();
	}
	else
		lig[sta.ediLig].difLig[channel]=intensity/255.0f;
	glLightfv(lightBase+sta.ediLig, GL_DIFFUSE, &lig[sta.ediLig].difLig[0]);
	updateGL();
}

/** Specular light intensity */
void OGLWidget::lsall(const int channel, const int intensity) {
	if(lig[sta.ediLig].speLigLoc && channel<3) {
		for(int i=0; i<3; i++)
				lig[sta.ediLig].speLig[i]=intensity/255.0f;
		emit updLigSpe();
	}
	else
		lig[sta.ediLig].speLig[channel]=intensity/255.0f;
	glLightfv(lightBase+sta.ediLig, GL_SPECULAR, &lig[sta.ediLig].speLig[0]);
	updateGL();
}

/** Attenuation */
void OGLWidget::setConAtt(int faktor) {
	lig[sta.ediLig].conAtt=faktor/100.0f;
	glLightfv(lightBase+sta.ediLig, GL_CONSTANT_ATTENUATION, &lig[sta.ediLig].conAtt);
	updateGL();
}

void OGLWidget::setLinAtt(int faktor) {
	lig[sta.ediLig].linAtt=faktor/300.0f;
	glLightfv(lightBase+sta.ediLig, GL_LINEAR_ATTENUATION, &lig[sta.ediLig].linAtt);
	updateGL();
}

void OGLWidget::setQuaAtt(int faktor) {
	lig[sta.ediLig].quaAtt=(float)faktor/1000.0f;
	glLightfv(lightBase+sta.ediLig, GL_QUADRATIC_ATTENUATION, &lig[sta.ediLig].quaAtt);
	updateGL();
}


/** *************************************************************************
 ** MATERIAL STUFF
****************************************************************************/

/** Ambient material */
void OGLWidget::maall(const int channel, const int intensity) {
	if(mat[sta.ediMat].ambMatLoc[mat[sta.ediMat].twoSid] && channel<3) {
		for(int i=0; i<3; i++)
				mat[sta.ediMat].ambMat[mat[sta.ediMat].twoSid][i]=intensity/255.0f;
		emit updMatWid();
	}
	else
		mat[sta.ediMat].ambMat[mat[sta.ediMat].twoSid][channel]=intensity/255.0f;
	updateGL();
}

/** Diffuse material */
void OGLWidget::mdall(const int channel, const int intensity) {
	if(mat[sta.ediMat].difMatLoc[mat[sta.ediMat].twoSid] && channel<3) {
		for(int i=0; i<3; i++)
				mat[sta.ediMat].difMat[mat[sta.ediMat].twoSid][i]=intensity/255.0f;
		emit updMatWid();
	}
	else
		mat[sta.ediMat].difMat[mat[sta.ediMat].twoSid][channel]=intensity/255.0f;
	updateGL();
}

/** Specular material */
void OGLWidget::msall(const int channel, const int intensity) {
	if(mat[sta.ediMat].speMatLoc[mat[sta.ediMat].twoSid] && channel<3) {
		for(int i=0; i<3; i++)
				mat[sta.ediMat].speMat[mat[sta.ediMat].twoSid][i]=intensity/255.0f;
		emit updMatWid();
	}
	else
		mat[sta.ediMat].speMat[mat[sta.ediMat].twoSid][channel]=intensity/255.0f;
	updateGL();
}

/** Emission material */
void OGLWidget::meall(const int channel, const int intensity) {
	if(mat[sta.ediMat].emiMatLoc[mat[sta.ediMat].twoSid] && channel<3) {
		for(int i=0; i<3; i++)
				mat[sta.ediMat].emiMat[mat[sta.ediMat].twoSid][i]=intensity/255.0f;
		emit updMatWid();
	}
	else
		mat[sta.ediMat].emiMat[mat[sta.ediMat].twoSid][channel]=intensity/255.0f;
	updateGL();
}

/** Toggle material edited currently */
void OGLWidget::toggleBackSide() {

	if(ent.modOne==0.0f && !mat[sta.ediMat].twoSid) {
		QMessageBox::information(
			this,
			tr("Material"),
			tr("Editing back-side colours, although the "
			"global setting is just 1-sided.<p></p>"
			"Zhu3D is <b>enabling</b> the 2-sided mode automatically now.")
		);
		ent.modOne=1.0f;
		updEntWid();
	}

	mat[sta.ediMat].twoSid = !mat[sta.ediMat].twoSid;
	updMatWid();
}


/** *************************************************************************
 ** SYNCHRONIZE BACKSIDE WITH FRONTSIDE
****************************************************************************/
void OGLWidget::syncSides() {
	int i;

	if(ent.modOne==0.0f) {
		QMessageBox::information(
			this,
			tr("Material"),
			tr("Changing back-side colours, although the "
			"global setting is just 1-sided.<p></p>"
			"Zhu3D is <b>enabling</b> the 2-sided mode automatically now.")
		);
		ent.modOne=1.0f;
		updEntWid();
	}

	mat[sta.ediMat].ambMatLoc[1] = mat[sta.ediMat].ambMatLoc[0];
	mat[sta.ediMat].difMatLoc[1] = mat[sta.ediMat].difMatLoc[0];
	mat[sta.ediMat].speMatLoc[1] = mat[sta.ediMat].speMatLoc[0];
	mat[sta.ediMat].emiMatLoc[1] = mat[sta.ediMat].emiMatLoc[0];

	for(i=0; i<4; i++) {
		mat[sta.ediMat].ambMat[1][i] = mat[sta.ediMat].ambMat[0][i];
		mat[sta.ediMat].difMat[1][i] = mat[sta.ediMat].difMat[0][i];
		mat[sta.ediMat].speMat[1][i] = mat[sta.ediMat].speMat[0][i];
		mat[sta.ediMat].emiMat[1][i] = mat[sta.ediMat].emiMat[0][i];
	}

	mat[sta.ediMat].shiMat[1] = mat[sta.ediMat].shiMat[0];

	updMatWid();
	updateGL();
}


/** *************************************************************************
 ** ENTIRE STUFF
****************************************************************************/

/** Entire background colour */
void OGLWidget::lmball(const int channel, const int intensity) {
	if(ent.bacEntLoc && channel<3) {
		for(int i=0; i<3; i++)
				ent.bacLig[i]=intensity/255.0f;
		emit updEntWid();
	}
	else
		ent.bacLig[channel]=intensity/255.0f;
	updateGL();
}

/** Entire ambient light modell */
void OGLWidget::lmaall(const int channel, const int intensity) {
	if(ent.ambEntLoc && channel<3) {
		for(int i=0; i<3; i++)
				ent.modLig[i]=intensity/255.0f;
		emit updEntWid();
	}
	else
		ent.modLig[channel]=intensity/255.0f;
	updateGL();
}


/** *************************************************************************
 ** LEGENDS
****************************************************************************/

/** Render axes legends */
void OGLWidget::renderXYZ() {
	const QString empty("");

	/** x */
	labelFont.setPointSize(rf2i(leg.rfsize[0]));
	if(leg.enabled[0])
		renderText( 1.5+leg.xOffs[0], -0.1+leg.yOffs[0], 0.0, leg.label[0], labelFont);
	else
		renderText( 1.5+leg.xOffs[0], -0.1+leg.yOffs[0], 0.0, "", labelFont);

	/** y */
	labelFont.setPointSize(rf2i(leg.rfsize[1]));
	if(leg.enabled[1])
		renderText( 0.1+leg.xOffs[1],  1.5+leg.yOffs[1], 0.0, leg.label[1], labelFont);
	else
		renderText( 0.1+leg.xOffs[1],  1.5+leg.yOffs[1], 0.0, empty, labelFont);

	/** z */
	labelFont.setPointSize(rf2i(leg.rfsize[2]));
	if(leg.enabled[2])
		renderText(-0.1+leg.xOffs[2], -0.1+leg.yOffs[2], 1.5, leg.label[2], labelFont);
	else
		renderText(-0.1+leg.xOffs[2], -0.1+leg.yOffs[2], 1.5, empty, labelFont);
}

/** Draws axes */
void OGLWidget::Draw_Axes(void) {
	const float delta=0.027f;

	/** Set colour and draw xyz-labels */
	glColor3f(sta.axisCol[0], sta.axisCol[1], sta.axisCol[2]);
	renderXYZ();

	/** Draw axes-lines */
	glDisable(GL_LIGHTING);
	glBegin(GL_LINES);
	glVertex3f( 0.0f, 0.0f, 0.0f);
	glVertex3f( 1.5f, 0.0f, 0.0f);

	glVertex3f( 0.0f, 0.0f, 0.0f);
	glVertex3f( 0.0f, 1.5f, 0.0f);

	glVertex3f( 0.0f, 0.0f, 0.0f);
	glVertex3f( 0.0f, 0.0f, 1.5f);
	glEnd();

	/** Draw arrows */
	if(sta.wired)
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	glBegin(GL_TRIANGLES);
	glVertex3f(1.5f, -delta, 0.0f);
	glVertex3f(1.5f,  delta, 0.0f);
	glVertex3f(1.5f+2.0f*delta, 0.0f, 0.0f);

	glVertex3f(-delta, 1.5f, 0.0f);
	glVertex3f( delta, 1.5f, 0.0f);
	glVertex3f(  0.0f, 1.5f+2.0f*delta, 0.0f);

	glVertex3f(-delta, 0.0f, 1.5f);
	glVertex3f( delta, 0.0f, 1.5f);
	glVertex3f(  0.0f, 0.0f, 1.5f+2.0f*delta);
	glEnd();

	/** Reset fill-mode when necessary */
	if(sta.wired)
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glEnable(GL_LIGHTING);
}

/** Draw measuring cross */
void OGLWidget::Draw_Cross(void) {

	/** Set colour */
	glColor3f(sta.axisCol[0], sta.axisCol[1], sta.axisCol[2]);

	/** Cross-size */
	const float delta=0.15f;

	/** Draw it */
	glDisable(GL_LIGHTING);
	glBegin(GL_LINES);
	glVertex2f(sta.crossX-delta,  sta.crossY);
	glVertex2f(sta.crossX+delta,  sta.crossY);
	glVertex2f(sta.crossX,        sta.crossY-delta);
	glVertex2f(sta.crossX,        sta.crossY+delta);
	glVertex3f(sta.crossX,        sta.crossY, -2.0f);
	glVertex3f(sta.crossX,        sta.crossY,  2.0f);
	glEnd();
	glEnable(GL_LIGHTING);
}

/** Static legends */
void OGLWidget::renderLegends() {
	const QString empty("");
	const double p=actWidth/(double)actHeight;

	glViewport(0, 0, actWidth, actHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-p, p, -0.5, 0.5, -0.5, 0.5);
	glMatrixMode(GL_MODELVIEW);

	glDisable(GL_LIGHTING);
	for(int i=3; i<9; i++) {
		glColor3f(leg.ligLeg[i-3][0], leg.ligLeg[i-3][1], leg.ligLeg[i-3][2]);
		if(leg.enabled[i]) {
			labelFont.setPointSize(leg.rfsize[i]);
			renderText(0.0+leg.xOffs[i],  0.0+leg.yOffs[i], 0.49, leg.label[i], labelFont);
		}
		else {
			labelFont.setPointSize(leg.rfsize[i]);
			renderText(0.0+leg.xOffs[i],  0.0+leg.yOffs[i], 0.49, empty, labelFont);
		}
	}
	glEnable(GL_LIGHTING);

	glViewport(0, 0, actWidth, actHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(sta.angle, (double)actWidth/(double)actHeight, 3.0, 10.0);
	glMatrixMode(GL_MODELVIEW);
}


/** *************************************************************************
 ** CENTRAL DRAWING ROUTINE
****************************************************************************/
void OGLWidget::paintGL() {

	/** Delete framebuffer && Z-buffer */
	oglBusy=true;
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	/** Initialize modelview-matrix */
	glLoadIdentity();

	/** Spare uneccessary actions. Static legends to draw? */
	if(leg.genLeg)
		glPushMatrix();

	/** Set lights */
	for(long i=0; i<MAXLIG; i++) {

		/** Sitch lights on/off */
		if(lig[i].setLig)
			glEnable(lightBase+i);
		else
			glDisable(lightBase+i);

		/** Set light-positions with inf./local */
		lig[i].ligPos[3]=ent.modInf;
		glLightfv(lightBase+i, GL_POSITION, &lig[i].ligPos[0]);
		
		/** Set light-shares */
		glLightfv(lightBase+i, GL_AMBIENT,  &lig[i].ambLig[0]);
		glLightfv(lightBase+i, GL_DIFFUSE,  &lig[i].difLig[0]);
		glLightfv(lightBase+i, GL_SPECULAR, &lig[i].speLig[0]);

		/** Set attenution-factors */
		glLightfv(lightBase+i, GL_CONSTANT_ATTENUATION,  &lig[i].conAtt);
		glLightfv(lightBase+i, GL_LINEAR_ATTENUATION,    &lig[i].linAtt);
		glLightfv(lightBase+i, GL_QUADRATIC_ATTENUATION, &lig[i].quaAtt);

		/** Set spotlights */
		if(!lig[i].spoSta)
			glLightfv(lightBase+i, GL_SPOT_CUTOFF, noSpot);
		else
			glLightfv(lightBase+i, GL_SPOT_CUTOFF, &lig[i].spoCut);
		glLightfv(lightBase+i, GL_SPOT_EXPONENT, &lig[i].spoExp);
		glLightfv(lightBase+i, GL_SPOT_DIRECTION, &lig[i].spoDir[0]);

	}

	/** Entire/global part */
	glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, ent.modInf);
	glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, ent.modOne);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, &ent.modLig[0]);
	glClearColor(ent.bacLig[0], ent.bacLig[1], ent.bacLig[2], ent.bacLig[3]);

	/** Do model-transformations */
	glTranslatef(0.0f, 0.0f, -0.5f);
	glTranslatef(sta.transX, sta.transY , sta.transZ);
	glRotatef(sta.rotX, 1.0f, 0.0f, 0.0f);
	glRotatef(sta.rotY, 0.0f, 1.0f, 0.0f);
	glRotatef(sta.rotZ, 0.0f, 0.0f, 1.0f);

	/** Check polygon-mode */
	if(sta.wired)
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	else
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	/** And draw under current model-transformation finally
	 ** Distinguishes between motion blur on/off */
	if(mot.enabled) {
		glPushMatrix();
		glClear(GL_ACCUM_BUFFER_BIT);
		for(long i=0; i<mot.steps; i++) {
			if(sta.draw==0) Draw_Triangles();
			if(sta.draw==1) Draw_Quads();
			if(sta.draw==2) Draw_Points();
			glAccum(GL_MULT, mot.fac);
			glAccum(GL_ACCUM, 1.0f-mot.fac);
			glTranslatef(mot.trans, mot.trans, mot.trans);
		}
		glAccum(GL_RETURN, 1.0f);
		glPopMatrix();
	}
	else {
		if(sta.draw==0) Draw_Triangles();
		if(sta.draw==1) Draw_Quads();
		if(sta.draw==2) Draw_Points();
	}

	/** Axes, cross */
	if(sta.cross) Draw_Cross();
	if(sta.axes) Draw_Axes();

	/** Spare uneccessary actions. Static legends to draw? */
	if(leg.genLeg) {
		glPopMatrix();
		glClear(GL_DEPTH_BUFFER_BIT);
		renderLegends();
	}

	/** Rendering done */
	oglBusy=false;

} /** End of paintGL() */
