/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <cstdlib>
#include "property.h"
#include "pinterface.h"


/** Current OpenGL viewer dimensions */
int actWidth;
int actHeight;


/** Extern globals */
ZHULIG lig[MAXLIG];        // Light properties
ZHUMAT mat[MAXFUN+1];      // Material properties
ZHUENT ent;                // Entire OpenGL-properties
ZHUANI ani;                // Animation properties
ZHUMOR mor;                // Morphing properties
ZHUFUN fun[MAXFUN];        // The functions
ZHUISO iso[3];             // The imlicite functions
ZHUPAR par;                // Parameter properties
ZHUSTA sta;                // General status-values
ZHUTEX tex[MAXFUN+1];      // Texture properties
long texSpan;              // Texure span width just once
ZHUFOG fog;                // Fog properties
ZHUPIC pic;                // Picture dimensions
long solverPrec;           // Hold the internal precision, set from "appearance"
ZHUMOT mot;                // Motion blur effects
QString comment;           // Holds commentary
QString usr[MAXUSR];       // Holds the items for user defined functions/constants
long lastUsrEntry;         // Current last usr-entry. Counts from 1..MAXUSR, 0 otherwise
long fetchLastUsrEntry();
int numCPUset;             // Number of currently user defined threads
ZHULEG leg;                // Legends

QString ofun[MAXFUN];      // Remember orginal input strings ...
QString oiso[MAXFUN];
QString opar[MAXFUN];

bool usrErr[MAXUSR];       // Error stuff ...
bool funErr[MAXFUN];
QString bakfun[MAXFUN];
QString bakiso[MAXFUN];
QString bakpar[MAXFUN];
QString bakusr[MAXUSR];

QList<ITL> itl;         // Holds grid-subdivisions for iso-threads

float asecs;            // Timer animation
float msecs;            // Timer morphing
float zsecs;            // Timer zhumark for iso-calcs

/** Constant values */
const ZHUCON con={
		1.500f,    // Zoom-factor
		0.050f,    // Translation-factor
		1.001f,    // Superfine scale-factor
		1.009f,    // Fine scale-factor
		1.070f,    // Normal scale-factor
		1.300f,    // Coarse scale-factor
		1.250f     // Tessellation-factor
};


/** Backup to RAM */
static ZHULIG blig[MAXLIG];      // Light properties
static ZHUMAT bmat[MAXFUN+1];    // Material properties
static ZHUENT bent;              // Entire OpenGL-properties
static ZHUANI bani;              // Animation properties
static ZHUMOR bmor;              // Morphing properties
static ZHUFUN bfun[3];           // The function
static ZHUISO biso[3];           // The imlicite function
static ZHUPAR bpar;              // Parameter properties
static ZHUSTA bsta;              // General status-values
static ZHUTEX btex[MAXFUN+1];    // Texture properties
static long btexSpan;            // Texure span width just once
static ZHUFOG bfog;              // Fog properties
static ZHUMOT bmot;              // Motion blur effects
static QString bcomment;         // Holds commentary
QString busr[MAXUSR];            // Holds the items for user defined functions/constants
static ZHULEG bleg;              // Legends

QString bofun[3];    // Backup orginal input strings
QString boiso[3];    // Backup orginal input strings
QString bopar[3];    // Backup orginal input strings


/** *************************************************************************
 ** Calculate grid-subdivisions in iso-thread list
****************************************************************************/
void iniITL() {
	int off, tmp=numCPUset;
	ITL elem;

	/** Consider odd thread numbers */
	if(numCPUset>1)
		if((sta.tgrids%numCPUset)!=0)
			tmp=numCPUset-1;
	off=sta.tgrids/numCPUset;

	/** Entry for one thread in any case */
	itl.clear();
	elem.from = 0;
	elem.to = off;
	itl.append(elem);

	/** Generate rest of the list */
	for(long i=1; i<tmp; ++i) {
		elem.from += off;
		elem.to += off;
		itl.append(elem);
	}

	/** Consider odd thread numbers */
	if(elem.to!=sta.tgrids) {
		elem.from=elem.to;
		elem.to=sta.tgrids;
		itl.append(elem);
	}
}


/** *************************************************************************
 ** Copy a QString to a plain old character-string
****************************************************************************/
void q2cstrcpy(char *str, const QString qstr) {
	strcpy(str, qstr.toAscii().data());
}

char *q2cstrcpy(const QString qstr) {
	return qstr.toAscii().data();
}


/** *************************************************************************
 ** Round float to int
****************************************************************************/
int rf2i(const float f) {
   return (int)((f<0.0f) ? f-0.5f : f+0.5f);
}


/** *************************************************************************
 ** Kill blanks, replace $ ... for clean parser input
 ** Multiple usage in mainwindow, funedit, ...
****************************************************************************/
QString prepareInput(const QString s) {
	QString tmp=s;

	/** Comment at start? */
	if(tmp.isEmpty() || tmp.startsWith("#"))
		return tmp;

	/** Clean */
	tmp.remove(QChar(' '));
	tmp=tmp.toLower();
	tmp.replace('$','_');
	return tmp.section(QChar('#'),0,0);;
}


/** *************************************************************************
 ** Error handling
****************************************************************************/
bool fetchUsrError() {
	for(long i=0; i<MAXUSR; ++i)
		if(usrErr[i])
			return true;
	return false;
}

bool fetchFunError() {
	for(long i=0; i<MAXFUN; ++i)
		if(funErr[i])
			return true;
	return false;
}

void iniErr() {
	long i;
	for(i=0; i<MAXUSR; ++i)
		usrErr[i]=false;
	for(i=0; i<MAXFUN; ++i)
		funErr[i]=false;
}


/** *************************************************************************
 ** USER-ITEMS STUFF
****************************************************************************/

/** Count from 1..MAXUSR. Returns 0 when table is empty */
long fetchLastUsrEntry() {
	for(long i=MAXUSR-1; i>=0; i--)
		if(!usr[i].isEmpty() && !usr[i].startsWith("#"))
			return i+1;
	return 0;
}

void iniUsr() {
	for(long i=0; i<MAXUSR; ++i) {
		usr[i]=(QString)"\0";
		usrErr[i]=false;
	}
	lastUsrEntry=0;
}


/** *************************************************************************
 ** INITIALIZE LIGHTS WITH DEFAULT-VALUES
****************************************************************************/
void iniLig() {
	long i, j;

	/** Set common values */
	for(i=0; i<MAXLIG; ++i) {

		/** Set all alpha-channels 1.0f */
		lig[i].ambLig[3]=1.0f;
		lig[i].difLig[3]=1.0f;
		lig[i].speLig[3]=1.0f;

		/** Booleans */
		lig[i].setLig=false;
		lig[i].ambLigLoc=true;
		lig[i].difLigLoc=true;
		lig[i].speLigLoc=true;

		/** Colour settings */
		for(j=0; j<3; ++j) {
			lig[i].ambLig[j]=0.15f;
			lig[i].difLig[j]=0.95f;
			lig[i].speLig[j]=0.25f;
			lig[i].spoDir[j]=0.0f;
		}

		/** Spotlight */
		lig[i].spoSta=false;
		lig[i].spoExp=30.0f;
		lig[i].spoCut=5.0f;

		/** Attenuation */
		lig[i].conAtt=1.0f;
		lig[i].linAtt=0.0f;
		lig[i].quaAtt=0.0f;
	}

	/** Switch light 0 and 7 on */
	lig[0].setLig=lig[7].setLig=true;

	/** Set parameters for spotlight 0 */
	lig[0].spoDir[0]= 0.10f;
	lig[0].spoDir[1]=-0.05f;
	lig[0].spoDir[2]=-0.60f;

	/** Set all light-positions to positional light */
	for(i=0; i<MAXLIG; ++i) lig[i].ligPos[3]=1.0f;

	/** Set "forground" light-positions */
	lig[0].ligPos[0]=-1.0f; lig[0].ligPos[1]= 1.0f; lig[0].ligPos[2]= 1.0f;
	lig[1].ligPos[0]=-1.0f; lig[1].ligPos[1]=-1.0f; lig[1].ligPos[2]= 1.0f;
	lig[2].ligPos[0]= 1.0f; lig[2].ligPos[1]=-1.0f; lig[2].ligPos[2]= 1.0f;
	lig[3].ligPos[0]= 1.0f; lig[3].ligPos[1]= 1.0f; lig[3].ligPos[2]= 1.0f;

	/** Set "background" light-positions */
	lig[4].ligPos[0]=-1.0f; lig[4].ligPos[1]= 1.0f; lig[4].ligPos[2]=-5.0f;
	lig[5].ligPos[0]=-1.0f; lig[5].ligPos[1]=-1.0f; lig[5].ligPos[2]=-5.0f;
	lig[6].ligPos[0]= 1.0f; lig[6].ligPos[1]=-1.0f; lig[6].ligPos[2]=-5.0f;
	lig[7].ligPos[0]= 1.0f; lig[7].ligPos[1]= 1.0f; lig[7].ligPos[2]=-5.0f;

	/** Set light-distances */
	for(i=0; i<MAXLIG/2; ++i) lig[i].ligDis=10;         // "Foreground"
	for(i=MAXLIG/2; i<MAXLIG; ++i) lig[i].ligDis=50;    // "Background"
}


/** *************************************************************************
 ** INITIALIZE MATERIALS WITH DEFAULT-VALUES
****************************************************************************/
void iniMat() {
	long i, j;

	/** Set all alpha-channels 1.0f */
	for(i=0; i<2; ++i)
		for(j=0; j<MAXFUN+1; ++j) {
			mat[j].ambMat[i][3]=1.0f;
			mat[j].difMat[i][3]=1.0f;
			mat[j].speMat[i][3]=1.0f;
			mat[j].emiMat[i][3]=1.0f;

			mat[j].ambMatLoc[i]=false;
			mat[j].difMatLoc[i]=false;
			mat[j].speMatLoc[i]=false;
			mat[j].emiMatLoc[i]=false;
			mat[j].shiMat[i]=10.0f;
		}

	/** One-sided surfaces */
	for(i=0; i<MAXFUN+1; ++i)
		mat[i].twoSid=false;

	/** Set common values for front-side and back-side */
	for(i=0; i<MAXFUN+1; ++i)
		for(j=0; j<3; ++j) {
			/** Front */
			mat[i].ambMat[0][j]=0.1f;
			mat[i].difMat[0][j]=0.2f;
			mat[i].speMat[0][j]=0.25f;
			mat[i].emiMat[0][j]=0.0f;
			/** Back */
			mat[i].ambMat[1][j]=0.1f;
			mat[i].difMat[1][j]=0.9f;
			mat[i].speMat[1][j]=0.25f;
			mat[i].emiMat[1][j]=0.0f;
		}

	/** Set default RGB-values */
	mat[0].difMat[0][0]=0.9f;     // Function 0 red
	mat[1].difMat[0][1]=0.6f;     // Function 1 Green
	mat[2].difMat[0][2]=0.9f;     // Function 2 Blue
	mat[2].difMat[0][1]=0.35f;    // Function 2 Blue

	mat[3].difMat[0][0]=0.9f;     // Parametric
	mat[3].difMat[0][1]=0.4f;
}


/** *************************************************************************
 ** INITIALIZE ENTIRE LIGHT WITH DEFAULT-VALUES
****************************************************************************/
void iniEnt() {
	ent.ambEntLoc=true;    // Lock RGB-values
	ent.bacEntLoc=true;    // Lock RGB-values
	ent.modInf=1.0f;       // Default modell-view is local
	ent.modOne=0.0f;       // Default modell-view is 1-sided

	// Background light
	ent.bacLig[0]=0.35f;
	ent.bacLig[1]=0.35f;
	ent.bacLig[2]=0.35f;
	ent.bacLig[3]=1.0f;

	// Model ambient light
	ent.modLig[0]=0.0f;
	ent.modLig[1]=0.0f;
	ent.modLig[2]=0.0f;
	ent.modLig[3]=1.0f;
}


/** *************************************************************************
 ** INITIALIZE ANIMATION WITH DEFAULT-VALUES
****************************************************************************/
void iniAni() {
	ani.xFac=0;          // Factor for x-rotation; [0..500]
	ani.yFac=0;          // Factor for y-rotation; [0..500]
	ani.zFac=120;        // Factor for z-rotation; [0..500]
	ani.fps=30;          // Frames per second
	ani.locXYZ=false;    // X,Y,Z-sliders locked? bool
	ani.active=false;    // Not active; bool
}


/** *************************************************************************
 ** INITIALIZE MORPHING WITH DEFAULT-VALUES
****************************************************************************/
void iniMor() {
	mor.active=false;    // Not active; bool
	mor.lower=-1.0f;     // Upper/lower bounds
	mor.upper=1.0f;
	mor.steps=44;        // Steps [1..100]
	mor.val=0.0f;        // Current value. Changed during morphing
	mor.fps=22;          // Frames per second
}


/** *************************************************************************
 ** INITIALIZE PIC-DIMENSIONS WITH DEFAULT-VALUES
****************************************************************************/
void iniPic() {
	pic.xDim=0;        // Dummy-value, updated later
	pic.yDim=0;        // Dummy value, updated later
	pic.locXY=true;    // X/Y-values locked? bool
	pic.quality=85;    // Quality 0..100
	pic.dpi=100;       // Dpi
	pic.fmt=PNG;       // PNG=default
}


/** *************************************************************************
 ** INITIALIZE ALL FUNCTIONS
****************************************************************************/
void iniFun() {

	for(long i=0; i<MAXFUN; ++i) {
		q2cstrcpy(fun[i].str, "\0");
		q2cstrcpy(iso[i].str, "\0");
		q2cstrcpy(par.str[i], "\0");

		ofun[i]="\0";
		oiso[i]="\0";
		opar[i]="\0";

		fun[i].drawFun=false;
		iso[i].drawIso=false;
	}

	/** Extra parameter stuff only once */
	par.drawPar=false;
	par.sLow = par.tLow = -3.14159265f;
	par.sHig = par.tHig =  3.14159265f;

	/** Show function 0 */
	fun[0].drawFun=true;
}


/** *************************************************************************
 ** INITIALIZE STATUS
****************************************************************************/
void iniSta() {

	sta.angle = 35.0;          // Initial angle for perspective

	sta.rotX = 0.0f;           // Initial values for rotations
	sta.rotY = 0.0f;
	sta.rotZ = 0.0f;

	sta.transX =  0.0f;        // Initial values For translations
	sta.transY =  0.0f;
	sta.transZ = -5.0f;

	sta.crossX = 0.5f;         // Initial coordinates for measuring-cross
	sta.crossY = 0.5f;

	sta.sa = 1.0f;             // Initial scale-factor over all
	sta.sx = 1.0f;             // Initial x,y,z scale-factors for the functions
	sta.sy = 1.0f;
	sta.sz = 1.0f;
	sta.spx = 1.0f;            // Initial x,y,z scale-factors for parametric view
	sta.spy = 1.0f;
	sta.spz = 1.0f;

	sta.tessWidth = 0.025f;    // Initial widht for the tessellations
	sta.fgrids=60;             // Initial number of function gridlines

	sta.cross=false;           // Measuring-Cross
	sta.axes=true;             // Axes
	sta.wired=false;           // Polygon/full-mode
	sta.draw=0;                // 0=Triangles, 1=Quads, 2=Points

	sta.ediLig=0;              // Edit light 0
	sta.ediMat=0;              // Edit function 0
	sta.funMod=FUNCTION;       // Functions

	// White colour for axes/xyz-labels is default
	for(long i=0; i<4; ++i)
		sta.axisCol[i]=1.0f;

	sta.triMod=CUBES;          // ISO triangulation mode
	sta.tgrids=24;             // ISO mesh

	comment="";                // Comment text
}


/** *************************************************************************
 ** INITIALIZE TEXURES
****************************************************************************/
void iniTex() {

	for(long i=0; i<MAXFUN+1; ++i) {
		tex[i].name="";
		tex[i].enabled=false;
		tex[i].flip=false;
		tex[i].hSize=0;
		tex[i].vSize=0;
		FREE(tex[i].data);
	}
	texSpan=16;
}


/** *************************************************************************
 ** INITIALIZE FOG
****************************************************************************/
void iniFog() {

	fog.enabled=false;         // Bool
	fog.fogLigLoc=true;        // Bool
	for(long i=0; i<3; ++i)    // Fog light shares
		fog.fogLig[i]=0.5f;
	fog.fogLig[3]=1.0f;
	fog.fogType=2;             // 0=GL_EXP  1=GL_EXP2  2=GL_LINEAR
	fog.intensity=15;          // Internal value 0.0-1.0    Slider: 0-100
	fog.start=30;              // Internal value 0.0-10.0   Slider: 0-100
	fog.end=50;                // Internal value 0.0-10.0   Slider: 0-100
}


/** *************************************************************************
 ** INITIALIZE MOTION BLUR
****************************************************************************/
void iniMot() {

	mot.enabled=false;    // Bool
	mot.steps=3;          // How often is blur translation applied?
	mot.fac=0.25f;        // The motion blur factor
	mot.trans=0.005f;     // Amount of translation for each step
}


/** *************************************************************************
 ** INITIALIZE LEGENDS
****************************************************************************/
void iniLeg() {
	long i, j;

	leg.savWidth=actWidth;
	leg.savHeight=actHeight;

	leg.label[0]="x";
	leg.label[1]="y";
	leg.label[2]="z";

	/** All labels */
	for(i=0; i<9; ++i) {
		leg.wfsize[i]=10;
		leg.rfsize[i]=10;
		leg.xOffs[i]=0.0f;
		leg.yOffs[i]=0.0f;
		leg.enabled[i]=true;
		leg.locLeg[i]=true;
		leg.prop[i]=leg.rfsize[i]/(float)actHeight;
	}

	/** Static labels */
	for(i=3; i<9; ++i) {
		leg.label[i]="";
		leg.enabled[i]=false;
	}

	/** Fonts */
	for(i=0; i<9; ++i) {
	#if !(defined(WINDOWS) || defined(WIN32) || defined(WIN64))
			leg.font[i]="System";
		#else
			leg.font[i]="MS Sans Serif";
		#endif
		leg.style[i]="Normal";
	}

	/** The alpha-channel is never changed */
	for(i=0; i<6; ++i)
		for(j=0; j<4; ++j)
			leg.ligLeg[i][j]=1.0f;

	/** Never saved in XML */
	leg.offs=0.003f;
	leg.curRow=0;
	leg.genLeg=false;
	leg.locMou=false;
}


/** *************************************************************************
 ** BACKUP-PROCEDURES
****************************************************************************/
void saveToRam() {
	long i;

	/** Lights */
	for(i=0; i<MAXLIG; ++i)
		blig[i] = lig[i];

	/** Materials & textures */
	for(i=0; i<MAXFUN+1; ++i) {
		bmat[i] = mat[i];
		btex[i] = tex[i];
	}

	/** Functions */
	for(i=0; i<MAXFUN; ++i) {
		bfun[i] = fun[i];
		biso[i] = iso[i];
		bofun[i] = ofun[i];
		boiso[i] = oiso[i];
		bopar[i] = opar[i];
	}
	bpar = par;

	/** User items */
	for(i=0; i<MAXUSR; ++i)
		busr[i] = usr[i];

	bent = ent;            // Entire
	bani = ani;            // Animation
	bmor = mor;            // Morphing
	bsta = sta;            // Status
	bpar = par;            // Parameter properties
	btexSpan = texSpan;    // Texture span
	bfog = fog;            // Fog
	bmot = mot;            // Motion blur
	bcomment = comment;    // Comment
	bleg = leg;            // Legends
}


void restoreFromRam() {
	long i;

	/** Lights */
	for(i=0; i<MAXLIG; ++i)
		lig[i] = blig[i];

	/** Materials & textures */
	for(i=0; i<MAXFUN+1; ++i) {
		mat[i] = bmat[i];
		tex[i] = btex[i];
	}

	/** Functions */
	for(i=0; i<MAXFUN; ++i) {
		fun[i] = bfun[i];
		iso[i] = biso[i];
		ofun[i] = bofun[i];
		oiso[i] = boiso[i];
		opar[i] = bopar[i];
	}
	par = bpar;

	/** User items */
	for(i=0; i<MAXUSR; ++i)
		usr[i] = busr[i];

	ent = bent;            // Entire
	ani = bani;            // Animation
	mor = bmor;            // Morphing
	sta = bsta;            // Status
	par = bpar;            // Parameter properties
	texSpan = btexSpan;    // Texture span
	fog = bfog;            // Fog
	mot = bmot;            // Motion blur
	comment = bcomment;    // Comment
	leg = bleg;            // Legends
}
