/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _PINTERFACE_H_
#define _PINTERFACE_H_

#include <QObject>
#include <QString>

#include "./warp/fparser.h"
#include "debug.h"

#define PCOUNT 9


/** Global parsers */
extern FunctionParser fpGL[PCOUNT];


/** Global functions */
int initAllParsers(void);


/** Minimal class for retranslating error messages in Qt 4.x */
class fpError {

	private:

	static const char *eString[];    // Error messages as plain C-strings
	static QString eQString[];       // Error messages as QString-strings

	public:

	fpError() {};
	~fpError() {};

	static void initParserQt(void);
	static QString getQtMessage(const int n) { return eQString[n]; }
};

/** _PINTERFACE_H_ */
#endif
