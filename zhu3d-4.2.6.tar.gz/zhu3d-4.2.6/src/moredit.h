/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _MOREDITOR_H_
#define _MOREDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>
#include <QTimer>

#include "ui_moredit.h"
#include "pinterface.h"
#include "property.h"
#include "timers.h"
#include "version.h"
#include "debug.h"


/** Handles morphing */
class morWidget : public QWidget, private Ui::morUI {

Q_OBJECT

public:
	morWidget(QWidget *parent=0);
	~morWidget() { timer->stop(); }

	void updMorWid();
	void morph(bool b) { if((mor.active=b)) timer->start(1000/mor.fps); else timer->stop(); }

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

private slots:

	/** Lower/upper bounds and steps in between */
	void fromSlot(const double f) { if(f<(mor.upper-0.1)) mor.lower=(float)f; else { mor.lower=mor.upper-0.1f; updMorWid(); } }
	void toSlot(const double f) { if(f>(mor.lower+0.1)) mor.upper=(float)f; else { mor.upper=mor.lower+0.1f; updMorWid(); } }
	void stepsSlot(const int i) { mor.steps=i; updMorWid(); }

	/** Start/stop morphing */
	void pushMorphSlot();
	void workSlot();

	/** Frames per second */
	void fpsSlot(const int fps);

signals:
	void gotNewMorph();    // Inform OpenGL viewer about new morph event
	void updMaiWid();      // Update mainwindow

private:
	float val;
	QTimer *timer;
	int load;              // Current CPU/GPU utilization

	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _MOREDITOR_H_ */
#endif
