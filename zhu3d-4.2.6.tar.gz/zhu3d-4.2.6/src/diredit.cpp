/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <QFileDialog>
#include "diredit.h"
#include "demedit.h"
#include "paths.h"


/** Globals needed from maiWin, oglEdi and speEdi */
QString workDir;
QString texDir;


/** For reloading file-list after directory switch */
extern demWidget *demEdi;


/** Constructor */
dirWidget::dirWidget(QWidget *parent) : QWidget(parent) {

	/** Set up directories editor */
	Ui_dirUI::setupUi(this);
	setMinimumSize(260, 80);
	setWindowTitle(tr("Directories"));

	/** Set current directories */
	workDir=MYWORKDIR;
	texDir=MYTEXDIR;

	/** Get remembered settings und update directory entries */
	readSettings();
	updDirWid();

	/** Set icons */
	pushWork->setIcon(QPixmap(QString(":/images/open.png")));
	pushTex->setIcon(QPixmap(QString(":/images/open.png")));

	/** Connections */
	connect(pushWork, SIGNAL(clicked()), this, SLOT(getNewWorkDir()));
	connect(pushTex,  SIGNAL(clicked()), this, SLOT(getNewTexDir()));
}


/** *************************************************************************
 ** GET NEW DIRECTORIES
****************************************************************************/
void dirWidget::getNewWorkDir() {

	/** Consider directories only */
	QString dir = QFileDialog::getExistingDirectory (
						this,
						tr("Set new directory"),
						curWork->text(),
						QFileDialog::DontResolveSymlinks | QFileDialog::ShowDirsOnly
					);

	// Windows and Qt >= 4.5.1 don't have a trailing "/"
    if(!dir.isEmpty()) {
		if(!dir.endsWith("/"))
			dir+="/";
        curWork->setText(dir);
		workDir=dir;
		demEdi->initDirList();
	}
}

void dirWidget::getNewTexDir() {

	/** Consider directories only */
	QString dir = QFileDialog::getExistingDirectory (
						this,
						tr("Set new directory"),
						curTex->text(),
						QFileDialog::DontResolveSymlinks | QFileDialog::ShowDirsOnly
					);

	// Windows and Qt >= 4.5.1 don't have a trailing "/"
    if(!dir.isEmpty()) {
		if(!dir.endsWith("/"))
			dir+="/";
        curTex->setText(dir);
		texDir=dir;
	}
}


/** *************************************************************************
 ** UPDATE
****************************************************************************/
void dirWidget::updDirWid() {
	curWork->setText(workDir);
	curTex->setText(texDir);
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void dirWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_dirUI::retranslateUi(this);
		setWindowTitle(tr("Directories"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void dirWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void dirWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("DirWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("DirWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() !=0) {
		workDir=settings.value("CurrentWorkDir").toString();
		texDir=settings.value("CurrentTexDir").toString();
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(500, 120));
		move(QPoint(220, 320));
	}
}

void dirWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("DirWindowPos", pos());
	settings.setValue("DirWindowSize", size());
	settings.setValue("CurrentWorkDir", workDir);
	settings.setValue("CurrentTexDir", texDir);
}
