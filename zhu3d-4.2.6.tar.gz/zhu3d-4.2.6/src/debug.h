/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _DEBUG_H_
#define _DEBUG_H_


/** Enable/disable in zhu3d.pro */
#ifdef ZHUDEBUG
	#include <QtDebug>
	#include <QApplication>
	#include <stdio.h>
	#include "error.h"
	extern errWidget *errEdi;
	#define PRINT(message) errEdi->print(message); QApplication::processEvents()
#else
	#define PRINT(message) /* */
#endif


/** _DEBUG_H_ */
#endif
