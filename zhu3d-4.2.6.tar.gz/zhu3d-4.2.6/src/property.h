/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _PROPERTY_H_
#define _PROPERTY_H_

#include <QByteArray>
#include <QString>
#include <QList>
#include <GL/gl.h>

#include "debug.h"

#define MAXLIG 8      // Number of lights
#define MAXFUN 3      // Number of functions/materials
#define MAXLEN 512    // Maximum string lenght for functions
#define MAXUSR 64     // Maximum number of user defined table entries
#define MAXCPU 8      // Maximum number of CPU cores = 16 threads
#define MINFON 6      // Minimum font sizes

/** Make GUI more responsive */
#define PROC_EVENT QApplication::processEvents()

/** A clean and safe version of free() */
#define FREE(pt) { if(pt!=NULL) { free(pt); pt=NULL; } }


/** Type-definitions for clarity */
typedef float RGBA[4];    // Red,green,blue,alpha
typedef float XYZM[4];    // x,y,z-mode; mode==0=directional  mode==1=position
typedef float XYZ[3];     // Coordinates


enum funMod {FUNCTION, IMPLICITE, PARAMETER};
enum picFmt {PNG, JPG, PDF, PS};
enum triTyp {CUBES, TETRAS};


/** Light property-type */
struct ZHULIG {
	long setLig;       // Individual light on?
	long ambLigLoc;    // Ambient RGB-sliders locked? bool
	long difLigLoc;    // Diffuse RGB-sliders locked? bool
	long speLigLoc;    // Specular RGB-sliders locked? bool

	long ligDis;       // Light distance; slider=[0,100]; default=10
	XYZM ligPos;       // Light position; internal=[0.0,10.0]; default=1.0

	RGBA ambLig;       // Ambient light
	RGBA difLig;       // Diffuse light
	RGBA speLig;       // Specular light (shininess)

	long  spoSta;      // Spotlight enabled?
	float spoExp;      // Spotlight intensity; slider=[0,45]; internal={0,135]
	float spoCut;      // Spotlight cutoff-angle; slider=internal=[0,45]; 180=off
	XYZ   spoDir;      // Spotlight direction-vector

	float conAtt;      // Constant attenuation; slider=[0,255]; internal=[0.0,2.55]
	float linAtt;      // Linear attenuation
	float quaAtt;      // Quadratic attenuation
};


/** Material property-type
 ** mat[0]..front-side; mat[1]..back-side */
struct ZHUMAT {
	long ambMatLoc[2];    // Ambient RGB-sliders locked? bool
	long difMatLoc[2];    // Diffuse RGB-sliders locked? bool
	long speMatLoc[2];    // Specular RGB-sliders locked? bool
	long emiMatLoc[2];    // Emission RBG-sliders locked? bool
	RGBA ambMat[2];       // Ambient material
	RGBA difMat[2];       // Diffuse material
	RGBA speMat[2];       // Specular material for shininess
	RGBA emiMat[2];       // Emission material
	float shiMat[2];      // Shininess; slider=internal=[0,128]
	long twoSid;          // Back-side button set? bool
};


/** Entire OpenGL-property-type */
struct ZHUENT {
	long ambEntLoc;    // Ambient RGB-sliders locked? bool
	long bacEntLoc;    // Background RGB-sliders locked? bool
	RGBA modLig;       // Entire ambient RGBA-light
	RGBA bacLig;       // Entire background colour
	float modInf;      // Modes: infinite=0.0 local=1.0; defaul=local
	float modOne;      // Modes: 1-sided=0.0 2-sided=1.0; default=1-sided
};


/** Animation-property-type */
struct ZHUANI {
	long xFac;      // Factor for x-rotation; [0..100]
	long yFac;      // Factor for y-rotation; [0..100]
	long zFac;      // Factor for z-rotation; [0..100]
	long fps;       // Frames per second
	long locXYZ;    // X,Y,Z-sliders locked? bool
	long active;    // Currently active? bool
};


/** Morphing-property-type */
struct ZHUMOR {
	long active;    // Currently active? bool
	float lower;    // Lower/upper bounds
	float upper;
	long steps;     // Steps 1..100
	float val;      // Current value
	long fps;       // Frames per second
};


/** The function-type */
struct ZHUFUN {
	char str[MAXLEN];    // Plain old Ascii-string
	long drawFun;        // Function to draw; bool
};


/** The Iso-type */
struct ZHUISO {
	char str[MAXLEN];    // Plain old Ascii-string
	long drawIso;        // Function to draw; bool
};


/** The parameter-type */
struct ZHUPAR {
	char str[3][MAXLEN];    // Strings for u(s,t), v(s,t), w(s,t)
	long drawPar;           // Parametric view to draw; bool
	float sLow, sHig;       // Interval: sLow < s < sHig
	float tLow, tHig;       // Interval: tLow < t < tHig
};


/** Status value-type */
struct ZHUSTA {
	GLdouble angle;     // Viewing angle

	float rotX;         // For rotations
	float rotY;
	float rotZ;
	float transX;       // For translations
	float transY;
	float transZ;
	float crossX;       // For cross-coordinates
	float crossY;
	float crossZ;

	float sa;           // Initial scale-factor over all
	float sx;           // Initial x,y,z scale-factors for the functions
	float sy;
	float sz;
	float spx;          // Initial x,y,z scale-factors parametric view
	float spy;
	float spz;

	float tessWidth;    // Initial widht for the tessellations
	long fgrids;        // Initial number of function gridlines

	long cross;         // Show Measuring-Cross; bool
	long axes;          // Show Axes; bool
	long wired;         // Polygon/full-mode; bool
	long draw;          // 0=Triangles, 1=Quads, 2=Points

	long ediLig;        // Holds actual edited light 0..7
	long ediMat;        // Holds actual edited material 0..2
	long funMod;        // Function mode: enum {FUNCTION, IMPLICITE, PARAMETER}

	long triMod;        // ISO-triangulation: enum {CUBES, TETRAS};
	long tgrids;        // Initial number of implicite function gridlines

	RGBA axisCol;       // Axis and xyz-label colour from 0f..1f
};


/** The texture-type */
struct ZHUTEX {
	QString name;           // Name of current texture
	long enabled;           // Bool
	long flip;              // Bool
	long hSize;             // Horizontal size
	long vSize;             // Vertical size
	unsigned char *data;    // The data chunk in RGB byte order
};


/** The fog-type */
struct ZHUFOG {
	long enabled;      // Bool
	long fogLigLoc;    // Bool
	RGBA fogLig;       // Fog light shares
	long fogType;      // 0=GL_EXP 1=GL_EXP2 2=GL_LINEAR
	long intensity;    // 0.0-1.0  Slider: 0-100
	long start;        // 0.0-10.0 Slider: 0-100
	long end;          // 0.0-10.0 Slider: 0-100
};


/** The picture-type */
struct ZHUPIC {
	long xDim;       // x-dimension for snapshot
	long yDim;       // y-dimension for snapshot
	long locXY;      // x-y locked?; bool; default==true
	long quality;    // Quality 0..100
	long dpi;        // Dpi 50..4800
	long fmt;        // {PNG, JPG, PDF, PS}
};


/** Constant-type */
struct ZHUCON {
	float zoomFac;      // Determines zoom-factor
	float transFac;     // Determines translation
	float sfineFac;     // Determines superfine scaling-factor
	float fineFac;      // Determines fine scaling-factor
	float normalFac;    // Determines normal scaling-factor
	float coarseFac;    // Determines coarse scaling-factor
	float tessFac;      // Determines tessellation change
};


/** Motion blur-type */
struct ZHUMOT {
	long enabled;    // Bool
	long steps;      // How often is blur translation applied?
	float fac;       // The motion blur factor
	float trans;     // Amount of translation for each step
};


/** Grid-subdivisions for iso-thread list */
typedef struct {
	long from;    // From grid
	long to;      // To grid
} ITL;


/** Legends type */
struct ZHULEG {
	long savWidth;       // Window width saved with
	long savHeight;      // Window height saved with
	QString label[9];    // Labels 0..2 = x,y,z  3..8 = general
	long wfsize[9];      // Fontsize wanted
	long rfsize[9];      // Fontsize real
	float xOffs[9];      // Current x-offset
	float yOffs[9];      // Current y-offset
	long enabled[9];     // Bool
	long locLeg[9];      // Bool; colour sliders locked?
	float prop[9];       // Font prop = actWidth/fsize[..]
	RGBA ligLeg[6];      // Individual colours for static legends
	QString font[9];     // Font
	QString style[9];    // Font style

	// Never saved in XML:
	float offs;         // General offset
	long curRow;        // Current row
	long genLeg;        // Bool; is any general legend activated?
	long locMou;        // Bool; move with mouse?
};


/** Global access */
extern ZHULIG lig[MAXLIG];
extern ZHUMAT mat[MAXFUN+1];
extern ZHUENT ent;
extern ZHUANI ani;
extern ZHUMOR mor;
extern ZHUFUN fun[MAXFUN];
extern ZHUISO iso[MAXFUN];
extern ZHUPAR par;
extern ZHUSTA sta;
extern ZHUTEX tex[MAXFUN+1];
extern long texSpan;
extern ZHUFOG fog;
extern ZHUPIC pic;
extern const ZHUCON con;
extern QString ofun[MAXFUN];
extern QString oiso[MAXFUN];
extern QString opar[MAXFUN];
extern long solverPrec;
extern ZHUMOT mot;
extern QString comment;
extern QString usr[MAXUSR];
extern long lastUsrEntry;
extern long fetchLastUsrEntry();
extern QList<ITL> itl;
extern int numCPUset;
extern ZHULEG leg;


/** Error handling */
extern bool usrErr[MAXUSR];
extern bool funErr[MAXFUN];
extern QString bakfun[MAXFUN];
extern QString bakiso[MAXFUN];
extern QString bakpar[MAXFUN];


/** Current OpenGL viewer dimensions */
extern int actWidth;
extern int actHeight;


/** Global timer variables */
extern float asecs;    // Animation
extern float msecs;    // Morphing
extern float zsecs;    // Zhumarks


/** Init-procedures */
void iniLig();
void iniMat();
void iniEnt();
void iniAni();
void iniMor();
void iniFun();
void iniSta();
void iniPic();
void iniTex();
void iniFog();
void iniMot();
void iniUsr();
void iniITL();
void iniErr();
void iniLeg();


/** Miscellanous little helpers */
void  q2cstrcpy(char *str, const QString qstr);
char *q2cstrcpy(const QString qstr);
QString prepareInput(const QString s);
int rf2i(const float f);


/** Used in benchmark */
void saveToRam();
void restoreFromRam();


/** Error handling */
bool fetchUsrError();
bool fetchFunError();


/** _PROPERTY_H_ */
#endif
