/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
 ****************************************************************************/

#ifndef _CPUINFO_H_
#define _CPUINFO_H_

/** Timer stuff */
#include "timers.h"
#include "tsc.h"


/** Apple Mac OS. */
#if defined(Q_WS_MAC)
	#include <sys/types.h>
	#include <sys/param.h>
	#include <sys/sysctl.h>

/** Microsoft Windows */
#elif (defined(WINDOWS) || defined(WIN32) || defined(WIN64))
	#include <windows.h>

/** *nix or SGI/Irix */
#else
	#include <unistd.h>
	#include <sys/time.h>        // Set priority
	#include <sys/resource.h>    // Set priority
	#include <sched.h>           // Scheduling CPU cores

/** Includes */
#endif


/** Here sched.h does not work! Replace whole class with Apple compliant stuff */
#if defined(Q_WS_MAC)

/** Counting cores, checking frequency and endianess */
class CPUINFO {

	public:

	CPUINFO() {}
	~CPUINFO() {}

	/** Returns core-number on success, 0 otherwise */
	static int cores() {
		int tmp=0;

		int mib[2]={ CTL_HW, HW_NCPUINFO };
		int cpus;
		size_t size=sizeof(cpus);
		if(0==sysctl(mib, 2, &cpus, &size, NULL, 0))
			tmp=cpus;

    	return tmp;
	}

	/** Returns frequency in MHz units. Average some 50 ms measurements */
	static double MHz() {
		double tmp=0.0;
		TIMERS tim;
		TSC tsc;

		tsc.start(); tim.uwait(50000); tmp+=tsc.stop();
		tsc.start(); tim.uwait(50000); tmp+=tsc.stop();
		tsc.start(); tim.uwait(50000); tmp+=tsc.stop();

		return (tmp*0.00002)/3.0;
	}

	/** Check out endinaness dynamically */
	static bool isBigEndian() {
        unsigned int i=1;
        unsigned char *pt = (unsigned char *) &i;
        if(pt[0])
			return false;
		return true;
	}
};

/** End for Apple Mac OS section */
#else

/** Counting cores, checking frequency and endianess */
class CPUINFO {

	public:

	CPUINFO() {}
	~CPUINFO() {}

	/** Returns core-number on success, 0 otherwise */
	static int cores() {
		int tmp=0;

		/** Microsoft Windows */
		#if (defined(WINDOWS) || defined(WIN32) || defined(WIN64))
			SYSTEM_INFO si;
			GetSystemInfo(&si);
			tmp=si.dwNumberOfProcessors;

		/** SGI/Irix */
		#elif defined(sgi)
			#if defined(_SC_NPROC_ONLN)
				tmp=sysconf(_SC_NPROC_ONLN);
			#endif

		/** Linux/Unix */
		#else
			#if defined(_SC_NPROCESSORS_ONLN)
				tmp=sysconf(_SC_NPROCESSORS_ONLN);
			#endif

		#endif

    	return tmp;
	}

	/** Returns frequency in MHz units. Average some 50 ms measurements */
	static double MHz() {
		double tmp=0.0;
		TSC tsc;
		TIMERS tim;

		/** Set high priority to mimimize interrupts and lock to one CPU-core
		 ** default=0  PRIO_MIN=-20  but this works as root only!!! */
		#if !(defined(WINDOWS) || defined(WIN32) || defined(WIN64))
		int p = getpriority(PRIO_PROCESS, 0);
		setpriority(PRIO_PROCESS, 0, PRIO_MIN);

		cpu_set_t affinity_mask, a;
		sched_getaffinity(0, sizeof(a), &a);
		CPU_ZERO(&affinity_mask);
		CPU_SET(0, &affinity_mask);
		sched_setaffinity(0, sizeof(affinity_mask), &affinity_mask);
		#endif

		tsc.start(); tim.uwait(50000); tmp+=tsc.stop();
		tsc.start(); tim.uwait(50000); tmp+=tsc.stop();
		tsc.start(); tim.uwait(50000); tmp+=tsc.stop();

		/** Reset priority and enable all CPU cores again */
		#if !(defined(WINDOWS) || defined(WIN32) || defined(WIN64))
		setpriority(PRIO_PROCESS, 0, p);

		for(int i=0; i<cores(); ++i) {
			CPU_SET(i, &a);
			sched_setaffinity(i, sizeof(a), &a);
		}
		#endif

		return (tmp*0.00002)/3.0;
	}

	/** Check out endinaness dynamically */
	static bool isBigEndian() {
        unsigned int i=1;
        unsigned char *pt = (unsigned char *) &i;
        if(pt[0])
			return false;
		return true;
	}
};

/** *nix/Win */
#endif


/** _CPUINFO_H_ */
#endif
