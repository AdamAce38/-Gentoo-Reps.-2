/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _PICEDITOR_H_
#define _PICEDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>

#include "ui_picedit.h"
#include "property.h"
#include "version.h"
#include "debug.h"


/** Set properties for pictures saving */
class picWidget : public QWidget, private Ui::picUI {

Q_OBJECT

public:
	picWidget(QWidget *parent=0);
	~picWidget() {}
	void updPicWid();

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

private slots:
	void xDimSlot(const int xVal);
	void yDimSlot(const int yVal);
	void qualSlot(const int q) { qual->setValue(pic.quality=q); }
	void dpiSlot(const int d) { dpi->setValue(pic.dpi=d); }
	void picXYLocked() { pic.locXY=!pic.locXY; updPicWid(); }
	void pngSlot() { pic.fmt=PNG; switchBox(); }
	void jpgSlot() { pic.fmt=JPG; switchBox(); }
	void pdfSlot() { pic.fmt=PDF; switchBox(); }
	void psSlot()  { pic.fmt=PS; switchBox(); }

private:
	bool xset;           // For avoiding regressions
	bool yset;           // For avoiding regressions
	void switchBox();    // Set checkboxes

	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _PICEDITOR_H_ */
#endif
