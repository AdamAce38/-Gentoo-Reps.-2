/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _MATERIALEDITOR_H_
#define _MATERIALEDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>

#include "ui_matedit.h"
#include "property.h"
#include "version.h"
#include "debug.h"


/** Material editor */
class matWidget : public QWidget, private Ui::matUI {

Q_OBJECT

public:
	matWidget(QWidget *parent=0);
	~matWidget() {}

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

public slots:
	void updMatWid();

private:
	/** Settings stuff */
	void readSettings();
	void writeSettings();
};

/** _MATERIALEDITOR_H_ */
#endif
