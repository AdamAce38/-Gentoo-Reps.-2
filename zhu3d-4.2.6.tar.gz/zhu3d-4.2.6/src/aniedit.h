/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _ANIEDITOR_H_
#define _ANIEDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>
#include <QTimer>

#include "ui_aniedit.h"
#include "property.h"
#include "version.h"
#include "debug.h"


/** Class handles animation */
class aniWidget : public QWidget, private Ui::aniUI {

Q_OBJECT

public:
	aniWidget(QWidget *parent=0);
	~aniWidget() { timer->stop(); }

	void updAniWid();
	void animate(bool mode);

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

private slots:
	void xSlot(const int xVal);
	void ySlot(const int yVal);
	void zSlot(const int zVal);
	void aniXYZLocked() { ani.locXYZ = !ani.locXYZ; }
	void pushAniSlot();

	void workSlot();       // The heavy worker-function
	void fpsSlot(const int fps);

signals:
	void gotNewAni();      // Inform viewer to update OpenGL
	void updMaiWid();      // Update mainwindow */
	void updMaiInf();      // Update info section of mainwindow
	void saveFromAni();    // Inform mainwindow to save current model

	/** Mouse-slider synchronisation in main */
	void xRotationChanged(const int x);
	void yRotationChanged(const int y);
	void zRotationChanged(const int z);

private:
	/** Current CPU/GPU utilization */
	QTimer *timer;
	static const float offset;
	int load;

	/** Settings stuff */
	void readSettings();
	void writeSettings();
};


/** _ANIEDITOR_H_ */
#endif
