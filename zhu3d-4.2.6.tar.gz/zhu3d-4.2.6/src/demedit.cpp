/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "demedit.h"
#include "mainwindow.h"     // Loading files/redraw


/** Extern globals */
extern MaiWindow *maiWin;   // Loading files/redraw
extern bool oglBusy;        // Checking OpenGL state
extern QString workDir;     // Current default directories fetched from dirEdi


/** Constructor */
demWidget::demWidget(QWidget *parent) : QWidget(parent) {

	/** Basics */
	setMinimumSize(150, 40);
	setWindowTitle(tr("Demo"));
	readSettings();
	QSize iconSize(20, 20);

	/** Create buttons */
	slides = new QPushButton;
	slides->setIcon(QPixmap(QString(":/images/play.png")));
	slides->setIconSize(iconSize);

	backward = new QPushButton;
	backward->setIcon(QPixmap(QString(":/images/player_rew.png")));
	backward->setAutoRepeatInterval(750);
	backward->setAutoRepeat(true);
	backward->setIconSize(iconSize);

	forward = new QPushButton;
	forward->setIcon(QPixmap(QString(":/images/player_fwd.png")));
	forward->setAutoRepeatInterval(750);
	forward->setAutoRepeat(true);
	forward->setIconSize(iconSize);

	/** Make grid-layout */
	QGridLayout *grid = new QGridLayout;
	grid->addWidget(slides,   0, 0);
	grid->addWidget(backward, 0, 1);
	grid->addWidget(forward,  0, 2);
	setLayout(grid);

	/** Timer stuff */
	demTimer = new QTimer();
	demTimer->setInterval(3500);
	timerMode=false;

	/** Set tooltipps */
	reTranslate();

	/** Connections */
	connect(slides,   SIGNAL(clicked()), this, SLOT(slidesSlot()));
	connect(backward, SIGNAL(clicked()), this, SLOT(backwardSlot()));
	connect(forward,  SIGNAL(clicked()), this, SLOT(forwardSlot()));
	connect(demTimer, SIGNAL(timeout()), this, SLOT(forwardSlot()));
}


/** *************************************************************************
 ** SET-SLOTS
****************************************************************************/
void demWidget::slidesSlot() {

	// File list empty?
	if(!listOk)
		return;

	timerMode=!timerMode;
	if(timerMode) {
		slides->setIcon(QPixmap(QString(":/images/stop.png")));
		slides->setToolTip(tr("Stop slideshow"));
		forwardSlot();
		demTimer->start();
		emit slideshowOn(true);
	}
	else {
		slides->setIcon(QPixmap(QString(":/images/play.png")));
		slides->setToolTip(tr("Start slideshow"));
		demTimer->stop();
		emit slideshowOn(false);
	}
}

void demWidget::backwardSlot() {

	// File list empty?
	if(!listOk)
		return;

	/** Avoid any interferences or chances for a crash */
	if(oglBusy)
		return;

	// Show previous example
	if(curListPos<=0)
		curListPos=list.size()-1;
	else
		curListPos--;

	QFileInfo fileInfo=list.at(curListPos);
	maiWin->loadFile(workDir+fileInfo.fileName());
}


void demWidget::forwardSlot() {

	// File list empty?
	if(!listOk)
		return;

	/** Show next example */
	if(curListPos==list.size()-1)
		curListPos=0;
	else
		curListPos++;

	QFileInfo fileInfo=list.at(curListPos);
	maiWin->loadFile(workDir+fileInfo.fileName());
}

void demWidget::initDirList() {
	QDir dir(workDir);
	QStringList filter("*.zhu");

	dir.setNameFilters(filter);
	list=dir.entryInfoList();
	curListPos=-1;

	// File list empty?
	if(list.isEmpty())
		listOk=false;
	else
		listOk=true;
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void demWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		setWindowTitle(tr("Demo"));
		reTranslate();
	}
	else
		QWidget::changeEvent(event);
}

void demWidget::reTranslate() {

	/** Tooltipps */
	if(timerMode)
	slides->setToolTip(tr("Stop slideshow"));
	else
	slides->setToolTip(tr("Start slideshow"));
	backward->setToolTip(tr("Backward"));
	forward->setToolTip(tr("Forward"));
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-PROPERTIES
****************************************************************************/
void demWidget::closeEvent(QCloseEvent *event) {
	demTimer->stop();
	timerMode=false;
	slides->setIcon(QPixmap(QString(":/images/play.png")));
	emit slideshowOn(false);
	writeSettings();
	event->accept();
}

void demWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("DemWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("DemWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(190, 55));
		move(QPoint(420, 610));
	}
}

void demWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);

	settings.setValue("DemWindowPos", pos());
	settings.setValue("DemWindowSize", size());
}
