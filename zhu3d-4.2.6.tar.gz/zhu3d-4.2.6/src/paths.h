/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _PATHS_H_
#define _PATHS_H_

/** Consider eventual customizing for qmake within zhu3d.pri */
/** Note: These options may concern packagers only */


/** Where was Zhu3D originally started from? */
extern QString appPath;


/** Location of html-helpfiles */
#ifndef DOCDIR
	#define MYDOCDIR (appPath+"/doc/")
#else
	#define MYDOCDIR (QString(DOCDIR)+"/")
#endif


/** Location of system-files like startup/languages/icons ... */
#ifndef SYSDIR
	#define MYSYSDIR (appPath+"/system/")
	#define MYLANDIR (appPath+"/system/languages/")
#else
	#define MYSYSDIR (QString(SYSDIR)+"/")
	#define MYLANDIR (QString(SYSDIR)+"/languages/")
#endif


/** Location of work directory with the zhu-files */
#ifndef WORKDIR
	#define MYWORKDIR (appPath+"/work/")
#else
	#define MYWORKDIR (QString(WORKDIR)+"/")
#endif


/** Location of texture directory */
#ifndef TEXDIR
	#define MYTEXDIR (appPath+"/work/textures/")
#else
	#define MYTEXDIR (QString(TEXDIR)+"/")
#endif


/** Set default gui */
#ifndef DEFGUI
	#define MYDEFGUI (QString("Plastique"))
#else
	#define MYDEFGUI (QString(DEFGUI))
#endif


/** _PATHS_H_ */
#endif
