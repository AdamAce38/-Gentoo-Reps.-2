/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <QHeaderView>
#include <QGridLayout>
#include <QBrush>
#include <QColor>
#include "usredit.h"
#include "glwidget.h"


/** Extern globals */
extern QString zhuLocale;
extern QTranslator zhuTranslator;
extern OGLWidget *oglWid;


/** Constructor */
usrWidget::usrWidget(QWidget *parent) : QWidget(parent) {

	setWindowTitle(tr("User defined items"));
	readSettings();
	rebuild=true;
	createUsrTable();
	createActions();

	QGridLayout *mainLayout = new QGridLayout;
	mainLayout->addWidget(usrTable, 0, 0);
	setLayout(mainLayout);

	/** Cell changed */
	connect(usrTable, SIGNAL(cellChanged(int, int)), this, SLOT(entryChanged(const int , const int)));

	/** A fun-edi input was erroneous. This is fetched in oglWid */
	connect(oglWid, SIGNAL(parsersTainted(bool)), this, SLOT(lockUsrSlot(bool)));
}


/** Row count starts with 0 in good old C-tradition */
void usrWidget::entryChanged(const int r, const int c) {
	int err;
	static bool whiteMessage=false;
	static bool redMessage=false;
	static bool selMessage=false;
	QBrush brush(QColor(255,255,255));

	/** Avoid repeated rebuilts when deleting/inserting rows */
	if(!rebuild)
		return;

	/** This caused some headache:-) Changing colours emit a cellChanged event.
	 ** Same for error case. So avoid multiple recursions */
	if(whiteMessage || selMessage)
		return;

	/** Avoid recursions on the next deepest level too */
	if(redMessage) {
		for(int i=0; i<MAXUSR; i++) {
			selMessage=true;
			usrTable->item(i,c)->setFlags(Qt::ItemIsSelectable);
			selMessage=false;
		}
		selMessage=true;
		usrTable->item(r,c)->setFlags(Qt::ItemIsEnabled | Qt::ItemIsEditable);
		selMessage=false;
		return;
	}

	/** Fetch new entry */
	usrErr[r]=false;
	usr[r]=usrTable->item(r,c)->text();
	lastUsrEntry=fetchLastUsrEntry();
	blockinsdel=false;

	/** Rebuild all parsers with error check */
	if((err=initAllParsers()) != FunctionParser::FP_NO_ERROR) {
		QString message=fpError::getQtMessage(err)+"\n";
		QMessageBox::critical(
			this,
			tr("Alert"),
			message
		);
		usrErr[r]=true;
		brush.setColor(QColor(255,127,127));
		redMessage=true;
		usrTable->item(r,c)->setBackground(brush);
		redMessage=false;
		emit parsersTainted(true);
		blockinsdel=true;
		return;
	}

	/** Now all entries MUST be ok */
	for(int i=0; i<MAXUSR; i++) {
		selMessage=true;
		usrTable->item(i,c)->setFlags(Qt::ItemIsEnabled | Qt::ItemIsEditable);
		selMessage=false;
	}

	/** Update on success */
	brush.setColor(QColor(255,255,255));
	whiteMessage=true;
	usrTable->item(r,c)->setBackground(brush);
	whiteMessage=false;
	emit parsersTainted(false);
	iniITL();
	if(r+1<MAXUSR)
		usrTable->setCurrentCell(r+1,c);
	oglWid->gotNewItem();
}


void usrWidget::createUsrTable() {
	usrTable = new QTableWidget(0, 1);
	QStringList columnLabel(tr("Item"));

	usrTable->setHorizontalHeaderLabels(columnLabel);
	usrTable->horizontalHeader()->setResizeMode(0, QHeaderView::Stretch);
	usrTable->verticalHeader()->show();
	usrTable->setShowGrid(true);

	for(int i=0; i<MAXUSR; i++) {
		QTableWidgetItem *entryItem = new QTableWidgetItem(usr[i]);
		entryItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsEditable);
		usrTable->insertRow(i);
		usrTable->setItem(i, 0, entryItem);
	}
}


/** *************************************************************************
 ** ACTIONS
****************************************************************************/
void usrWidget::createActions() {

	delAction = new QAction(tr("Delete row"), this);
	connect(delAction, SIGNAL(triggered()), this, SLOT(delActionSlot()));

	insAction = new QAction(tr("Insert row"), this);
	connect(insAction, SIGNAL(triggered()), this, SLOT(insActionSlot()));
}

void usrWidget::contextMenuEvent(QContextMenuEvent *event) {
	QMenu menu(this);
	menu.addAction(delAction);
	menu.addAction(insAction);

	/** Check if rows can be deleted/inserted */
	if(usrTable->item(usrTable->currentRow(),0)->text().isEmpty() && usrTable->currentRow()<MAXUSR-1)
		delAction->setEnabled(true);
	else
		delAction->setEnabled(false);

	if(usrTable->item(usrTable->currentRow(),0)->text().startsWith("#"))
		delAction->setEnabled(true);

	if(usrTable->item(MAXUSR-1,0)->text().isEmpty() && usrTable->currentRow()<MAXUSR-1)
		insAction->setEnabled(true);
	else
		insAction->setEnabled(false);

	/** Last item-eval was erroneous */
	if(blockinsdel) {
		delAction->setEnabled(false);
		insAction->setEnabled(false);
	}

	menu.exec(event->globalPos());
}

void usrWidget::delActionSlot() {
	const int tmp=usrTable->currentRow();

	for(int i=tmp; i<MAXUSR-1; i++)
		usr[i]=usr[i+1];
	usr[MAXUSR-1]="";

	/** Avoid repeated rebuilts when deleting/inserting rows */
	rebuild=false;
	updUsrWid();
	rebuild=true;

	usrTable->setCurrentCell(tmp,0);
}

void usrWidget::insActionSlot() {
	const int tmp=usrTable->currentRow();

	for(int i=MAXUSR-1; i>tmp; i--)
		usr[i]=usr[i-1];
	usr[tmp]="";

	/** Avoid repeated rebuilts when deleting/inserting rows */
	rebuild=false;
	updUsrWid();
	rebuild=true;

	usrTable->setCurrentCell(tmp,0);
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void usrWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		setWindowTitle(tr("User defined items"));
		QStringList columnLabel(tr("Item"));
		delAction->setText(tr("Delete row"));
		insAction->setText(tr("Insert row"));
		usrTable->setHorizontalHeaderLabels(columnLabel);
	}
	else if(event->type() == QEvent::FontChange)
		usrTable->verticalHeader()->resizeSections(QHeaderView::ResizeToContents);
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void usrWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void usrWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("UsrWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("UsrWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(330, 400));
		move(QPoint(50, 330));
	}
}

void usrWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("UsrWindowPos", pos());
	settings.setValue("UsrWindowSize", size());
}
