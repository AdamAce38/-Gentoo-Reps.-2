/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "ligedit.h"
#include "glwidget.h"


/** Extern globals */
extern OGLWidget  *oglWid;


/** Constructor */
ligWidget::ligWidget(QWidget *parent) : QWidget(parent) {

	/** Set up light-editor */
	Ui_ligUI::setupUi(this);
	setMinimumSize(300, 450);
	setWindowTitle(tr("Lights"));
	readSettings();

	/** Set all lights */
	connect(set0, SIGNAL(clicked()), oglWid, SLOT(setLig0()));
	connect(set1, SIGNAL(clicked()), oglWid, SLOT(setLig1()));
	connect(set2, SIGNAL(clicked()), oglWid, SLOT(setLig2()));
	connect(set3, SIGNAL(clicked()), oglWid, SLOT(setLig3()));
	connect(set4, SIGNAL(clicked()), oglWid, SLOT(setLig4()));
	connect(set5, SIGNAL(clicked()), oglWid, SLOT(setLig5()));
	connect(set6, SIGNAL(clicked()), oglWid, SLOT(setLig6()));
	connect(set7, SIGNAL(clicked()), oglWid, SLOT(setLig7()));

	/** Edit single light */
	connect(edit0, SIGNAL(clicked()), oglWid, SLOT(ediLig0()));
	connect(edit1, SIGNAL(clicked()), oglWid, SLOT(ediLig1()));
	connect(edit2, SIGNAL(clicked()), oglWid, SLOT(ediLig2()));
	connect(edit3, SIGNAL(clicked()), oglWid, SLOT(ediLig3()));
	connect(edit4, SIGNAL(clicked()), oglWid, SLOT(ediLig4()));
	connect(edit5, SIGNAL(clicked()), oglWid, SLOT(ediLig5()));
	connect(edit6, SIGNAL(clicked()), oglWid, SLOT(ediLig6()));
	connect(edit7, SIGNAL(clicked()), oglWid, SLOT(ediLig7()));

	/** Intensity ambient */
	connect(IAR, SIGNAL(valueChanged(int)), oglWid, SLOT(lared(int)));
	connect(IAG, SIGNAL(valueChanged(int)), oglWid, SLOT(lagreen(int)));
	connect(IAB, SIGNAL(valueChanged(int)), oglWid, SLOT(lablue(int)));
	connect(IAA, SIGNAL(valueChanged(int)), oglWid, SLOT(laalpha(int)));

	/** Intensity diffuse */
	connect(IDR, SIGNAL(valueChanged(int)), oglWid, SLOT(ldred(int)));
	connect(IDG, SIGNAL(valueChanged(int)), oglWid, SLOT(ldgreen(int)));
	connect(IDB, SIGNAL(valueChanged(int)), oglWid, SLOT(ldblue(int)));
	connect(IDA, SIGNAL(valueChanged(int)), oglWid, SLOT(ldalpha(int)));

	/** Intensity specular */
	connect(ISR, SIGNAL(valueChanged(int)), oglWid, SLOT(lsred(int)));
	connect(ISG, SIGNAL(valueChanged(int)), oglWid, SLOT(lsgreen(int)));
	connect(ISB, SIGNAL(valueChanged(int)), oglWid, SLOT(lsblue(int)));
	connect(ISA, SIGNAL(valueChanged(int)), oglWid, SLOT(lsalpha(int)));

	/** Spotlights; A=angle I=intensity */
	connect(spotA,   SIGNAL(valueChanged(int)), oglWid, SLOT(setSpotA(int)));
	connect(spotI,   SIGNAL(valueChanged(int)), oglWid, SLOT(setSpotI(int)));
	connect(spotX,   SIGNAL(valueChanged(int)), oglWid, SLOT(setSpotX(int)));
	connect(spotY,   SIGNAL(valueChanged(int)), oglWid, SLOT(setSpotY(int)));
	connect(spotZ,   SIGNAL(valueChanged(int)), oglWid, SLOT(setSpotZ(int)));
	connect(spotBox, SIGNAL(toggled(bool)),     oglWid, SLOT(togSpot(bool)));

	/** Attenuation; con=constant lin=linear qua=quadratic */
	connect(con, SIGNAL(valueChanged(int)), oglWid, SLOT(setConAtt(int)));
	connect(lin, SIGNAL(valueChanged(int)), oglWid, SLOT(setLinAtt(int)));
	connect(qua, SIGNAL(valueChanged(int)), oglWid, SLOT(setQuaAtt(int)));

	/** Light miscellaneous */
	connect(distance, SIGNAL(valueChanged(int)), oglWid, SLOT(lightDistance(int)));
	connect(locAmb,   SIGNAL(clicked()), oglWid, SLOT(ligAmbLocked()));
	connect(locDif,   SIGNAL(clicked()), oglWid, SLOT(ligDifLocked()));
	connect(locSpe,   SIGNAL(clicked()), oglWid, SLOT(ligSpeLocked()));
	connect(oglWid,   SIGNAL(updLigWid()), this, SLOT(updLigWid()));

	/** To prevent flickering when light sliders are locked */
	connect(oglWid, SIGNAL(updLigAmb()), this, SLOT(updLigAmb()));
	connect(oglWid, SIGNAL(updLigDif()), this, SLOT(updLigDif()));
	connect(oglWid, SIGNAL(updLigSpe()), this, SLOT(updLigSpe()));
}


/** *************************************************************************
 ** UPDATE SLIDER-VALUES IN LIGHT-EDITOR
****************************************************************************/
void ligWidget::updLigWid() {

	/** Check setting-section */
	if(lig[0].setLig) set0->setChecked(true); else set0->setChecked(false);
	if(lig[1].setLig) set1->setChecked(true); else set1->setChecked(false);
	if(lig[2].setLig) set2->setChecked(true); else set2->setChecked(false);
	if(lig[3].setLig) set3->setChecked(true); else set3->setChecked(false);
	if(lig[4].setLig) set4->setChecked(true); else set4->setChecked(false);
	if(lig[5].setLig) set5->setChecked(true); else set5->setChecked(false);
	if(lig[6].setLig) set6->setChecked(true); else set6->setChecked(false);
	if(lig[7].setLig) set7->setChecked(true); else set7->setChecked(false);

	/** Check edit-section */
	if(lig[0].setLig) edit0->setEnabled(true); else edit0->setEnabled(false);
	if(lig[1].setLig) edit1->setEnabled(true); else edit1->setEnabled(false);
	if(lig[2].setLig) edit2->setEnabled(true); else edit2->setEnabled(false);
	if(lig[3].setLig) edit3->setEnabled(true); else edit3->setEnabled(false);
	if(lig[4].setLig) edit4->setEnabled(true); else edit4->setEnabled(false);
	if(lig[5].setLig) edit5->setEnabled(true); else edit5->setEnabled(false);
	if(lig[6].setLig) edit6->setEnabled(true); else edit6->setEnabled(false);
	if(lig[7].setLig) edit7->setEnabled(true); else edit7->setEnabled(false);

	edit0->setChecked(false);
	edit1->setChecked(false);
	edit2->setChecked(false);
	edit3->setChecked(false);
	edit4->setChecked(false);
	edit5->setChecked(false);
	edit6->setChecked(false);
	edit7->setChecked(false);

	switch(sta.ediLig) {
		case(0): edit0->setChecked(true); break;
		case(1): edit1->setChecked(true); break;
		case(2): edit2->setChecked(true); break;
		case(3): edit3->setChecked(true); break;
		case(4): edit4->setChecked(true); break;
		case(5): edit5->setChecked(true); break;
		case(6): edit6->setChecked(true); break;
		case(7): edit7->setChecked(true); break;
	}

	/** Check light-box */
	switch(sta.ediLig) {
		case(0): if(lig[0].setLig) ligBox->setEnabled(true); else ligBox->setEnabled(false); break;
		case(1): if(lig[1].setLig) ligBox->setEnabled(true); else ligBox->setEnabled(false); break;
		case(2): if(lig[2].setLig) ligBox->setEnabled(true); else ligBox->setEnabled(false); break;
		case(3): if(lig[3].setLig) ligBox->setEnabled(true); else ligBox->setEnabled(false); break;
		case(4): if(lig[4].setLig) ligBox->setEnabled(true); else ligBox->setEnabled(false); break;
		case(5): if(lig[5].setLig) ligBox->setEnabled(true); else ligBox->setEnabled(false); break;
		case(6): if(lig[6].setLig) ligBox->setEnabled(true); else ligBox->setEnabled(false); break;
		case(7): if(lig[7].setLig) ligBox->setEnabled(true); else ligBox->setEnabled(false); break;
	}

	/** RGB-locked and distance */
	locAmb->setChecked(lig[sta.ediLig].ambLigLoc);
	locDif->setChecked(lig[sta.ediLig].difLigLoc);
	locSpe->setChecked(lig[sta.ediLig].speLigLoc);
	distance->setValue(lig[sta.ediLig].ligDis);

	/** Ambient lights */
	IAR->setValue((int)(lig[sta.ediLig].ambLig[0]*255.0f));
	IAG->setValue((int)(lig[sta.ediLig].ambLig[1]*255.0f));
	IAB->setValue((int)(lig[sta.ediLig].ambLig[2]*255.0f));
	IAA->setValue((int)(lig[sta.ediLig].ambLig[3]*255.0f));

	/** Diffuse lights */
	IDR->setValue((int)(lig[sta.ediLig].difLig[0]*255.0f));
	IDG->setValue((int)(lig[sta.ediLig].difLig[1]*255.0f));
	IDB->setValue((int)(lig[sta.ediLig].difLig[2]*255.0f));
	IDA->setValue((int)(lig[sta.ediLig].difLig[3]*255.0f));

	/** Specular lights */
	ISR->setValue((int)(lig[sta.ediLig].speLig[0]*255.0f));
	ISG->setValue((int)(lig[sta.ediLig].speLig[1]*255.0f));
	ISB->setValue((int)(lig[sta.ediLig].speLig[2]*255.0f));
	ISA->setValue((int)(lig[sta.ediLig].speLig[3]*255.0f));

	/** Spotlight settings */
	spotA->setValue((int)(lig[sta.ediLig].spoCut));
	spotI->setValue((int)(lig[sta.ediLig].spoExp/3.0f));
	spotX->setValue((int)(lig[sta.ediLig].spoDir[0]*100.0f));
	spotY->setValue((int)(lig[sta.ediLig].spoDir[1]*100.0f));
	spotZ->setValue((int)(lig[sta.ediLig].spoDir[2]*100.0f));
	spotBox->setChecked(lig[sta.ediLig].spoSta);

	/** Attenuations */
	con->setValue((int)(lig[sta.ediLig].conAtt*100.0f));
	lin->setValue((int)(lig[sta.ediLig].linAtt*300.0f));
	qua->setValue((int)(lig[sta.ediLig].quaAtt*1000.0f));

	/** Consider all spotlight possibilities */
	switch(sta.ediLig) {
		case(0):	if(lig[0].setLig && ent.modInf==1.0f) {
						spotBox->setEnabled(true);
						attBox->setEnabled(true);
						distBox->setEnabled(true);
					}
					else {
						spotBox->setEnabled(false);
						attBox->setEnabled(false);
						distBox->setEnabled(false);
					}
					break;
		case(1):	if(lig[1].setLig && ent.modInf==1.0f) {
						spotBox->setEnabled(true);
						attBox->setEnabled(true);
						distBox->setEnabled(true);
					}
					else {
						spotBox->setEnabled(false);
						attBox->setEnabled(false);
						distBox->setEnabled(false);
					}
					break;
		case(2):	if(lig[2].setLig && ent.modInf==1.0f) {
						spotBox->setEnabled(true);
						attBox->setEnabled(true);
						distBox->setEnabled(true);
					}
					else {
						spotBox->setEnabled(false);
						attBox->setEnabled(false);
						distBox->setEnabled(false);
					}
					break;
		case(3):	if(lig[3].setLig && ent.modInf==1.0f) {
						spotBox->setEnabled(true);
						attBox->setEnabled(true);
						distBox->setEnabled(true);
					}
					else {
						spotBox->setEnabled(false);
						attBox->setEnabled(false);
						distBox->setEnabled(false);
					}
					break;
		case(4):	if(lig[4].setLig && ent.modInf==1.0f) {
						spotBox->setEnabled(true);
						attBox->setEnabled(true);
						distBox->setEnabled(true);
					}
					else {
						spotBox->setEnabled(false);
						attBox->setEnabled(false);
						distBox->setEnabled(false);
					}
					break;
		case(5):	if(lig[5].setLig && ent.modInf==1.0f) {
						spotBox->setEnabled(true);
						attBox->setEnabled(true);
						distBox->setEnabled(true);
					}
					else {
						spotBox->setEnabled(false);
						attBox->setEnabled(false);
						distBox->setEnabled(false);
					}
					break;
		case(6):	if(lig[6].setLig && ent.modInf==1.0f) {
						spotBox->setEnabled(true);
						attBox->setEnabled(true);
						distBox->setEnabled(true);
					}
					else {
						spotBox->setEnabled(false);
						attBox->setEnabled(false);
						distBox->setEnabled(false);
					}
					break;
		case(7):	if(lig[7].setLig && ent.modInf==1.0f) {
						spotBox->setEnabled(true);
						attBox->setEnabled(true);
						distBox->setEnabled(true);
					}
					else {
						spotBox->setEnabled(false);
						attBox->setEnabled(false);
						distBox->setEnabled(false);
					}
					break;
	}
}

/** Prevent flickering when light sliders are locked */
void ligWidget::updLigAmb() {
	IAR->setValue((int)(lig[sta.ediLig].ambLig[0]*255.0f));
	IAG->setValue((int)(lig[sta.ediLig].ambLig[1]*255.0f));
	IAB->setValue((int)(lig[sta.ediLig].ambLig[2]*255.0f));
	IAA->setValue((int)(lig[sta.ediLig].ambLig[3]*255.0f));
}

void ligWidget::updLigDif() {
	IDR->setValue((int)(lig[sta.ediLig].difLig[0]*255.0f));
	IDG->setValue((int)(lig[sta.ediLig].difLig[1]*255.0f));
	IDB->setValue((int)(lig[sta.ediLig].difLig[2]*255.0f));
	IDA->setValue((int)(lig[sta.ediLig].difLig[3]*255.0f));
}

void ligWidget::updLigSpe() {
	ISR->setValue((int)(lig[sta.ediLig].speLig[0]*255.0f));
	ISG->setValue((int)(lig[sta.ediLig].speLig[1]*255.0f));
	ISB->setValue((int)(lig[sta.ediLig].speLig[2]*255.0f));
	ISA->setValue((int)(lig[sta.ediLig].speLig[3]*255.0f));
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void ligWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_ligUI::retranslateUi(this);
		setWindowTitle(tr("Lights"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void ligWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void ligWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("LightWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("LightWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(355, 570));
		move(QPoint(70, 0));
	}
}

void ligWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("LightWindowPos", pos());
	settings.setValue("LightWindowSize", size());
}
