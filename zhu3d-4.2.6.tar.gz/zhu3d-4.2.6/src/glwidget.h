/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _GLWIDGET_H_
#define _GLWIDGET_H_

#include <QGLWidget>      // Central OpenGL viewer
#include <QMessageBox>    // Parser messages
#include <QPrinter>
#include <QPrintDialog>
#include <QImage>         // Printing stuff
#include <QPainter>       // Printing stuff
#include <QFileDialog>
#include <QFont>          // Legends font

#include "gldraw.h"       // For some extern globals/functions there
#include "property.h"     // For light/material/entire-parameters
#include "timers.h"       // For animation stuff
#include "version.h"
#include "debug.h"


/** Start adress for OpenGL-lights */
extern const int lightBase;


/** Comfort macros */
#define listUpAll listUp[0]=listUp[1]=listUp[2]=listUp[3]=true
#define listUpFun listUp[0]=listUp[1]=listUp[2]=true
#define listUpPar listUp[3]=true


/** *************************************************************************
 ** CENTRAL OPENGL-VIWER WINDOW
****************************************************************************/
class OGLWidget : public QGLWidget {

Q_OBJECT

public:
	OGLWidget(QWidget *parent=0);
	~OGLWidget() {};

	void readSettings();                                              // Settings needed from benchmark
	void writeSettings();                                             // Settings needed from benchmark
	int getMaxTex() { return maxTex; }                                // Texture stuff needed from speEdi
	void gotNewItem() { listUpAll; updateGL(); emit updMaiInf(); }    // User table changed
	void iniAll();                                                    // Reset all values; needed from maiWin
	void updWinTit();                                                 // Update window title
	void newFont(QString font);                                       // Works but is somehow experimental so far

public slots:

	/** OpenGL core */
	void newFileOpened() {
		QApplication::setOverrideCursor(Qt::WaitCursor);
		resizeGL(actWidth, actHeight);
		listUpAll;
		updateGL();
		QApplication::restoreOverrideCursor();
	}
	void updateOnMorph() { TIMERS t; listUpAll; updateGL(); if(mor.active) msecs=t.stop(); }
	void updateGLonly() { TIMERS t; updateGL(); if(ani.active) asecs=t.stop(); }

	/** Set rotation-sliders */
	void setXRotation(const int newx);
	void setYRotation(const int newy);
	void setZRotation(const int newz);

	/** Set modes */
	void drawModeTriangle()  { sta.draw=0; listUpAll; updateGL(); }
	void drawModeQuad()      { sta.draw=1; listUpAll; updateGL(); }
	void drawModePoint()     { sta.draw=2; listUpAll; updateGL(); }
	void drawModeParameter();

	/** Set functions/parametric view to draw */
	void toggleF0();
	void toggleF1();
	void toggleF2();
	void toggleF3();

	/** Handle more settings from maiWin */
	void toggleCross() { sta.cross = !sta.cross; updateGL(); }
	void toggleAxes()  { sta.axes = !sta.axes; updateGL(); }
	void togglePolygon();

	/** Scale actions */
	void scaleXplus();
	void scaleXminus();
	void scaleYplus();
	void scaleYminus();
	void scaleZplus();
	void scaleZminus();
	void scaleXYZplus();
	void scaleXYZminus();
	void scaleGridplus();
	void scaleGridminus();

	/** Handle zoom-actions */
	void zoomIn()  { sta.angle-=con.zoomFac; resizeGL(actWidth, actHeight); updateGL(); }
	void zoomOut() { sta.angle+=con.zoomFac; resizeGL(actWidth, actHeight); updateGL(); }

	/** Handle translations */
	void transLeft()  { sta.transX-=con.transFac; updateGL(); }
	void transRight() { sta.transX+=con.transFac; updateGL(); }
	void transUp()    { sta.transY+=con.transFac; updateGL(); }
	void transDown()  { sta.transY-=con.transFac; updateGL(); }

	/** Got new function-inputs from maiWin */
	void setNewF0();
	void setNewF1();
	void setNewF2();

	/** Related error messages */
	bool errorNewF0(int p);
	bool errorNewF1(int p);
	bool errorNewF2(int p);

	/** File stuff, framebuffer etc. */
	void savePic();
	void printPic();
	void sfineScale()  { scaleFac=con.sfineFac; }
	void fineScale()   { scaleFac=con.fineFac; }
	void normalScale() { scaleFac=con.normalFac; }
	void coarseScale() { scaleFac=con.coarseFac; }

	/** LIGHT-STUFF */
	void setLig0() { setLigAll(0); }
	void setLig1() { setLigAll(1); }
	void setLig2() { setLigAll(2); }
	void setLig3() { setLigAll(3); }
	void setLig4() { setLigAll(4); }
	void setLig5() { setLigAll(5); }
	void setLig6() { setLigAll(6); }
	void setLig7() { setLigAll(7); }

	void setLigAll(const int nr) {
		lig[nr].setLig=!lig[nr].setLig;
		emit updLigWid();
		if(lig[nr].setLig) glEnable(lightBase+nr); else glDisable(lightBase+nr);
		updateGL();
	}

	void ediLig0() { ediLigAll(0); }
	void ediLig1() { ediLigAll(1); }
	void ediLig2() { ediLigAll(2); }
	void ediLig3() { ediLigAll(3); }
	void ediLig4() { ediLigAll(4); }
	void ediLig5() { ediLigAll(5); }
	void ediLig6() { ediLigAll(6); }
	void ediLig7() { ediLigAll(7); }

	void ediLigAll(const int n) { sta.ediLig=n; emit updLigWid(); }

	/** Set ambient light intensities */
	void lared  (const int intensity) { laall(0, intensity); }
	void lagreen(const int intensity) { laall(1, intensity); }
	void lablue (const int intensity) { laall(2, intensity); }
	void laalpha(const int intensity) { laall(3, intensity); }
	void laall(const int channel, const int intensity);

	/** Set diffuse light intensities */
	void ldred  (const int intensity) { ldall(0, intensity); }
	void ldgreen(const int intensity) { ldall(1, intensity); }
	void ldblue (const int intensity) { ldall(2, intensity); }
	void ldalpha(const int intensity) { ldall(3, intensity); }
	void ldall(const int channel, const int intensity);

	/** Set specular light intensities */
	void lsred  (const int intensity) { lsall(0, intensity); }
	void lsgreen(const int intensity) { lsall(1, intensity); }
	void lsblue (const int intensity) { lsall(2, intensity); }
	void lsalpha(const int intensity) { lsall(3, intensity); }
	void lsall(const int channel, const int intensity);

	/** Spotlight actions */
	void setSpotA(const int angle)     { lig[sta.ediLig].spoCut=(float)angle; updateGL(); }
	void setSpotI(const int intensity) { lig[sta.ediLig].spoExp=intensity*3.0f; updateGL(); }
	void setSpotX(const int x) { lig[sta.ediLig].spoDir[0]=x/100.0f; updateGL(); }
	void setSpotY(const int y) { lig[sta.ediLig].spoDir[1]=y/100.0f; updateGL(); }
	void setSpotZ(const int z) { lig[sta.ediLig].spoDir[2]=z/100.0f; updateGL(); }
	void togSpot(const bool b) { lig[sta.ediLig].spoSta=b; updateGL(); }

	/** Set attenuation factors */
	void setConAtt(int faktor);
	void setLinAtt(int faktor);
	void setQuaAtt(int faktor);

	/** Miscellaneous light settings */
	void lightDistance(const int d);
	void ligAmbLocked() { lig[sta.ediLig].ambLigLoc = !lig[sta.ediLig].ambLigLoc; }
	void ligDifLocked() { lig[sta.ediLig].difLigLoc = !lig[sta.ediLig].difLigLoc; }
	void ligSpeLocked() { lig[sta.ediLig].speLigLoc = !lig[sta.ediLig].speLigLoc; }

	/** MATERIAL STUFF */
	void ediMat0() { ediMatAll(0); }
	void ediMat1() { ediMatAll(1); }
	void ediMat2() { ediMatAll(2); }
	void ediMat3() { ediMatAll(3); }
	void ediMatAll(const int n) { sta.ediMat=n; emit updMatWid(); }

	/** Set ambient material */
	void mared  (const int intensity) { maall(0, intensity); }
	void magreen(const int intensity) { maall(1, intensity); }
	void mablue (const int intensity) { maall(2, intensity); }
	void maalpha(const int intensity) { maall(3, intensity); }
	void maall(const int channel, const int intensity);

	/** Set diffuse material */
	void mdred  (const int intensity) { mdall(0, intensity); }
	void mdgreen(const int intensity) { mdall(1, intensity); }
	void mdblue (const int intensity) { mdall(2, intensity); }
	void mdalpha(const int intensity) { mdall(3, intensity); }
	void mdall(const int channel, const int intensity);

	/** Set specular material */
	void msred  (const int intensity) { msall(0, intensity); }
	void msgreen(const int intensity) { msall(1, intensity); }
	void msblue (const int intensity) { msall(2, intensity); }
	void msalpha(const int intensity) { msall(3, intensity); }
	void msall(const int channel, const int intensity);

	/** Set emmission material */
	void mered  (const int intensity) { meall(0, intensity); }
	void megreen(const int intensity) { meall(1, intensity); }
	void meblue (const int intensity) { meall(2, intensity); }
	void mealpha(const int intensity) { meall(3, intensity); }
	void meall(const int channel, const int intensity);

	void matexp(const int intensity) {
			mat[sta.ediMat].shiMat[mat[sta.ediMat].twoSid] = (float)intensity; updateGL(); }
	void matAmbLocked() {
			mat[sta.ediMat].ambMatLoc[mat[sta.ediMat].twoSid] = !
			mat[sta.ediMat].ambMatLoc[mat[sta.ediMat].twoSid]; }
	void matDifLocked() {
			mat[sta.ediMat].difMatLoc[mat[sta.ediMat].twoSid] = !
			mat[sta.ediMat].difMatLoc[mat[sta.ediMat].twoSid]; }
	void matSpeLocked() {
			mat[sta.ediMat].speMatLoc[mat[sta.ediMat].twoSid] = !
			mat[sta.ediMat].speMatLoc[mat[sta.ediMat].twoSid]; }
	void matEmiLocked() {
			mat[sta.ediMat].emiMatLoc[mat[sta.ediMat].twoSid] = !
			mat[sta.ediMat].emiMatLoc[mat[sta.ediMat].twoSid]; }

	void toggleBackSide();
	void syncSides();

	/** ENTIRE LIGHT STUFF */
	void entAmbLocked() { ent.ambEntLoc = !ent.ambEntLoc; }
	void entBacLocked() { ent.bacEntLoc = !ent.bacEntLoc; }

	/** Set entire ambient light */
	void lmared  (const int intensity) { lmaall(0, intensity); }
	void lmagreen(const int intensity) { lmaall(1, intensity); }
	void lmablue (const int intensity) { lmaall(2, intensity); }
	void lmaalpha(const int intensity) { lmaall(3, intensity); }
	void lmaall(const int channel, const int intensity);

	/** Set entire background colour */
	void lmbred  (const int intensity) { lmball(0, intensity); }
	void lmbgreen(const int intensity) { lmball(1, intensity); }
	void lmbblue (const int intensity) { lmball(2, intensity); }
	void lmbalpha(const int intensity) { lmball(3, intensity); }
	void lmball(const int channel, const int intensity);

	void modInf() { ent.modInf=0.0f; updLigWid(); updateGL(); }
	void modLoc() { ent.modInf=1.0f; updLigWid(); updateGL(); }
	void modOne() { ent.modOne=0.0f; for(int i=0; i<4; i++) mat[i].twoSid=0; emit updMatWid(); updateGL(); }
	void modTwo() { ent.modOne=1.0f; updateGL(); }

signals:
	void xRotationChanged(int x);    // Mouse-slider synchronization
	void yRotationChanged(int y);    // Mouse-slider synchronization
	void killAll();                  // Close maiWin too

	void updMaiWid();    // Update maiWin
	void updMaiInf();    // Update info-section in maiWin
	void updLigWid();    // Update light-editor
	void updMatWid();    // Update material-editor
	void updEntWid();    // Update entire-editor

	void updLigAmb();    // Update ambient light sliders when locked
	void updLigDif();    // Update diffuse light sliders when locked
	void updLigSpe();    // Update specular light sliders when locked

	void F0error();      // Signals to funEdi
	void F1error();
	void F2error();
	void parsersTainted(bool b);    // For simplicity used in fntEdi too!

protected:
	void initializeGL();
	void paintGL();
	void resizeGL(int width, int height);
	void mousePressEvent(QMouseEvent *event);
	void mouseReleaseEvent(QMouseEvent *event);
	void mouseMoveEvent(QMouseEvent *event);
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

private:
	void renderXYZ();
	void Draw_Axes(void);
	void Draw_Cross(void);
	void renderLegends();

	QPoint lastPos;    // Last mouse-position in the viewer
	int maxTex;        // Holds maximum texture size
	float scaleFac;    // Scalefactor
};

/** _GLWIDGET_H_ */
#endif
