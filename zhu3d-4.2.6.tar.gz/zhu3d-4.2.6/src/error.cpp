/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "error.h"


/** Constructor */
errWidget::errWidget(QWidget *parent) : QWidget(parent) {

	/** Set up light-editor */
	Ui_errUI::setupUi(this);
	setWindowTitle(tr("Debug-window"));
	readSettings();
}


/** *************************************************************************
 ** OVERLOADED PRINT-VERSIONS
****************************************************************************/
void errWidget::print(const QString message) {
	errorTextEdit->append(message);
}

void errWidget::print(const char *message) {
	const QString tmp(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const unsigned char *message) {
	const QString tmp((char *)message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const char message) {
	QString tmp;
	tmp.setNum(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const unsigned char message) {
	QString tmp;
	tmp.setNum(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const int message) {
	QString tmp;
	tmp.setNum(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const unsigned int message) {
	QString tmp;
	tmp.setNum(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const long message) {
	QString tmp;
	tmp.setNum(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const unsigned long message) {
	QString tmp;
	tmp.setNum(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const long long message) {
	QString tmp;
	tmp.setNum(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const unsigned long long message) {
	QString tmp;
	tmp.setNum(message);
	errorTextEdit->append(tmp);
}

void errWidget::print(const float message) {
	QString tmp;
	tmp.setNum(message, 'g', 7);
	errorTextEdit->append(tmp);
}

void errWidget::print(const double message) {
	QString tmp;
	tmp.setNum(message, 'g', 15);
	errorTextEdit->append(tmp);
}


void errWidget::print(const long double message) {
	QString tmp;
	const double r=(double)message;
	tmp.setNum(r, 'g', 15);
	errorTextEdit->append(tmp);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void errWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void errWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	move(settings.value("ErrorWindowPos", QPoint(200, 200)).toPoint());
	resize(settings.value("ErrorWindowSize", QSize(400, 400)).toSize());
}

void errWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("ErrorWindowPos", pos());
	settings.setValue("ErrorWindowSize", size());
}
