/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "funedit.h"
#include "glwidget.h"
#include "usredit.h"

/** Extern globals */
extern OGLWidget *oglWid;
extern usrWidget *usrEdi;


/** Constructor */
funWidget::funWidget(QWidget *parent) : QWidget(parent) {

	/** Set up entire editor */
	Ui_funUI::setupUi(this);
	setMinimumSize(220, 100);
	setWindowTitle(tr("Function editor"));
	readSettings();

	/** Prepare the input strings */
	connect(F0, SIGNAL(returnPressed()), this, SLOT(deliverF0Slot()));
	connect(F1, SIGNAL(returnPressed()), this, SLOT(deliverF1Slot()));
	connect(F2, SIGNAL(returnPressed()), this, SLOT(deliverF2Slot()));

	/** Inform oglWid */
	connect(this, SIGNAL(F0changed()), oglWid, SLOT(setNewF0()));
	connect(this, SIGNAL(F1changed()), oglWid, SLOT(setNewF1()));
	connect(this, SIGNAL(F2changed()), oglWid, SLOT(setNewF2()));

	/** Error messages from parser */
	connect(oglWid, SIGNAL(F0error()), this, SLOT(errorF0Slot()));
	connect(oglWid, SIGNAL(F1error()), this, SLOT(errorF1Slot()));
	connect(oglWid, SIGNAL(F2error()), this, SLOT(errorF2Slot()));

	/** Parsers tainted?
	 ** Signal from oglWid should be always false and unlocks F0,F1,F2 after previous error */
	connect(usrEdi, SIGNAL(parsersTainted(bool)), this, SLOT(lockFunSlot(bool)));
	connect(oglWid, SIGNAL(parsersTainted(bool)), this, SLOT(unlockSlot(bool)));
}


/** *************************************************************************
 ** DELIVERY SLOTS
****************************************************************************/
void funWidget::deliverF0Slot() {

	QString inp = F0->text();
	F0->setStyleSheet("background: white;");

	/** Function mode */
	if(sta.funMod==FUNCTION) {
		ofun[0]=inp;
		q2cstrcpy(fun[0].str, prepareInput(inp));
	}

	/** Parameter mode */
	if(sta.funMod==PARAMETER) {
		opar[0]=inp;
		q2cstrcpy(par.str[0], prepareInput(inp));
	}

	/** Implicite function mode */
	if(sta.funMod==IMPLICITE) {
		oiso[0]=inp;
		q2cstrcpy(iso[0].str, prepareInput(inp));
	}

	emit F0changed();
}

void funWidget::deliverF1Slot() {

	QString inp = F1->text();
	F1->setStyleSheet("background: white;");

	/** Function mode */
	if(sta.funMod==FUNCTION) {
		ofun[1]=inp;
		q2cstrcpy(fun[1].str, prepareInput(inp));
	}

	/** Parameter mode */
	if(sta.funMod==PARAMETER) {
		opar[1]=inp;
		q2cstrcpy(par.str[1], prepareInput(inp));
	}

	/** Implicite function mode */
	if(sta.funMod==IMPLICITE) {
		oiso[1]=inp;
		q2cstrcpy(iso[1].str, prepareInput(inp));
	}

	emit F1changed();
}

void funWidget::deliverF2Slot() {

	QString inp = F2->text();
	F2->setStyleSheet("background: white;");

	/** Function mode */
	if(sta.funMod==FUNCTION) {
		ofun[2]=inp;
		q2cstrcpy(fun[2].str, prepareInput(inp));
	}

	/** Parameter mode */
	if(sta.funMod==PARAMETER) {
		opar[2]=inp;
		q2cstrcpy(par.str[2], prepareInput(inp));
	}

	/** Implicite function mode */
	if(sta.funMod==IMPLICITE) {
		oiso[2]=inp;
		q2cstrcpy(iso[2].str, prepareInput(inp));
	}

	emit F2changed();
}


/** *************************************************************************
 ** UPDATE ENTRIES IN FUNCTION-EDITOR
****************************************************************************/
void funWidget::updFunWid() {
	QString tmp;

	/** Comment first */
	textEdit->clear();
	textEdit->append(comment);
	textEdit->moveCursor(QTextCursor::Start);

	/** Functions */
	if(sta.funMod==FUNCTION) {
		F0Label->setText(" F0");
		F1Label->setText(" F1");
		F2Label->setText(" F2");
		F0->setText(ofun[0]);
		F1->setText(ofun[1]);
		F2->setText(ofun[2]);
		return;
	}

	/** Implicite functions */
	if(sta.funMod==IMPLICITE) {
		F0Label->setText(" I0");
		F1Label->setText(" I1");
		F2Label->setText(" I2");
		F0->setText(oiso[0]);
		F1->setText(oiso[1]);
		F2->setText(oiso[2]);
		return;
	}

	/** Parameter system */
	if(sta.funMod==PARAMETER) {
		F0Label->setText(" X");
		F1Label->setText(" Y");
		F2Label->setText(" Z");
		F0->setText(opar[0]);
		F1->setText(opar[1]);
		F2->setText(opar[2]);
	}
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void funWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_funUI::retranslateUi(this);
		setWindowTitle(tr("Function editor"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void funWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void funWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("FunWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("FunWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(400, 200));
		move(QPoint(0, 490));
	}
}

void funWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("FunWindowPos", pos());
	settings.setValue("FunWindowSize", size());
}
