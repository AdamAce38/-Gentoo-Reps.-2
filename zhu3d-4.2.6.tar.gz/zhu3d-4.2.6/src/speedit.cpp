/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include <QFileDialog>
#include <GL/gl.h>
#include "speedit.h"
#include "sysinfo.h"


/** From OpenGL viewer */
extern unsigned int texID[4];
extern OGLWidget *oglWid;


/** From directory editor */
extern QString texDir;


/** Constructor */
speWidget::speWidget(QWidget *parent) : QWidget(parent) {

	/** Set up texture editor */
	Ui_speUI::setupUi(this);
	setMinimumSize(290, 580);
	setWindowTitle(tr("OpenGL"));

	/** Get remembered settings
	 ** Especially important: update current texture path too */
	readSettings();

	/** Set icons */
	pushF0->setIcon(QPixmap(QString(":/images/open.png")));
	pushF1->setIcon(QPixmap(QString(":/images/open.png")));
	pushF2->setIcon(QPixmap(QString(":/images/open.png")));
	pushPar->setIcon(QPixmap(QString(":/images/open.png")));

	remF0->setIcon(QPixmap(QString(":/images/remove.png")));
	remF1->setIcon(QPixmap(QString(":/images/remove.png")));
	remF2->setIcon(QPixmap(QString(":/images/remove.png")));
	remPar->setIcon(QPixmap(QString(":/images/remove.png")));

	flipF0->setIcon(QPixmap(QString(":/images/animate.png")));
	flipF1->setIcon(QPixmap(QString(":/images/animate.png")));
	flipF2->setIcon(QPixmap(QString(":/images/animate.png")));
	flipPar->setIcon(QPixmap(QString(":/images/animate.png")));

	/** Set line edits */
	texName0->setText(tex[0].name);
	texName1->setText(tex[1].name);
	texName2->setText(tex[2].name);
	texName3->setText(tex[3].name);

	/** Connect texture part */
	connect(pushF0,  SIGNAL(clicked()), this, SLOT(getF0()));
	connect(pushF1,  SIGNAL(clicked()), this, SLOT(getF1()));
	connect(pushF2,  SIGNAL(clicked()), this, SLOT(getF2()));
	connect(pushPar, SIGNAL(clicked()), this, SLOT(getPar()));

	connect(remF0,  SIGNAL(clicked()), this, SLOT(delF0()));
	connect(remF1,  SIGNAL(clicked()), this, SLOT(delF1()));
	connect(remF2,  SIGNAL(clicked()), this, SLOT(delF2()));
	connect(remPar, SIGNAL(clicked()), this, SLOT(delPar()));

	connect(checkF0,  SIGNAL(clicked()), this, SLOT(checkedF0()));
	connect(checkF1,  SIGNAL(clicked()), this, SLOT(checkedF1()));
	connect(checkF2,  SIGNAL(clicked()), this, SLOT(checkedF2()));
	connect(checkPar, SIGNAL(clicked()), this, SLOT(checkedPar()));

	connect(flipF0,  SIGNAL(clicked()), this, SLOT(flipPressedF0()));
	connect(flipF1,  SIGNAL(clicked()), this, SLOT(flipPressedF1()));
	connect(flipF2,  SIGNAL(clicked()), this, SLOT(flipPressedF2()));
	connect(flipPar, SIGNAL(clicked()), this, SLOT(flipPressedPar()));

	connect(span, SIGNAL(valueChanged(int)), this, SLOT(spanSlot(int)));

	/** Inform OpenGL viewer to update */
	connect(this, SIGNAL(gotNewFile()), oglWid, SLOT(newFileOpened()));
	connect(this, SIGNAL(gotNewView()), oglWid, SLOT(updateGLonly()));

	/** Connect fog part */
	connect(fogBox,  SIGNAL(toggled(bool)), this, SLOT(togFog(bool)));
	connect(locFog,  SIGNAL(clicked()),     this, SLOT(locFogSlot()));
	connect(syncFog, SIGNAL(clicked()),     this, SLOT(syncFogSlot()));
	connect(FR, SIGNAL(valueChanged(int)), this, SLOT(fogred(int)));
	connect(FG, SIGNAL(valueChanged(int)), this, SLOT(foggreen(int)));
	connect(FB, SIGNAL(valueChanged(int)), this, SLOT(fogblue(int)));
	connect(FA, SIGNAL(valueChanged(int)), this, SLOT(fogalpha(int)));

	connect(exp,  SIGNAL(clicked()), this, SLOT(expSlot()));
	connect(exp2, SIGNAL(clicked()), this, SLOT(exp2Slot()));
	connect(lin,  SIGNAL(clicked()), this, SLOT(linSlot()));

	connect(fogIntensity, SIGNAL(valueChanged(int)), this, SLOT(fint(int)));
	connect(fogStart, SIGNAL(valueChanged(int)), this, SLOT(fstart(int)));
	connect(fogEnd, SIGNAL(valueChanged(int)), this, SLOT(fend(int)));

	/** Connect motion blur part */
	connect(motBox, SIGNAL(toggled(bool)),     this, SLOT(togMot(bool)));
	connect(fac,    SIGNAL(valueChanged(int)), this, SLOT(motFac(int)));
	connect(steps,  SIGNAL(valueChanged(int)), this, SLOT(motSteps(int)));
	connect(trans,  SIGNAL(valueChanged(int)), this, SLOT(motTrans(int)));
}


/** *************************************************************************
 ** GET NEW TEXTURE
****************************************************************************/
void speWidget::getTexture(const int n) {

	/** File selector */
	QString fileName=QFileDialog::getOpenFileName(
					this,
					tr("Open")+" ppm-"+tr("file"),
					texDir,
					"Images (*.png *.jpg *.tif *.ppm *.bmp *.xbm *.xpm *.pbm *.pgm)");

	/** Got file or canceled file-selector? */
	if(fileName.isEmpty())
		return;

	/** Load texture */
	tex[n].name=fileName.section('/',-1,-1);
	if(loadTexture(fileName, n))
		emit gotNewFile();
}

/** Load texture without file selector
 ** fileName always MUST have the a complete path! */
bool speWidget::loadTexture(const QString fileName, const int n) {
	long i, j, k=0;

	/** Sure not a valid texture-file? "None" for old versions < 4.0.0 */
	if(tex[n].name=="None" || tex[n].name.isEmpty()) {
		tex[n].enabled=false;
		return false;
	}

	/** Try to load texture. Immediate return on failure */
	if(!texPic.load(fileName)) {
		tex[n].enabled=false;
		tex[n].name="";
		updTex();
		QMessageBox::critical(
			this,
			tr("Open"),
			tr("Error loading file:") + " " + fileName
		);
		return false;
	}

	/** Now width/height are defined. Check dimensions first */
	if(texPic.width() > oglWid->getMaxTex()) {
		tex[n].enabled=false;
		tex[n].name="";
		updTex();
		QMessageBox::critical(
			this,
			tr("OpenGL"),
			tr("Texture width too large")
		);
		return false;
	}
	if(texPic.height() > oglWid->getMaxTex()) {
		tex[n].enabled=false;
		tex[n].name="";
		updTex();
		QMessageBox::critical(
			this,
			tr("OpenGL"),
			tr("Texture height too large")
		);
		return false;
	}

	/** Check if texture dimensions are power of 2 */
	if(!checkPower2(texPic.width())) {
		tex[n].enabled=false;
		tex[n].name="";
		updTex();
		QMessageBox::critical(
			this,
			tr("OpenGL"),
			tr("Texture width not a power of 2")
		);
		return false;
	}
	if(!checkPower2(texPic.height())) {
		tex[n].enabled=false;
		tex[n].name="";
		updTex();
		QMessageBox::critical(
			this,
			tr("OpenGL"),
			tr("Texture height not a power of 2")
		);
		return false;
	}

	/** Some more preparations */
	texPic=texPic.mirrored();
	tex[n].hSize=texPic.width();
	tex[n].vSize=texPic.height();

	/** Clean allocation of texture memory */
	FREE(tex[n].data);
	tex[n].data = (unsigned char *) malloc(sizeof(unsigned char)*(tex[n].hSize*tex[n].vSize*3));
	if(tex[n].data==NULL) {
		QMessageBox::critical(
			this,
			tr("System information"),
			tr("Out of memory")
		);
		return false;
	}

	/** Convert to pure RGB */
	for(i=0; i<tex[n].vSize; i++)
		for(j=0; j<tex[n].hSize; j++) {
			rgb=texPic.pixel(j,i);
			*(tex[n].data + k++) = qRed(rgb);
			*(tex[n].data + k++) = qGreen(rgb);
			*(tex[n].data + k++) = qBlue(rgb);
		}

	/** Texture flipped? */
	if(tex[n].flip)
		if(!flipTexture(n)) {
			QMessageBox::critical(
				this,
				tr("System information"),
				tr("Out of memory")
			);
			return false;
		}

	/** Everything was ok so far */
	tex[n].enabled=true;
	updTex();
	upload(n);
	emit gotNewFile();
	return true;
}

/** Flip texture vertically */
void speWidget::flipPressed(const int n)   {
	if(!flipTexture(n)) {
		QMessageBox::critical(
			this,
			tr("System information"),
			tr("Out of memory")
		);
		return;
	}
	tex[n].flip=!tex[n].flip;
	upload(n);
	emit gotNewView();
}

/** Flip raw texture data vertically */
bool speWidget::flipTexture(const int n) {
	const long w=tex[n].hSize, h=tex[n].vSize;
	unsigned char *tmp, **pic, *dat=tex[n].data;
	long i, j;

	/** Data chunk empty? */
	if(dat==NULL)
		return true;

	/** Allocate array */
	if((tmp=(unsigned char *)malloc(3*w*h*sizeof(unsigned char *))) == NULL) {
		QMessageBox::critical(
			this,
			tr("System information"),
			tr("Out of memory")
		);
		return false;
	}
	if((pic=(unsigned char **)malloc(3*w*sizeof(unsigned char *))) == NULL) {
		QMessageBox::critical(
			this,
			tr("System information"),
			tr("Out of memory")
		);
		FREE(tmp);
		return false;
	}
	for(i=0; i<3*w; i++)
		pic[i]=tmp+(i*h);

	/** Switch row/columns for pic */
	for(i=0; i<3*w; i++)
		for(j=0; j<h; j++)
			pic[i][j]=dat[i+j*3*w];

	/** Flip vertically */
	for(i=0; i<3*w; i++)
		for(j=0; j<h; j++)
			dat[i+j*3*w]=pic[i][h-j-1];

	/** Proper exit */
	FREE(pic);
	FREE(tmp);
	return true;
}

/** Upload new texture to graphic card */
void speWidget::upload(const int texnr) {
	glBindTexture(GL_TEXTURE_2D, texID[texnr]);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tex[texnr].hSize, tex[texnr].vSize, \
				 0, GL_RGB, GL_UNSIGNED_BYTE, tex[texnr].data);
}

/** Remove texture from Zhu3D-file */
void speWidget::delTexture(const int n) {
	tex[n].name="";
	tex[n].enabled=false;
	FREE(tex[n].data);
	updTex();
	emit gotNewFile();
}

/** Check if texture dimensions are power of 2 */
bool speWidget::checkPower2(const int n) {
	if(n<2)
		return false;
	for(int i=2; i<=n; i<<=1)
		if(i==n)
			return true;
	return false;
}


/** *************************************************************************
 ** FOG SECTION
****************************************************************************/

/** Fog light */
void speWidget::fogall(const int channel, const int intensity) {
	if(fog.fogLigLoc && channel<3)
		for(int i=0; i<3; i++) {
				fog.fogLig[i]=intensity/255.0f;
				updFogLig();
		}
	else
		fog.fogLig[channel]=intensity/255.0f;
	setFog();
}

/** Set OpenGL values for fog */
void speWidget::setFog() {
	switch(fog.fogType) {
		case 0: glFogi(GL_FOG_MODE, GL_EXP);  break;
		case 1: glFogi(GL_FOG_MODE, GL_EXP2); break;
		case 2: glFogi(GL_FOG_MODE, GL_LINEAR);  break;
	}
	glFogfv(GL_FOG_COLOR, fog.fogLig);
	glFogf(GL_FOG_DENSITY, fog.intensity/100.0f);
	glFogf(GL_FOG_START, fog.start/10.f);
	glFogf(GL_FOG_END, fog.end/10.0f);
	if(fog.enabled)
		glEnable(GL_FOG);
	else
		glDisable(GL_FOG);
	emit gotNewView();
}

/** Fog type */
void speWidget::expSlot()  {
	fog.fogType=0;
	intLabel->setEnabled(true);
	startLabel->setEnabled(false);
	endLabel->setEnabled(false);
	fogIntensity->setEnabled(true);
	fogStart->setEnabled(false);
	fogEnd->setEnabled(false);
	setFog();
}

void speWidget::exp2Slot() {
	fog.fogType=1;
	intLabel->setEnabled(true);
	startLabel->setEnabled(false);
	endLabel->setEnabled(false);
	fogIntensity->setEnabled(true);
	fogStart->setEnabled(false);
	fogEnd->setEnabled(false);
	setFog();
}

void speWidget::linSlot() {
	fog.fogType=2;
	intLabel->setEnabled(false);
	startLabel->setEnabled(true);
	endLabel->setEnabled(true);
	fogIntensity->setEnabled(false);
	fogStart->setEnabled(true);
	fogEnd->setEnabled(true);
	setFog();
}

/** Synchronize start-end slider */
void speWidget::fstart(int i) {
	const int off=2;

	if(i>100-off) {
		i=100-off;
		fog.end=100;
		fogStart->setValue(i);
		fogEnd->setValue(100);
	}

	if(i>=fog.end-off) {
		fog.end=i+off;
		fogEnd->setValue(fog.end);
	}

	fog.start=i;
	setFog();
	emit gotNewView();
}

void speWidget::fend(int i)   {
	const int off=2;

	if(i<off) {
		i=off;
		fog.start=0;
		fogStart->setValue(fog.start);
		fogEnd->setValue(off);
	}

	if(i<=fog.start+off) {
		fog.start=i-off;
		fogStart->setValue(fog.start);
	}

	fog.end=i;
	setFog();
	emit gotNewView();
}

/** Synchronize fog color with background color */
void speWidget::syncFogSlot()   {
	for(int i=0; i<4; i++)
			fog.fogLig[i]=ent.bacLig[i];
	fog.fogLigLoc=ent.bacEntLoc;
	updFogLig();
	setFog();
}


/** *************************************************************************
 ** UPDATES
****************************************************************************/

/** Do a lot to be user friendly an switch on/off all possible items */
void speWidget::updTex() {

	/** set texture names and span width */
	texName0->setText(tex[0].name);
	texName1->setText(tex[1].name);
	texName2->setText(tex[2].name);
	texName3->setText(tex[3].name);
	span->setValue(texSpan);

	/** Function F0 */
	flipF0->setEnabled(tex[0].enabled);
	checkF0->setChecked(tex[0].enabled);
	texName0->setEnabled(tex[0].enabled);

	/** Function F1 */
	flipF1->setEnabled(tex[1].enabled);
	checkF1->setChecked(tex[1].enabled);
	texName1->setEnabled(tex[1].enabled);

	/** Function F2 */
	flipF2->setEnabled(tex[2].enabled);
	checkF2->setChecked(tex[2].enabled);
	texName2->setEnabled(tex[2].enabled);

	/** Parameter system */
	flipPar->setEnabled(tex[3].enabled);
	checkPar->setChecked(tex[3].enabled);
	texName3->setEnabled(tex[3].enabled);

	/** Handle spanBox independent */
	if(tex[0].name!="" || tex[1].name!="" || tex[2].name!="" || tex[3].name!="" ) {
		if(tex[0].enabled || tex[1].enabled || tex[2].enabled || tex[3].enabled)
			spanBox->setEnabled(true);
		else
			spanBox->setEnabled(false);
	}

	/** Handle removes/checkboxes independent */
	if(tex[0].name=="") {
		remF0->setEnabled(false);
		checkF0->setEnabled(false);
	}
	else {
		remF0->setEnabled(true);
		checkF0->setEnabled(true);
	}
	if(tex[1].name=="") {
		remF1->setEnabled(false);
		checkF1->setEnabled(false);
	}
	else {
		remF1->setEnabled(true);
		checkF1->setEnabled(true);
	}
	if(tex[2].name=="") {
		remF2->setEnabled(false);
		checkF2->setEnabled(false);
	}
	else {
		remF2->setEnabled(true);
		checkF2->setEnabled(true);
	}
	if(tex[3].name=="") {
		remPar->setEnabled(false);
		checkPar->setEnabled(false);
	}
	else {
		remPar->setEnabled(true);
		checkPar->setEnabled(true);
	}
}

/** Update fog light only due to flicker reasons */
void speWidget::updFogLig() {
	FR->setValue((int)(fog.fogLig[0]*255.0f));
	FG->setValue((int)(fog.fogLig[1]*255.0f));
	FB->setValue((int)(fog.fogLig[2]*255.0f));
	FA->setValue((int)(fog.fogLig[3]*255.0f));
	locFog->setChecked(fog.fogLigLoc);
}

/** Update whole fog section */
void speWidget::updFog() {

	fogBox->setChecked(fog.enabled);
	updFogLig();

	exp->setChecked(false);
	exp2->setChecked(false);
	lin->setChecked(false);
	switch(fog.fogType) {
		case 0: exp->setChecked(true);
				intLabel->setEnabled(true);
				startLabel->setEnabled(false);
				endLabel->setEnabled(false);
				fogIntensity->setEnabled(true);
				fogStart->setEnabled(false);
				fogEnd->setEnabled(false);
				break;
		case 1: exp2->setChecked(true);
				intLabel->setEnabled(true);
				startLabel->setEnabled(false);
				endLabel->setEnabled(false);
				fogIntensity->setEnabled(true);
				fogStart->setEnabled(false);
				fogEnd->setEnabled(false);
				break;
		case 2: lin->setChecked(true);
				intLabel->setEnabled(false);
				startLabel->setEnabled(true);
				endLabel->setEnabled(true);
				fogIntensity->setEnabled(false);
				fogStart->setEnabled(true);
				fogEnd->setEnabled(true);
				break;
	}

	fogIntensity->setValue(fog.intensity);
	fogStart->setValue(fog.start);
	fogEnd->setValue(fog.end);
}

/** Update whole motion blur section */
void speWidget::updMot() {

	motBox->setChecked(mot.enabled);
	fac->setValue((int)(mot.fac*100.0f));
	steps->setValue(mot.steps);
	trans->setValue((int)(mot.trans*10000.0f));
}


/** *************************************************************************
 ** REIMPLEMENT EVENTS FOR LOCALIZATIONS
****************************************************************************/
void speWidget::changeEvent(QEvent* event) {
	if(event->type() == QEvent::LanguageChange) {
		Ui_speUI::retranslateUi(this);
		setWindowTitle(tr("OpenGL"));
	}
	else
		QWidget::changeEvent(event);
}


/** *************************************************************************
 ** HANDLE SAVE/RESTORE OF WINDOW-COORDINATES
****************************************************************************/
void speWidget::closeEvent(QCloseEvent *event) {
	writeSettings();
	event->accept();
}

void speWidget::readSettings() {
	QSettings settings("Zhu3D", NAME);
	QPoint pos=settings.value("SpeWindowPos", QPoint(0, 0)).toPoint();
	QSize size=settings.value("SpeWindowSize", QSize(0, 0)).toSize();

	/** Ensure to start with defaults on 1st program-start ever */
	if(size.width() != 0) {
		resize(size);
		move(pos);
	}
	else {
		resize(QSize(330, 680));
		move(QPoint(200, 35));
	}
}

void speWidget::writeSettings() {
	QSettings settings("Zhu3D", NAME);
	settings.setValue("SpeWindowPos", pos());
	settings.setValue("SpeWindowSize", size());
}
