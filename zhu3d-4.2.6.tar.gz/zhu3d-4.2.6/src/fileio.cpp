/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#include "fileio.h"


/** Extern globals */
extern speWidget *speEdi;
extern funWidget *funEdi;
extern QString texDir;


/** Clean indents for XML */
static const QString b("   ");


/** Extract entry macros. Do NOT forget brackets arround them, when used in for loops et al !!! */
#define exts(s) (s)=file.readLine(); (s)=(s).section("<entry>",1,1).section("</entry>",0,0)
#define exti(i) tmp=file.readLine(); (i)=tmp.section("<entry>",1,1).section("</entry>",0,0).toLong()
#define extf(f) tmp=file.readLine(); (f)=tmp.section("<entry>",1,1).section("</entry>",0,0).toFloat()
#define skipEntries() while(file.readLine().contains("<entry>"));
#define checkSection(s) tmp=file.readLine(); if(!tmp.endsWith((QString)"<"+(s)+">\n")) return 3;


/** Load files >= 4.0.0 */
int zhuFile::load(const QString &fileName) {
	long i, j, k;
	QFile file(fileName);
	QString tmp;

	/** Open */
	file.open(QFile::ReadOnly | QFile::Text);
	QTextStream in(&file);
	tmp=file.readLine();
	tmp=file.readLine();

	/** Consider XML-validation bug in versions prior 4.1.2 and skip one input-line */
	if(getVersion(tmp)<412)
		tmp=file.readLine();

	/** Functions
	 ** Check equation string lengths to prevent potential buffer overflows */
	checkSection("Functions");
	for(i=0; i<MAXFUN; i++) { exts(ofun[i]); }
	for(i=0; i<MAXFUN; i++) { exts(oiso[i]); }
	for(i=0; i<MAXFUN; i++) { exts(opar[i]); }
	for(i=0; i<MAXFUN; i++) {
		if(ofun[i].length()>=MAXLEN-1) return 2; q2cstrcpy(fun[i].str, prepareInput(ofun[i]));
		if(oiso[i].length()>=MAXLEN-1) return 2; q2cstrcpy(iso[i].str, prepareInput(oiso[i]));
		if(opar[i].length()>=MAXLEN-1) return 2; q2cstrcpy(par.str[i], prepareInput(opar[i]));
	}
	skipEntries();

	/** Status */
	checkSection("Status");
	for(i=0; i<MAXFUN; i++) { exti(fun[i].drawFun); }
	for(i=0; i<MAXFUN; i++) { exti(iso[i].drawIso); }
	exti(par.drawPar);

	extf(par.sLow);
	extf(par.sHig);
	extf(par.tLow);
	extf(par.tHig);

	extf(sta.spx);
	extf(sta.spy);
	extf(sta.spz);

	exti(sta.funMod);
	extf(sta.angle);

	extf(sta.rotX);
	extf(sta.rotY);
	extf(sta.rotZ);

	extf(sta.transX);
	extf(sta.transY);
	extf(sta.transZ);

	extf(sta.crossX);
	extf(sta.crossY);

	extf(sta.sa);
	extf(sta.sx);
	extf(sta.sy);
	extf(sta.sz);

	exti(sta.fgrids);
	extf(sta.tessWidth);
	exti(sta.tgrids);
	exti(sta.triMod);
	sta.tessWidth=2.0f/sta.fgrids;

	exti(sta.cross);
	exti(sta.axes);
	exti(sta.wired);

	exti(sta.draw);
	exti(sta.ediLig);
	exti(sta.ediMat);

	for(i=0; i<3; i++) { extf(sta.axisCol[i]); }
	skipEntries();

	/** Lights */
	checkSection("Lights");
	exti(sta.ediLig);
	for(i=0; i<MAXLIG; i++) {
		exti(lig[i].setLig);
		exti(lig[i].ambLigLoc);
		exti(lig[i].difLigLoc);
		exti(lig[i].speLigLoc);
		exti(lig[i].ligDis);
		for(j=0; j<3; j++) { extf(lig[i].ligPos[j]); }
		for(j=0; j<4; j++) { extf(lig[i].ambLig[j]); }
		for(j=0; j<4; j++) { extf(lig[i].difLig[j]); }
		for(j=0; j<4; j++) { extf(lig[i].speLig[j]); }
		for(j=0; j<3; j++) { extf(lig[i].spoDir[j]); }
			// Fix for "array subscript is above array bounds" for j<4 for line above
			// Read dummy instead of "real" array value
			float errorDummy;
			extf(errorDummy);
			errorDummy = errorDummy;
		exti(lig[i].spoSta);
		extf(lig[i].spoExp);
		extf(lig[i].spoCut);
		extf(lig[i].conAtt);
		extf(lig[i].linAtt);
		extf(lig[i].quaAtt);
	}
	skipEntries();

	/** Materials */
	checkSection("Materials");
	exti(sta.ediMat);
	for(i=0; i<2; i++)
		for(j=0; j<MAXFUN+1; j++) {
			exti(mat[i].ambMatLoc[i]);
			exti(mat[i].difMatLoc[i]);
			exti(mat[i].speMatLoc[i]);
			exti(mat[i].emiMatLoc[i]);
			for(k=0; k<4; k++) { extf(mat[j].ambMat[i][k]); }
			for(k=0; k<4; k++) { extf(mat[j].difMat[i][k]); }
			for(k=0; k<4; k++) { extf(mat[j].speMat[i][k]); }
			for(k=0; k<4; k++) { extf(mat[j].emiMat[i][k]); }
			extf(mat[j].shiMat[i]);
	}
	for(i=0; i<MAXFUN+1; i++) { exti(mat[i].twoSid); }
	skipEntries();

	/** Entire */
	checkSection("Entire");
	exti(ent.ambEntLoc);
	exti(ent.bacEntLoc);
	extf(ent.modInf);
	extf(ent.modOne);
	for(i=0; i<4; i++) { extf(ent.bacLig[i]); }
	for(i=0; i<4; i++) { extf(ent.modLig[i]); }
	skipEntries();

	/** Animation */
	checkSection("Animation");
	exti(ani.xFac);
	exti(ani.yFac);
	exti(ani.zFac);
	exti(ani.locXYZ);
	exti(ani.active);
	exti(ani.fps);
	skipEntries();

	/** Fog */
	checkSection("Fog");
	exti(fog.enabled);
	exti(fog.fogLigLoc);
	for(i=0; i<4; i++) { extf(fog.fogLig[i]); }
	exti(fog.fogType);
	exti(fog.intensity);
	exti(fog.start);
	exti(fog.end);
	skipEntries();

	/** Textures; hSize & vSize are calculated in loadTexture() */
	checkSection("Textures");
	exti(texSpan);
	for(i=0; i<MAXFUN+1; i++) {
		exts(tex[i].name);
		exti(tex[i].enabled);
		exti(tex[i].flip);
		speEdi->loadTexture(texDir+tex[i].name, i);
	}
	skipEntries();

	/** Motion blur */
	checkSection("Motion-blur");
	exti(mot.enabled);
	exti(mot.steps);
	extf(mot.fac);
	extf(mot.trans);
	skipEntries();

	/** User table
	 ** Check string length of table entries to prevent potential buffer overflows */
	checkSection("User-table");
	for(i=0; i<MAXUSR; i++) {
		exts(usr[i]);
		if(usr[i].length()>=MAXLEN-1) return 2;
	}
	lastUsrEntry=fetchLastUsrEntry();
	skipEntries();

	/** Morphing */
	checkSection("Morphing");
	exti(mor.active);
	extf(mor.lower);
	extf(mor.upper);
	exti(mor.steps);
	extf(mor.val);
	exti(mor.fps);
	skipEntries();

	/** Legends */
	checkSection("Legends");
	exti(leg.savWidth);
	exti(leg.savHeight);
	for(i=0; i<9; i++) {
		exts(leg.label[i]);
		exti(leg.wfsize[i]);
		exti(leg.rfsize[i]);
		extf(leg.xOffs[i]);
		extf(leg.yOffs[i]);
		exti(leg.enabled[i]);
		exti(leg.locLeg[i]);
		extf(leg.prop[i]);
		leg.rfsize[i]=rf2i(leg.rfsize[i]*actHeight/(float)leg.savHeight);
	}
	for(i=0; i<6; i++)
		for(j=0; j<4; j++) { extf(leg.ligLeg[i][j]); }
	for(i=0; i<9; i++) {
		exts(leg.font[0]);
		exts(leg.style[0]);
	}
	skipEntries();

	/** Extension 0..2 */
	checkSection("Extension-0"); exts(tmp); skipEntries();
	checkSection("Extension-1"); exts(tmp); skipEntries();
	checkSection("Extension-2"); exts(tmp); skipEntries();

	/** Comment */
	checkSection("Comment");
	tmp="";
	tmp=file.readLine();
	while(!tmp.contains("</entry>"))
		tmp+=file.readLine();
	comment=tmp.remove(b+b+"<entry>").remove("</entry>\n");

	tmp=file.readLine();
	tmp=file.readLine();
	if(tmp!="</Zhu3D>")
		return 3;

	/** Everthing loaded */
	file.close();
	return 0;
}


/** *************************************************************************
 ** SAVE
****************************************************************************/
static QString begSec(const QString s) {
	return b+"<"+s+">\n";
}

static QString endSec(const QString s) {
	return b+"</"+s+">\n";
}

static QString outs(const QString s) {
	return b+b+"<entry>"+s+"</entry>\n";
}

static QString outf(const float f) {
	QString tmp;
	return b+b+"<entry>"+tmp.setNum(f,'f')+"</entry>\n";
}

static QString outi(const long i) {
	QString tmp;
	return b+b+"<entry>"+tmp.setNum(i)+"</entry>\n";
}


/** Save 4.1.2 format */
int zhuFile::save(const QString &fileName) {
	long i, j, k;
	QFile file(fileName);

	/** Check success */
	if(!file.open(QFile::WriteOnly | QFile::Text))
		return 0;

	QTextStream out(&file);
	QApplication::setOverrideCursor(Qt::WaitCursor);

	out << (QString)"<?xml version=\"1.0\" encoding=\"UTF-8\"?>" << "\n";
	out << (QString)"<Zhu3D version=\""+VERS+"\">" << "\n";

	out << begSec("Functions");
		for(i=0; i<MAXFUN; i++) out << outs(ofun[i]);
		for(i=0; i<MAXFUN; i++) out << outs(oiso[i]);
		for(i=0; i<MAXFUN; i++) out << outs(opar[i]);
	out << endSec("Functions");

	out << begSec("Status");
		for(i=0; i<MAXFUN; i++) out << outi(fun[i].drawFun);
		for(i=0; i<MAXFUN; i++) out << outi(iso[i].drawIso);
		out << outi(par.drawPar);

		out << outf(par.sLow);
		out << outf(par.sHig);
		out << outf(par.tLow);
		out << outf(par.tHig);

		out << outf(sta.spx);
		out << outf(sta.spy);
		out << outf(sta.spz);

		out << outi(sta.funMod);
		out << outf(sta.angle);

		out << outf(sta.rotX);
		out << outf(sta.rotY);
		out << outf(sta.rotZ);

		out << outf(sta.transX);
		out << outf(sta.transY);
		out << outf(sta.transZ);

		out << outf(sta.crossX);
		out << outf(sta.crossY);

		out << outf(sta.sa);
		out << outf(sta.sx);
		out << outf(sta.sy);
		out << outf(sta.sz);

		out << outi(sta.fgrids);
		out << outf(sta.tessWidth);
		out << outi(sta.tgrids);
		out << outi(sta.triMod);

		out << outi(sta.cross);
		out << outi(sta.axes);
		out << outi(sta.wired);

		out << outi(sta.draw);
		out << outi(sta.ediLig);
		out << outi(sta.ediMat);

		for(i=0; i<3; i++) out << outf(sta.axisCol[i]);
	out << endSec("Status");

	out << begSec("Lights");
		out << outi(sta.ediLig);
		for(i=0; i<MAXLIG; i++) {
			out << outi(lig[i].setLig);
			out << outi(lig[i].ambLigLoc);
			out << outi(lig[i].difLigLoc);
			out << outi(lig[i].speLigLoc);
			out << outi(lig[i].ligDis);
			for(j=0; j<3; j++) out << outf(lig[i].ligPos[j]);
			for(j=0; j<4; j++) out << outf(lig[i].ambLig[j]);
			for(j=0; j<4; j++) out << outf(lig[i].difLig[j]);
			for(j=0; j<4; j++) out << outf(lig[i].speLig[j]);
			for(j=0; j<3; j++) out << outf(lig[i].spoDir[j]);
				// Fix for "array subscript is above array bounds" for j<4 for line above
				// Story dummy instead of a "real" array value
				out << outf(0.0f);
			out << outi(lig[i].spoSta);
			out << outf(lig[i].spoExp);
			out << outf(lig[i].spoCut);
			out << outf(lig[i].conAtt);
			out << outf(lig[i].linAtt);
			out << outf(lig[i].quaAtt);
		}
	out << endSec("Lights");

	out << begSec("Materials");
		out << outi(sta.ediMat);
		for(i=0; i<2; i++)
			for(j=0; j<MAXFUN+1; j++) {
				out << outi(mat[i].ambMatLoc[i]);
				out << outi(mat[i].difMatLoc[i]);
				out << outi(mat[i].speMatLoc[i]);
				out << outi(mat[i].emiMatLoc[i]);
				for(k=0; k<4; k++) out << outf(mat[j].ambMat[i][k]);
				for(k=0; k<4; k++) out << outf(mat[j].difMat[i][k]);
				for(k=0; k<4; k++) out << outf(mat[j].speMat[i][k]);
				for(k=0; k<4; k++) out << outf(mat[j].emiMat[i][k]);
				out << outf(mat[j].shiMat[i]);
		}
		for(i=0; i<MAXFUN+1; i++) out << outi(mat[i].twoSid);
	out << endSec("Materials");

	out << begSec("Entire");
		out << outi(ent.ambEntLoc);
		out << outi(ent.bacEntLoc);
		out << outf(ent.modInf);
		out << outf(ent.modOne);
		for(i=0; i<4; i++) out << outf(ent.bacLig[i]);
		for(i=0; i<4; i++) out << outf(ent.modLig[i]);
	out << endSec("Entire");

	out << begSec("Animation");
		out << outi(ani.xFac);
		out << outi(ani.yFac);
		out << outi(ani.zFac);
		out << outi(ani.locXYZ);
		out << outi(ani.active);
		out << outi(ani.fps);
	out << endSec("Animation");

	out << begSec("Fog");
		out << outi(fog.enabled);
		out << outi(fog.fogLigLoc);
		for(i=0; i<4; i++) out << outf(fog.fogLig[i]);
		out << outi(fog.fogType);
		out << outi(fog.intensity);
		out << outi(fog.start);
		out << outi(fog.end);
	out << endSec("Fog");

	out << begSec("Textures");
		out << outi(texSpan);
		for(i=0; i<MAXFUN+1; i++) {
			out << outs(tex[i].name);
			out << outi(tex[i].enabled);
			out << outi(tex[i].flip);
		}
	out << endSec("Textures");

	out << begSec("Motion-blur");
		out << outi(mot.enabled);
		out << outi(mot.steps);
		out << outf(mot.fac);
		out << outf(mot.trans);
	out << endSec("Motion-blur");

	out << begSec("User-table");
		for(i=0; i<MAXUSR; i++)
			out << outs(usr[i]);
	out << endSec("User-table");

	out << begSec("Morphing");
		QString tmp, low, upp, ste, val, fps;
		out << outi(mor.active);
		out << outf(mor.lower);
		out << outf(mor.upper);
		out << outi(mor.steps);
		out << outf(mor.val);
		out << outi(mor.fps);
	out << endSec("Morphing");

	out << begSec("Legends");
		out << outi(leg.savWidth=actWidth);
		out << outi(leg.savHeight=actHeight);
		for(i=0; i<9; i++) {
			out << outs(leg.label[i]);
			out << outi(leg.wfsize[i]);
			out << outi(leg.rfsize[i]);
			out << outf(leg.xOffs[i]);
			out << outf(leg.yOffs[i]);
			out << outi(leg.enabled[i]);
			out << outi(leg.locLeg[i]);
			out << outf(leg.rfsize[i]/(float)actHeight);
		}
		for(i=0; i<6; i++)
			for(j=0; j<4; j++) out << outf(leg.ligLeg[i][j]);
		for(i=0; i<9; i++) {
			out << outs(leg.font[i]);
			out << outs(leg.style[i]);
		}
	out << endSec("Legends");

	out << begSec("Extension-0");
		out << outs("");
	out << endSec("Extension-0");

	out << begSec("Extension-1");
		out << outs("");
	out << endSec("Extension-1");

	out << begSec("Extension-2");
		out << outs("");
	out << endSec("Extension-2");

	out << begSec("Comment");
		out << outs(funEdi->getCom());
	out << endSec("Comment");

	/** Everything finished */
	out << (QString)"</Zhu3D>";
	QApplication::restoreOverrideCursor();
	file.close();
	return 1;
}

/** Fetch file version */
int zhuFile::getVersion(const QString &header) {

	QString tmp=header;
	tmp=tmp.section('=',1,1);

	/** Remove odd chars for number string */
	tmp.remove(QChar('.'));
	tmp.remove(QChar('"'));
	tmp.remove(QChar('>'));

	return version=tmp.toInt();
}
