/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/
// #undef USE_SSE3         // For testing purposes only

#include <cstdlib>         // For Quicksort only
#ifdef USE_SSE3            // Is SSE3 enabled in zhu3d.pro ?
#include <pmmintrin.h>
#endif
#include "gldraw.h"
#include "iso.h"           // Isosurface generation
#include "pinterface.h"    // Bytecode parser, modified float version
#include "timers.h"        // For benchmarking "Isomarks"


/** Adressing the 8 lights and texture ID's */
extern const long lightBase;     // Global from OGLWidget
extern unsigned int texID[4];    // Global from OGLWidget


/** Number of threads */
extern int numCPU;


/** Some stuff for descending sorting the alpha-channels */
#define MAX(a,b) (((a)>(b))?(a):(b))

struct ALPHA {
	long index;      // Remember original index
	float val;       // Material property for diffuse alpha-channel
	bool parflag;    // Originally an entry for parametric system?
};


/** Array for alpha channels */
static ALPHA alpha[MAXFUN+1];


/** The compare-function for Quicksort */
static int cmpAlpha(const void *elem1, const void *elem2) {
	if( ((ALPHA *)elem1)->val < ((ALPHA *)elem2)->val )
		return 1;
	else
		if( ((ALPHA *)elem1)->val > ((ALPHA *)elem2)->val )
			return -1;
		else
			return 0;
}


/** Fetch all alpha-channel-values */
static void getAlpha(void) {
	for(long i=0; i<MAXFUN+1; i++) {
		alpha[i].index=i;
		alpha[i].parflag=false;
		if(!mat[i].twoSid)
			alpha[i].val = mat[i].difMat[0][3];
		else
			alpha[i].val = MAX(mat[i].difMat[0][3], mat[i].difMat[1][3]);
	}

	/** Mark the parametric system at last */
	alpha[MAXFUN].parflag=true;
}


/** Generate OpenGL-lists */
static void GenFunPoints(const long n);
static void GenIsoPoints(const long n);
static void GenParPoints();

static void GenFunQuads(const long n);
static void GenParQuads();
static void GenTexFunQuads(const long n);
static void GenTexParQuads();

static void GenFunTriangles(const long n);
static void GenIsoTriangles(const long n);
static void GenParTriangles();
static void GenTexFunTriangles(const long n);
static void GenTexIsoTriangles(const long n);
static void GenTexParTriangles();


/** List-Handling & decision which functions to draw */
bool listUp[MAXFUN+1] = {true, false, false, false};
long oglLis[MAXFUN+1] = {1, 2, 3, 4};
bool drawFunGL[MAXFUN];


/** Prototypes for conveniance functions */
float fxy0(const float xpar, const float ypar);
float fxy1(const float xpar, const float ypar);
float fxy2(const float xpar, const float ypar);
static float par0(const float xpar, const float ypar);
static float par1(const float xpar, const float ypar);
static float par2(const float xpar, const float ypar);
static void setMat(const long n);    // 0..2 for functions; 3 for parameter-mode


/** Array of function-pointers */
static float (*funPtr[MAXFUN])(const float xpar, const float ypar) = {fxy0, fxy1, fxy2};


/** Local helper function */
#ifdef USESSE3
inline static void normCrossProd(__m128 v1, __m128 v2, __m128 &normal);
#else
inline static void normCrossProd(const float v1[3], const float v2[3], float norm[3]);
#endif


/** *************************************************************************
 ** IMPLEMENTATION PART
****************************************************************************/

/** Calculating parser-values for functions/parametric-system */
float fxy0(const float xpar, const float ypar) {
	FPFLOAT vars[2];
	const float tmpsz = (mor.active) ? (sta.sz*mor.val) : sta.sz;
	vars[0] = xpar * sta.sx;
	vars[1] = ypar * sta.sy;
	return fpGL[0].Eval(vars) * tmpsz;
}

float fxy1(const float xpar, const float ypar) {
	FPFLOAT vars[2];
	const float tmpsz = (mor.active) ? (sta.sz*mor.val) : sta.sz;
	vars[0] = xpar * sta.sx;
	vars[1] = ypar * sta.sy;
	return fpGL[1].Eval(vars) * tmpsz;
}

float fxy2(const float xpar, const float ypar) {
	FPFLOAT vars[2];
	const float tmpsz = (mor.active) ? (sta.sz*mor.val) : sta.sz;
	vars[0] = xpar * sta.sx;
	vars[1] = ypar * sta.sy;
	return fpGL[2].Eval(vars) * tmpsz;
}

static float par0(const float xpar, const float ypar) {
	FPFLOAT vars[2];
	const float tmpspz = (mor.active) ? (sta.spz*mor.val) : sta.spz;
	vars[0] = xpar * sta.spx;
	vars[1] = ypar * sta.spy;
	return fpGL[3].Eval(vars) * tmpspz;
}

static float par1(const float xpar, const float ypar) {
	FPFLOAT vars[2];
	const float tmpspz = (mor.active) ? (sta.spz*mor.val) : sta.spz;
	vars[0] = xpar * sta.spx;
	vars[1] = ypar * sta.spy;
	return fpGL[4].Eval(vars) * tmpspz;
}

static float par2(const float xpar, const float ypar) {
	FPFLOAT vars[2];
	const float tmpspz = (mor.active) ? (sta.spz*mor.val) : sta.spz;
	vars[0] = xpar * sta.spx;
	vars[1] = ypar * sta.spy;
	return fpGL[5].Eval(vars) * tmpspz;
}


/** Check whether to draw functions or implicite functions currently */
void Draw_Which(void) {
	long i;

	if(sta.funMod==FUNCTION)
		for(i=0; i<MAXFUN; i++)
			drawFunGL[i]=fun[i].drawFun;

	if(sta.funMod==IMPLICITE)
		for(i=0; i<MAXFUN; i++)
			drawFunGL[i]=iso[i].drawIso;

	if(sta.funMod==PARAMETER)
		for(i=0; i<MAXFUN; i++)
			drawFunGL[i]=false;
}


/** Generate normal-vector from v1 and v2 and normalize it */
#ifdef USESSE3
inline static void normCrossProd(__m128 v1, __m128 v2, __m128 &normal) {

	__m128 va, vb, xa, xb;

	va = _mm_shuffle_ps(v1, v1, _MM_SHUFFLE(3,0,2,1));
	vb = _mm_shuffle_ps(v2, v2, _MM_SHUFFLE(3,1,0,2));
	v1 = _mm_shuffle_ps(v1, v1, _MM_SHUFFLE(3,1,0,2));
	v2 = _mm_shuffle_ps(v2, v2, _MM_SHUFFLE(3,0,2,1));

	xa = _mm_mul_ps(va, vb);
	xb = _mm_mul_ps(v1, v2);

	// Now we got the normal vector in xa. Lets normalize it at last
	xa = _mm_sub_ps(xa, xb);
	xb = _mm_mul_ps(xa, xa);
	xb = _mm_hadd_ps(xb, xb);
	xb = _mm_hadd_ps(xb, xb);

	normal = _mm_mul_ps(xa, _mm_rsqrt_ps(xb));
}
#else
inline static void normCrossProd(const float v1[3], const float v2[3], float norm[3]) {

	/** Calculate normal vector */
	norm[0] = v1[1]*v2[2] - v1[2]*v2[1];
	norm[1] = v1[2]*v2[0] - v1[0]*v2[2];
	norm[2] = v1[0]*v2[1] - v1[1]*v2[0];

	/** Normalize it */
	const float len = 1.0f/sqrtf(norm[0]*norm[0] + norm[1]*norm[1] + norm[2]*norm[2]);

	norm[0] *= len;
	norm[1] *= len;
	norm[2] *= len;
}
// USE_SSE3
#endif


/** *************************************************************************
 ** Draw points
****************************************************************************/
void Draw_Points(void) {

	/** Consider depth-buffers for transparent views
	 ** Get data & sort on descending alpha-channels */
	getAlpha();
	qsort(alpha, MAXFUN+1, sizeof(ALPHA), &cmpAlpha);

	for(long i=0; i<MAXFUN+1; i++)

		/** Check for originally parametric system */
		if(alpha[i].parflag) {
			/** Update list and view only, when needed */
			if(par.drawPar) {
				setMat(alpha[i].index);
				if(listUp[alpha[i].index])
					GenParPoints();
				glCallList(oglLis[alpha[i].index]);
			}
		}
		/** It was a function originally */
		else
			/** Update list and view only, when needed */
			if(drawFunGL[alpha[i].index]) {
				setMat(alpha[i].index);
				if(listUp[alpha[i].index]) {
					if(sta.funMod==FUNCTION)
						GenFunPoints(alpha[i].index);
					else
						GenIsoPoints(alpha[i].index);
					}
				glCallList(oglLis[alpha[i].index]);
			}
}


/** Generate iso-points */
static void GenIsoPoints(const long n) {

	ISOGEN isoGen[numCPUset];
	int i, j;
	TIMERS t;

	/** Init threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].vMarching(itl.at(i).from, itl.at(i).to, n);

	/** Start threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].start();

	/** Synchronize threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].wait();

	/** Timer zhumark for iso-calcs */
	zsecs=t.stop();

	glNewList(oglLis[n], GL_COMPILE);
	glPushMatrix();
	glTranslatef(-1.0f, -1.0f, -1.0f);
	glBegin(GL_POINTS);
	for(i=0; i<numCPUset; i++)
		for(j=0; j<isoGen[i].normList.size(); j++) {
			glNormal3fv((float *)&isoGen[i].normList.at(j).p0);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p0);
			glNormal3fv((float *)&isoGen[i].normList.at(j).p1);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p1);
			glNormal3fv((float *)&isoGen[i].normList.at(j).p2);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p2);
		}
	glEnd();
	glPopMatrix();
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}


/** Generate point-list */
#ifdef USESSE3
static void GenFunPoints(const long n) {
	float x, y;
	__m128 p[4], v1, v2, norm;
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	glBegin(GL_POINTS);
	x=-1.0f;
	for(i=0; i<sta.fgrids; i++, x+=step) {
		y=-1.0f;
  		for(j=0; j<sta.fgrids; j++, y+=step) {

			p[0] = _mm_set_ps(0.0f, (*funPtr[n])(x, y), y, x);
			p[1] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y), y, x+step);
			p[2] = _mm_set_ps(0.0f, (*funPtr[n])(x, y+step), y+step, x);
			p[3] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y+step), y+step, x+step);

			v1 = _mm_sub_ps(p[3], p[0]);
			v2 = _mm_sub_ps(p[3], p[1]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			glVertex3fv((float*)&p[0]);    // x  y
			glVertex3fv((float*)&p[1]);    // x+ y
			glVertex3fv((float*)&p[2]);    // x  y+
			glVertex3fv((float*)&p[3]);    // x+ y+
		}
	}
	glEnd();
	glEndList();
	listUp[n]=false;
	PROC_EVENT;
}
#else
static void GenFunPoints(const long n) {
	float x, y;
	float p[4][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	glBegin(GL_POINTS);
	x=-1.0f;
	for(i=0; i<sta.fgrids; i++, x+=step) {
		y=-1.0f;
  		for(j=0; j<sta.fgrids; j++, y+=step) {

			p[0][0]=x;
			p[0][1]=y;
			p[0][2]=(*funPtr[n])(x, y);

			p[1][0]=x+step;
			p[1][1]=y;
			p[1][2]=(*funPtr[n])(x+step, y);

			p[2][0]=x;
			p[2][1]=y+step;
			p[2][2]=(*funPtr[n])(x, y+step);

			p[3][0]=x+step;
			p[3][1]=y+step;
			p[3][2]=(*funPtr[n])(x+step, y+step);

			v1[0]=p[3][0]-p[0][0];
			v1[1]=p[3][1]-p[0][1];
			v1[2]=p[3][2]-p[0][2];

			v2[0]=p[3][0]-p[1][0];
			v2[1]=p[3][1]-p[1][1];
			v2[2]=p[3][2]-p[1][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			glVertex3fv(p[0]);    // x  y
			glVertex3fv(p[1]);    // x+ y
			glVertex3fv(p[2]);    // x  y+
			glVertex3fv(p[3]);    // x+ y+
		}
	}
	glEnd();
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** Generate point-parameter list */
#ifdef USESSE3
static void GenParPoints() {
	float s, t;
	__m128 p[4], v1, v2, norm;
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	glBegin(GL_POINTS);
	s=-1.0f;
	for(i=0; i<sta.fgrids; i++, s+=step) {
		t=-1.0f;
  		for(j=0; j<sta.fgrids; j++, t+=step) {

			p[0] = _mm_set_ps(0.0f, par2(s,t), par1(s,t), par0(s,t));
			p[1] = _mm_set_ps(0.0f, par2(s+step, t), par1(s+step, t), par0(s+step, t));
			p[2] = _mm_set_ps(0.0f, par2(s, t+step), par1(s, t+step), par0(s, t+step));
			p[3] = _mm_set_ps(0.0f, par2(s+step, t+step), par1(s+step, t+step), par0(s+step, t+step));

			v1 = _mm_sub_ps(p[3], p[0]);
			v2 = _mm_sub_ps(p[3], p[1]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			glVertex3fv((float*)&p[0]);    // s  t
			glVertex3fv((float*)&p[1]);    // s+ t
			glVertex3fv((float*)&p[2]);    // s  t+
			glVertex3fv((float*)&p[3]);    // s+ t+
		}
	}
	glEnd();
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
#else
static void GenParPoints() {
	float s, t;
	float p[4][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	glBegin(GL_POINTS);
	s=-1.0f;
	for(i=0; i<sta.fgrids; i++, s+=step) {
		t=-1.0f;
  		for(j=0; j<sta.fgrids; j++, t+=step) {

			p[0][0]=par0(s,t);
			p[0][1]=par1(s,t);
			p[0][2]=par2(s,t);

			p[1][0]=par0(s+step, t);
			p[1][1]=par1(s+step, t);
			p[1][2]=par2(s+step, t);

			p[2][0]=par0(s, t+step);
			p[2][1]=par1(s, t+step);
			p[2][2]=par2(s, t+step);

			p[3][0]=par0(s+step, t+step);
			p[3][1]=par1(s+step, t+step);
			p[3][2]=par2(s+step, t+step);

			v1[0]=p[3][0]-p[0][0];
			v1[1]=p[3][1]-p[0][1];
			v1[2]=p[3][2]-p[0][2];

			v2[0]=p[3][0]-p[1][0];
			v2[1]=p[3][1]-p[1][1];
			v2[2]=p[3][2]-p[1][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			glVertex3fv(p[0]);    // s  t
			glVertex3fv(p[1]);    // s+ t
			glVertex3fv(p[2]);    // s  t+
			glVertex3fv(p[3]);    // s+ t+
		}
	}
	glEnd();
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** *************************************************************************
 ** Draws Quads
****************************************************************************/
void Draw_Quads(void) {

	/** Consider depth-buffers for transparent views
	 ** Get data & sort on descending alpha-channels */
	getAlpha();
	qsort(alpha, MAXFUN+1, sizeof(ALPHA), &cmpAlpha);

	for(long i=0; i<MAXFUN+1; i++)

		/** Check for originally parametric system */
		if(alpha[i].parflag) {
			/** Update list and view only, when needed */
			if(par.drawPar) {
				setMat(alpha[i].index);
				if(listUp[alpha[i].index]) {
					if(tex[alpha[i].index].enabled == true)
						GenTexParQuads();
					else
						GenParQuads();
				}
				glCallList(oglLis[alpha[i].index]);
			}
		}
		/** It was a function originally */
		else
			/** Update list and view only, when needed */
			if(drawFunGL[alpha[i].index]) {
				setMat(alpha[i].index);
				if(listUp[alpha[i].index]) {
					if(tex[alpha[i].index].enabled == true && sta.funMod!=IMPLICITE)
						GenTexFunQuads(alpha[i].index);
					else
						GenFunQuads(alpha[i].index);
				}
				glCallList(oglLis[alpha[i].index]);
			}
}


/** Generate function quad-list */
#ifdef USESSE3
static void GenFunQuads(const long n) {
	float x, y;
	__m128 p[3], v1, v2, norm;
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	x=-1.0f;
	for(i=0; i<sta.fgrids; i++, x+=step) {
		glBegin(GL_QUAD_STRIP);
		y=-1.0f;
		for(j=0; j<=sta.fgrids; j++, y+=step) {

			p[0] = _mm_set_ps(0.0f, (*funPtr[n])(x, y), y, x);
			p[1] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y), y, x+step);
			p[2] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y+step), y+step, x+step);

			v1 = _mm_sub_ps(p[2], p[0]);
			v2 = _mm_sub_ps(p[2], p[1]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			glVertex3fv((float*)&p[0]);    // x  y
			glVertex3fv((float*)&p[1]);    // x+ y
		}
		glEnd();
	}
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}
#else
static void GenFunQuads(const long n) {
	float x, y;
	float p[3][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	x=-1.0f;
	for(i=0; i<sta.fgrids; i++, x+=step) {
		glBegin(GL_QUAD_STRIP);
		y=-1.0f;
		for(j=0; j<=sta.fgrids; j++, y+=step) {
			p[0][0]=x;
			p[0][1]=y;
			p[0][2]=(*funPtr[n])(x, y);

			p[1][0]=x+step;
			p[1][1]=y;
			p[1][2]=(*funPtr[n])(x+step, y);

			p[2][0]=x+step;
			p[2][1]=y+step;
			p[2][2]=(*funPtr[n])(x+step, y+step);

			v1[0]=p[2][0]-p[0][0];
			v1[1]=p[2][1]-p[0][1];
			v1[2]=p[2][2]-p[0][2];

			v2[0]=p[2][0]-p[1][0];
			v2[1]=p[2][1]-p[1][1];
			v2[2]=p[2][2]-p[1][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			glVertex3fv(p[0]);    // x  y
			glVertex3fv(p[1]);    // x+ y
		}
		glEnd();
	}
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** Generate parameter quad-list */
#ifdef USESSE3
static void GenParQuads() {
	float s, t;
	__m128 p[3], v1, v2, norm;
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	s=-1.0f;
	for(i=0; i<sta.fgrids; i++, s+=step) {
		glBegin(GL_QUAD_STRIP);
		t=-1.0f;
		for(j=0; j<=sta.fgrids; j++, t+=step) {

			p[0] = _mm_set_ps(0.0f, par2(s,t), par1(s,t), par0(s,t));
			p[1] = _mm_set_ps(0.0f, par2(s+step, t), par1(s+step, t), par0(s+step, t));
			p[2] = _mm_set_ps(0.0f, par2(s+step, t+step), par1(s+step, t+step), par0(s+step, t+step));

			v1 = _mm_sub_ps(p[2], p[0]);
			v2 = _mm_sub_ps(p[2], p[1]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			glVertex3fv((float*)&p[0]);    // s  t
			glVertex3fv((float*)&p[1]);    // s+ t
		}
		glEnd();
	}
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
#else
static void GenParQuads() {
	float s, t;
	float p[3][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	s=-1.0f;
	for(i=0; i<sta.fgrids; i++, s+=step) {
		glBegin(GL_QUAD_STRIP);
		t=-1.0f;
		for(j=0; j<=sta.fgrids; j++, t+=step) {

			p[0][0]=par0(s,t);
			p[0][1]=par1(s,t);
			p[0][2]=par2(s,t);

			p[1][0]=par0(s+step, t);
			p[1][1]=par1(s+step, t);
			p[1][2]=par2(s+step, t);

			p[2][0]=par0(s+step, t+step);
			p[2][1]=par1(s+step, t+step);
			p[2][2]=par2(s+step, t+step);

			v1[0]=p[2][0]-p[0][0];
			v1[1]=p[2][1]-p[0][1];
			v1[2]=p[2][2]-p[0][2];

			v2[0]=p[2][0]-p[1][0];
			v2[1]=p[2][1]-p[1][1];
			v2[2]=p[2][2]-p[1][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			glVertex3fv(p[0]);    // s  t
			glVertex3fv(p[1]);    // s+ t
		}
		glEnd();
	}
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** Generate texture quad-list */
#ifdef USESSE3
static void GenTexFunQuads(const long n) {
	float x, y;
	__m128 p[4], v1, v2, norm;
	const float step=2.0f/sta.fgrids;

	float xs, ys;
	const float wd=1.0f/texSpan;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[n]);
	x=-1.0f;
	for(i=0; i<sta.fgrids; i++, x+=step) {
		y=-1.0f;
		xs=(i%texSpan)*wd;
		for(j=0; j<sta.fgrids; j++, y+=step) {

			p[0] = _mm_set_ps(0.0f, (*funPtr[n])(x, y), y, x);
			p[1] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y), y, x+step);
			p[2] = _mm_set_ps(0.0f, (*funPtr[n])(x, y+step), y+step, x);
			p[3] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y+step), y+step, x+step);

			v1 = _mm_sub_ps(p[3], p[0]);
			v2 = _mm_sub_ps(p[3], p[1]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			ys=(j%texSpan)*wd;

			glBegin(GL_QUAD_STRIP);
			glTexCoord2f(xs,    ys);	glVertex3fv((float*)&p[0]);    // x  y
			glTexCoord2f(xs+wd, ys);	glVertex3fv((float*)&p[1]);    // x+ y
			glTexCoord2f(xs,    ys+wd);	glVertex3fv((float*)&p[2]);    // x  y+
			glTexCoord2f(xs+wd, ys+wd);	glVertex3fv((float*)&p[3]);    // x+ y+
			glEnd();
		}
	}
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}
#else
static void GenTexFunQuads(const long n) {
	float x, y;
	float p[4][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;

	float xs, ys;
	const float wd=1.0f/texSpan;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[n]);
	x=-1.0f;
	for(i=0; i<sta.fgrids; i++, x+=step) {
		y=-1.0f;
		xs=(i%texSpan)*wd;
		for(j=0; j<sta.fgrids; j++, y+=step) {

			p[0][0]=x;
			p[0][1]=y;
			p[0][2]=(*funPtr[n])(x, y);

			p[1][0]=x+step;
			p[1][1]=y;
			p[1][2]=(*funPtr[n])(x+step, y);

			p[2][0]=x;
			p[2][1]=y+step;
			p[2][2]=(*funPtr[n])(x, y+step);

			p[3][0]=x+step;
			p[3][1]=y+step;
			p[3][2]=(*funPtr[n])(x+step, y+step);

			v1[0]=p[3][0]-p[0][0];
			v1[1]=p[3][1]-p[0][1];
			v1[2]=p[3][2]-p[0][2];

			v2[0]=p[3][0]-p[1][0];
			v2[1]=p[3][1]-p[1][1];
			v2[2]=p[3][2]-p[1][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);
			ys=(j%texSpan)*wd;

			glBegin(GL_QUAD_STRIP);
			glTexCoord2f(xs,    ys);	glVertex3fv(p[0]);    // x  y
			glTexCoord2f(xs+wd, ys);	glVertex3fv(p[1]);    // x+ y
			glTexCoord2f(xs,    ys+wd);	glVertex3fv(p[2]);    // x  y+
			glTexCoord2f(xs+wd, ys+wd);	glVertex3fv(p[3]);    // x+ y+
			glEnd();
		}
	}
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** Generate texture+parameter quad-list */
#ifdef USESSE3
static void GenTexParQuads() {
	float s, t;
	__m128 p[4], v1, v2, norm;
	const float step=2.0f/sta.fgrids;

	float xs, ys;
	const float wd=1.0f/texSpan;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	s=-1.0f;
	for(i=0; i<sta.fgrids; i++, s+=step) {
		t=-1.0f;
		xs=(i%texSpan)*wd;
		for(j=0; j<sta.fgrids; j++, t+=step) {

			p[0] = _mm_set_ps(0.0f, par2(s,t), par1(s,t), par0(s,t));
			p[1] = _mm_set_ps(0.0f, par2(s+step, t), par1(s+step, t), par0(s+step, t));
			p[2] = _mm_set_ps(0.0f, par2(s, t+step), par1(s, t+step), par0(s, t+step));
			p[3] = _mm_set_ps(0.0f, par2(s+step, t+step), par1(s+step, t+step), par0(s+step, t+step));

			v1 = _mm_sub_ps(p[3], p[0]);
			v2 = _mm_sub_ps(p[3], p[1]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			ys=(j%texSpan)*wd;

			glBegin(GL_QUAD_STRIP);
			glTexCoord2f(xs,    ys);	glVertex3fv((float*)&p[0]);    // s  t
			glTexCoord2f(xs+wd, ys);	glVertex3fv((float*)&p[1]);    // s+ t
			glTexCoord2f(xs,    ys+wd);	glVertex3fv((float*)&p[2]);    // s  t+
			glTexCoord2f(xs+wd, ys+wd);	glVertex3fv((float*)&p[3]);    // s+ t+
			glEnd();
		}
	}
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
#else
static void GenTexParQuads() {
	float s, t;
	float p[4][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;

	float xs, ys;
	const float wd=1.0f/texSpan;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	s=-1.0f;
	for(i=0; i<sta.fgrids; i++, s+=step) {
		t=-1.0f;
		xs=(i%texSpan)*wd;
		for(j=0; j<sta.fgrids; j++, t+=step) {

			p[0][0]=par0(s,t);
			p[0][1]=par1(s,t);
			p[0][2]=par2(s,t);

			p[1][0]=par0(s+step, t);
			p[1][1]=par1(s+step, t);
			p[1][2]=par2(s+step, t);

			p[2][0]=par0(s, t+step);
			p[2][1]=par1(s, t+step);
			p[2][2]=par2(s, t+step);

			p[3][0]=par0(s+step, t+step);
			p[3][1]=par1(s+step, t+step);
			p[3][2]=par2(s+step, t+step);

			v1[0]=p[3][0]-p[0][0];
			v1[1]=p[3][1]-p[0][1];
			v1[2]=p[3][2]-p[0][2];

			v2[0]=p[3][0]-p[1][0];
			v2[1]=p[3][1]-p[1][1];
			v2[2]=p[3][2]-p[1][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			ys=(j%texSpan)*wd;

			glBegin(GL_QUAD_STRIP);
			glTexCoord2f(xs,    ys);	glVertex3fv(p[0]);    // s  t
			glTexCoord2f(xs+wd, ys);	glVertex3fv(p[1]);    // s+ t
			glTexCoord2f(xs,    ys+wd);	glVertex3fv(p[2]);    // s  t+
			glTexCoord2f(xs+wd, ys+wd);	glVertex3fv(p[3]);    // s+ t+
			glEnd();
		}
	}
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** *************************************************************************
 ** Draws Triangles
****************************************************************************/
void Draw_Triangles(void) {

	/** Consider depth-buffers for transparent views
	 ** Get data & sort on descending alpha-channels */
	getAlpha();
	qsort(alpha, MAXFUN+1, sizeof(ALPHA), &cmpAlpha);

	for(long i=0; i<MAXFUN+1; i++)

		/** Check for originally parametric system */
		if(alpha[i].parflag) {
			/** Update list and view only, when needed */
			if(par.drawPar) {
				setMat(alpha[i].index);
				if(listUp[alpha[i].index]) {
					if(tex[alpha[i].index].enabled == true)
						GenTexParTriangles();
					else
						GenParTriangles();
				}
				glCallList(oglLis[alpha[i].index]);
			}
		}
		/** It was a function originally */
		else
			/** Update list and view only, when needed */
			if(drawFunGL[alpha[i].index]) {
				setMat(alpha[i].index);
				if(listUp[alpha[i].index]) {
					if(tex[alpha[i].index].enabled) {
						if(sta.funMod==FUNCTION)
							GenTexFunTriangles(alpha[i].index);
						if(sta.funMod==IMPLICITE)
							GenTexIsoTriangles(alpha[i].index);
					}
					else {
						if(sta.funMod==FUNCTION)
							GenFunTriangles(alpha[i].index);
						if(sta.funMod==IMPLICITE)
							GenIsoTriangles(alpha[i].index);
					}
				}
				glCallList(oglLis[alpha[i].index]);
			}
}


/** Generate iso triangle-list */
static void GenIsoTriangles(const long n) {

	ISOGEN isoGen[numCPUset];
	int i, j;
	TIMERS t;

	/** Init threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].vMarching(itl.at(i).from, itl.at(i).to, n);

	/** Start threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].start();

	/** Synchronize threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].wait();

	/** Timer zhumark for iso-calcs */
	zsecs=t.stop();

	/** Continue with OpenGL stuff */
	glNewList(oglLis[n], GL_COMPILE);
	glPushMatrix();
	glTranslatef(-1.0f, -1.0f, -1.0f);
	glBegin(GL_TRIANGLES);
	for(i=0; i<numCPUset; i++)
		for(j=0; j<isoGen[i].normList.size(); j++) {
			glNormal3fv((float *)&isoGen[i].normList.at(j).p0);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p0);
			glNormal3fv((float *)&isoGen[i].normList.at(j).p1);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p1);
			glNormal3fv((float *)&isoGen[i].normList.at(j).p2);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p2);
		}
	glEnd();
	glPopMatrix();
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}

/** Generate texture+iso triangle-list */
static void GenTexIsoTriangles(const long n) {

	ISOGEN isoGen[numCPUset];
	int i, j;
	const float wd = 1.0f/(texSpan/5.0f);

	/** Init threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].vMarching(itl.at(i).from, itl.at(i).to, n);

	/** Start threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].start();

	/** Synchronize threads */
	for(i=0; i<numCPUset; i++)
		isoGen[i].wait();

	/** Continue with OpenGL stuff */
	glNewList(oglLis[n], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[n]);
	glPushMatrix();
	glTranslatef(-1.0f, -1.0f, -1.0f);
	glBegin(GL_TRIANGLES);
	for(i=0; i<numCPUset; i++)
		for(j=0; j<isoGen[i].normList.size(); j++) {
			glNormal3fv((float *)&isoGen[i].normList.at(j).p0);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p0);
			glNormal3fv((float *)&isoGen[i].normList.at(j).p1);
			glTexCoord2f(wd, wd);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p1);
			glNormal3fv((float *)&isoGen[i].normList.at(j).p2);
			glTexCoord2f(0.0f, wd);
			glVertex3fv((float *)&isoGen[i].vertList.at(j).p2);
		}
	glEnd();
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}


/** Generate function triangle-list */
#ifdef USESSE3
static void GenFunTriangles(const long n) {
	float x, y;
	__m128 p[3], v1, v2, norm;
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	x=-1.0f;
	for(i=0; i<sta.fgrids; i++, x+=step) {
		glBegin(GL_TRIANGLE_STRIP);
		y=-1.0f;
		for(j=0; j<=sta.fgrids; j++, y+=step) {

			p[0] = _mm_set_ps(0.0f, (*funPtr[n])(x, y), y, x);
			p[1] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y), y, x+step);
			p[2] = _mm_set_ps(0.0f, (*funPtr[n])(x, y+step), y+step, x);

			v1 = _mm_sub_ps(p[1], p[0]);
			v2 = _mm_sub_ps(p[2], p[0]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			glVertex3fv((float*)&p[0]);
			glVertex3fv((float*)&p[1]);
		}
		glEnd();
	}
	glEndList();
	listUp[n]=false;
	PROC_EVENT;
}
#else
static void GenFunTriangles(const long n) {
	float x, y;
	float p[3][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	x=-1.0f;
	for(i=0; i<sta.fgrids; i++, x+=step) {
		glBegin(GL_TRIANGLE_STRIP);
		y=-1.0f;
		for(j=0; j<=sta.fgrids; j++, y+=step) {
			p[0][0]=x;
			p[0][1]=y;
			p[0][2]=(*funPtr[n])(x, y);

			p[1][0]=x+step;
			p[1][1]=y;
			p[1][2]=(*funPtr[n])(x+step, y);

			p[2][0]=x;
			p[2][1]=y+step;
			p[2][2]=(*funPtr[n])(x, y+step);

			v1[0]=p[1][0]-p[0][0];
			v1[1]=p[1][1]-p[0][1];
			v1[2]=p[1][2]-p[0][2];

			v2[0]=p[2][0]-p[0][0];
			v2[1]=p[2][1]-p[0][1];
			v2[2]=p[2][2]-p[0][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			glVertex3fv(p[0]);
			glVertex3fv(p[1]);
		}
		glEnd();
	}
	glEndList();
	listUp[n]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** Generate parameter triangle-list */
#ifdef USESSE3
static void GenParTriangles() {
	float s, t;
	__m128 p[3], v1, v2, norm;
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	s=-1.0f;
	for(i=0; i<sta.fgrids; i++, s+=step) {
		glBegin(GL_TRIANGLE_STRIP);
		t=-1.0f;
		for(j=0; j<=sta.fgrids; j++, t+=step) {

			p[0] = _mm_set_ps(0.0f, par2(s,t), par1(s,t), par0(s,t));
			p[1] = _mm_set_ps(0.0f, par2(s+step, t), par1(s+step, t), par0(s+step, t));
			p[2] = _mm_set_ps(0.0f, par2(s, t+step), par1(s, t+step), par0(s, t+step));

			v1 = _mm_sub_ps(p[1], p[0]);
			v2 = _mm_sub_ps(p[2], p[0]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			glVertex3fv((float*)&p[0]);
			glVertex3fv((float*)&p[1]);
		}
		glEnd();
	}
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
#else
static void GenParTriangles() {
	float s, t;
	float p[3][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	s=-1.0f;
	for(i=0; i<sta.fgrids; i++, s+=step) {
		glBegin(GL_TRIANGLE_STRIP);
		t=-1.0f;
		for(j=0; j<=sta.fgrids; j++, t+=step) {
			p[0][0]=par0(s,t);
			p[0][1]=par1(s,t);
			p[0][2]=par2(s,t);

			p[1][0]=par0(s+step, t);
			p[1][1]=par1(s+step, t);
			p[1][2]=par2(s+step, t);

			p[2][0]=par0(s, t+step);
			p[2][1]=par1(s, t+step);
			p[2][2]=par2(s, t+step);

			v1[0]=p[1][0]-p[0][0];
			v1[1]=p[1][1]-p[0][1];
			v1[2]=p[1][2]-p[0][2];

			v2[0]=p[2][0]-p[0][0];
			v2[1]=p[2][1]-p[0][1];
			v2[2]=p[2][2]-p[0][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			glVertex3fv(p[0]);
			glVertex3fv(p[1]);
		}
		glEnd();
	}
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** Generate texture+function triangle-list */
#ifdef USESSE3
static void GenTexFunTriangles(const long n) {
	float x, y;
	__m128 p[3], v1, v2, norm;
	const float step=2.0f/sta.fgrids;

	float xs, ys;
	const float wd=1.0f/texSpan;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[n]);
	x=-1.0f;
	glBegin(GL_TRIANGLES);
	for(i=0; i<sta.fgrids; i++, x+=step) {
		y=-1.0f;
		xs=(i%texSpan)*wd;
		for(j=0; j<sta.fgrids; j++, y+=step) {

			p[0] = _mm_set_ps(0.0f, (*funPtr[n])(x, y), y, x);
			p[1] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y), y, x+step);
			p[2] = _mm_set_ps(0.0f, (*funPtr[n])(x, y+step), y+step, x);

			v1 = _mm_sub_ps(p[1], p[0]);
			v2 = _mm_sub_ps(p[2], p[0]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			ys=(j%texSpan)*wd;

			glTexCoord2f(xs,    ys);	glVertex3fv((float*)&p[0]);
			glTexCoord2f(xs+wd, ys);	glVertex3fv((float*)&p[1]);
			glTexCoord2f(xs,    ys+wd);	glVertex3fv((float*)&p[2]);

			p[0] = _mm_set_ps(0.0f, (*funPtr[n])(x, y+step), y+step, x);
			p[1] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y), y, x+step);
			p[2] = _mm_set_ps(0.0f, (*funPtr[n])(x+step, y+step), y+step, x+step);

			v1 = _mm_sub_ps(p[1], p[0]);
			v2 = _mm_sub_ps(p[2], p[0]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			glTexCoord2f(xs,    ys+wd);	glVertex3fv((float*)&p[0]);
			glTexCoord2f(xs+wd, ys);	glVertex3fv((float*)&p[1]);
			glTexCoord2f(xs+wd, ys+wd);	glVertex3fv((float*)&p[2]);
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}
#else
static void GenTexFunTriangles(const long n) {
	float x, y;
	float p[3][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;

	float xs, ys;
	const float wd=1.0f/texSpan;
	long i, j;

	glNewList(oglLis[n], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[n]);
	x=-1.0f;
	glBegin(GL_TRIANGLES);
	for(i=0; i<sta.fgrids; i++, x+=step) {
		y=-1.0f;
		xs=(i%texSpan)*wd;
		for(j=0; j<sta.fgrids; j++, y+=step) {

			p[0][0]=x;
			p[0][1]=y;
			p[0][2]=(*funPtr[n])(x, y);

			p[1][0]=x+step;
			p[1][1]=y;
			p[1][2]=(*funPtr[n])(x+step, y);

			p[2][0]=x;
			p[2][1]=y+step;
			p[2][2]=(*funPtr[n])(x, y+step);

			v1[0]=p[1][0]-p[0][0];
			v1[1]=p[1][1]-p[0][1];
			v1[2]=p[1][2]-p[0][2];

			v2[0]=p[2][0]-p[0][0];
			v2[1]=p[2][1]-p[0][1];
			v2[2]=p[2][2]-p[0][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			ys=(j%texSpan)*wd;

			glTexCoord2f(xs,    ys);	glVertex3fv(p[0]);
			glTexCoord2f(xs+wd, ys);	glVertex3fv(p[1]);
			glTexCoord2f(xs,    ys+wd);	glVertex3fv(p[2]);

			p[0][0]=x;
			p[0][1]=y+step;
			p[0][2]=(*funPtr[n])(x, y+step);

			p[1][0]=x+step;
			p[1][1]=y;
			p[1][2]=(*funPtr[n])(x+step, y);

			p[2][0]=x+step;
			p[2][1]=y+step;
			p[2][2]=(*funPtr[n])(x+step, y+step);

			v1[0]=p[1][0]-p[0][0];
			v1[1]=p[1][1]-p[0][1];
			v1[2]=p[1][2]-p[0][2];

			v2[0]=p[2][0]-p[0][0];
			v2[1]=p[2][1]-p[0][1];
			v2[2]=p[2][2]-p[0][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			glTexCoord2f(xs,    ys+wd);	glVertex3fv(p[0]);
			glTexCoord2f(xs+wd, ys);	glVertex3fv(p[1]);
			glTexCoord2f(xs+wd, ys+wd);	glVertex3fv(p[2]);
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[n]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** Generate texture+parameter triangle-list */
#ifdef USESSE3
static void GenTexParTriangles() {
	float s, t;
	__m128 p[3], v1, v2, norm;
	const float step=2.0f/sta.fgrids;

	float xs, ys;
	const float wd=1.0f/texSpan;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	s=-1.0f;
	glBegin(GL_TRIANGLES);
	for(i=0; i<sta.fgrids; i++, s+=step) {
		t=-1.0f;
		xs=(i%texSpan)*wd;
		for(j=0; j<sta.fgrids; j++, t+=step) {

			p[0] = _mm_set_ps(0.0f, par2(s,t), par1(s,t), par0(s,t));
			p[1] = _mm_set_ps(0.0f, par2(s+step, t), par1(s+step, t), par0(s+step, t));
			p[2] = _mm_set_ps(0.0f, par2(s, t+step), par1(s, t+step), par0(s, t+step));

			v1 = _mm_sub_ps(p[1], p[0]);
			v2 = _mm_sub_ps(p[2], p[0]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			ys=(j%texSpan)*wd;

			glTexCoord2f(xs,    ys);	glVertex3fv((float*)&p[0]);
			glTexCoord2f(xs+wd, ys);	glVertex3fv((float*)&p[1]);
			glTexCoord2f(xs,    ys+wd);	glVertex3fv((float*)&p[2]);

			p[0] = _mm_set_ps(0.0f, par2(s,t+step), par1(s,t+step), par0(s,t+step));
			p[1] = _mm_set_ps(0.0f, par2(s+step, t), par1(s+step, t), par0(s+step, t));
			p[2] = _mm_set_ps(0.0f, par2(s+step, t+step), par1(s+step, t+step), par0(s+step, t+step));

			v1 = _mm_sub_ps(p[1], p[0]);
			v2 = _mm_sub_ps(p[2], p[0]);

			normCrossProd(v1, v2, norm);
			glNormal3fv((float*)&norm);

			glTexCoord2f(xs,    ys+wd);	glVertex3fv((float*)&p[0]);
			glTexCoord2f(xs+wd, ys);	glVertex3fv((float*)&p[1]);
			glTexCoord2f(xs+wd, ys+wd);	glVertex3fv((float*)&p[2]);
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
#else
static void GenTexParTriangles() {
	float s, t;
	float p[3][3], v1[3], v2[3], norm[3];
	const float step=2.0f/sta.fgrids;

	float xs, ys;
	const float wd=1.0f/texSpan;
	long i, j;

	glNewList(oglLis[3], GL_COMPILE);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	s=-1.0f;
	glBegin(GL_TRIANGLES);
	for(i=0; i<sta.fgrids; i++, s+=step) {
		t=-1.0f;
		xs=(i%texSpan)*wd;
		for(j=0; j<sta.fgrids; j++, t+=step) {

			p[0][0]=par0(s,t);
			p[0][1]=par1(s,t);
			p[0][2]=par2(s,t);

			p[1][0]=par0(s+step, t);
			p[1][1]=par1(s+step, t);
			p[1][2]=par2(s+step, t);

			p[2][0]=par0(s, t+step);
			p[2][1]=par1(s, t+step);
			p[2][2]=par2(s, t+step);

			v1[0]=p[1][0]-p[0][0];
			v1[1]=p[1][1]-p[0][1];
			v1[2]=p[1][2]-p[0][2];

			v2[0]=p[2][0]-p[0][0];
			v2[1]=p[2][1]-p[0][1];
			v2[2]=p[2][2]-p[0][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			ys=(j%texSpan)*wd;

			glTexCoord2f(xs,    ys);	glVertex3fv(p[0]);
			glTexCoord2f(xs+wd, ys);	glVertex3fv(p[1]);
			glTexCoord2f(xs,    ys+wd);	glVertex3fv(p[2]);

			p[0][0]=par0(s, t+step);
			p[0][1]=par1(s, t+step);
			p[0][2]=par2(s, t+step);

			p[1][0]=par0(s+step, t);
			p[1][1]=par1(s+step, t);
			p[1][2]=par2(s+step, t);

			p[2][0]=par0(s+step, t+step);
			p[2][1]=par1(s+step, t+step);
			p[2][2]=par2(s+step, t+step);

			v1[0]=p[1][0]-p[0][0];
			v1[1]=p[1][1]-p[0][1];
			v1[2]=p[1][2]-p[0][2];

			v2[0]=p[2][0]-p[0][0];
			v2[1]=p[2][1]-p[0][1];
			v2[2]=p[2][2]-p[0][2];

			normCrossProd(v1, v2, norm);
			glNormal3fv(norm);

			glTexCoord2f(xs,    ys+wd);	glVertex3fv(p[0]);
			glTexCoord2f(xs+wd, ys);	glVertex3fv(p[1]);
			glTexCoord2f(xs+wd, ys+wd);	glVertex3fv(p[2]);
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glEndList();

	listUp[3]=false;
	PROC_EVENT;
}
// USE_SSE3
#endif


/** *************************************************************************
 ** Set material-properties
****************************************************************************/
static void setMat(const long n) {

	/** Mode is 1-sided */
	if(ent.modOne==0.0f) {
		glMaterialfv(GL_FRONT, GL_AMBIENT,    mat[n].ambMat[0]);
		glMaterialfv(GL_FRONT, GL_DIFFUSE,    mat[n].difMat[0]);
		glMaterialfv(GL_FRONT, GL_SPECULAR,   mat[n].speMat[0]);
		glMaterialfv(GL_FRONT, GL_EMISSION,   mat[n].emiMat[0]);
		glMaterialfv(GL_FRONT, GL_SHININESS, &mat[n].shiMat[0]);
		return;
	}

	/** Mode is 2-sided */
	glMaterialfv(GL_FRONT, GL_AMBIENT,    mat[n].ambMat[0]);
	glMaterialfv(GL_BACK,  GL_AMBIENT,    mat[n].ambMat[1]);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,    mat[n].difMat[0]);
	glMaterialfv(GL_BACK,  GL_DIFFUSE,    mat[n].difMat[1]);
	glMaterialfv(GL_FRONT, GL_SPECULAR,   mat[n].speMat[0]);
	glMaterialfv(GL_BACK,  GL_SPECULAR,   mat[n].speMat[1]);
	glMaterialfv(GL_FRONT, GL_EMISSION,   mat[n].emiMat[0]);
	glMaterialfv(GL_BACK,  GL_EMISSION,   mat[n].emiMat[1]);
	glMaterialfv(GL_FRONT, GL_SHININESS, &mat[n].shiMat[0]);
	glMaterialfv(GL_BACK,  GL_SHININESS, &mat[n].shiMat[1]);
}
