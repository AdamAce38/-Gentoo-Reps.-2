/** *************************************************************************
 **
 ** Copyright (C) 2013 Heinz van Saanen
 **
 ** This file is part of the function viewer Zhu3D.
 **
 ** This file may be used under the terms of the GNU General Public
 ** License version 3 as published by the Free Software Foundation
 ** and appearing in the file LICENSE.GPL included in the packaging of
 ** this file.
 **
 ** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 ** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 **
****************************************************************************/

#ifndef _ENTEDITOR_H_
#define _ENTEDITOR_H_

#include <QWidget>
#include <QCloseEvent>
#include <QSettings>

#include "glwidget.h"
#include "ui_entedit.h"
#include "property.h"
#include "version.h"
#include "debug.h"


/** Globals */
extern OGLWidget *oglWid;


/** Handles global settings */
class entWidget : public QWidget, private Ui::entUI {

Q_OBJECT

public:
	entWidget(QWidget *parent=0);
	~entWidget() {}

protected:
	void closeEvent(QCloseEvent *event);
	void changeEvent(QEvent* event);

public slots:
	void updEntWid();

private:
	/** Private settings stuff */
	void readSettings();
	void writeSettings();
};

/** _ENTEDITOR_H_ */
#endif
