Sometimes you may need a well defined slideshow for presentation
or educational purposes. This is a neat way how to do this with
just a few mouse clicks:

1) Create a suitable directory like this one
2) Copy the needed zhu-files in there
3) If necessary for ordering, rename them 01.zhu, 02.zhu, ...
4) Change your current work-dir with "Settings/Directories"
   to the new slideshow directory

That's it. "Help/Demo" will automatically start with your customised
slideshow now.
