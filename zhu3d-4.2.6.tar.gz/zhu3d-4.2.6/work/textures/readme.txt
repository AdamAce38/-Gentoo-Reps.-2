LEGAL STUFF

Searching the web for free textures was somehow frustrating. Many pictures
have special legal restrictions I was tired of to mention. So I took my
digicam and made some examples by myself. These texture are not very
brillant, but sufficient for demonstration purposes. And they have an
advantage: You can do with them, whatever you want. If you need more
professional textures search the web, where you find tons of them.


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SPECIAL NOTES ON THE OpenGL-texture:
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

An EXCEPTION is clearly the OpenGL logo! It is a trademark of SGI and
therefore has the usual restrictions of course you have to be aware of!


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SPECIAL NOTES ON THE earth-texture:
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

The earth-texture was taken from http://www.visibleearth.nasa.gov and
has the following CREDIT:

NASA Goddard Space Flight Center Image by Reto Stöckli (land surface,
shallow water, clouds). Enhancements by Robert Simmon (ocean color,
compositing, 3D globes, animation). Data and technical support:
MODIS Land Group; MODIS Science Data Support Team; MODIS Atmosphere
Group; MODIS Ocean Group Additional data: USGS EROS Data Center
(topography); USGS Terrestrial Remote Sensing Flagstaff Field Center
(Antarctica); Defense Meteorological Satellite Program (city lights).

On the NASA website you can find more free textures from earth,
different satellite photos and some other interesting stuff 


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SPECIAL NOTES ON bluescreen- and the karl-textures:
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Taken from http://www.stupidedia.org. Stupipedia claims, that these
pictures have a GNU Free Documentation License, Version 1.2 or later.
