<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs_CZ">
<context>
    <name>MaiWindow</name>
    <message>
        <location filename="../../src/mainwindow.cpp" line="56"/>
        <location filename="../../src/mainwindow.cpp" line="177"/>
        <location filename="../../src/mainwindow.cpp" line="289"/>
        <location filename="../../src/mainwindow.cpp" line="972"/>
        <location filename="../../src/mainwindow.cpp" line="1877"/>
        <source>Solver report</source>
        <translation>Editor řešení</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="887"/>
        <location filename="../../src/mainwindow.cpp" line="1737"/>
        <source>Stop animation</source>
        <translation>Zastavit animaci</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="223"/>
        <location filename="../../src/mainwindow.cpp" line="1471"/>
        <location filename="../../src/mainwindow.cpp" line="1480"/>
        <location filename="../../src/mainwindow.cpp" line="1490"/>
        <location filename="../../src/mainwindow.cpp" line="1501"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="223"/>
        <location filename="../../src/mainwindow.cpp" line="255"/>
        <source>file</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1472"/>
        <location filename="../../src/mainwindow.cpp" line="1481"/>
        <location filename="../../src/mainwindow.cpp" line="1491"/>
        <location filename="../../src/mainwindow.cpp" line="1502"/>
        <source>Error loading file:</source>
        <translation>Při nahrávání souboru došlo k chybě:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="255"/>
        <location filename="../../src/mainwindow.cpp" line="275"/>
        <location filename="../../src/mainwindow.cpp" line="316"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="276"/>
        <location filename="../../src/mainwindow.cpp" line="317"/>
        <source>Error saving file:</source>
        <translation>Při ukládání došlo k chybě:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="290"/>
        <source>Currently there is nothing to save!</source>
        <translation>Nyní ještě není co ukládat!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="298"/>
        <location filename="../../src/mainwindow.cpp" line="942"/>
        <location filename="../../src/mainwindow.cpp" line="1867"/>
        <source>Save solutions</source>
        <translation>Uložit řešení</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="357"/>
        <source>Cannot find any helpfile</source>
        <translation>Nelze najít soubor s nápovědou</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="378"/>
        <location filename="../../src/mainwindow.cpp" line="1049"/>
        <location filename="../../src/mainwindow.cpp" line="1174"/>
        <location filename="../../src/mainwindow.cpp" line="1858"/>
        <location filename="../../src/mainwindow.cpp" line="1906"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="413"/>
        <source>System information</source>
        <translation>Informace o systému</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="425"/>
        <source>About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="892"/>
        <location filename="../../src/mainwindow.cpp" line="1732"/>
        <source>Start animation</source>
        <translation>Začít s animací</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="930"/>
        <location filename="../../src/mainwindow.cpp" line="1861"/>
        <source>&amp;New</source>
        <translation>&amp;Nový</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="931"/>
        <location filename="../../src/mainwindow.cpp" line="1862"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="934"/>
        <location filename="../../src/mainwindow.cpp" line="1863"/>
        <source>&amp;Open ...</source>
        <translation>&amp;Otevřít...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="935"/>
        <location filename="../../src/mainwindow.cpp" line="1864"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="938"/>
        <location filename="../../src/mainwindow.cpp" line="1865"/>
        <source>&amp;Save as</source>
        <translation>&amp;Uložit jako</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="939"/>
        <location filename="../../src/mainwindow.cpp" line="1866"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="945"/>
        <location filename="../../src/mainwindow.cpp" line="1868"/>
        <source>Save picture</source>
        <translation>Uložit obrázek</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="948"/>
        <location filename="../../src/mainwindow.cpp" line="1869"/>
        <source>Print picture</source>
        <translation>Tisk obrázku</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="951"/>
        <location filename="../../src/mainwindow.cpp" line="1870"/>
        <source>&amp;Exit</source>
        <translation>U&amp;končit</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="952"/>
        <location filename="../../src/mainwindow.cpp" line="1871"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="957"/>
        <location filename="../../src/mainwindow.cpp" line="1874"/>
        <source>Lights</source>
        <translation>Zdroje světla</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="960"/>
        <location filename="../../src/mainwindow.cpp" line="1875"/>
        <source>Surfaces</source>
        <translation>Povrchy</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="963"/>
        <location filename="../../src/mainwindow.cpp" line="1876"/>
        <source>Global</source>
        <translation>Celkové</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="980"/>
        <location filename="../../src/mainwindow.cpp" line="1883"/>
        <source>Animation</source>
        <translation>Animace</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="966"/>
        <location filename="../../src/mainwindow.cpp" line="1878"/>
        <source>User defined</source>
        <translation>Stanoveno uživatelem</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="975"/>
        <location filename="../../src/mainwindow.cpp" line="1660"/>
        <location filename="../../src/mainwindow.cpp" line="1880"/>
        <source>Functions</source>
        <translation>Funkce</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="991"/>
        <location filename="../../src/mainwindow.cpp" line="1888"/>
        <source>Picture</source>
        <translation>Obrázek</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="994"/>
        <location filename="../../src/mainwindow.cpp" line="1889"/>
        <source>micro</source>
        <translation>Mikro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1000"/>
        <location filename="../../src/mainwindow.cpp" line="1890"/>
        <source>fine</source>
        <translation>Jemné</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1006"/>
        <location filename="../../src/mainwindow.cpp" line="1891"/>
        <source>normal</source>
        <translation>Obvyklé</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1012"/>
        <location filename="../../src/mainwindow.cpp" line="1892"/>
        <source>coarse</source>
        <translation>Hrubé</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1018"/>
        <location filename="../../src/mainwindow.cpp" line="1893"/>
        <source>View only</source>
        <translation>Pouze pohled</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1021"/>
        <location filename="../../src/mainwindow.cpp" line="1894"/>
        <source>Scaling only</source>
        <translation>Pouze změna velikosti</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1024"/>
        <location filename="../../src/mainwindow.cpp" line="1895"/>
        <source>Lights only</source>
        <translation>Pouze zdroje světla</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1027"/>
        <location filename="../../src/mainwindow.cpp" line="1896"/>
        <source>All together</source>
        <translation>Všechno dohromady</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1030"/>
        <location filename="../../src/mainwindow.cpp" line="1897"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1137"/>
        <location filename="../../src/mainwindow.cpp" line="1853"/>
        <source>Special</source>
        <translation>Zvláštní</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1033"/>
        <location filename="../../src/mainwindow.cpp" line="1898"/>
        <source>Directories</source>
        <translation>Adresáře</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1038"/>
        <location filename="../../src/mainwindow.cpp" line="1901"/>
        <source>Show open editors</source>
        <translation>Ukázat otevřené editory</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1041"/>
        <location filename="../../src/mainwindow.cpp" line="1902"/>
        <source>Hide open editors</source>
        <translation>Skrýt otevřené editory</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1044"/>
        <location filename="../../src/mainwindow.cpp" line="1903"/>
        <source>Open all editors</source>
        <translation>Otevřít všechny editory</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1050"/>
        <location filename="../../src/mainwindow.cpp" line="1908"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1053"/>
        <location filename="../../src/mainwindow.cpp" line="1909"/>
        <source>System</source>
        <translation>Systém</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1059"/>
        <location filename="../../src/mainwindow.cpp" line="1806"/>
        <location filename="../../src/mainwindow.cpp" line="1910"/>
        <source>Benchmark</source>
        <translation>Srovnávací zkouška</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1062"/>
        <location filename="../../src/mainwindow.cpp" line="1911"/>
        <source>About Zhu3D</source>
        <translation>O Zhu3D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1065"/>
        <location filename="../../src/mainwindow.cpp" line="1912"/>
        <source>About Qt</source>
        <translation>O Qt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1070"/>
        <source>Zoom in</source>
        <translation>Přiblížit</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1071"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1074"/>
        <source>Zoom out</source>
        <translation>Oddálit</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1075"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1078"/>
        <source>Move left</source>
        <translation>Posunout doleva</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1079"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <source>Move right</source>
        <translation>Posunout doprava</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1083"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1086"/>
        <source>Move up</source>
        <translation>Posunout nahoru</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1087"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1090"/>
        <source>Move down</source>
        <translation>Posunout dolů</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1091"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1094"/>
        <location filename="../../src/mainwindow.cpp" line="1657"/>
        <source>Solve system</source>
        <translation>Řešit systém rovnic</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1097"/>
        <source>Start/stop animation</source>
        <translation>Spustit/Zastavit animaci</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1111"/>
        <location filename="../../src/mainwindow.cpp" line="1194"/>
        <location filename="../../src/mainwindow.cpp" line="1851"/>
        <source>File</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1124"/>
        <location filename="../../src/mainwindow.cpp" line="1852"/>
        <source>Editors</source>
        <translation>Editory</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1144"/>
        <location filename="../../src/mainwindow.cpp" line="1854"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1146"/>
        <location filename="../../src/mainwindow.cpp" line="1855"/>
        <source>Scaling</source>
        <translation>Škálování</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1152"/>
        <location filename="../../src/mainwindow.cpp" line="1856"/>
        <source>Reset</source>
        <translation>Vynulovat</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1167"/>
        <location filename="../../src/mainwindow.cpp" line="1857"/>
        <source>Windows</source>
        <translation>Okno</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1199"/>
        <source>Zoom</source>
        <translation>Zvětšení</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1204"/>
        <source>Move</source>
        <translation>Pohybovat</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1211"/>
        <source>Extras</source>
        <translation>Doplňky</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1327"/>
        <source>Creation date:</source>
        <translation>Zpráva z:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1377"/>
        <location filename="../../src/mainwindow.cpp" line="1379"/>
        <location filename="../../src/mainwindow.cpp" line="1384"/>
        <location filename="../../src/mainwindow.cpp" line="1386"/>
        <location filename="../../src/mainwindow.cpp" line="1393"/>
        <location filename="../../src/mainwindow.cpp" line="1395"/>
        <location filename="../../src/mainwindow.cpp" line="1400"/>
        <location filename="../../src/mainwindow.cpp" line="1402"/>
        <source>Cross</source>
        <translation>Kříž</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1482"/>
        <source>Zhu3D file is too old or not valid!</source>
        <translation>Soubor Zhu3D-je buď příliš starý nebo není platný!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1536"/>
        <source>untitled</source>
        <translation>Bez názvu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1633"/>
        <source>X-values</source>
        <translation>Hodnoty x</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1634"/>
        <source>Y-values</source>
        <translation>Hodnoty y</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1635"/>
        <source>Z-values</source>
        <translation>Hodnoty z</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1636"/>
        <source> A</source>
        <translation> A</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1637"/>
        <source>All XYZ-values together</source>
        <translation>Všechny hodnoty xyz společně</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1652"/>
        <source>Scale functions</source>
        <translation>Škálovat funkce</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1659"/>
        <source>Function editor</source>
        <translation>Editor funkcí</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1662"/>
        <source>Edit: Functions</source>
        <translation>Upravit: Funkce</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1662"/>
        <location filename="../../src/mainwindow.cpp" line="1692"/>
        <location filename="../../src/mainwindow.cpp" line="1720"/>
        <source>Grid:</source>
        <translation>Mřížka:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1682"/>
        <source>Scale iso functions</source>
        <translation>Škálovat funkce ISO</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1687"/>
        <location filename="../../src/mainwindow.cpp" line="1715"/>
        <source>For solving switch to function-mode</source>
        <translation>Pro řešení přepnout na režim funkcí</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1689"/>
        <source>Iso editor</source>
        <translation>Editor ISO</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1690"/>
        <source>Iso functions</source>
        <translation>Funkce ISO</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1692"/>
        <source>Edit: Isosurfaces</source>
        <translation>Upravit: ISO povrchy</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1710"/>
        <source>Scale parametric system</source>
        <translation>Škálovat parametrický systém</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1717"/>
        <source>Parameter editor</source>
        <translation>Editor parametrů</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1718"/>
        <source>Parameters</source>
        <translation>Parametry</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1720"/>
        <source>Edit: Parameter</source>
        <translation>Upravit: Parameter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1777"/>
        <source>Benchmarking now ...</source>
        <translation>Probíhá srovnávací zkouška...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1056"/>
        <location filename="../../src/mainwindow.cpp" line="1907"/>
        <source>Demo</source>
        <translation>Demo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="983"/>
        <location filename="../../src/mainwindow.cpp" line="1884"/>
        <source>Morphing</source>
        <translation>Morfování</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="909"/>
        <location filename="../../src/mainwindow.cpp" line="1750"/>
        <source>Stop morphing</source>
        <translation>Zastavit morfování</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="914"/>
        <location filename="../../src/mainwindow.cpp" line="1745"/>
        <source>Start morphing</source>
        <translation>Spustit morfování</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="986"/>
        <location filename="../../src/mainwindow.cpp" line="1885"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1100"/>
        <source>Start/stop morphing</source>
        <translation>Spustit/zastavit morfování</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="969"/>
        <location filename="../../src/mainwindow.cpp" line="1879"/>
        <source>Legends</source>
        <translation>Popisky</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1492"/>
        <source>XML parser error</source>
        <translation>Chyba syntaktického analyzátoru XML</translation>
    </message>
</context>
<context>
    <name>OGLWidget</name>
    <message>
        <location filename="../../src/glwidget.cpp" line="255"/>
        <location filename="../../src/glwidget.cpp" line="303"/>
        <location filename="../../src/glwidget.cpp" line="351"/>
        <source>Alert</source>
        <translation>Pozor</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1205"/>
        <location filename="../../src/glwidget.cpp" line="1228"/>
        <source>Material</source>
        <translation>Látka</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1206"/>
        <source>Editing back-side colours, although the global setting is just 1-sided.&lt;p&gt;&lt;/p&gt;Zhu3D is &lt;b&gt;enabling&lt;/b&gt; the 2-sided mode automatically now.</source>
        <translation>Upravuje barvy zadní strany, ačkoli obecné nastavení je pouze jednostranné.&lt;p&gt;&lt;/p&gt;Zhu3D &lt;b&gt;nyní automaticky povoluje&lt;/b&gt; režim se dvěma stranami.</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1229"/>
        <source>Changing back-side colours, although the global setting is just 1-sided.&lt;p&gt;&lt;/p&gt;Zhu3D is &lt;b&gt;enabling&lt;/b&gt; the 2-sided mode automatically now.</source>
        <translation>Mění barvy zadní strany, ačkoli obecné nastavení je pouze jednostranné.&lt;p&gt;&lt;/p&gt;Zhu3D &lt;b&gt;nyní automaticky povoluje&lt;/b&gt; režim se dvěma stranami.</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="213"/>
        <source>Viewer</source>
        <translation>Pozorovatel</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="843"/>
        <source>Save as *.png</source>
        <translation>Uložit jako *.png</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="863"/>
        <source>Save as *.jpg</source>
        <translation>Uložit jako *.jpg</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="824"/>
        <location filename="../../src/glwidget.cpp" line="965"/>
        <source>Rendering</source>
        <translation>Udělání</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="824"/>
        <location filename="../../src/glwidget.cpp" line="965"/>
        <source>picture ...</source>
        <translation>obrázek...</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="883"/>
        <source>Save as *.pdf</source>
        <translation>Uložit jako *.pdf</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="917"/>
        <source>Save as *.ps</source>
        <translation>Uložit jako *.ps</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="248"/>
        <source>Parser message from F0/I0/X</source>
        <translation>Zpráva syntaktického analyzátoru z F0/I0/X</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="296"/>
        <source>Parser message from F1/I1/Y</source>
        <translation>Zpráva syntaktického analyzátoru z F1/I1/Y</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="344"/>
        <source>Parser message from F2/I2/Z</source>
        <translation>Zpráva syntaktického analyzátoru z F2/I2/Z</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/main.cpp" line="168"/>
        <location filename="../../src/main.cpp" line="181"/>
        <location filename="../../src/mainwindow.cpp" line="1266"/>
        <location filename="../../src/mainwindow.cpp" line="1275"/>
        <source>Program start</source>
        <translation>Spuštěníprogramu</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="182"/>
        <source>Missing OpenGL! Terminating now</source>
        <translation>Chybí OpenGL! Program nyní bude ukončen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1267"/>
        <source>CPU clockcounter is not supported!</source>
        <translation>Není podporováno počítadlo taktu CPU!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1268"/>
        <source>System info cannot provide MHz-values</source>
        <translation>Systém neposkytuje informaci o hodnotě MHz</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1276"/>
        <source>Missing OpenGL acceleration!</source>
        <translation>Chybí zrychlení OpenGL!</translation>
    </message>
    <message>
        <location filename="../../src/sysinfo.cpp" line="46"/>
        <source>Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <location filename="../../src/sysinfo.cpp" line="47"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1277"/>
        <source>Framerates will be very low</source>
        <translation>Počty snímků budou velmi nízké</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="358"/>
        <source>ERROR 0: Syntax error</source>
        <translation>CHYBA 0: Chyba syntaxe</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="359"/>
        <source>ERROR 1: Mismatched parenthesis</source>
        <translation>CHYBA 1: Neodpovídající si závorky</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="360"/>
        <source>ERROR 2: Missing closing parenthesis</source>
        <translation>CHYBA 2: Chybí uzavřené závorky</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="361"/>
        <source>ERROR 3: Empty parentheses</source>
        <translation>CHYBA 3: Prázdné závorky</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="362"/>
        <source>ERROR 4: Operator expected</source>
        <translation>CHYBA 4: Očekáván operátor</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="363"/>
        <source>ERROR 5: Out of memory</source>
        <translation>CHYBA 5: Už není paměť</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="364"/>
        <source>ERROR 6: Unexpected error</source>
        <translation>CHYBA 6: Neočekávaná chyba</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="365"/>
        <source>ERROR 7: Unknown parameter</source>
        <translation>CHYBA 7: Neznámý parameter</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="366"/>
        <source>ERROR 8: Illegal number of function parameters</source>
        <translation>CHYBA 8: Nesprávný počet parametrů funkce</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="367"/>
        <source>ERROR 9: Premature end of string</source>
        <translation>CHYBA 9: Předčasný konec řetězce</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="368"/>
        <source>ERROR 10: Expecting parenthesis after function</source>
        <translation>CHYBA 10: Po funkci očekávány závorky</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="369"/>
        <source>ERROR 11: Parser initialization failed</source>
        <translation>CHYBA 11: Inicializace syntaktického analyzátoru se nezdařila</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="370"/>
        <source>ERROR 12: Missing equal sign</source>
        <translation>CHYBA 12: Žádné rovnítko</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="371"/>
        <source>ERROR 13: Adding new constant failed</source>
        <translation>CHYBA 13: Přidání nové stálé hodnoty (konstanty) se nezdařilo</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="372"/>
        <source>ERROR 14: Adding new function failed</source>
        <translation>CHYBA 14: Přidání nové funkce se nezdařilo</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="373"/>
        <source>ERROR 15: Parser update failed</source>
        <translation>CHYBA 15: Aktualizace syntaktického analyzátoru se nezdařila</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="146"/>
        <source>Search started at:  X=%1  Y=%2
Time needed for %3 iterations: %4 ms
The result is %5realiable.

Solution:  X=%6  Y=%7  Z=%8</source>
        <translation>Hledání započato s:  X=%1  Y=%2
Čas potřebný pro %3 iterací: %4 ms
Výsledek je %5 spolehlivý.

Řešení:  X=%6  Y=%7  Z=%8</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="156"/>
        <source>NOT </source>
        <translation>NE</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="165"/>
        <source>Solver</source>
        <translation>Řešitel rovnic</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="166"/>
        <source>Result is NOT reliable</source>
        <translation>Řešení NENÍ spolehlivé</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="65"/>
        <source>Alert</source>
        <translation>Pozor</translation>
    </message>
</context>
<context>
    <name>aniUI</name>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="19"/>
        <source>Rotation speed around the axes</source>
        <translation>Rychlost otáčení kolem os</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="22"/>
        <source>Rotation</source>
        <translation>Otáčení</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="77"/>
        <source>X-rotation offset</source>
        <translation>Vyrovnání kolem osy x</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="99"/>
        <source>Y-rotation offset</source>
        <translation>Vyrovnání kolem osy y</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="118"/>
        <source>Z-rotation offset</source>
        <translation>Vyrovnání kolem osy z</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="142"/>
        <source>Lock XYZ-values</source>
        <translation>Zamknout hodnoty posunutí xyz</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="145"/>
        <source>Lock</source>
        <translation>Zamknout</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="193"/>
        <source>GPU/CPU utilization in %</source>
        <translation>Vytížení GPU/CPU-v %</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="217"/>
        <source>Frames/second</source>
        <translation>Snímků za sekundu</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="220"/>
        <source>Frames</source>
        <translation>Snímky</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="273"/>
        <source>PushButton</source>
        <translation>Tlačítko</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="270"/>
        <source>Start/stop animation</source>
        <translation>Spustit/Zastavit animaci</translation>
    </message>
</context>
<context>
    <name>aniWidget</name>
    <message>
        <location filename="../../src/aniedit.cpp" line="35"/>
        <location filename="../../src/aniedit.cpp" line="193"/>
        <source>Film</source>
        <translation>Film</translation>
    </message>
    <message>
        <location filename="../../src/aniedit.cpp" line="177"/>
        <source>Stop</source>
        <translation>Zastavit</translation>
    </message>
    <message>
        <location filename="../../src/aniedit.cpp" line="181"/>
        <source>Animate</source>
        <translation>Animovat</translation>
    </message>
</context>
<context>
    <name>demWidget</name>
    <message>
        <location filename="../../src/demedit.cpp" line="32"/>
        <location filename="../../src/demedit.cpp" line="159"/>
        <source>Demo</source>
        <translation>Demo</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="88"/>
        <location filename="../../src/demedit.cpp" line="170"/>
        <source>Stop slideshow</source>
        <translation>Zastavit promítání diapozitivů</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="95"/>
        <location filename="../../src/demedit.cpp" line="172"/>
        <source>Start slideshow</source>
        <translation>Spustit promítání diapozitivů</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="173"/>
        <source>Backward</source>
        <translation>Dozadu</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="174"/>
        <source>Forward</source>
        <translation>Dopředu</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Uložit</translation>
    </message>
    <message>
        <source>Error saving file:</source>
        <translation type="obsolete">Při ukládání došlo k chybě:</translation>
    </message>
</context>
<context>
    <name>dirUI</name>
    <message>
        <location filename="../../src/ui/diredit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="25"/>
        <source>Set new default directories</source>
        <translation>Nastavit nové výchozí adresáře</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="45"/>
        <location filename="../../src/ui/diredit.ui" line="75"/>
        <source>Set new directory</source>
        <translation>Nastavit nový adresář</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="97"/>
        <location filename="../../src/ui/diredit.ui" line="117"/>
        <source>Current textures directory</source>
        <translation>Nynější adresář pro povrchy</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="107"/>
        <location filename="../../src/ui/diredit.ui" line="127"/>
        <source>Current work directory</source>
        <translation>Nynější pracovní adresář</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="120"/>
        <source>Textures: </source>
        <translation>Povrchy: </translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="130"/>
        <source>Work: </source>
        <translation>Práce: </translation>
    </message>
</context>
<context>
    <name>dirWidget</name>
    <message>
        <location filename="../../src/diredit.cpp" line="38"/>
        <location filename="../../src/diredit.cpp" line="116"/>
        <source>Directories</source>
        <translation>Adresáře</translation>
    </message>
    <message>
        <location filename="../../src/diredit.cpp" line="66"/>
        <location filename="../../src/diredit.cpp" line="86"/>
        <source>Set new directory</source>
        <translation>Nastavit nový adresář</translation>
    </message>
</context>
<context>
    <name>entUI</name>
    <message>
        <location filename="../../src/ui/entedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="36"/>
        <source>Ambient light</source>
        <translation>Světlo okolního prostředí</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="39"/>
        <source>Amb.</source>
        <translation>Okolní světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="94"/>
        <source>Red ambient light</source>
        <translation>Okolní červené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="113"/>
        <source>Green ambient light</source>
        <translation>Okolní zelené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="132"/>
        <source>Blue ambient light</source>
        <translation>Okolní modré světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="154"/>
        <source>Ambient alpha channel</source>
        <translation>Alfa kanál prostředí</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="172"/>
        <location filename="../../src/ui/entedit.ui" line="326"/>
        <source>Lock RGB-sliders</source>
        <translation>Zamknout posuvníky RGB</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="175"/>
        <location filename="../../src/ui/entedit.ui" line="329"/>
        <source>Lock</source>
        <translation>Zamknout</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="190"/>
        <source>Background properties</source>
        <translation>Vlastnosti pozadí</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="193"/>
        <source>Backgr.</source>
        <translation>Pozadí</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="248"/>
        <source>Red background light</source>
        <translation>Červené světlo pozadí</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="267"/>
        <source>Green background light</source>
        <translation>Zelené světlo pozadí</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="286"/>
        <source>Blue background light</source>
        <translation>Modré světlo pozadí</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="308"/>
        <source>Background alpha channel</source>
        <translation>Alfa kanál světla pozadí</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="390"/>
        <source>1-side</source>
        <translation>Jednostranné</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="406"/>
        <source>2-side</source>
        <translation>Oboustranné</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="443"/>
        <source>Infinite light sources</source>
        <translation>Nekonečný počet světelných zdrojů</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="446"/>
        <source>Inf.</source>
        <translation>Nekonečný</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="459"/>
        <source>Local light sources</source>
        <translation>Místní světelné zdroje</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="462"/>
        <source>Local</source>
        <translation>Místní</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="387"/>
        <source>Surfaces are one-sided</source>
        <translation>Povrchy jsou jednostranné</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="403"/>
        <source>Surfaces are two-sided</source>
        <translation>Povrchy jsou oboustranné</translation>
    </message>
</context>
<context>
    <name>entWidget</name>
    <message>
        <location filename="../../src/entedit.cpp" line="26"/>
        <location filename="../../src/entedit.cpp" line="84"/>
        <source>Global</source>
        <translation>Celkové</translation>
    </message>
</context>
<context>
    <name>errUI</name>
    <message>
        <location filename="../../src/ui/error.ui" line="16"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
</context>
<context>
    <name>errWidget</name>
    <message>
        <location filename="../../src/error.cpp" line="25"/>
        <source>Debug-window</source>
        <translation>Okno pro vyhledávání a odstraňování chyb</translation>
    </message>
</context>
<context>
    <name>fntWidget</name>
    <message>
        <location filename="../../src/fntedit.cpp" line="389"/>
        <source>Font</source>
        <translation>Písmo</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="411"/>
        <location filename="../../src/fntedit.cpp" line="412"/>
        <source>Precision for solver report in digits</source>
        <translation>Nastavení přesnosti pro zprávu o řešení (počet číslic)</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="388"/>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="407"/>
        <location filename="../../src/fntedit.cpp" line="408"/>
        <source>Application language</source>
        <translation>Jazyk aplikace</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="304"/>
        <location filename="../../src/fntedit.cpp" line="424"/>
        <source>English</source>
        <translation>Anglický</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="303"/>
        <location filename="../../src/fntedit.cpp" line="423"/>
        <source>German</source>
        <translation>Německý</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="305"/>
        <location filename="../../src/fntedit.cpp" line="425"/>
        <source>Spanish</source>
        <translation>Španělský</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="308"/>
        <location filename="../../src/fntedit.cpp" line="428"/>
        <source>Czech</source>
        <translation>Český</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="390"/>
        <source>Font style</source>
        <translation>Styl písma</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="391"/>
        <source>Font size</source>
        <translation>Velikost písma</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="392"/>
        <source>Icon size</source>
        <translation>Velikost ikony</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="395"/>
        <source>Precision</source>
        <translation>Přesnost</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="394"/>
        <source>GUI style</source>
        <translation>Styl uživatelského rozhraní</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="159"/>
        <location filename="../../src/fntedit.cpp" line="402"/>
        <source>internal</source>
        <translation>vnitřní</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="160"/>
        <location filename="../../src/fntedit.cpp" line="403"/>
        <source>external</source>
        <translation>vnější</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="393"/>
        <source>Help browser</source>
        <translation>Prohlížeč nápovědy</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="409"/>
        <location filename="../../src/fntedit.cpp" line="410"/>
        <source>Choose internal or external help browser</source>
        <translation>Použít vnitřní nebo vnější prohlížeč nápovědy</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="413"/>
        <location filename="../../src/fntedit.cpp" line="414"/>
        <source>Choose triangulation method</source>
        <translation>Vybrat metodu triangulace</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="396"/>
        <source>Isosurfaces</source>
        <translation>Isopovrchy</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="306"/>
        <location filename="../../src/fntedit.cpp" line="426"/>
        <source>French</source>
        <translation>Francouzský</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="307"/>
        <location filename="../../src/fntedit.cpp" line="427"/>
        <source>Chinese</source>
        <translation>Čínský</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="61"/>
        <location filename="../../src/fntedit.cpp" line="377"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="397"/>
        <source>Threads</source>
        <translation>Vlákna</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="415"/>
        <location filename="../../src/fntedit.cpp" line="416"/>
        <source>Threads for isosurface-triangulation</source>
        <translation>Vlákna triangulace isopovrchů</translation>
    </message>
</context>
<context>
    <name>funUI</name>
    <message>
        <location filename="../../src/ui/funedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="109"/>
        <source>F0:</source>
        <translation>F0:</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="142"/>
        <source>F1:</source>
        <translation>F1:</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="175"/>
        <source>F2:</source>
        <translation>F2:</translation>
    </message>
</context>
<context>
    <name>funWidget</name>
    <message>
        <location filename="../../src/funedit.cpp" line="32"/>
        <location filename="../../src/funedit.cpp" line="190"/>
        <source>Function editor</source>
        <translation>Editor funkcí</translation>
    </message>
</context>
<context>
    <name>legUI</name>
    <message>
        <location filename="../../src/ui/legedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="31"/>
        <source>Colour</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="71"/>
        <source>Red</source>
        <translation>Červená</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="90"/>
        <source>Green</source>
        <translation>Zelená</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="109"/>
        <source>Blue</source>
        <translation>Modrá</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="133"/>
        <source>Lock RGB-sliders</source>
        <translation>Zamknout posuvníky RGB</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="136"/>
        <source>Lock</source>
        <translation>Zamknout</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="151"/>
        <source>Lock mouse</source>
        <translation>Zamknout myš</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="158"/>
        <source>Synchronize colours</source>
        <translation>Seřídit barvy</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="161"/>
        <source>Sync</source>
        <translation>Seřízení</translation>
    </message>
</context>
<context>
    <name>legWidget</name>
    <message>
        <location filename="../../src/legedit.cpp" line="37"/>
        <location filename="../../src/legedit.cpp" line="342"/>
        <source>Legends</source>
        <translation>Popisy</translation>
    </message>
    <message>
        <location filename="../../src/legedit.cpp" line="86"/>
        <source>Item</source>
        <translation>Položka</translation>
    </message>
    <message>
        <location filename="../../src/legedit.cpp" line="86"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
</context>
<context>
    <name>ligUI</name>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="19"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="78"/>
        <source>Enable/disable spotlight</source>
        <translation>Povolit/Zakázat světlomet</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="81"/>
        <source>Spotlight</source>
        <translation>Světlomet</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="271"/>
        <source>Spotlight attributes</source>
        <translation>Nastavení světlometu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="274"/>
        <source>Attr.</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="312"/>
        <source>Spotlight angle</source>
        <translation>Úhel paprsku světlometu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="334"/>
        <source>Spotlight intensity</source>
        <translation>Síla paprsku světlometu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="129"/>
        <source>Spotlight direction</source>
        <translation>Směr paprsku světlometu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="132"/>
        <source>Dir.</source>
        <translation>Směr</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="170"/>
        <source>Spotlight X-direction</source>
        <translation>Směr X paprsku světlometu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="195"/>
        <source>Spotlight Y-direction</source>
        <translation>Směr Y paprsku světlometu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="217"/>
        <source>Spotlight Z-direction</source>
        <translation>Směr Z paprsku světlometu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="400"/>
        <source>Attenuation</source>
        <translation>Zeslabení</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="403"/>
        <source>Att.</source>
        <translation>Zeslabení</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="430"/>
        <source>Constant light attenuation</source>
        <translation>Stálé zeslabení světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="458"/>
        <source>Linear light attenuation</source>
        <translation>Přímé zeslabení světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="480"/>
        <source>Quadratic light attenuation</source>
        <translation>Čtvercové zeslabení světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="517"/>
        <source>Distance</source>
        <translation>Vzdálenost zdroje světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="520"/>
        <source>Dis.</source>
        <translation>Vzdálenost</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="541"/>
        <source>Light distance from origin</source>
        <translation>Vzdálenost od zdroje světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1268"/>
        <source>Set lights</source>
        <translation>Povolit/Zakázat zdroje světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1312"/>
        <source>Set light 0</source>
        <translation>Povolit/Zakázat zroj světla 0</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1146"/>
        <location filename="../../src/ui/ligedit.ui" line="1315"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1331"/>
        <source>Set light 1</source>
        <translation>Povolit/Zakázat zroj světla 1</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1159"/>
        <location filename="../../src/ui/ligedit.ui" line="1334"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1344"/>
        <source>Set light 2</source>
        <translation>Povolit/Zakázat zroj světla 2</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1169"/>
        <location filename="../../src/ui/ligedit.ui" line="1347"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1357"/>
        <source>Set light 3</source>
        <translation>Povolit/Zakázat zroj světla 3</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1179"/>
        <location filename="../../src/ui/ligedit.ui" line="1360"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1370"/>
        <source>Set light 4</source>
        <translation>Povolit/Zakázat zroj světla 4</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1192"/>
        <location filename="../../src/ui/ligedit.ui" line="1373"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1383"/>
        <source>Set light 5</source>
        <translation>Povolit/Zakázat zroj světla 5</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1205"/>
        <location filename="../../src/ui/ligedit.ui" line="1386"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1396"/>
        <source>Set light 6</source>
        <translation>Povolit/Zakázat zroj světla 6</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1218"/>
        <location filename="../../src/ui/ligedit.ui" line="1399"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1409"/>
        <source>Set light 7</source>
        <translation>Povolit/Zakázat zroj světla 7</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1231"/>
        <location filename="../../src/ui/ligedit.ui" line="1412"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1102"/>
        <source>  Edit single light</source>
        <translation>Upravit jednoduchý zdroj světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1143"/>
        <source>Edit light 0</source>
        <translation>Upravit zdroj světla 0</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1156"/>
        <source>Edit light 1</source>
        <translation>Upravit zdroj světla 1</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1166"/>
        <source>Edit light 2</source>
        <translation>Upravit zdroj světla 2</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1176"/>
        <source>Edit light 3</source>
        <translation>Upravit zdroj světla 3</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1189"/>
        <source>Edit light 4</source>
        <translation>Upravit zdroj světla 4</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1202"/>
        <source>Edit light 5</source>
        <translation>Upravit zdroj světla 5</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1215"/>
        <source>Edit light 6</source>
        <translation>Upravit zdroj světla 6</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1228"/>
        <source>Edit light 7</source>
        <translation>Upravit zdroj světla 7</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="592"/>
        <source>Light intensity</source>
        <translation>Síla světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="619"/>
        <source>Ambient light</source>
        <translation>Okolní světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="622"/>
        <source>Amb.</source>
        <translation>Okolí</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="677"/>
        <source>Ambient red light</source>
        <translation>Okolní červené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="696"/>
        <source>Ambient green light</source>
        <translation>Okolní zelené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="715"/>
        <source>Ambient blue light</source>
        <translation>Okolní modré světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="737"/>
        <source>Ambient alpha channel</source>
        <translation>Alfa kanál prostředí</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="755"/>
        <location filename="../../src/ui/ligedit.ui" line="915"/>
        <location filename="../../src/ui/ligedit.ui" line="1075"/>
        <source>Lock RGB-sliders</source>
        <translation>Zamknout posuvníky RGB</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="758"/>
        <location filename="../../src/ui/ligedit.ui" line="918"/>
        <location filename="../../src/ui/ligedit.ui" line="1078"/>
        <source>Lock</source>
        <translation>Zamknout</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="779"/>
        <source>Diffuse light</source>
        <translation>Rozptýlené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="782"/>
        <source>Diff.</source>
        <translation>Rozptýlené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="837"/>
        <source>Diffuse red light</source>
        <translation>Rozptýlené červené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="856"/>
        <source>Diffuse green light</source>
        <translation>Rozptýlené zelené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="875"/>
        <source>Diffuse blue light</source>
        <translation>Rozptýlené modré světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="897"/>
        <source>Diffuse alpha channel</source>
        <translation>Alfa kanál rozptýleného světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="939"/>
        <source>Specular light</source>
        <translation>Blýskavé/třpytivé světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="942"/>
        <source>Spec.</source>
        <translation>Blýskavé světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="997"/>
        <source>Specular red light</source>
        <translation>Blýskavé/třpytivé červené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1016"/>
        <source>Specular green light</source>
        <translation>Blýskavé/třpytivé zelené světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1035"/>
        <source>Specular blue light</source>
        <translation>Blýskavé/třpytivé modré světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1057"/>
        <source>Specular alpha channel</source>
        <translation>Alfa kanál blýskavého/třpytivého světla</translation>
    </message>
</context>
<context>
    <name>ligWidget</name>
    <message>
        <location filename="../../src/ligedit.cpp" line="31"/>
        <location filename="../../src/ligedit.cpp" line="315"/>
        <source>Lights</source>
        <translation>Zdroje světla</translation>
    </message>
</context>
<context>
    <name>mainCtrl</name>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="252"/>
        <source>Scale</source>
        <translation>Změna velikosti</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="285"/>
        <location filename="../../src/ui/mainwindow.ui" line="384"/>
        <location filename="../../src/ui/mainwindow.ui" line="410"/>
        <location filename="../../src/ui/mainwindow.ui" line="423"/>
        <source>Scale up</source>
        <translation>Zvětšit</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="288"/>
        <location filename="../../src/ui/mainwindow.ui" line="387"/>
        <location filename="../../src/ui/mainwindow.ui" line="400"/>
        <location filename="../../src/ui/mainwindow.ui" line="413"/>
        <location filename="../../src/ui/mainwindow.ui" line="426"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="298"/>
        <location filename="../../src/ui/mainwindow.ui" line="332"/>
        <location filename="../../src/ui/mainwindow.ui" line="345"/>
        <location filename="../../src/ui/mainwindow.ui" line="358"/>
        <source>Scale down</source>
        <translation>Zmenšit</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="301"/>
        <location filename="../../src/ui/mainwindow.ui" line="335"/>
        <location filename="../../src/ui/mainwindow.ui" line="348"/>
        <location filename="../../src/ui/mainwindow.ui" line="361"/>
        <location filename="../../src/ui/mainwindow.ui" line="374"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="311"/>
        <source> X</source>
        <translation> x</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="318"/>
        <source> Y</source>
        <translation> y</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="325"/>
        <source> Z</source>
        <translation> z</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="371"/>
        <source>Decrease gridlines</source>
        <translation>Zmenšit mřížku</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="397"/>
        <source>Increase gridlines</source>
        <translation>Zvětšit mřížku</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="436"/>
        <source> A</source>
        <translation> A</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="443"/>
        <source>Gridlines</source>
        <translation>Čáry mřížky</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="446"/>
        <source> G</source>
        <translation> R</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="31"/>
        <source>Enabe/disable views</source>
        <translation>Povolit/Zakázat pohledy</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="34"/>
        <source>Show</source>
        <translation>Ukázat</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="64"/>
        <source>Show function 0</source>
        <translation>Ukázat funkci 0</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="67"/>
        <source>F0</source>
        <translation>F0</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="83"/>
        <source>Show function 1</source>
        <translation>Ukázat funkci 1</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="86"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="99"/>
        <source>Show function 2</source>
        <translation>Ukázat funkci 2</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="102"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="115"/>
        <source>Show parametric system</source>
        <translation>Ukázat parametrickou soustavu</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="118"/>
        <source>Par.</source>
        <translation>Param.</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="662"/>
        <source>Toggle cross on/off</source>
        <translation>Zapnout/Vypnout kříž</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="665"/>
        <source>Cross</source>
        <translation>Kříž</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="643"/>
        <source>Toggle axes on/off</source>
        <translation>Zapnout/Vypnout osy</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="646"/>
        <source>Axes</source>
        <translation>Osy</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="140"/>
        <source>Set current mode</source>
        <translation>Nastavit nynější režim</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="143"/>
        <source>Mode</source>
        <translation>Režim</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="233"/>
        <source>Set point-mode</source>
        <translation>Zapnout režim bodů</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="236"/>
        <source>Point</source>
        <translation>Bod</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="201"/>
        <source>Quad</source>
        <translation>Čtverec</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="176"/>
        <source>Set wire-mode</source>
        <translation>Povolit/Zakázat režim s drátěnou mříží</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="179"/>
        <source>Wire</source>
        <translation>Drát</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="709"/>
        <source>Cross coordinates and regarding function values</source>
        <translation>Souřadnice kříže a odpovídající hodnoty funkcí</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="528"/>
        <source>Rotate around X-axis</source>
        <translation>Otáčet kolem osy x</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="556"/>
        <source>Rotate around Y-axis</source>
        <translation>Otáčet kolem osy y</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="584"/>
        <source>Rotate around Z-axis</source>
        <translation>Otáčet kolem osy z</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="1088"/>
        <source>Switch between functions, isosurfaces and parametric system</source>
        <translation>Přepínat mezi funkcemi, Isopovrchy a soustavou parametrů</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="198"/>
        <source>Quadratic tessellation</source>
        <translation>Čtvercová teselace (zdobení mozaikou)</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="214"/>
        <source>Triangle tessellation</source>
        <translation>Trojúhelníková teselace (zdobení mozaikou)</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="217"/>
        <source>Triangle</source>
        <translation>Trojúhelník</translation>
    </message>
</context>
<context>
    <name>matUI</name>
    <message>
        <location filename="../../src/ui/matedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="51"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="64"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="74"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="84"/>
        <source>Par.</source>
        <translation>Parametry</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="118"/>
        <source>Sync</source>
        <translation>Seřízení</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="159"/>
        <source>Amb.</source>
        <translation>Okolní světlo</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="265"/>
        <location filename="../../src/ui/matedit.ui" line="392"/>
        <location filename="../../src/ui/matedit.ui" line="529"/>
        <location filename="../../src/ui/matedit.ui" line="656"/>
        <source>Lock RGB-sliders</source>
        <translation>Zamknout posuvníky RGB</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="268"/>
        <location filename="../../src/ui/matedit.ui" line="395"/>
        <location filename="../../src/ui/matedit.ui" line="532"/>
        <location filename="../../src/ui/matedit.ui" line="659"/>
        <source>Lock</source>
        <translation>Zamknout</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="286"/>
        <source>Diff.</source>
        <translation>Rozptýlené</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="423"/>
        <source>Spec.</source>
        <translation>Blýskavé</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="550"/>
        <source>Emi.</source>
        <translation>Vysílané</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="688"/>
        <source>Specular shininess</source>
        <translation>Zrcadlový odlesk</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="691"/>
        <source>Spec. shininess</source>
        <translation>Zrcadlový odlesk</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="25"/>
        <source>Edit surface properties</source>
        <translation>Upravit vlastnosti povrchu</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="28"/>
        <source>Edit surface</source>
        <translation>Upravit povrch</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="81"/>
        <source>Edit surface parametric-system</source>
        <translation>Upravit soustavu parametrů povrchu</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="156"/>
        <source>Ambient surface properties</source>
        <translation>Vlastnosti světla okolního povrchu</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="283"/>
        <source>Diffuse surface properties</source>
        <translation>Vlastnosti světla rozptýleného po povrchu</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="420"/>
        <source>Specular surface properties</source>
        <translation>Vlastnosti světla blýskavého/třpytivého povrchu</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="547"/>
        <source>Emission surface properties</source>
        <translation>Vlastnosti světla vysílaného povrchem</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="709"/>
        <source>Specular shininess low&lt;-&gt;high</source>
        <translation>Lesk blýskavého/třpytícího se světla slabý&lt;-&gt;silný</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="187"/>
        <location filename="../../src/ui/matedit.ui" line="314"/>
        <location filename="../../src/ui/matedit.ui" line="451"/>
        <location filename="../../src/ui/matedit.ui" line="578"/>
        <source>Red surface</source>
        <translation>Červený povrch</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="206"/>
        <location filename="../../src/ui/matedit.ui" line="333"/>
        <location filename="../../src/ui/matedit.ui" line="470"/>
        <location filename="../../src/ui/matedit.ui" line="597"/>
        <source>Green surface</source>
        <translation>Zelený povrch</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="225"/>
        <location filename="../../src/ui/matedit.ui" line="352"/>
        <location filename="../../src/ui/matedit.ui" line="489"/>
        <location filename="../../src/ui/matedit.ui" line="616"/>
        <source>Blue surface</source>
        <translation>Modrý povrch</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="247"/>
        <source>Ambient alpha channel</source>
        <translation>Alfa kanál prostředí</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="374"/>
        <source>Diffuse alpha channel</source>
        <translation>Alfa kanál rozptýleného světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="511"/>
        <source>Specular alpha channel</source>
        <translation>Alfa kanál blýskavého/třpytivého světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="638"/>
        <source>Emission alpha channel</source>
        <translation>Alfa kanál vysílaného světla</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="115"/>
        <source>Synchronize back side with front</source>
        <translation>Seřídit zadní a přední stranu</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="136"/>
        <source>Change between front and back</source>
        <translation>Měnit mezi zadní a přední stranou</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="139"/>
        <source>Back</source>
        <translation>Zadní strana</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="48"/>
        <source>Edit surface F0/I0</source>
        <translation>Upravit povrch F0/I0</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="61"/>
        <source>Edit surface F1/I1</source>
        <translation>Upravit povrch F1/I1</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="71"/>
        <source>Edit surface F2/I2</source>
        <translation>Upravit povrch F2I/I2</translation>
    </message>
</context>
<context>
    <name>matWidget</name>
    <message>
        <location filename="../../src/matedit.cpp" line="31"/>
        <location filename="../../src/matedit.cpp" line="136"/>
        <source>Surfaces</source>
        <translation>Povrchy</translation>
    </message>
</context>
<context>
    <name>morUI</name>
    <message>
        <location filename="../../src/ui/moredit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="19"/>
        <source>Limits</source>
        <translation>Hranice</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="25"/>
        <source>Lower limit</source>
        <translation>Dolní hranice</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="44"/>
        <source> - </source>
        <translation> - </translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="51"/>
        <source>Upper limit</source>
        <translation>Horní hranice</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="127"/>
        <source>Steps</source>
        <translation>Kroky</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="124"/>
        <source>Steps in between lower/upper limits</source>
        <translation>Kroků mezi dolní/horní hranicí</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="177"/>
        <source>Frames/second</source>
        <translation>Snímků za sekundu</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="180"/>
        <source>Frames</source>
        <translation>Snímky</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="233"/>
        <source>Morph</source>
        <translation>Morfovat</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="230"/>
        <source>Start/stop morphing</source>
        <translation>Spustit/zastavit morfování</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="106"/>
        <source>CPU/GPU utilization in %</source>
        <translation>Vytížení CPU/GPU-v %</translation>
    </message>
</context>
<context>
    <name>morWidget</name>
    <message>
        <location filename="../../src/moredit.cpp" line="34"/>
        <location filename="../../src/moredit.cpp" line="167"/>
        <source>Morphing</source>
        <translation>Morfování</translation>
    </message>
    <message>
        <location filename="../../src/moredit.cpp" line="152"/>
        <source>Stop</source>
        <translation>Zastavit</translation>
    </message>
    <message>
        <location filename="../../src/moredit.cpp" line="154"/>
        <source>Morph</source>
        <translation>Morfovat</translation>
    </message>
</context>
<context>
    <name>picUI</name>
    <message>
        <location filename="../../src/ui/picedit.ui" line="16"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="28"/>
        <source>Properties</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="292"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="302"/>
        <source>JPG</source>
        <translation>JPG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="112"/>
        <source>Dimensions</source>
        <translation>Rozměry</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="205"/>
        <location filename="../../src/ui/picedit.ui" line="224"/>
        <source>X-Dimension</source>
        <translation>Rozměr x</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="227"/>
        <source>X</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="160"/>
        <location filename="../../src/ui/picedit.ui" line="179"/>
        <source>Y-Dimension</source>
        <translation>Rozměr y</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="182"/>
        <source>Y</source>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="48"/>
        <location filename="../../src/ui/picedit.ui" line="61"/>
        <source>Picture quality: 0=low 100=high</source>
        <translation>Kvalita obrázku: 0=nízká 100=vysoká</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="239"/>
        <source>Format</source>
        <translation>Obrázkový formát</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="259"/>
        <source>Portable Document Format</source>
        <translation>Přenositelný formát dokumentu (Portable Document Format)</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="262"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="269"/>
        <source>PostScript</source>
        <translation>PostScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="272"/>
        <source>PS</source>
        <translation>PS</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="289"/>
        <source>Portable Network Graphics</source>
        <translation>Přenositelná síťová grafika (Portable Network Graphics)</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="299"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="100"/>
        <source>Dpi</source>
        <translation>Dpi</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="124"/>
        <source>Lock/unlock XY-values</source>
        <translation>Zamknout/Odemknout hodnoty xy</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="64"/>
        <source>Quality</source>
        <translation>Kvalita</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="81"/>
        <location filename="../../src/ui/picedit.ui" line="97"/>
        <source>Dpi: 75..4800</source>
        <translation>Dpi: 75..4800</translation>
    </message>
</context>
<context>
    <name>picWidget</name>
    <message>
        <location filename="../../src/picedit.cpp" line="27"/>
        <location filename="../../src/picedit.cpp" line="133"/>
        <source>Picture</source>
        <translation>Obrázek</translation>
    </message>
</context>
<context>
    <name>speUI</name>
    <message>
        <location filename="../../src/ui/speedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="19"/>
        <source>Textures</source>
        <translation>Povrchy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="107"/>
        <location filename="../../src/ui/speedit.ui" line="218"/>
        <location filename="../../src/ui/speedit.ui" line="329"/>
        <location filename="../../src/ui/speedit.ui" line="440"/>
        <source>Flip texture vertical</source>
        <translation>Obrátit povrch svisle</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="129"/>
        <location filename="../../src/ui/speedit.ui" line="240"/>
        <location filename="../../src/ui/speedit.ui" line="351"/>
        <location filename="../../src/ui/speedit.ui" line="462"/>
        <source>On</source>
        <translation>Zapnuto</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="51"/>
        <location filename="../../src/ui/speedit.ui" line="162"/>
        <location filename="../../src/ui/speedit.ui" line="273"/>
        <location filename="../../src/ui/speedit.ui" line="384"/>
        <source>Load new texture</source>
        <translation>Nahrát nový povrch</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="361"/>
        <source>Par.</source>
        <translation>Param.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="576"/>
        <source>Fog</source>
        <translation>Mlha</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="659"/>
        <source>Red fog light</source>
        <translation>Červené světlo mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="684"/>
        <source>Green fog light</source>
        <translation>Zelené světlo mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="709"/>
        <source>Blue fog light</source>
        <translation>Modré světlo mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="737"/>
        <source>Fog light alpha channel</source>
        <translation>Alfa kanál světla mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="755"/>
        <source>Lock RGB-sliders</source>
        <translation>Zamknout posuvníky RGB</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="758"/>
        <source>Lock</source>
        <translation>Zamknout</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="798"/>
        <source>Fog mode</source>
        <translation>Režim mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="801"/>
        <source>Mode</source>
        <translation>Režim</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="825"/>
        <source>Exp</source>
        <translation>Exponovaný</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="835"/>
        <source>Exp2</source>
        <translation>Exp2</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="842"/>
        <source>Linear</source>
        <translation>Lineární</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="845"/>
        <source>Lin.</source>
        <translation>Lineár.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="855"/>
        <source>Fog settings</source>
        <translation>Nastavení mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="858"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="882"/>
        <location filename="../../src/ui/speedit.ui" line="930"/>
        <source>Intensity</source>
        <translation>Síla</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="898"/>
        <location filename="../../src/ui/speedit.ui" line="950"/>
        <source>Fog end value</source>
        <translation>Konečná hodnota mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="914"/>
        <location filename="../../src/ui/speedit.ui" line="940"/>
        <source>Fog starting value</source>
        <translation>Počáteční hodnota mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="933"/>
        <source>Int.</source>
        <translation>Int.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="943"/>
        <source>Start</source>
        <translation>Začátek</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="953"/>
        <source>End</source>
        <translation>Konec</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="822"/>
        <source>Exponential</source>
        <translation>Exponenciální</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="832"/>
        <source>Quadratic exponential</source>
        <translation>Kvadratická exponenciální</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="368"/>
        <source>Texture parameter system</source>
        <translation>Soustava pomocných parametrů povrchu</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="771"/>
        <source>Sync</source>
        <translation>Seřízení</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="493"/>
        <source>Span</source>
        <translation>Rozpětí</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="532"/>
        <source>Increase/decrease texture span</source>
        <translation>Zvětšit/Zmenšit rozpětí povrchu</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="612"/>
        <source>Fog colour properties</source>
        <translation>Barevné vlastnosti mlhy</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="615"/>
        <source>Colour</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="768"/>
        <source>Synchronize fog with background colour</source>
        <translation>Seřídit barvu mlhy s barvou pozadí</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="79"/>
        <location filename="../../src/ui/speedit.ui" line="190"/>
        <location filename="../../src/ui/speedit.ui" line="301"/>
        <location filename="../../src/ui/speedit.ui" line="412"/>
        <source>Remove texture from file</source>
        <translation>Odstranit povrch ze souboru</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="984"/>
        <source>Motion blur</source>
        <translation>Rozmazání pohybu</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1011"/>
        <location filename="../../src/ui/speedit.ui" line="1094"/>
        <source>Translation offset for each iteration</source>
        <translation>Posun překladu na každou iteraci</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1030"/>
        <location filename="../../src/ui/speedit.ui" line="1084"/>
        <source>Iterations calculated per frame</source>
        <translation>Iterace počítané na snímek</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1052"/>
        <location filename="../../src/ui/speedit.ui" line="1074"/>
        <source>Magnitude of blur effect</source>
        <translation>Velikost účinku rozmazání</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1077"/>
        <source>Magnitude</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1087"/>
        <source>Iterations</source>
        <translation>Iterace</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1097"/>
        <source>Offset</source>
        <translation>Posun</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="28"/>
        <source>F0/I0</source>
        <translation>F0/I0</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="35"/>
        <source>Texture F0/I0</source>
        <translation>Povrch F0/I0</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="139"/>
        <source>F1/I1</source>
        <translation>F1/I1</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="146"/>
        <source>Texture F1/I1</source>
        <translation>Povrch F1/I1</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="250"/>
        <source>F2/I2</source>
        <translation>F2/I2</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="257"/>
        <source>Texture F2/I2</source>
        <translation>Povrch F2/I2</translation>
    </message>
</context>
<context>
    <name>speWidget</name>
    <message>
        <location filename="../../src/speedit.cpp" line="126"/>
        <location filename="../../src/speedit.cpp" line="158"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="126"/>
        <source>file</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="159"/>
        <source>Error loading file:</source>
        <translation>Při nahrávání souboru došlo k chybě:</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="38"/>
        <location filename="../../src/speedit.cpp" line="171"/>
        <location filename="../../src/speedit.cpp" line="182"/>
        <location filename="../../src/speedit.cpp" line="195"/>
        <location filename="../../src/speedit.cpp" line="206"/>
        <location filename="../../src/speedit.cpp" line="613"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="172"/>
        <source>Texture width too large</source>
        <translation>Šířka povrchu je příliš velká</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="183"/>
        <source>Texture height too large</source>
        <translation>Výška povrchu je příliš velká</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="196"/>
        <source>Texture width not a power of 2</source>
        <translation>Šířka povrchu není mocnina dvou</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="207"/>
        <source>Texture height not a power of 2</source>
        <translation>Výška povrchu není mocnina dvou</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="223"/>
        <location filename="../../src/speedit.cpp" line="243"/>
        <location filename="../../src/speedit.cpp" line="262"/>
        <location filename="../../src/speedit.cpp" line="286"/>
        <location filename="../../src/speedit.cpp" line="294"/>
        <source>System information</source>
        <translation>Systémová informace</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="224"/>
        <location filename="../../src/speedit.cpp" line="244"/>
        <location filename="../../src/speedit.cpp" line="263"/>
        <location filename="../../src/speedit.cpp" line="287"/>
        <location filename="../../src/speedit.cpp" line="295"/>
        <source>Out of memory</source>
        <translation>Už není paměť</translation>
    </message>
</context>
<context>
    <name>usrWidget</name>
    <message>
        <location filename="../../src/usredit.cpp" line="34"/>
        <location filename="../../src/usredit.cpp" line="220"/>
        <source>User defined items</source>
        <translation>Uživatelem stanovené záznamy</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="93"/>
        <source>Alert</source>
        <translation>Pozor</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="128"/>
        <location filename="../../src/usredit.cpp" line="221"/>
        <source>Item</source>
        <translation>Záznam</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="149"/>
        <location filename="../../src/usredit.cpp" line="222"/>
        <source>Delete row</source>
        <translation>Smazat řádek</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="152"/>
        <location filename="../../src/usredit.cpp" line="223"/>
        <source>Insert row</source>
        <translation>Vložit řádek</translation>
    </message>
</context>
</TS>
