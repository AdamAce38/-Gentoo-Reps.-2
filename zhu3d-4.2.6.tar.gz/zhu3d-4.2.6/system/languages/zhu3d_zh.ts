<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<context>
    <name>MaiWindow</name>
    <message>
        <location filename="../../src/mainwindow.cpp" line="56"/>
        <location filename="../../src/mainwindow.cpp" line="177"/>
        <location filename="../../src/mainwindow.cpp" line="289"/>
        <location filename="../../src/mainwindow.cpp" line="972"/>
        <location filename="../../src/mainwindow.cpp" line="1877"/>
        <source>Solver report</source>
        <translation>解答报告</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="887"/>
        <location filename="../../src/mainwindow.cpp" line="1737"/>
        <source>Stop animation</source>
        <translation>停止动画</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="223"/>
        <location filename="../../src/mainwindow.cpp" line="1471"/>
        <location filename="../../src/mainwindow.cpp" line="1480"/>
        <location filename="../../src/mainwindow.cpp" line="1490"/>
        <location filename="../../src/mainwindow.cpp" line="1501"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="223"/>
        <location filename="../../src/mainwindow.cpp" line="255"/>
        <source>file</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1472"/>
        <location filename="../../src/mainwindow.cpp" line="1481"/>
        <location filename="../../src/mainwindow.cpp" line="1491"/>
        <location filename="../../src/mainwindow.cpp" line="1502"/>
        <source>Error loading file:</source>
        <translation>下载文件错误 :</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="255"/>
        <location filename="../../src/mainwindow.cpp" line="275"/>
        <location filename="../../src/mainwindow.cpp" line="316"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="276"/>
        <location filename="../../src/mainwindow.cpp" line="317"/>
        <source>Error saving file:</source>
        <translation>文件保存错误:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="290"/>
        <source>Currently there is nothing to save!</source>
        <translation>没有任何文件保存!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="298"/>
        <location filename="../../src/mainwindow.cpp" line="942"/>
        <location filename="../../src/mainwindow.cpp" line="1867"/>
        <source>Save solutions</source>
        <translation>保存解答</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="357"/>
        <source>Cannot find any helpfile</source>
        <translation>找不到任何帮助信息</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="378"/>
        <location filename="../../src/mainwindow.cpp" line="1049"/>
        <location filename="../../src/mainwindow.cpp" line="1174"/>
        <location filename="../../src/mainwindow.cpp" line="1858"/>
        <location filename="../../src/mainwindow.cpp" line="1906"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="413"/>
        <source>System information</source>
        <translation>信息系统</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="425"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="892"/>
        <location filename="../../src/mainwindow.cpp" line="1732"/>
        <source>Start animation</source>
        <translation>启动动画</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="930"/>
        <location filename="../../src/mainwindow.cpp" line="1861"/>
        <source>&amp;New</source>
        <translation>&amp;新</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="931"/>
        <location filename="../../src/mainwindow.cpp" line="1862"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="934"/>
        <location filename="../../src/mainwindow.cpp" line="1863"/>
        <source>&amp;Open ...</source>
        <translation>&amp;打开 ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="935"/>
        <location filename="../../src/mainwindow.cpp" line="1864"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="938"/>
        <location filename="../../src/mainwindow.cpp" line="1865"/>
        <source>&amp;Save as</source>
        <translation>&amp;另存为</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="939"/>
        <location filename="../../src/mainwindow.cpp" line="1866"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="945"/>
        <location filename="../../src/mainwindow.cpp" line="1868"/>
        <source>Save picture</source>
        <translation>保存图像</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="948"/>
        <location filename="../../src/mainwindow.cpp" line="1869"/>
        <source>Print picture</source>
        <translation>打印图像</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="951"/>
        <location filename="../../src/mainwindow.cpp" line="1870"/>
        <source>&amp;Exit</source>
        <translation>&amp;退出</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="952"/>
        <location filename="../../src/mainwindow.cpp" line="1871"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="957"/>
        <location filename="../../src/mainwindow.cpp" line="1874"/>
        <source>Lights</source>
        <translation>灯光</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="960"/>
        <location filename="../../src/mainwindow.cpp" line="1875"/>
        <source>Surfaces</source>
        <translation>表面</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="963"/>
        <location filename="../../src/mainwindow.cpp" line="1876"/>
        <source>Global</source>
        <translation>全部</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="980"/>
        <location filename="../../src/mainwindow.cpp" line="1883"/>
        <source>Animation</source>
        <translation>动画</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="966"/>
        <location filename="../../src/mainwindow.cpp" line="1878"/>
        <source>User defined</source>
        <translation>自定义</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="975"/>
        <location filename="../../src/mainwindow.cpp" line="1660"/>
        <location filename="../../src/mainwindow.cpp" line="1880"/>
        <source>Functions</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="991"/>
        <location filename="../../src/mainwindow.cpp" line="1888"/>
        <source>Picture</source>
        <translation>图像</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="994"/>
        <location filename="../../src/mainwindow.cpp" line="1889"/>
        <source>micro</source>
        <translation>微小</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1000"/>
        <location filename="../../src/mainwindow.cpp" line="1890"/>
        <source>fine</source>
        <translation>细小</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1006"/>
        <location filename="../../src/mainwindow.cpp" line="1891"/>
        <source>normal</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1012"/>
        <location filename="../../src/mainwindow.cpp" line="1892"/>
        <source>coarse</source>
        <translation>粗大</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1018"/>
        <location filename="../../src/mainwindow.cpp" line="1893"/>
        <source>View only</source>
        <translation>只读</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1021"/>
        <location filename="../../src/mainwindow.cpp" line="1894"/>
        <source>Scaling only</source>
        <translation>缩放比例</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1024"/>
        <location filename="../../src/mainwindow.cpp" line="1895"/>
        <source>Lights only</source>
        <translation>只有灯光</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1027"/>
        <location filename="../../src/mainwindow.cpp" line="1896"/>
        <source>All together</source>
        <translation>一起</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1030"/>
        <location filename="../../src/mainwindow.cpp" line="1897"/>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1137"/>
        <location filename="../../src/mainwindow.cpp" line="1853"/>
        <source>Special</source>
        <translation>特别</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1033"/>
        <location filename="../../src/mainwindow.cpp" line="1898"/>
        <source>Directories</source>
        <translation>索引</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1038"/>
        <location filename="../../src/mainwindow.cpp" line="1901"/>
        <source>Show open editors</source>
        <translation>显示已开编辑</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1041"/>
        <location filename="../../src/mainwindow.cpp" line="1902"/>
        <source>Hide open editors</source>
        <translation>隐藏已开编辑</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1044"/>
        <location filename="../../src/mainwindow.cpp" line="1903"/>
        <source>Open all editors</source>
        <translation>打开所有编辑</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1050"/>
        <location filename="../../src/mainwindow.cpp" line="1908"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1053"/>
        <location filename="../../src/mainwindow.cpp" line="1909"/>
        <source>System</source>
        <translation>系统</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1059"/>
        <location filename="../../src/mainwindow.cpp" line="1806"/>
        <location filename="../../src/mainwindow.cpp" line="1910"/>
        <source>Benchmark</source>
        <translation>测试</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1062"/>
        <location filename="../../src/mainwindow.cpp" line="1911"/>
        <source>About Zhu3D</source>
        <translation>关于 Zhu3D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1065"/>
        <location filename="../../src/mainwindow.cpp" line="1912"/>
        <source>About Qt</source>
        <translation>关于 Qt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1070"/>
        <source>Zoom in</source>
        <translation>放大</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1071"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1074"/>
        <source>Zoom out</source>
        <translation>缩小</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1075"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1078"/>
        <source>Move left</source>
        <translation>向左移</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1079"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <source>Move right</source>
        <translation>向右移</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1083"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1086"/>
        <source>Move up</source>
        <translation>向上移</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1087"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1090"/>
        <source>Move down</source>
        <translation>向下移</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1091"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1094"/>
        <location filename="../../src/mainwindow.cpp" line="1657"/>
        <source>Solve system</source>
        <translation>解答系统</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1097"/>
        <source>Start/stop animation</source>
        <translation>启动/停止 动画</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1111"/>
        <location filename="../../src/mainwindow.cpp" line="1194"/>
        <location filename="../../src/mainwindow.cpp" line="1851"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1124"/>
        <location filename="../../src/mainwindow.cpp" line="1852"/>
        <source>Editors</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1144"/>
        <location filename="../../src/mainwindow.cpp" line="1854"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1146"/>
        <location filename="../../src/mainwindow.cpp" line="1855"/>
        <source>Scaling</source>
        <translation>缩放</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1152"/>
        <location filename="../../src/mainwindow.cpp" line="1856"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1167"/>
        <location filename="../../src/mainwindow.cpp" line="1857"/>
        <source>Windows</source>
        <translation>窗口</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1199"/>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1204"/>
        <source>Move</source>
        <translation>移动</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1211"/>
        <source>Extras</source>
        <translation>额外</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1327"/>
        <source>Creation date:</source>
        <translation>创建日期:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1377"/>
        <location filename="../../src/mainwindow.cpp" line="1379"/>
        <location filename="../../src/mainwindow.cpp" line="1384"/>
        <location filename="../../src/mainwindow.cpp" line="1386"/>
        <location filename="../../src/mainwindow.cpp" line="1393"/>
        <location filename="../../src/mainwindow.cpp" line="1395"/>
        <location filename="../../src/mainwindow.cpp" line="1400"/>
        <location filename="../../src/mainwindow.cpp" line="1402"/>
        <source>Cross</source>
        <translation>十字坐标</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1482"/>
        <source>Zhu3D file is too old or not valid!</source>
        <translation>文件 Zhu3D 太老或已过期!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1536"/>
        <source>untitled</source>
        <translation>无标题</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1633"/>
        <source>X-values</source>
        <translation>X值</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1634"/>
        <source>Y-values</source>
        <translation>Y值</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1635"/>
        <source>Z-values</source>
        <translation>Z值</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1636"/>
        <source> A</source>
        <translation> A</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1637"/>
        <source>All XYZ-values together</source>
        <translation>所有XYZ的值</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1652"/>
        <source>Scale functions</source>
        <translation>运行比例</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1659"/>
        <source>Function editor</source>
        <translation>运行编辑</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1662"/>
        <source>Edit: Functions</source>
        <translation>编辑：函数灯光</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1662"/>
        <location filename="../../src/mainwindow.cpp" line="1692"/>
        <location filename="../../src/mainwindow.cpp" line="1720"/>
        <source>Grid:</source>
        <translation>方格:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1682"/>
        <source>Scale iso functions</source>
        <translation>等值面比例运行 </translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1687"/>
        <location filename="../../src/mainwindow.cpp" line="1715"/>
        <source>For solving switch to function-mode</source>
        <translation>用运行模式解决</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1689"/>
        <source>Iso editor</source>
        <translation>编辑 等值面</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1690"/>
        <source>Iso functions</source>
        <translation>运行 等值面</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1692"/>
        <source>Edit: Isosurfaces</source>
        <translation>编辑：等值面</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1710"/>
        <source>Scale parametric system</source>
        <translation>参数系统比例</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1717"/>
        <source>Parameter editor</source>
        <translation>编辑参数</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1718"/>
        <source>Parameters</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1720"/>
        <source>Edit: Parameter</source>
        <translation>编辑：参数</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1777"/>
        <source>Benchmarking now ...</source>
        <translation>开始测试 ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1056"/>
        <location filename="../../src/mainwindow.cpp" line="1907"/>
        <source>Demo</source>
        <translation>示范</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="983"/>
        <location filename="../../src/mainwindow.cpp" line="1884"/>
        <source>Morphing</source>
        <translation>曲解</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="909"/>
        <location filename="../../src/mainwindow.cpp" line="1750"/>
        <source>Stop morphing</source>
        <translation>停止 形态显示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="914"/>
        <location filename="../../src/mainwindow.cpp" line="1745"/>
        <source>Start morphing</source>
        <translation>开始 形态显示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="986"/>
        <location filename="../../src/mainwindow.cpp" line="1885"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1100"/>
        <source>Start/stop morphing</source>
        <translation>开始/停止 形态显示</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="969"/>
        <location filename="../../src/mainwindow.cpp" line="1879"/>
        <source>Legends</source>
        <translation>解说</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1492"/>
        <source>XML parser error</source>
        <translation>XML 解析错误</translation>
    </message>
</context>
<context>
    <name>OGLWidget</name>
    <message>
        <location filename="../../src/glwidget.cpp" line="255"/>
        <location filename="../../src/glwidget.cpp" line="303"/>
        <location filename="../../src/glwidget.cpp" line="351"/>
        <source>Alert</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1205"/>
        <location filename="../../src/glwidget.cpp" line="1228"/>
        <source>Material</source>
        <translation>要素</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1206"/>
        <source>Editing back-side colours, although the global setting is just 1-sided.&lt;p&gt;&lt;/p&gt;Zhu3D is &lt;b&gt;enabling&lt;/b&gt; the 2-sided mode automatically now.</source>
        <translation>编辑背景颜色，总配置只有一面的.&lt;p&gt;&lt;/p&gt;Zhu3D是&lt;b&gt;可以写成&lt;/b&gt; 现在双面模式自动生成.</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1229"/>
        <source>Changing back-side colours, although the global setting is just 1-sided.&lt;p&gt;&lt;/p&gt;Zhu3D is &lt;b&gt;enabling&lt;/b&gt; the 2-sided mode automatically now.</source>
        <translation>改变背景颜色,总配置只有一面的.&lt;p&gt;&lt;/p&gt;Zhu3D为&lt;b&gt;可以写成&lt;/b&gt;现在双面模式自动生成.</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="213"/>
        <source>Viewer</source>
        <translation>视图</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="843"/>
        <source>Save as *.png</source>
        <translation>另存为 *.png </translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="863"/>
        <source>Save as *.jpg</source>
        <translation>另存为 *.jpg </translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="824"/>
        <location filename="../../src/glwidget.cpp" line="965"/>
        <source>Rendering</source>
        <translation>绘制</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="824"/>
        <location filename="../../src/glwidget.cpp" line="965"/>
        <source>picture ...</source>
        <translation>图像 ...</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="883"/>
        <source>Save as *.pdf</source>
        <translation>另存为 *.pdf </translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="917"/>
        <source>Save as *.ps</source>
        <translation>另存为 *.ps</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="248"/>
        <source>Parser message from F0/I0/X</source>
        <translation>从 F0/I0/X 中分析</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="296"/>
        <source>Parser message from F1/I1/Y</source>
        <translation>从 F1/I1/Y 中分析</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="344"/>
        <source>Parser message from F2/I2/Z</source>
        <translation>从 F2/I2/Z 中分析</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/main.cpp" line="168"/>
        <location filename="../../src/main.cpp" line="181"/>
        <location filename="../../src/mainwindow.cpp" line="1266"/>
        <location filename="../../src/mainwindow.cpp" line="1275"/>
        <source>Program start</source>
        <translation>程序开始</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="182"/>
        <source>Missing OpenGL! Terminating now</source>
        <translation>缺少OpenGL :程序自动结束</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1267"/>
        <source>CPU clockcounter is not supported!</source>
        <translation>CPU时钟不被支持 !</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1268"/>
        <source>System info cannot provide MHz-values</source>
        <translation>信息系统不能提供 MHz-values</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1276"/>
        <source>Missing OpenGL acceleration!</source>
        <translation>缺少OpenGL acceleration!</translation>
    </message>
    <message>
        <location filename="../../src/sysinfo.cpp" line="46"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/sysinfo.cpp" line="47"/>
        <source>No</source>
        <translation>不是</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1277"/>
        <source>Framerates will be very low</source>
        <translation>图像分辨率太弱</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="358"/>
        <source>ERROR 0: Syntax error</source>
        <translation>错误 0: 语法错误</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="359"/>
        <source>ERROR 1: Mismatched parenthesis</source>
        <translation>错误 1: 括弧不对应</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="360"/>
        <source>ERROR 2: Missing closing parenthesis</source>
        <translation>错误 2: 缺少后括弧</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="361"/>
        <source>ERROR 3: Empty parentheses</source>
        <translation>错误 3: 空括弧</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="362"/>
        <source>ERROR 4: Operator expected</source>
        <translation>错误 4: 缺少运算符号</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="363"/>
        <source>ERROR 5: Out of memory</source>
        <translation>错误 5: 没有内存</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="364"/>
        <source>ERROR 6: Unexpected error</source>
        <translation>错误 6: 无法预料的错误</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="365"/>
        <source>ERROR 7: Unknown parameter</source>
        <translation>错误 7: 未知参数</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="366"/>
        <source>ERROR 8: Illegal number of function parameters</source>
        <translation>错误 8: 非法函数参数</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="367"/>
        <source>ERROR 9: Premature end of string</source>
        <translation>错误 9: 字符串过早结束</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="368"/>
        <source>ERROR 10: Expecting parenthesis after function</source>
        <translation>错误 10: 运行结束后期待括弧</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="369"/>
        <source>ERROR 11: Parser initialization failed</source>
        <translation>错误 11: 分析初始化失败</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="370"/>
        <source>ERROR 12: Missing equal sign</source>
        <translation>错误 12: 缺少等号</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="371"/>
        <source>ERROR 13: Adding new constant failed</source>
        <translation>错误 13: 添加新常数失败</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="372"/>
        <source>ERROR 14: Adding new function failed</source>
        <translation>错误 14: 添加新函数失败</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="373"/>
        <source>ERROR 15: Parser update failed</source>
        <translation>错误 15:解析升级失败</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="146"/>
        <source>Search started at:  X=%1  Y=%2
Time needed for %3 iterations: %4 ms
The result is %5realiable.

Solution:  X=%6  Y=%7  Z=%8</source>
        <translation>开始查找 :  X=%1  Y=%2
%3重复需要时间 : %4 ms
结果是%5不确定的.

解答 :  X=%6  Y=%7  Z=%8</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="156"/>
        <source>NOT </source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="165"/>
        <source>Solver</source>
        <translation>解答</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="166"/>
        <source>Result is NOT reliable</source>
        <translation>结果是不确定的</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="65"/>
        <source>Alert</source>
        <translation>警告</translation>
    </message>
</context>
<context>
    <name>aniUI</name>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="13"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="19"/>
        <source>Rotation speed around the axes</source>
        <translation>绕轴旋转速度</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="22"/>
        <source>Rotation</source>
        <translation>旋转</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="77"/>
        <source>X-rotation offset</source>
        <translation>X轴旋转偏移值</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="99"/>
        <source>Y-rotation offset</source>
        <translation>Y轴旋转偏移值</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="118"/>
        <source>Z-rotation offset</source>
        <translation>Z轴旋转偏移值</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="142"/>
        <source>Lock XYZ-values</source>
        <translation>锁住 XYZ-values</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="145"/>
        <source>Lock</source>
        <translation>锁住</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="193"/>
        <source>GPU/CPU utilization in %</source>
        <translation>GPU/CPU 用 %</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="217"/>
        <source>Frames/second</source>
        <translation>图像/秒</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="220"/>
        <source>Frames</source>
        <translation>图像</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="273"/>
        <source>PushButton</source>
        <translation>PushButton</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="270"/>
        <source>Start/stop animation</source>
        <translation>开始/停止 动画</translation>
    </message>
</context>
<context>
    <name>aniWidget</name>
    <message>
        <location filename="../../src/aniedit.cpp" line="35"/>
        <location filename="../../src/aniedit.cpp" line="193"/>
        <source>Film</source>
        <translation>胶片</translation>
    </message>
    <message>
        <location filename="../../src/aniedit.cpp" line="177"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../../src/aniedit.cpp" line="181"/>
        <source>Animate</source>
        <translation>激活动画</translation>
    </message>
</context>
<context>
    <name>demWidget</name>
    <message>
        <location filename="../../src/demedit.cpp" line="32"/>
        <location filename="../../src/demedit.cpp" line="159"/>
        <source>Demo</source>
        <translation>示范</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="88"/>
        <location filename="../../src/demedit.cpp" line="170"/>
        <source>Stop slideshow</source>
        <translation>停止幻灯显示</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="95"/>
        <location filename="../../src/demedit.cpp" line="172"/>
        <source>Start slideshow</source>
        <translation>开始幻灯显示</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="173"/>
        <source>Backward</source>
        <translation>向后</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="174"/>
        <source>Forward</source>
        <translation>向前</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Error saving file:</source>
        <translation type="obsolete">文件保存错误:</translation>
    </message>
</context>
<context>
    <name>dirUI</name>
    <message>
        <location filename="../../src/ui/diredit.ui" line="13"/>
        <source>Form</source>
        <translation>格式</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="25"/>
        <source>Set new default directories</source>
        <translation>设置新默认索引</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="45"/>
        <location filename="../../src/ui/diredit.ui" line="75"/>
        <source>Set new directory</source>
        <translation>设置新索引</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="97"/>
        <location filename="../../src/ui/diredit.ui" line="117"/>
        <source>Current textures directory</source>
        <translation>目前索引构造</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="107"/>
        <location filename="../../src/ui/diredit.ui" line="127"/>
        <source>Current work directory</source>
        <translation>目前工作索引</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="120"/>
        <source>Textures: </source>
        <translation>图案 :</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="130"/>
        <source>Work: </source>
        <translation>工作:</translation>
    </message>
</context>
<context>
    <name>dirWidget</name>
    <message>
        <location filename="../../src/diredit.cpp" line="38"/>
        <location filename="../../src/diredit.cpp" line="116"/>
        <source>Directories</source>
        <translation>索引</translation>
    </message>
    <message>
        <location filename="../../src/diredit.cpp" line="66"/>
        <location filename="../../src/diredit.cpp" line="86"/>
        <source>Set new directory</source>
        <translation>设置新的索引</translation>
    </message>
</context>
<context>
    <name>entUI</name>
    <message>
        <location filename="../../src/ui/entedit.ui" line="13"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="36"/>
        <source>Ambient light</source>
        <translation>环境光</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="39"/>
        <source>Amb.</source>
        <translation>Amb.</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="94"/>
        <source>Red ambient light</source>
        <translation>环境红光</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="113"/>
        <source>Green ambient light</source>
        <translation>环境绿光</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="132"/>
        <source>Blue ambient light</source>
        <translation>环境蓝光</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="154"/>
        <source>Ambient alpha channel</source>
        <translation>alpha 通道环境</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="172"/>
        <location filename="../../src/ui/entedit.ui" line="326"/>
        <source>Lock RGB-sliders</source>
        <translation>锁住 RGB-sliders</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="175"/>
        <location filename="../../src/ui/entedit.ui" line="329"/>
        <source>Lock</source>
        <translation>锁住</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="190"/>
        <source>Background properties</source>
        <translation>背景属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="193"/>
        <source>Backgr.</source>
        <translation>背景.</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="248"/>
        <source>Red background light</source>
        <translation>红色背景光</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="267"/>
        <source>Green background light</source>
        <translation>绿色背景光</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="286"/>
        <source>Blue background light</source>
        <translation>蓝色背景光</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="308"/>
        <source>Background alpha channel</source>
        <translation>alpha通道背景</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="390"/>
        <source>1-side</source>
        <translation>一面</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="406"/>
        <source>2-side</source>
        <translation>两面</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="443"/>
        <source>Infinite light sources</source>
        <translation>无限光来源</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="446"/>
        <source>Inf.</source>
        <translation>Inf.</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="459"/>
        <source>Local light sources</source>
        <translation>局部光来源</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="462"/>
        <source>Local</source>
        <translation>局部的</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="387"/>
        <source>Surfaces are one-sided</source>
        <translation>一面的表面</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="403"/>
        <source>Surfaces are two-sided</source>
        <translation>两面的表面</translation>
    </message>
</context>
<context>
    <name>entWidget</name>
    <message>
        <location filename="../../src/entedit.cpp" line="26"/>
        <location filename="../../src/entedit.cpp" line="84"/>
        <source>Global</source>
        <translation>全部</translation>
    </message>
</context>
<context>
    <name>errUI</name>
    <message>
        <location filename="../../src/ui/error.ui" line="16"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
</context>
<context>
    <name>errWidget</name>
    <message>
        <location filename="../../src/error.cpp" line="25"/>
        <source>Debug-window</source>
        <translation>Debug窗口</translation>
    </message>
</context>
<context>
    <name>fntWidget</name>
    <message>
        <location filename="../../src/fntedit.cpp" line="389"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="411"/>
        <location filename="../../src/fntedit.cpp" line="412"/>
        <source>Precision for solver report in digits</source>
        <translation>解决报告的精确度</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="388"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="407"/>
        <location filename="../../src/fntedit.cpp" line="408"/>
        <source>Application language</source>
        <translation>语言应用</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="304"/>
        <location filename="../../src/fntedit.cpp" line="424"/>
        <source>English</source>
        <translation>英语</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="303"/>
        <location filename="../../src/fntedit.cpp" line="423"/>
        <source>German</source>
        <translation>德语</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="305"/>
        <location filename="../../src/fntedit.cpp" line="425"/>
        <source>Spanish</source>
        <translation>西班牙语</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="308"/>
        <location filename="../../src/fntedit.cpp" line="428"/>
        <source>Czech</source>
        <translation>捷克语</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="390"/>
        <source>Font style</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="391"/>
        <source>Font size</source>
        <translation>字号</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="392"/>
        <source>Icon size</source>
        <translation>图标大小</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="395"/>
        <source>Precision</source>
        <translation>精确度</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="394"/>
        <source>GUI style</source>
        <translation>GUI格式</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="159"/>
        <location filename="../../src/fntedit.cpp" line="402"/>
        <source>internal</source>
        <translation>内部的</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="160"/>
        <location filename="../../src/fntedit.cpp" line="403"/>
        <source>external</source>
        <translation>外部的</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="393"/>
        <source>Help browser</source>
        <translation>帮助浏览</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="409"/>
        <location filename="../../src/fntedit.cpp" line="410"/>
        <source>Choose internal or external help browser</source>
        <translation>选择内部或外部的帮助浏览</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="413"/>
        <location filename="../../src/fntedit.cpp" line="414"/>
        <source>Choose triangulation method</source>
        <translation>选择三角网格法</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="396"/>
        <source>Isosurfaces</source>
        <translation>等值面</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="306"/>
        <location filename="../../src/fntedit.cpp" line="426"/>
        <source>French</source>
        <translation>法语</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="307"/>
        <location filename="../../src/fntedit.cpp" line="427"/>
        <source>Chinese</source>
        <translation>中文</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="61"/>
        <location filename="../../src/fntedit.cpp" line="377"/>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="397"/>
        <source>Threads</source>
        <translation>虚线</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="415"/>
        <location filename="../../src/fntedit.cpp" line="416"/>
        <source>Threads for isosurface-triangulation</source>
        <translation>三角等值面虚线</translation>
    </message>
</context>
<context>
    <name>funUI</name>
    <message>
        <location filename="../../src/ui/funedit.ui" line="13"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="109"/>
        <source>F0:</source>
        <translation>F0:</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="142"/>
        <source>F1:</source>
        <translation>F1:</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="175"/>
        <source>F2:</source>
        <translation>F2:</translation>
    </message>
</context>
<context>
    <name>funWidget</name>
    <message>
        <location filename="../../src/funedit.cpp" line="32"/>
        <location filename="../../src/funedit.cpp" line="190"/>
        <source>Function editor</source>
        <translation>运行编辑</translation>
    </message>
</context>
<context>
    <name>legUI</name>
    <message>
        <location filename="../../src/ui/legedit.ui" line="13"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="31"/>
        <source>Colour</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="71"/>
        <source>Red</source>
        <translation>红色</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="90"/>
        <source>Green</source>
        <translation>绿色</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="109"/>
        <source>Blue</source>
        <translation>蓝色</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="133"/>
        <source>Lock RGB-sliders</source>
        <translation>锁住 RGB-sliders</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="136"/>
        <source>Lock</source>
        <translation>锁住</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="151"/>
        <source>Lock mouse</source>
        <translation>锁住鼠标</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="158"/>
        <source>Synchronize colours</source>
        <translation>颜色同步</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="161"/>
        <source>Sync</source>
        <translation>Sync</translation>
    </message>
</context>
<context>
    <name>legWidget</name>
    <message>
        <location filename="../../src/legedit.cpp" line="37"/>
        <location filename="../../src/legedit.cpp" line="342"/>
        <source>Legends</source>
        <translation>解说</translation>
    </message>
    <message>
        <location filename="../../src/legedit.cpp" line="86"/>
        <source>Item</source>
        <translation>项目</translation>
    </message>
    <message>
        <location filename="../../src/legedit.cpp" line="86"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
</context>
<context>
    <name>ligUI</name>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="19"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="78"/>
        <source>Enable/disable spotlight</source>
        <translation>运行/停止 摄像机</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="81"/>
        <source>Spotlight</source>
        <translation>聚光灯</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="271"/>
        <source>Spotlight attributes</source>
        <translation>聚光灯属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="274"/>
        <source>Attr.</source>
        <translation>Attr.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="312"/>
        <source>Spotlight angle</source>
        <translation>聚光灯角度</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="334"/>
        <source>Spotlight intensity</source>
        <translation>聚光灯强度</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="129"/>
        <source>Spotlight direction</source>
        <translation>聚光灯方向</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="132"/>
        <source>Dir.</source>
        <translation>Dir.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="170"/>
        <source>Spotlight X-direction</source>
        <translation> X轴方向聚光灯</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="195"/>
        <source>Spotlight Y-direction</source>
        <translation>Y轴方向聚光灯</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="217"/>
        <source>Spotlight Z-direction</source>
        <translation>Z轴方向聚光灯</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="400"/>
        <source>Attenuation</source>
        <translation>减弱</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="403"/>
        <source>Att.</source>
        <translation>Att.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="430"/>
        <source>Constant light attenuation</source>
        <translation>常数光减弱</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="458"/>
        <source>Linear light attenuation</source>
        <translation>线性光减弱</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="480"/>
        <source>Quadratic light attenuation</source>
        <translation>四边形式的光减弱</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="517"/>
        <source>Distance</source>
        <translation>间距</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="520"/>
        <source>Dis.</source>
        <translation>Dis.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="541"/>
        <source>Light distance from origin</source>
        <translation>起点光间距</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1268"/>
        <source>Set lights</source>
        <translation>设置灯光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1312"/>
        <source>Set light 0</source>
        <translation>设置灯光 0</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1146"/>
        <location filename="../../src/ui/ligedit.ui" line="1315"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1331"/>
        <source>Set light 1</source>
        <translation>设置灯光 1</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1159"/>
        <location filename="../../src/ui/ligedit.ui" line="1334"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1344"/>
        <source>Set light 2</source>
        <translation>设置灯光 2</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1169"/>
        <location filename="../../src/ui/ligedit.ui" line="1347"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1357"/>
        <source>Set light 3</source>
        <translation>设置灯光 3</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1179"/>
        <location filename="../../src/ui/ligedit.ui" line="1360"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1370"/>
        <source>Set light 4</source>
        <translation>设置灯光 4</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1192"/>
        <location filename="../../src/ui/ligedit.ui" line="1373"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1383"/>
        <source>Set light 5</source>
        <translation>设置灯光 5</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1205"/>
        <location filename="../../src/ui/ligedit.ui" line="1386"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1396"/>
        <source>Set light 6</source>
        <translation>设置灯光 6</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1218"/>
        <location filename="../../src/ui/ligedit.ui" line="1399"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1409"/>
        <source>Set light 7</source>
        <translation>设置灯光 7</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1231"/>
        <location filename="../../src/ui/ligedit.ui" line="1412"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1102"/>
        <source>  Edit single light</source>
        <translation>编辑 单一光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1143"/>
        <source>Edit light 0</source>
        <translation>编辑 光 0</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1156"/>
        <source>Edit light 1</source>
        <translation>编辑 光 1</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1166"/>
        <source>Edit light 2</source>
        <translation>编辑 光 2</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1176"/>
        <source>Edit light 3</source>
        <translation>编辑 光 3</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1189"/>
        <source>Edit light 4</source>
        <translation>编辑 光 4</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1202"/>
        <source>Edit light 5</source>
        <translation>编辑 光 5</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1215"/>
        <source>Edit light 6</source>
        <translation>编辑 光 6</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1228"/>
        <source>Edit light 7</source>
        <translation>编辑 光 7</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="592"/>
        <source>Light intensity</source>
        <translation>光强度</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="619"/>
        <source>Ambient light</source>
        <translation>环境光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="622"/>
        <source>Amb.</source>
        <translation>Amb.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="677"/>
        <source>Ambient red light</source>
        <translation>环境红光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="696"/>
        <source>Ambient green light</source>
        <translation>环境绿光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="715"/>
        <source>Ambient blue light</source>
        <translation>环境蓝光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="737"/>
        <source>Ambient alpha channel</source>
        <translation>alpha 通道环境</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="755"/>
        <location filename="../../src/ui/ligedit.ui" line="915"/>
        <location filename="../../src/ui/ligedit.ui" line="1075"/>
        <source>Lock RGB-sliders</source>
        <translation>锁住 RGB-sliders</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="758"/>
        <location filename="../../src/ui/ligedit.ui" line="918"/>
        <location filename="../../src/ui/ligedit.ui" line="1078"/>
        <source>Lock</source>
        <translation>锁住</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="779"/>
        <source>Diffuse light</source>
        <translation>散光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="782"/>
        <source>Diff.</source>
        <translation>Diff.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="837"/>
        <source>Diffuse red light</source>
        <translation>红色散光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="856"/>
        <source>Diffuse green light</source>
        <translation>绿色散光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="875"/>
        <source>Diffuse blue light</source>
        <translation>蓝色散光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="897"/>
        <source>Diffuse alpha channel</source>
        <translation>alpha通道扩散</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="939"/>
        <source>Specular light</source>
        <translation>反射光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="942"/>
        <source>Spec.</source>
        <translation>Spéc.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="997"/>
        <source>Specular red light</source>
        <translation>红色反射光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1016"/>
        <source>Specular green light</source>
        <translation>绿色反射光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1035"/>
        <source>Specular blue light</source>
        <translation>蓝色反射光</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1057"/>
        <source>Specular alpha channel</source>
        <translation>alpha通道反射</translation>
    </message>
</context>
<context>
    <name>ligWidget</name>
    <message>
        <location filename="../../src/ligedit.cpp" line="31"/>
        <location filename="../../src/ligedit.cpp" line="315"/>
        <source>Lights</source>
        <translation>灯光</translation>
    </message>
</context>
<context>
    <name>mainCtrl</name>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="13"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="252"/>
        <source>Scale</source>
        <translation>比例</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="285"/>
        <location filename="../../src/ui/mainwindow.ui" line="384"/>
        <location filename="../../src/ui/mainwindow.ui" line="410"/>
        <location filename="../../src/ui/mainwindow.ui" line="423"/>
        <source>Scale up</source>
        <translation>放大</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="288"/>
        <location filename="../../src/ui/mainwindow.ui" line="387"/>
        <location filename="../../src/ui/mainwindow.ui" line="400"/>
        <location filename="../../src/ui/mainwindow.ui" line="413"/>
        <location filename="../../src/ui/mainwindow.ui" line="426"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="298"/>
        <location filename="../../src/ui/mainwindow.ui" line="332"/>
        <location filename="../../src/ui/mainwindow.ui" line="345"/>
        <location filename="../../src/ui/mainwindow.ui" line="358"/>
        <source>Scale down</source>
        <translation>缩小</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="301"/>
        <location filename="../../src/ui/mainwindow.ui" line="335"/>
        <location filename="../../src/ui/mainwindow.ui" line="348"/>
        <location filename="../../src/ui/mainwindow.ui" line="361"/>
        <location filename="../../src/ui/mainwindow.ui" line="374"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="311"/>
        <source> X</source>
        <translation> X</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="318"/>
        <source> Y</source>
        <translation> Y</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="325"/>
        <source> Z</source>
        <translation> Z</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="371"/>
        <source>Decrease gridlines</source>
        <translation>逐减方格</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="397"/>
        <source>Increase gridlines</source>
        <translation>逐增方格</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="436"/>
        <source> A</source>
        <translation> A</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="443"/>
        <source>Gridlines</source>
        <translation>方格</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="446"/>
        <source> G</source>
        <translation> G</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="31"/>
        <source>Enabe/disable views</source>
        <translation>运行/停止 视图</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="34"/>
        <source>Show</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="64"/>
        <source>Show function 0</source>
        <translation>显示 函数 0</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="67"/>
        <source>F0</source>
        <translation>F0</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="83"/>
        <source>Show function 1</source>
        <translation>显示 函数1 </translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="86"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="99"/>
        <source>Show function 2</source>
        <translation> 显示 函数2</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="102"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="115"/>
        <source>Show parametric system</source>
        <translation>显示参数系统</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="118"/>
        <source>Par.</source>
        <translation>Par.</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="662"/>
        <source>Toggle cross on/off</source>
        <translation>运行/停止 十字坐标</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="665"/>
        <source>Cross</source>
        <translation>十字坐标</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="643"/>
        <source>Toggle axes on/off</source>
        <translation>显示/隐藏 坐标轴</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="646"/>
        <source>Axes</source>
        <translation>轴</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="140"/>
        <source>Set current mode</source>
        <translation>设置目前模式</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="143"/>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="233"/>
        <source>Set point-mode</source>
        <translation>设置点模式</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="236"/>
        <source>Point</source>
        <translation>点</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="201"/>
        <source>Quad</source>
        <translation>四边形</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="176"/>
        <source>Set wire-mode</source>
        <translation>设置线模式</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="179"/>
        <source>Wire</source>
        <translation>线</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="709"/>
        <source>Cross coordinates and regarding function values</source>
        <translation> 对等坐标并保持函数值</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="528"/>
        <source>Rotate around X-axis</source>
        <translation>绕X轴旋转</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="556"/>
        <source>Rotate around Y-axis</source>
        <translation>绕Y轴旋转</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="584"/>
        <source>Rotate around Z-axis</source>
        <translation>绕Z轴旋转</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="1088"/>
        <source>Switch between functions, isosurfaces and parametric system</source>
        <translation>在函数，等值面和参数系统间切换</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="198"/>
        <source>Quadratic tessellation</source>
        <translation>四边形网格</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="214"/>
        <source>Triangle tessellation</source>
        <translation>三角网格</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="217"/>
        <source>Triangle</source>
        <translation>三角网格</translation>
    </message>
</context>
<context>
    <name>matUI</name>
    <message>
        <location filename="../../src/ui/matedit.ui" line="13"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="51"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="64"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="74"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="84"/>
        <source>Par.</source>
        <translation>Par.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="118"/>
        <source>Sync</source>
        <translation>Sync</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="159"/>
        <source>Amb.</source>
        <translation>Amb.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="265"/>
        <location filename="../../src/ui/matedit.ui" line="392"/>
        <location filename="../../src/ui/matedit.ui" line="529"/>
        <location filename="../../src/ui/matedit.ui" line="656"/>
        <source>Lock RGB-sliders</source>
        <translation>锁住 RGB-sliders</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="268"/>
        <location filename="../../src/ui/matedit.ui" line="395"/>
        <location filename="../../src/ui/matedit.ui" line="532"/>
        <location filename="../../src/ui/matedit.ui" line="659"/>
        <source>Lock</source>
        <translation>锁住</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="286"/>
        <source>Diff.</source>
        <translation>Diff.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="423"/>
        <source>Spec.</source>
        <translation>Spec.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="550"/>
        <source>Emi.</source>
        <translation>Emi.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="688"/>
        <source>Specular shininess</source>
        <translation>反射亮度</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="691"/>
        <source>Spec. shininess</source>
        <translation>Spec. 亮度</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="25"/>
        <source>Edit surface properties</source>
        <translation>编辑表面属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="28"/>
        <source>Edit surface</source>
        <translation>编辑表面</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="81"/>
        <source>Edit surface parametric-system</source>
        <translation>编辑表面参数系统</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="156"/>
        <source>Ambient surface properties</source>
        <translation>环境表面属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="283"/>
        <source>Diffuse surface properties</source>
        <translation>扩散表面属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="420"/>
        <source>Specular surface properties</source>
        <translation>反射表面属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="547"/>
        <source>Emission surface properties</source>
        <translation>辐射表面属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="709"/>
        <source>Specular shininess low&lt;-&gt;high</source>
        <translation>反射亮度 弱&lt;-&gt;强</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="187"/>
        <location filename="../../src/ui/matedit.ui" line="314"/>
        <location filename="../../src/ui/matedit.ui" line="451"/>
        <location filename="../../src/ui/matedit.ui" line="578"/>
        <source>Red surface</source>
        <translation>红色表面</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="206"/>
        <location filename="../../src/ui/matedit.ui" line="333"/>
        <location filename="../../src/ui/matedit.ui" line="470"/>
        <location filename="../../src/ui/matedit.ui" line="597"/>
        <source>Green surface</source>
        <translation>绿色表面</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="225"/>
        <location filename="../../src/ui/matedit.ui" line="352"/>
        <location filename="../../src/ui/matedit.ui" line="489"/>
        <location filename="../../src/ui/matedit.ui" line="616"/>
        <source>Blue surface</source>
        <translation>蓝色表面</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="247"/>
        <source>Ambient alpha channel</source>
        <translation>alpha通道环境</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="374"/>
        <source>Diffuse alpha channel</source>
        <translation>alpha通道扩散</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="511"/>
        <source>Specular alpha channel</source>
        <translation>alpha通道反射</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="638"/>
        <source>Emission alpha channel</source>
        <translation>alpha 通道辐射</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="115"/>
        <source>Synchronize back side with front</source>
        <translation>背面和正面同步</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="136"/>
        <source>Change between front and back</source>
        <translation>切换正面和背面</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="139"/>
        <source>Back</source>
        <translation>背面</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="48"/>
        <source>Edit surface F0/I0</source>
        <translation>编辑表面 F0/I0</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="61"/>
        <source>Edit surface F1/I1</source>
        <translation>编辑表面 F1/I1</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="71"/>
        <source>Edit surface F2/I2</source>
        <translation>编辑表面 F2I/I2</translation>
    </message>
</context>
<context>
    <name>matWidget</name>
    <message>
        <location filename="../../src/matedit.cpp" line="31"/>
        <location filename="../../src/matedit.cpp" line="136"/>
        <source>Surfaces</source>
        <translation>表面</translation>
    </message>
</context>
<context>
    <name>morUI</name>
    <message>
        <location filename="../../src/ui/moredit.ui" line="13"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="19"/>
        <source>Limits</source>
        <translation>限制</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="25"/>
        <source>Lower limit</source>
        <translation>低限制</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="44"/>
        <source> - </source>
        <translation> - </translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="51"/>
        <source>Upper limit</source>
        <translation>高限制</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="127"/>
        <source>Steps</source>
        <translation>阶段</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="124"/>
        <source>Steps in between lower/upper limits</source>
        <translation>低/高限制间的阶段</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="177"/>
        <source>Frames/second</source>
        <translation>图像/秒</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="180"/>
        <source>Frames</source>
        <translation>图像</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="233"/>
        <source>Morph</source>
        <translation>曲解</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="230"/>
        <source>Start/stop morphing</source>
        <translation>开始/停止 形态显示</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="106"/>
        <source>CPU/GPU utilization in %</source>
        <translation>CPU/GPU 用 %</translation>
    </message>
</context>
<context>
    <name>morWidget</name>
    <message>
        <location filename="../../src/moredit.cpp" line="34"/>
        <location filename="../../src/moredit.cpp" line="167"/>
        <source>Morphing</source>
        <translation>曲解</translation>
    </message>
    <message>
        <location filename="../../src/moredit.cpp" line="152"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../../src/moredit.cpp" line="154"/>
        <source>Morph</source>
        <translation>曲解</translation>
    </message>
</context>
<context>
    <name>picUI</name>
    <message>
        <location filename="../../src/ui/picedit.ui" line="16"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="28"/>
        <source>Properties</source>
        <translation>属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="292"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="302"/>
        <source>JPG</source>
        <translation>JPG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="112"/>
        <source>Dimensions</source>
        <translation>维</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="205"/>
        <location filename="../../src/ui/picedit.ui" line="224"/>
        <source>X-Dimension</source>
        <translation> X 维</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="227"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="160"/>
        <location filename="../../src/ui/picedit.ui" line="179"/>
        <source>Y-Dimension</source>
        <translation>Y 维</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="182"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="48"/>
        <location filename="../../src/ui/picedit.ui" line="61"/>
        <source>Picture quality: 0=low 100=high</source>
        <translation>图像质量 : 0=低 100=高</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="239"/>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="259"/>
        <source>Portable Document Format</source>
        <translation> PDF格式</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="262"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="269"/>
        <source>PostScript</source>
        <translation>PostScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="272"/>
        <source>PS</source>
        <translation>PS</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="289"/>
        <source>Portable Network Graphics</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="299"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="100"/>
        <source>Dpi</source>
        <translation>Dpi</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="124"/>
        <source>Lock/unlock XY-values</source>
        <translation>锁住/开启  XY值</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="64"/>
        <source>Quality</source>
        <translation>质量</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="81"/>
        <location filename="../../src/ui/picedit.ui" line="97"/>
        <source>Dpi: 75..4800</source>
        <translation>Dpi: 75..4800</translation>
    </message>
</context>
<context>
    <name>picWidget</name>
    <message>
        <location filename="../../src/picedit.cpp" line="27"/>
        <location filename="../../src/picedit.cpp" line="133"/>
        <source>Picture</source>
        <translation>图像</translation>
    </message>
</context>
<context>
    <name>speUI</name>
    <message>
        <location filename="../../src/ui/speedit.ui" line="13"/>
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="19"/>
        <source>Textures</source>
        <translation>图案</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="107"/>
        <location filename="../../src/ui/speedit.ui" line="218"/>
        <location filename="../../src/ui/speedit.ui" line="329"/>
        <location filename="../../src/ui/speedit.ui" line="440"/>
        <source>Flip texture vertical</source>
        <translation>垂直旋转图案</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="129"/>
        <location filename="../../src/ui/speedit.ui" line="240"/>
        <location filename="../../src/ui/speedit.ui" line="351"/>
        <location filename="../../src/ui/speedit.ui" line="462"/>
        <source>On</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="51"/>
        <location filename="../../src/ui/speedit.ui" line="162"/>
        <location filename="../../src/ui/speedit.ui" line="273"/>
        <location filename="../../src/ui/speedit.ui" line="384"/>
        <source>Load new texture</source>
        <translation>下载新的图案</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="361"/>
        <source>Par.</source>
        <translation>Par.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="576"/>
        <source>Fog</source>
        <translation>烟雾</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="659"/>
        <source>Red fog light</source>
        <translation> 红色雾光</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="684"/>
        <source>Green fog light</source>
        <translation>绿色雾光</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="709"/>
        <source>Blue fog light</source>
        <translation>蓝色雾光</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="737"/>
        <source>Fog light alpha channel</source>
        <translation>alpha通道烟雾</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="755"/>
        <source>Lock RGB-sliders</source>
        <translation>锁住 RGB-sliders</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="758"/>
        <source>Lock</source>
        <translation>锁住</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="798"/>
        <source>Fog mode</source>
        <translation>烟雾模式</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="801"/>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="825"/>
        <source>Exp</source>
        <translation>Exp</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="835"/>
        <source>Exp2</source>
        <translation>Exp2</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="842"/>
        <source>Linear</source>
        <translation>线性的</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="845"/>
        <source>Lin.</source>
        <translation>Lin.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="855"/>
        <source>Fog settings</source>
        <translation>设置烟雾</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="858"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="882"/>
        <location filename="../../src/ui/speedit.ui" line="930"/>
        <source>Intensity</source>
        <translation>强度</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="898"/>
        <location filename="../../src/ui/speedit.ui" line="950"/>
        <source>Fog end value</source>
        <translation>烟雾结束值</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="914"/>
        <location filename="../../src/ui/speedit.ui" line="940"/>
        <source>Fog starting value</source>
        <translation>烟雾开始值</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="933"/>
        <source>Int.</source>
        <translation>Int.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="943"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="953"/>
        <source>End</source>
        <translation>结束</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="822"/>
        <source>Exponential</source>
        <translation>指数函数</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="832"/>
        <source>Quadratic exponential</source>
        <translation>两次指数函数</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="368"/>
        <source>Texture parameter system</source>
        <translation>参数图案</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="771"/>
        <source>Sync</source>
        <translation>Sync</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="493"/>
        <source>Span</source>
        <translation>范围</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="532"/>
        <source>Increase/decrease texture span</source>
        <translation>增大/减小图案范围</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="612"/>
        <source>Fog colour properties</source>
        <translation>烟雾颜色属性</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="615"/>
        <source>Colour</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="768"/>
        <source>Synchronize fog with background colour</source>
        <translation>烟雾和背景颜色同步</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="79"/>
        <location filename="../../src/ui/speedit.ui" line="190"/>
        <location filename="../../src/ui/speedit.ui" line="301"/>
        <location filename="../../src/ui/speedit.ui" line="412"/>
        <source>Remove texture from file</source>
        <translation>从文件中取消图案</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="984"/>
        <source>Motion blur</source>
        <translation>动态模糊</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1011"/>
        <location filename="../../src/ui/speedit.ui" line="1094"/>
        <source>Translation offset for each iteration</source>
        <translation>每次迭代的转换偏移</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1030"/>
        <location filename="../../src/ui/speedit.ui" line="1084"/>
        <source>Iterations calculated per frame</source>
        <translation>每个图像迭代计算</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1052"/>
        <location filename="../../src/ui/speedit.ui" line="1074"/>
        <source>Magnitude of blur effect</source>
        <translation>模糊光度</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1077"/>
        <source>Magnitude</source>
        <translation>光度</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1087"/>
        <source>Iterations</source>
        <translation>迭代</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1097"/>
        <source>Offset</source>
        <translation>偏移</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="28"/>
        <source>F0/I0</source>
        <translation>F0/I0</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="35"/>
        <source>Texture F0/I0</source>
        <translation>图案 F0/I0</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="139"/>
        <source>F1/I1</source>
        <translation>F1/I1</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="146"/>
        <source>Texture F1/I1</source>
        <translation>图案 F1/I1</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="250"/>
        <source>F2/I2</source>
        <translation>F2/I2</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="257"/>
        <source>Texture F2/I2</source>
        <translation>图案 F2/I2</translation>
    </message>
</context>
<context>
    <name>speWidget</name>
    <message>
        <location filename="../../src/speedit.cpp" line="126"/>
        <location filename="../../src/speedit.cpp" line="158"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="126"/>
        <source>file</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="159"/>
        <source>Error loading file:</source>
        <translation>下载文件错误 :</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="38"/>
        <location filename="../../src/speedit.cpp" line="171"/>
        <location filename="../../src/speedit.cpp" line="182"/>
        <location filename="../../src/speedit.cpp" line="195"/>
        <location filename="../../src/speedit.cpp" line="206"/>
        <location filename="../../src/speedit.cpp" line="613"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="172"/>
        <source>Texture width too large</source>
        <translation> 图案宽度太大</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="183"/>
        <source>Texture height too large</source>
        <translation>图案高度太长</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="196"/>
        <source>Texture width not a power of 2</source>
        <translation>图案宽度不是一个平方</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="207"/>
        <source>Texture height not a power of 2</source>
        <translation>图案高度不是 一个平方</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="223"/>
        <location filename="../../src/speedit.cpp" line="243"/>
        <location filename="../../src/speedit.cpp" line="262"/>
        <location filename="../../src/speedit.cpp" line="286"/>
        <location filename="../../src/speedit.cpp" line="294"/>
        <source>System information</source>
        <translation>信息系统</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="224"/>
        <location filename="../../src/speedit.cpp" line="244"/>
        <location filename="../../src/speedit.cpp" line="263"/>
        <location filename="../../src/speedit.cpp" line="287"/>
        <location filename="../../src/speedit.cpp" line="295"/>
        <source>Out of memory</source>
        <translation>没有内存</translation>
    </message>
</context>
<context>
    <name>usrWidget</name>
    <message>
        <location filename="../../src/usredit.cpp" line="34"/>
        <location filename="../../src/usredit.cpp" line="220"/>
        <source>User defined items</source>
        <translation>自定义项目</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="93"/>
        <source>Alert</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="128"/>
        <location filename="../../src/usredit.cpp" line="221"/>
        <source>Item</source>
        <translation>项目</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="149"/>
        <location filename="../../src/usredit.cpp" line="222"/>
        <source>Delete row</source>
        <translation>删除行</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="152"/>
        <location filename="../../src/usredit.cpp" line="223"/>
        <source>Insert row</source>
        <translation>插入行</translation>
    </message>
</context>
</TS>
