<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<context>
    <name>MaiWindow</name>
    <message>
        <location filename="../../src/mainwindow.cpp" line="56"/>
        <location filename="../../src/mainwindow.cpp" line="177"/>
        <location filename="../../src/mainwindow.cpp" line="289"/>
        <location filename="../../src/mainwindow.cpp" line="972"/>
        <location filename="../../src/mainwindow.cpp" line="1877"/>
        <source>Solver report</source>
        <translation>Lösungseditor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="887"/>
        <location filename="../../src/mainwindow.cpp" line="1737"/>
        <source>Stop animation</source>
        <translation>Beende Animation</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="223"/>
        <location filename="../../src/mainwindow.cpp" line="1471"/>
        <location filename="../../src/mainwindow.cpp" line="1480"/>
        <location filename="../../src/mainwindow.cpp" line="1490"/>
        <location filename="../../src/mainwindow.cpp" line="1501"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="223"/>
        <location filename="../../src/mainwindow.cpp" line="255"/>
        <source>file</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1472"/>
        <location filename="../../src/mainwindow.cpp" line="1481"/>
        <location filename="../../src/mainwindow.cpp" line="1491"/>
        <location filename="../../src/mainwindow.cpp" line="1502"/>
        <source>Error loading file:</source>
        <translation>Fehler beim Laden:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="255"/>
        <location filename="../../src/mainwindow.cpp" line="275"/>
        <location filename="../../src/mainwindow.cpp" line="316"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="276"/>
        <location filename="../../src/mainwindow.cpp" line="317"/>
        <source>Error saving file:</source>
        <translation>Fehler beim Speichern:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="290"/>
        <source>Currently there is nothing to save!</source>
        <translation>Es gibt derzeit noch nichts zu speichern!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="298"/>
        <location filename="../../src/mainwindow.cpp" line="942"/>
        <location filename="../../src/mainwindow.cpp" line="1867"/>
        <source>Save solutions</source>
        <translation>Speichere Lösungen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="357"/>
        <source>Cannot find any helpfile</source>
        <translation>Kann keine Hilfedatei finden</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="378"/>
        <location filename="../../src/mainwindow.cpp" line="1049"/>
        <location filename="../../src/mainwindow.cpp" line="1174"/>
        <location filename="../../src/mainwindow.cpp" line="1858"/>
        <location filename="../../src/mainwindow.cpp" line="1906"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="413"/>
        <source>System information</source>
        <translation>Systeminformation</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="425"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="892"/>
        <location filename="../../src/mainwindow.cpp" line="1732"/>
        <source>Start animation</source>
        <translation>Animation starten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="930"/>
        <location filename="../../src/mainwindow.cpp" line="1861"/>
        <source>&amp;New</source>
        <translation>&amp;Neu</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="931"/>
        <location filename="../../src/mainwindow.cpp" line="1862"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="934"/>
        <location filename="../../src/mainwindow.cpp" line="1863"/>
        <source>&amp;Open ...</source>
        <translation>&amp;Öffnen ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="935"/>
        <location filename="../../src/mainwindow.cpp" line="1864"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+Ö</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="938"/>
        <location filename="../../src/mainwindow.cpp" line="1865"/>
        <source>&amp;Save as</source>
        <translation>&amp;Speichern unter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="939"/>
        <location filename="../../src/mainwindow.cpp" line="1866"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="945"/>
        <location filename="../../src/mainwindow.cpp" line="1868"/>
        <source>Save picture</source>
        <translation>Speichere Bild</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="948"/>
        <location filename="../../src/mainwindow.cpp" line="1869"/>
        <source>Print picture</source>
        <translation>Drucke Bild</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="951"/>
        <location filename="../../src/mainwindow.cpp" line="1870"/>
        <source>&amp;Exit</source>
        <translation>&amp;Beenden</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="952"/>
        <location filename="../../src/mainwindow.cpp" line="1871"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="957"/>
        <location filename="../../src/mainwindow.cpp" line="1874"/>
        <source>Lights</source>
        <translation>Lichtquellen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="960"/>
        <location filename="../../src/mainwindow.cpp" line="1875"/>
        <source>Surfaces</source>
        <translation>Oberflächen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="963"/>
        <location filename="../../src/mainwindow.cpp" line="1876"/>
        <source>Global</source>
        <translation>Global</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="980"/>
        <location filename="../../src/mainwindow.cpp" line="1883"/>
        <source>Animation</source>
        <translation>Animation</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="966"/>
        <location filename="../../src/mainwindow.cpp" line="1878"/>
        <source>User defined</source>
        <translation>Benutzerdefiniert</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="975"/>
        <location filename="../../src/mainwindow.cpp" line="1660"/>
        <location filename="../../src/mainwindow.cpp" line="1880"/>
        <source>Functions</source>
        <translation>Funktionen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="991"/>
        <location filename="../../src/mainwindow.cpp" line="1888"/>
        <source>Picture</source>
        <translation>Bild</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="994"/>
        <location filename="../../src/mainwindow.cpp" line="1889"/>
        <source>micro</source>
        <translation>mikro</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1000"/>
        <location filename="../../src/mainwindow.cpp" line="1890"/>
        <source>fine</source>
        <translation>fein</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1006"/>
        <location filename="../../src/mainwindow.cpp" line="1891"/>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1012"/>
        <location filename="../../src/mainwindow.cpp" line="1892"/>
        <source>coarse</source>
        <translation>grob</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1018"/>
        <location filename="../../src/mainwindow.cpp" line="1893"/>
        <source>View only</source>
        <translation>Nur Ansicht</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1021"/>
        <location filename="../../src/mainwindow.cpp" line="1894"/>
        <source>Scaling only</source>
        <translation>Nur Skalierung</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1024"/>
        <location filename="../../src/mainwindow.cpp" line="1895"/>
        <source>Lights only</source>
        <translation>Nur Lichtquellen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1027"/>
        <location filename="../../src/mainwindow.cpp" line="1896"/>
        <source>All together</source>
        <translation>Alle zusammen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1030"/>
        <location filename="../../src/mainwindow.cpp" line="1897"/>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1137"/>
        <location filename="../../src/mainwindow.cpp" line="1853"/>
        <source>Special</source>
        <translation>Spezial</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1033"/>
        <location filename="../../src/mainwindow.cpp" line="1898"/>
        <source>Directories</source>
        <translation>Verzeichnisse</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1038"/>
        <location filename="../../src/mainwindow.cpp" line="1901"/>
        <source>Show open editors</source>
        <translation>Zeige offene Editoren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1041"/>
        <location filename="../../src/mainwindow.cpp" line="1902"/>
        <source>Hide open editors</source>
        <translation>Minimiere offene Editoren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1044"/>
        <location filename="../../src/mainwindow.cpp" line="1903"/>
        <source>Open all editors</source>
        <translation>Öffne alle Editoren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1050"/>
        <location filename="../../src/mainwindow.cpp" line="1908"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1053"/>
        <location filename="../../src/mainwindow.cpp" line="1909"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1059"/>
        <location filename="../../src/mainwindow.cpp" line="1806"/>
        <location filename="../../src/mainwindow.cpp" line="1910"/>
        <source>Benchmark</source>
        <translation>Benchmark</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1062"/>
        <location filename="../../src/mainwindow.cpp" line="1911"/>
        <source>About Zhu3D</source>
        <translation>Über Zhu3D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1065"/>
        <location filename="../../src/mainwindow.cpp" line="1912"/>
        <source>About Qt</source>
        <translation>Über Qt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1070"/>
        <source>Zoom in</source>
        <translation>Einzoomen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1071"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1074"/>
        <source>Zoom out</source>
        <translation>Auszoomen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1075"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1078"/>
        <source>Move left</source>
        <translation>Nach links</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1079"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1082"/>
        <source>Move right</source>
        <translation>Nach rechts</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1083"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1086"/>
        <source>Move up</source>
        <translation>Nach oben</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1087"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1090"/>
        <source>Move down</source>
        <translation>Nach unten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1091"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1094"/>
        <location filename="../../src/mainwindow.cpp" line="1657"/>
        <source>Solve system</source>
        <translation>Löse Gleichungssystem</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1097"/>
        <source>Start/stop animation</source>
        <translation>Animation Start/Stopp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1111"/>
        <location filename="../../src/mainwindow.cpp" line="1194"/>
        <location filename="../../src/mainwindow.cpp" line="1851"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1124"/>
        <location filename="../../src/mainwindow.cpp" line="1852"/>
        <source>Editors</source>
        <translation>Editoren</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1144"/>
        <location filename="../../src/mainwindow.cpp" line="1854"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1146"/>
        <location filename="../../src/mainwindow.cpp" line="1855"/>
        <source>Scaling</source>
        <translation>Skalierung</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1152"/>
        <location filename="../../src/mainwindow.cpp" line="1856"/>
        <source>Reset</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1167"/>
        <location filename="../../src/mainwindow.cpp" line="1857"/>
        <source>Windows</source>
        <translation>Fenster</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1199"/>
        <source>Zoom</source>
        <translation>Zoomen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1204"/>
        <source>Move</source>
        <translation>Bewegen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1211"/>
        <source>Extras</source>
        <translation>Extras</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1327"/>
        <source>Creation date:</source>
        <translation>Bericht von:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1377"/>
        <location filename="../../src/mainwindow.cpp" line="1379"/>
        <location filename="../../src/mainwindow.cpp" line="1384"/>
        <location filename="../../src/mainwindow.cpp" line="1386"/>
        <location filename="../../src/mainwindow.cpp" line="1393"/>
        <location filename="../../src/mainwindow.cpp" line="1395"/>
        <location filename="../../src/mainwindow.cpp" line="1400"/>
        <location filename="../../src/mainwindow.cpp" line="1402"/>
        <source>Cross</source>
        <translation>Kreuz</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1482"/>
        <source>Zhu3D file is too old or not valid!</source>
        <translation>Zhu3D-Datei ist zu alt oder ungültig!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1536"/>
        <source>untitled</source>
        <translation>unbenannt</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1633"/>
        <source>X-values</source>
        <translation>X-Werte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1634"/>
        <source>Y-values</source>
        <translation>Y-Werte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1635"/>
        <source>Z-values</source>
        <translation>Z-Werte</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1636"/>
        <source> A</source>
        <translation> A</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1637"/>
        <source>All XYZ-values together</source>
        <translation>Alle XYZ-Werte zusammen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1652"/>
        <source>Scale functions</source>
        <translation>Skaliere Funktionen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1659"/>
        <source>Function editor</source>
        <translation>Funktionen-Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1662"/>
        <source>Edit: Functions</source>
        <translation>Bearbeite: Funktionen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1662"/>
        <location filename="../../src/mainwindow.cpp" line="1692"/>
        <location filename="../../src/mainwindow.cpp" line="1720"/>
        <source>Grid:</source>
        <translation>Raster:</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1682"/>
        <source>Scale iso functions</source>
        <translation>Skaliere Iso-Funktionen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1687"/>
        <location filename="../../src/mainwindow.cpp" line="1715"/>
        <source>For solving switch to function-mode</source>
        <translation>Zum Lösen in den Funktionsmodus wechseln</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1689"/>
        <source>Iso editor</source>
        <translation>Iso-Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1690"/>
        <source>Iso functions</source>
        <translation>Iso-Funktionen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1692"/>
        <source>Edit: Isosurfaces</source>
        <translation>Bearbeite: Isoflächen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1710"/>
        <source>Scale parametric system</source>
        <translation>Skaliere Parametersystem</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1717"/>
        <source>Parameter editor</source>
        <translation>Parameter-Editor</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1718"/>
        <source>Parameters</source>
        <translation>Parameter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1720"/>
        <source>Edit: Parameter</source>
        <translation>Bearbeite: Parameter</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1777"/>
        <source>Benchmarking now ...</source>
        <translation>Benchmark läuft ...</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1056"/>
        <location filename="../../src/mainwindow.cpp" line="1907"/>
        <source>Demo</source>
        <translation>Demo</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="983"/>
        <location filename="../../src/mainwindow.cpp" line="1884"/>
        <source>Morphing</source>
        <translation>Morphing</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="909"/>
        <location filename="../../src/mainwindow.cpp" line="1750"/>
        <source>Stop morphing</source>
        <translation>Beende Morphing</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="914"/>
        <location filename="../../src/mainwindow.cpp" line="1745"/>
        <source>Start morphing</source>
        <translation>Morphing starten</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="986"/>
        <location filename="../../src/mainwindow.cpp" line="1885"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1100"/>
        <source>Start/stop morphing</source>
        <translation>Morphing Start/Stopp</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="969"/>
        <location filename="../../src/mainwindow.cpp" line="1879"/>
        <source>Legends</source>
        <translation>Beschriftung</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1492"/>
        <source>XML parser error</source>
        <translation>XML Parser-Fehler</translation>
    </message>
</context>
<context>
    <name>OGLWidget</name>
    <message>
        <location filename="../../src/glwidget.cpp" line="255"/>
        <location filename="../../src/glwidget.cpp" line="303"/>
        <location filename="../../src/glwidget.cpp" line="351"/>
        <source>Alert</source>
        <translation>Achtung</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1205"/>
        <location filename="../../src/glwidget.cpp" line="1228"/>
        <source>Material</source>
        <translation>Material</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1206"/>
        <source>Editing back-side colours, although the global setting is just 1-sided.&lt;p&gt;&lt;/p&gt;Zhu3D is &lt;b&gt;enabling&lt;/b&gt; the 2-sided mode automatically now.</source>
        <translation>Editieren einer Rückseite, obwohl die globale Einstellung nur einseitig ist.&lt;p&gt;&lt;/p&gt;Zhu3D &lt;b&gt;wechselt&lt;/b&gt; jetzt automatisch in den Zweiseiten-Modus.</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="1229"/>
        <source>Changing back-side colours, although the global setting is just 1-sided.&lt;p&gt;&lt;/p&gt;Zhu3D is &lt;b&gt;enabling&lt;/b&gt; the 2-sided mode automatically now.</source>
        <translation>Ändern der Rückseite, obwohl die globale Einstellung nur einseitig ist.&lt;p&gt;&lt;/p&gt;Zhu3D &lt;b&gt;wechselt&lt;/b&gt; jetzt automatisch in den Zweiseiten-Modus.</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="213"/>
        <source>Viewer</source>
        <translation>Betrachter</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="843"/>
        <source>Save as *.png</source>
        <translation>Als *.png speichern</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="863"/>
        <source>Save as *.jpg</source>
        <translation>Als *.jpg speichern</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="824"/>
        <location filename="../../src/glwidget.cpp" line="965"/>
        <source>Rendering</source>
        <translation>Rendere</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="824"/>
        <location filename="../../src/glwidget.cpp" line="965"/>
        <source>picture ...</source>
        <translation>Bild ...</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="883"/>
        <source>Save as *.pdf</source>
        <translation>Als *.pdf speichern</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="917"/>
        <source>Save as *.ps</source>
        <translation>Als *.ps speichern</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="248"/>
        <source>Parser message from F0/I0/X</source>
        <translation>Parser-Nachricht von F0/I0/X</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="296"/>
        <source>Parser message from F1/I1/Y</source>
        <translation>Parser-Nachricht von F1/I1/Y</translation>
    </message>
    <message>
        <location filename="../../src/glwidget.cpp" line="344"/>
        <source>Parser message from F2/I2/Z</source>
        <translation>Parser-Nachricht von F2/I2/Z</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/main.cpp" line="168"/>
        <location filename="../../src/main.cpp" line="181"/>
        <location filename="../../src/mainwindow.cpp" line="1266"/>
        <location filename="../../src/mainwindow.cpp" line="1275"/>
        <source>Program start</source>
        <translation>Programmstart</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="182"/>
        <source>Missing OpenGL! Terminating now</source>
        <translation>Kein OpenGL! Programmabbruch</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1267"/>
        <source>CPU clockcounter is not supported!</source>
        <translation>CPU-Taktzähler wird nicht unterstützt!</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1268"/>
        <source>System info cannot provide MHz-values</source>
        <translation>Systeminfo kann MHz-Werte nicht anzeigen</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1276"/>
        <source>Missing OpenGL acceleration!</source>
        <translation>Keine OpenGL-Hardwarebeschleunigung!</translation>
    </message>
    <message>
        <location filename="../../src/sysinfo.cpp" line="46"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../../src/sysinfo.cpp" line="47"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1277"/>
        <source>Framerates will be very low</source>
        <translation>Frameraten werden sehr niedrig sein</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="358"/>
        <source>ERROR 0: Syntax error</source>
        <translation>FEHLER 0: Syntax-Fehler</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="359"/>
        <source>ERROR 1: Mismatched parenthesis</source>
        <translation>FEHLER 1: Fehlerhafte Klammerung</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="360"/>
        <source>ERROR 2: Missing closing parenthesis</source>
        <translation>FEHLER 2: Keine schließende Klammer</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="361"/>
        <source>ERROR 3: Empty parentheses</source>
        <translation>FEHLER 3: Leere Klammern</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="362"/>
        <source>ERROR 4: Operator expected</source>
        <translation>FEHLER 4: Operator erwartet</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="363"/>
        <source>ERROR 5: Out of memory</source>
        <translation>FEHLER 5: Kein Speicher mehr</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="364"/>
        <source>ERROR 6: Unexpected error</source>
        <translation>FEHLER 6: Unerwarteter Fehler</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="365"/>
        <source>ERROR 7: Unknown parameter</source>
        <translation>FEHLER 7: Unbekannter Parameter</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="366"/>
        <source>ERROR 8: Illegal number of function parameters</source>
        <translation>FEHLER 8: Falsche Anzahl von Funktionsparametern</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="367"/>
        <source>ERROR 9: Premature end of string</source>
        <translation>FEHLER 9: Vorzeitiges Zeichenketten-Ende</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="368"/>
        <source>ERROR 10: Expecting parenthesis after function</source>
        <translation>FEHLER 10: Klammer nach Funktion erwartet</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="369"/>
        <source>ERROR 11: Parser initialization failed</source>
        <translation>FEHLER 11: Parser-Initialisierung fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="370"/>
        <source>ERROR 12: Missing equal sign</source>
        <translation>FEHLER 12: Kein Gleichheitszeichen</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="371"/>
        <source>ERROR 13: Adding new constant failed</source>
        <translation>FEHLER 13: Anlegen neuer Konstante fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="372"/>
        <source>ERROR 14: Adding new function failed</source>
        <translation>FEHLER 14: Anlegen neuer Funktion fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../../src/pinterface.cpp" line="373"/>
        <source>ERROR 15: Parser update failed</source>
        <translation>FEHLER 15: Parser-Update fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="146"/>
        <source>Search started at:  X=%1  Y=%2
Time needed for %3 iterations: %4 ms
The result is %5realiable.

Solution:  X=%6  Y=%7  Z=%8</source>
        <translation>Suche gestartet bei:  X=%1  Y=%2
Benötigte Zeit für %3 Iterationen: %4 ms
Das Ergebnis ist %5zuverlässig.

Lösung:  X=%6  Y=%7  Z=%8</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="156"/>
        <source>NOT </source>
        <translation>NICHT </translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="165"/>
        <source>Solver</source>
        <translation>Gleichungslöser</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="166"/>
        <source>Result is NOT reliable</source>
        <translation>Lösung ist NICHT zuverlässig</translation>
    </message>
    <message>
        <location filename="../../src/solver.cpp" line="65"/>
        <source>Alert</source>
        <translation>Achtung</translation>
    </message>
</context>
<context>
    <name>aniUI</name>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="19"/>
        <source>Rotation speed around the axes</source>
        <translation>Rotationsgeschwindigkeit um die Achsen</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="22"/>
        <source>Rotation</source>
        <translation>Rotation</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="77"/>
        <source>X-rotation offset</source>
        <translation>Versatz um X-Achse</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="99"/>
        <source>Y-rotation offset</source>
        <translation>Versatz um Y-Achse</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="118"/>
        <source>Z-rotation offset</source>
        <translation>Versatz um Z-Achse</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="142"/>
        <source>Lock XYZ-values</source>
        <translation>Sperre XYZ-Schieberegler</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="145"/>
        <source>Lock</source>
        <translation>Sperre</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="193"/>
        <source>GPU/CPU utilization in %</source>
        <translation>GPU/CPU-Auslastung in %</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="217"/>
        <source>Frames/second</source>
        <translation>Bilder/Sekunde</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="220"/>
        <source>Frames</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="273"/>
        <source>PushButton</source>
        <translation>PushButton</translation>
    </message>
    <message>
        <location filename="../../src/ui/aniedit.ui" line="270"/>
        <source>Start/stop animation</source>
        <translation>Starte/stoppe Animation</translation>
    </message>
</context>
<context>
    <name>aniWidget</name>
    <message>
        <location filename="../../src/aniedit.cpp" line="35"/>
        <location filename="../../src/aniedit.cpp" line="193"/>
        <source>Film</source>
        <translation>Film</translation>
    </message>
    <message>
        <location filename="../../src/aniedit.cpp" line="177"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../../src/aniedit.cpp" line="181"/>
        <source>Animate</source>
        <translation>Animieren</translation>
    </message>
</context>
<context>
    <name>demWidget</name>
    <message>
        <location filename="../../src/demedit.cpp" line="32"/>
        <location filename="../../src/demedit.cpp" line="159"/>
        <source>Demo</source>
        <translation>Demo</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="88"/>
        <location filename="../../src/demedit.cpp" line="170"/>
        <source>Stop slideshow</source>
        <translation>Diaschau stoppen</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="95"/>
        <location filename="../../src/demedit.cpp" line="172"/>
        <source>Start slideshow</source>
        <translation>Starte Diaschau</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="173"/>
        <source>Backward</source>
        <translation>Rückwärts</translation>
    </message>
    <message>
        <location filename="../../src/demedit.cpp" line="174"/>
        <source>Forward</source>
        <translation>Vorwärts</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Speichern</translation>
    </message>
    <message>
        <source>Error saving file:</source>
        <translation type="obsolete">Fehler beim Speichern:</translation>
    </message>
</context>
<context>
    <name>dirUI</name>
    <message>
        <location filename="../../src/ui/diredit.ui" line="13"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="25"/>
        <source>Set new default directories</source>
        <translation>Neue Default-Verzeichnisse setzen</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="45"/>
        <location filename="../../src/ui/diredit.ui" line="75"/>
        <source>Set new directory</source>
        <translation>Neues Verzeichniss setzen</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="97"/>
        <location filename="../../src/ui/diredit.ui" line="117"/>
        <source>Current textures directory</source>
        <translation>Aktuelles Textur-Verzeichniss</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="107"/>
        <location filename="../../src/ui/diredit.ui" line="127"/>
        <source>Current work directory</source>
        <translation>Aktuelles Arbeits-Verzeichniss</translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="120"/>
        <source>Textures: </source>
        <translation>Texturen: </translation>
    </message>
    <message>
        <location filename="../../src/ui/diredit.ui" line="130"/>
        <source>Work: </source>
        <translation>Arbeit: </translation>
    </message>
</context>
<context>
    <name>dirWidget</name>
    <message>
        <location filename="../../src/diredit.cpp" line="38"/>
        <location filename="../../src/diredit.cpp" line="116"/>
        <source>Directories</source>
        <translation>Verzeichnisse</translation>
    </message>
    <message>
        <location filename="../../src/diredit.cpp" line="66"/>
        <location filename="../../src/diredit.cpp" line="86"/>
        <source>Set new directory</source>
        <translation>Neues Verzeichniss setzen</translation>
    </message>
</context>
<context>
    <name>entUI</name>
    <message>
        <location filename="../../src/ui/entedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="36"/>
        <source>Ambient light</source>
        <translation>Umgebungslicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="39"/>
        <source>Amb.</source>
        <translation>Umg.</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="94"/>
        <source>Red ambient light</source>
        <translation>Rotes Umgebungslicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="113"/>
        <source>Green ambient light</source>
        <translation>Grünes Umgebungslicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="132"/>
        <source>Blue ambient light</source>
        <translation>Blaues Umgebungslicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="154"/>
        <source>Ambient alpha channel</source>
        <translation>Umgebungslicht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="172"/>
        <location filename="../../src/ui/entedit.ui" line="326"/>
        <source>Lock RGB-sliders</source>
        <translation>Sperre RGB-Schieberegler</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="175"/>
        <location filename="../../src/ui/entedit.ui" line="329"/>
        <source>Lock</source>
        <translation>Sperre</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="190"/>
        <source>Background properties</source>
        <translation>Hintergrund-Eigenschaften</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="193"/>
        <source>Backgr.</source>
        <translation>Hinter.</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="248"/>
        <source>Red background light</source>
        <translation>Rotes Hintergrundlicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="267"/>
        <source>Green background light</source>
        <translation>Grünes Hintergrundlicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="286"/>
        <source>Blue background light</source>
        <translation>Blaues Hintergrundlicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="308"/>
        <source>Background alpha channel</source>
        <translation>Hintergrundlicht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="390"/>
        <source>1-side</source>
        <translation>1-seitig</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="406"/>
        <source>2-side</source>
        <translation>2-seitig</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="443"/>
        <source>Infinite light sources</source>
        <translation>Lichtquellen im Unendlichen</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="446"/>
        <source>Inf.</source>
        <translation>Unend.</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="459"/>
        <source>Local light sources</source>
        <translation>Lokale Lichtquellen</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="462"/>
        <source>Local</source>
        <translation>Lokal</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="387"/>
        <source>Surfaces are one-sided</source>
        <translation>Oberflächen sind einseitig</translation>
    </message>
    <message>
        <location filename="../../src/ui/entedit.ui" line="403"/>
        <source>Surfaces are two-sided</source>
        <translation>Oberflächen sind zweiseitig</translation>
    </message>
</context>
<context>
    <name>entWidget</name>
    <message>
        <location filename="../../src/entedit.cpp" line="26"/>
        <location filename="../../src/entedit.cpp" line="84"/>
        <source>Global</source>
        <translation>Global</translation>
    </message>
</context>
<context>
    <name>errUI</name>
    <message>
        <location filename="../../src/ui/error.ui" line="16"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
</context>
<context>
    <name>errWidget</name>
    <message>
        <location filename="../../src/error.cpp" line="25"/>
        <source>Debug-window</source>
        <translation>Debug-Fenster</translation>
    </message>
</context>
<context>
    <name>fntWidget</name>
    <message>
        <location filename="../../src/fntedit.cpp" line="389"/>
        <source>Font</source>
        <translation>Font</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="411"/>
        <location filename="../../src/fntedit.cpp" line="412"/>
        <source>Precision for solver report in digits</source>
        <translation>Stellengenauigkeit für Lösungsbericht</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="388"/>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="407"/>
        <location filename="../../src/fntedit.cpp" line="408"/>
        <source>Application language</source>
        <translation>Anwendersprache</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="304"/>
        <location filename="../../src/fntedit.cpp" line="424"/>
        <source>English</source>
        <translation>Englisch</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="303"/>
        <location filename="../../src/fntedit.cpp" line="423"/>
        <source>German</source>
        <translation>Deutsch</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="305"/>
        <location filename="../../src/fntedit.cpp" line="425"/>
        <source>Spanish</source>
        <translation>Spanisch</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="308"/>
        <location filename="../../src/fntedit.cpp" line="428"/>
        <source>Czech</source>
        <translation>Tschechisch</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="390"/>
        <source>Font style</source>
        <translation>Fontstil</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="391"/>
        <source>Font size</source>
        <translation>Fontgröße</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="392"/>
        <source>Icon size</source>
        <translation>Icongröße</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="395"/>
        <source>Precision</source>
        <translation>Genauigkeit</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="394"/>
        <source>GUI style</source>
        <translation>GUI-Stil</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="159"/>
        <location filename="../../src/fntedit.cpp" line="402"/>
        <source>internal</source>
        <translation>intern</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="160"/>
        <location filename="../../src/fntedit.cpp" line="403"/>
        <source>external</source>
        <translation>extern</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="393"/>
        <source>Help browser</source>
        <translation>Hilfe-Browser</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="409"/>
        <location filename="../../src/fntedit.cpp" line="410"/>
        <source>Choose internal or external help browser</source>
        <translation>Internen oder externen Hilfe-Browser verwenden</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="413"/>
        <location filename="../../src/fntedit.cpp" line="414"/>
        <source>Choose triangulation method</source>
        <translation>Triangulations-Methode auswählen</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="396"/>
        <source>Isosurfaces</source>
        <translation>Isoflächen</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="306"/>
        <location filename="../../src/fntedit.cpp" line="426"/>
        <source>French</source>
        <translation>Französisch</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="307"/>
        <location filename="../../src/fntedit.cpp" line="427"/>
        <source>Chinese</source>
        <translation>Chinesisch</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="61"/>
        <location filename="../../src/fntedit.cpp" line="377"/>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="397"/>
        <source>Threads</source>
        <translation>Threads</translation>
    </message>
    <message>
        <location filename="../../src/fntedit.cpp" line="415"/>
        <location filename="../../src/fntedit.cpp" line="416"/>
        <source>Threads for isosurface-triangulation</source>
        <translation>Threads für Isoflächen-Triangulation</translation>
    </message>
</context>
<context>
    <name>funUI</name>
    <message>
        <location filename="../../src/ui/funedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="109"/>
        <source>F0:</source>
        <translation>F0:</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="142"/>
        <source>F1:</source>
        <translation>F1:</translation>
    </message>
    <message>
        <location filename="../../src/ui/funedit.ui" line="175"/>
        <source>F2:</source>
        <translation>F2:</translation>
    </message>
</context>
<context>
    <name>funWidget</name>
    <message>
        <location filename="../../src/funedit.cpp" line="32"/>
        <location filename="../../src/funedit.cpp" line="190"/>
        <source>Function editor</source>
        <translation>Funktionen-Editor</translation>
    </message>
</context>
<context>
    <name>legUI</name>
    <message>
        <location filename="../../src/ui/legedit.ui" line="13"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="31"/>
        <source>Colour</source>
        <translation>Farbe</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="71"/>
        <source>Red</source>
        <translation>Rot</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="90"/>
        <source>Green</source>
        <translation>Grün</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="109"/>
        <source>Blue</source>
        <translation>Blau</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="133"/>
        <source>Lock RGB-sliders</source>
        <translation>Sperre RGB-Schieberegler</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="136"/>
        <source>Lock</source>
        <translation>Sperre</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="151"/>
        <source>Lock mouse</source>
        <translation>Sperre Maus</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="158"/>
        <source>Synchronize colours</source>
        <translation>Synchronisiere Farben</translation>
    </message>
    <message>
        <location filename="../../src/ui/legedit.ui" line="161"/>
        <source>Sync</source>
        <translation>Sync</translation>
    </message>
</context>
<context>
    <name>legWidget</name>
    <message>
        <location filename="../../src/legedit.cpp" line="37"/>
        <location filename="../../src/legedit.cpp" line="342"/>
        <source>Legends</source>
        <translation>Beschriftung</translation>
    </message>
    <message>
        <location filename="../../src/legedit.cpp" line="86"/>
        <source>Item</source>
        <translation>Eintrag</translation>
    </message>
    <message>
        <location filename="../../src/legedit.cpp" line="86"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
</context>
<context>
    <name>ligUI</name>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="19"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="78"/>
        <source>Enable/disable spotlight</source>
        <translation>Scheinwerfer ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="81"/>
        <source>Spotlight</source>
        <translation>Scheinwerfer</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="271"/>
        <source>Spotlight attributes</source>
        <translation>Scheinwerfer Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="274"/>
        <source>Attr.</source>
        <translation>Einst.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="312"/>
        <source>Spotlight angle</source>
        <translation>Scheinwerfer Strahlwinkel</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="334"/>
        <source>Spotlight intensity</source>
        <translation>Scheinwerfer Intensität</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="129"/>
        <source>Spotlight direction</source>
        <translation>Scheinwerfer Richtung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="132"/>
        <source>Dir.</source>
        <translation>Richt.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="170"/>
        <source>Spotlight X-direction</source>
        <translation>Scheinwerfer X-Richtung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="195"/>
        <source>Spotlight Y-direction</source>
        <translation>Scheinwerfer Y-Richtung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="217"/>
        <source>Spotlight Z-direction</source>
        <translation>Scheinwerfer Z-Richtung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="400"/>
        <source>Attenuation</source>
        <translation>Abschwächung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="403"/>
        <source>Att.</source>
        <translation>Abschw.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="430"/>
        <source>Constant light attenuation</source>
        <translation>Konstante Abschächung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="458"/>
        <source>Linear light attenuation</source>
        <translation>Lineare Abschwächung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="480"/>
        <source>Quadratic light attenuation</source>
        <translation>Quadratische Abschwächung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="517"/>
        <source>Distance</source>
        <translation>Entfernung der Lichtquelle</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="520"/>
        <source>Dis.</source>
        <translation>Ent.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="541"/>
        <source>Light distance from origin</source>
        <translation>Entfernung vom Ursprung</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1268"/>
        <source>Set lights</source>
        <translation>Lichtquellen ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1312"/>
        <source>Set light 0</source>
        <translation>Lichtquelle 0 ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1146"/>
        <location filename="../../src/ui/ligedit.ui" line="1315"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1331"/>
        <source>Set light 1</source>
        <translation>Lichtquelle 1 ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1159"/>
        <location filename="../../src/ui/ligedit.ui" line="1334"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1344"/>
        <source>Set light 2</source>
        <translation>Lichtquelle 2 ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1169"/>
        <location filename="../../src/ui/ligedit.ui" line="1347"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1357"/>
        <source>Set light 3</source>
        <translation>Lichtquelle 3 ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1179"/>
        <location filename="../../src/ui/ligedit.ui" line="1360"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1370"/>
        <source>Set light 4</source>
        <translation>Lichtquelle 4 ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1192"/>
        <location filename="../../src/ui/ligedit.ui" line="1373"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1383"/>
        <source>Set light 5</source>
        <translation>Lichtquelle 5 ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1205"/>
        <location filename="../../src/ui/ligedit.ui" line="1386"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1396"/>
        <source>Set light 6</source>
        <translation>Lichtquelle 6 ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1218"/>
        <location filename="../../src/ui/ligedit.ui" line="1399"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1409"/>
        <source>Set light 7</source>
        <translation>Lichtquelle 7 ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1231"/>
        <location filename="../../src/ui/ligedit.ui" line="1412"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1102"/>
        <source>  Edit single light</source>
        <translation>  Lichtquelle bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1143"/>
        <source>Edit light 0</source>
        <translation>Lichtquelle 0 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1156"/>
        <source>Edit light 1</source>
        <translation>Lichtquelle 1 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1166"/>
        <source>Edit light 2</source>
        <translation>Lichtquelle 2 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1176"/>
        <source>Edit light 3</source>
        <translation>Lichtquelle 3 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1189"/>
        <source>Edit light 4</source>
        <translation>Lichtquelle 4 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1202"/>
        <source>Edit light 5</source>
        <translation>Lichtquelle 5 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1215"/>
        <source>Edit light 6</source>
        <translation>Lichtquelle 6 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1228"/>
        <source>Edit light 7</source>
        <translation>Lichtquelle 7 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="592"/>
        <source>Light intensity</source>
        <translation>Lichtintensität</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="619"/>
        <source>Ambient light</source>
        <translation>Umgebungslicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="622"/>
        <source>Amb.</source>
        <translation>Umg.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="677"/>
        <source>Ambient red light</source>
        <translation>Rotes Umgebungslicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="696"/>
        <source>Ambient green light</source>
        <translation>Grünes Umgebungslicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="715"/>
        <source>Ambient blue light</source>
        <translation>Blaues Umgebungslicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="737"/>
        <source>Ambient alpha channel</source>
        <translation>Umgebungslicht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="755"/>
        <location filename="../../src/ui/ligedit.ui" line="915"/>
        <location filename="../../src/ui/ligedit.ui" line="1075"/>
        <source>Lock RGB-sliders</source>
        <translation>Sperre RGB-Schieberegler</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="758"/>
        <location filename="../../src/ui/ligedit.ui" line="918"/>
        <location filename="../../src/ui/ligedit.ui" line="1078"/>
        <source>Lock</source>
        <translation>Sperre</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="779"/>
        <source>Diffuse light</source>
        <translation>Diffuses Licht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="782"/>
        <source>Diff.</source>
        <translation>Diff.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="837"/>
        <source>Diffuse red light</source>
        <translation>Rotes diffuses Licht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="856"/>
        <source>Diffuse green light</source>
        <translation>Grünes diffuses Licht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="875"/>
        <source>Diffuse blue light</source>
        <translation>Blaues diffuses Licht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="897"/>
        <source>Diffuse alpha channel</source>
        <translation>Diffuses Licht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="939"/>
        <source>Specular light</source>
        <translation>Glanzlicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="942"/>
        <source>Spec.</source>
        <translation>Glanz.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="997"/>
        <source>Specular red light</source>
        <translation>Rotes Glanzlicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1016"/>
        <source>Specular green light</source>
        <translation>Grünes Glanzlicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1035"/>
        <source>Specular blue light</source>
        <translation>Blaues Glanzlicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/ligedit.ui" line="1057"/>
        <source>Specular alpha channel</source>
        <translation>Glanzlicht Alpha-Kanal</translation>
    </message>
</context>
<context>
    <name>ligWidget</name>
    <message>
        <location filename="../../src/ligedit.cpp" line="31"/>
        <location filename="../../src/ligedit.cpp" line="315"/>
        <source>Lights</source>
        <translation>Lichtquellen</translation>
    </message>
</context>
<context>
    <name>mainCtrl</name>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="252"/>
        <source>Scale</source>
        <translation>Skaliere</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="285"/>
        <location filename="../../src/ui/mainwindow.ui" line="384"/>
        <location filename="../../src/ui/mainwindow.ui" line="410"/>
        <location filename="../../src/ui/mainwindow.ui" line="423"/>
        <source>Scale up</source>
        <translation>Hinauf skalieren</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="288"/>
        <location filename="../../src/ui/mainwindow.ui" line="387"/>
        <location filename="../../src/ui/mainwindow.ui" line="400"/>
        <location filename="../../src/ui/mainwindow.ui" line="413"/>
        <location filename="../../src/ui/mainwindow.ui" line="426"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="298"/>
        <location filename="../../src/ui/mainwindow.ui" line="332"/>
        <location filename="../../src/ui/mainwindow.ui" line="345"/>
        <location filename="../../src/ui/mainwindow.ui" line="358"/>
        <source>Scale down</source>
        <translation>Hinunter skalieren</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="301"/>
        <location filename="../../src/ui/mainwindow.ui" line="335"/>
        <location filename="../../src/ui/mainwindow.ui" line="348"/>
        <location filename="../../src/ui/mainwindow.ui" line="361"/>
        <location filename="../../src/ui/mainwindow.ui" line="374"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="311"/>
        <source> X</source>
        <translation> X</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="318"/>
        <source> Y</source>
        <translation> Y</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="325"/>
        <source> Z</source>
        <translation> Z</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="371"/>
        <source>Decrease gridlines</source>
        <translation>Raster vermindern</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="397"/>
        <source>Increase gridlines</source>
        <translation>Raster erhöhen</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="436"/>
        <source> A</source>
        <translation> A</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="443"/>
        <source>Gridlines</source>
        <translation>Rasterlinien</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="446"/>
        <source> G</source>
        <translation> R</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="31"/>
        <source>Enabe/disable views</source>
        <translation>Ansichten ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="34"/>
        <source>Show</source>
        <translation>Zeigen</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="64"/>
        <source>Show function 0</source>
        <translation>Zeige Funktion 0</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="67"/>
        <source>F0</source>
        <translation>F0</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="83"/>
        <source>Show function 1</source>
        <translation>Zeige Funktion 1</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="86"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="99"/>
        <source>Show function 2</source>
        <translation>Zeige Funktion 2</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="102"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="115"/>
        <source>Show parametric system</source>
        <translation>Zeige Parametersystem</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="118"/>
        <source>Par.</source>
        <translation>Par.</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="662"/>
        <source>Toggle cross on/off</source>
        <translation>Kreuz ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="665"/>
        <source>Cross</source>
        <translation>Kreuz</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="643"/>
        <source>Toggle axes on/off</source>
        <translation>Achsen ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="646"/>
        <source>Axes</source>
        <translation>Achsen</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="140"/>
        <source>Set current mode</source>
        <translation>Modus festlegen</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="143"/>
        <source>Mode</source>
        <translation>Modus</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="233"/>
        <source>Set point-mode</source>
        <translation>Punktmodus einschalten</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="236"/>
        <source>Point</source>
        <translation>Punkt</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="201"/>
        <source>Quad</source>
        <translation>Quad.</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="176"/>
        <source>Set wire-mode</source>
        <translation>Drahtgitter ein/aus</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="179"/>
        <source>Wire</source>
        <translation>Draht</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="709"/>
        <source>Cross coordinates and regarding function values</source>
        <translation>Kreuzkoordinaten und entsprechende Funktionswerte</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="528"/>
        <source>Rotate around X-axis</source>
        <translation>Rotiere um X-Achse</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="556"/>
        <source>Rotate around Y-axis</source>
        <translation>Rotiere um Y-Achse</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="584"/>
        <source>Rotate around Z-axis</source>
        <translation>Rotiere um Z-Achse</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="1088"/>
        <source>Switch between functions, isosurfaces and parametric system</source>
        <translation>Zwischen Funktionen, Isoflächen und Parametersystem wechseln</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="198"/>
        <source>Quadratic tessellation</source>
        <translation>Quadrat-Tessellation</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="214"/>
        <source>Triangle tessellation</source>
        <translation>Dreieck-Tessellation</translation>
    </message>
    <message>
        <location filename="../../src/ui/mainwindow.ui" line="217"/>
        <source>Triangle</source>
        <translation>Dreieck</translation>
    </message>
</context>
<context>
    <name>matUI</name>
    <message>
        <location filename="../../src/ui/matedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="51"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="64"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="74"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="84"/>
        <source>Par.</source>
        <translation>Par.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="118"/>
        <source>Sync</source>
        <translation>Sync</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="159"/>
        <source>Amb.</source>
        <translation>Umg.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="265"/>
        <location filename="../../src/ui/matedit.ui" line="392"/>
        <location filename="../../src/ui/matedit.ui" line="529"/>
        <location filename="../../src/ui/matedit.ui" line="656"/>
        <source>Lock RGB-sliders</source>
        <translation>Sperre RGB-Schieberegler</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="268"/>
        <location filename="../../src/ui/matedit.ui" line="395"/>
        <location filename="../../src/ui/matedit.ui" line="532"/>
        <location filename="../../src/ui/matedit.ui" line="659"/>
        <source>Lock</source>
        <translation>Sperre</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="286"/>
        <source>Diff.</source>
        <translation>Diff.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="423"/>
        <source>Spec.</source>
        <translation>Glanz.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="550"/>
        <source>Emi.</source>
        <translation>Emi.</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="688"/>
        <source>Specular shininess</source>
        <translation>Glanzlichtintensität</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="691"/>
        <source>Spec. shininess</source>
        <translation>Glanzlicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="25"/>
        <source>Edit surface properties</source>
        <translation>Oberflächeneigenschaften bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="28"/>
        <source>Edit surface</source>
        <translation>Oberfläche bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="81"/>
        <source>Edit surface parametric-system</source>
        <translation>Oberfläche Parametersystem bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="156"/>
        <source>Ambient surface properties</source>
        <translation>Umgebungslichteigenschaften</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="283"/>
        <source>Diffuse surface properties</source>
        <translation>Diffuse Lichteigenschaften </translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="420"/>
        <source>Specular surface properties</source>
        <translation>Glanzlichteigenschaften</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="547"/>
        <source>Emission surface properties</source>
        <translation>Emissionslichteigenschaften</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="709"/>
        <source>Specular shininess low&lt;-&gt;high</source>
        <translation>Glanzlicht schwach&lt;-&gt;stark</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="187"/>
        <location filename="../../src/ui/matedit.ui" line="314"/>
        <location filename="../../src/ui/matedit.ui" line="451"/>
        <location filename="../../src/ui/matedit.ui" line="578"/>
        <source>Red surface</source>
        <translation>Rote Oberfäche</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="206"/>
        <location filename="../../src/ui/matedit.ui" line="333"/>
        <location filename="../../src/ui/matedit.ui" line="470"/>
        <location filename="../../src/ui/matedit.ui" line="597"/>
        <source>Green surface</source>
        <translation>Grüne Oberfläche</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="225"/>
        <location filename="../../src/ui/matedit.ui" line="352"/>
        <location filename="../../src/ui/matedit.ui" line="489"/>
        <location filename="../../src/ui/matedit.ui" line="616"/>
        <source>Blue surface</source>
        <translation>Blaue Oberfläche</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="247"/>
        <source>Ambient alpha channel</source>
        <translation>Umgebungslicht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="374"/>
        <source>Diffuse alpha channel</source>
        <translation>Diffuses Licht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="511"/>
        <source>Specular alpha channel</source>
        <translation>Glanzlicht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="638"/>
        <source>Emission alpha channel</source>
        <translation>Emissionslicht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="115"/>
        <source>Synchronize back side with front</source>
        <translation>Synchronisiere Rückseite mit Vorderseite</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="136"/>
        <source>Change between front and back</source>
        <translation>Zwischen Rückseite und Vorderseite wechseln</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="139"/>
        <source>Back</source>
        <translation>Rückseite</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="48"/>
        <source>Edit surface F0/I0</source>
        <translation>Oberfläche F0/I0 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="61"/>
        <source>Edit surface F1/I1</source>
        <translation>Oberfläche F1/I1 bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/ui/matedit.ui" line="71"/>
        <source>Edit surface F2/I2</source>
        <translation>Oberfläche F2I/I2 bearbeiten</translation>
    </message>
</context>
<context>
    <name>matWidget</name>
    <message>
        <location filename="../../src/matedit.cpp" line="31"/>
        <location filename="../../src/matedit.cpp" line="136"/>
        <source>Surfaces</source>
        <translation>Oberflächen</translation>
    </message>
</context>
<context>
    <name>morUI</name>
    <message>
        <location filename="../../src/ui/moredit.ui" line="13"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="19"/>
        <source>Limits</source>
        <translation>Grenzen</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="25"/>
        <source>Lower limit</source>
        <translation>Untere Grenze</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="44"/>
        <source> - </source>
        <translation> - </translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="51"/>
        <source>Upper limit</source>
        <translation>Obere Grenze</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="127"/>
        <source>Steps</source>
        <translation>Schritte</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="124"/>
        <source>Steps in between lower/upper limits</source>
        <translation>Schritte zwischen unterer/oberer Grenze</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="177"/>
        <source>Frames/second</source>
        <translation>Bilder/Sekunde</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="180"/>
        <source>Frames</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="233"/>
        <source>Morph</source>
        <translation>Morphen</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="230"/>
        <source>Start/stop morphing</source>
        <translation> Starte/stoppe Morphing</translation>
    </message>
    <message>
        <location filename="../../src/ui/moredit.ui" line="106"/>
        <source>CPU/GPU utilization in %</source>
        <translation>CPU/GPU-Auslastung in %</translation>
    </message>
</context>
<context>
    <name>morWidget</name>
    <message>
        <location filename="../../src/moredit.cpp" line="34"/>
        <location filename="../../src/moredit.cpp" line="167"/>
        <source>Morphing</source>
        <translation>Morphing</translation>
    </message>
    <message>
        <location filename="../../src/moredit.cpp" line="152"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../../src/moredit.cpp" line="154"/>
        <source>Morph</source>
        <translation>Morphen</translation>
    </message>
</context>
<context>
    <name>picUI</name>
    <message>
        <location filename="../../src/ui/picedit.ui" line="16"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="28"/>
        <source>Properties</source>
        <translation>Eigenschaften</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="292"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="302"/>
        <source>JPG</source>
        <translation>JPG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="112"/>
        <source>Dimensions</source>
        <translation>Abmessungen</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="205"/>
        <location filename="../../src/ui/picedit.ui" line="224"/>
        <source>X-Dimension</source>
        <translation>X-Abmessung</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="227"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="160"/>
        <location filename="../../src/ui/picedit.ui" line="179"/>
        <source>Y-Dimension</source>
        <translation>Y-Abmessung</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="182"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="48"/>
        <location filename="../../src/ui/picedit.ui" line="61"/>
        <source>Picture quality: 0=low 100=high</source>
        <translation>Bildqualität: 0=niedrig 100=hoch</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="239"/>
        <source>Format</source>
        <translation>Bildformat</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="259"/>
        <source>Portable Document Format</source>
        <translation>Portable Document Format</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="262"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="269"/>
        <source>PostScript</source>
        <translation>PostScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="272"/>
        <source>PS</source>
        <translation>PS</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="289"/>
        <source>Portable Network Graphics</source>
        <translation>Portable Network Graphics</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="299"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="100"/>
        <source>Dpi</source>
        <translation>Dpi</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="124"/>
        <source>Lock/unlock XY-values</source>
        <translation>Sperre/entsperre XY-Werte</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="64"/>
        <source>Quality</source>
        <translation>Qualität</translation>
    </message>
    <message>
        <location filename="../../src/ui/picedit.ui" line="81"/>
        <location filename="../../src/ui/picedit.ui" line="97"/>
        <source>Dpi: 75..4800</source>
        <translation>Dpi: 75..4800</translation>
    </message>
</context>
<context>
    <name>picWidget</name>
    <message>
        <location filename="../../src/picedit.cpp" line="27"/>
        <location filename="../../src/picedit.cpp" line="133"/>
        <source>Picture</source>
        <translation>Bild</translation>
    </message>
</context>
<context>
    <name>speUI</name>
    <message>
        <location filename="../../src/ui/speedit.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="19"/>
        <source>Textures</source>
        <translation>Texturen</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="107"/>
        <location filename="../../src/ui/speedit.ui" line="218"/>
        <location filename="../../src/ui/speedit.ui" line="329"/>
        <location filename="../../src/ui/speedit.ui" line="440"/>
        <source>Flip texture vertical</source>
        <translation>Textur vertikal spiegeln</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="129"/>
        <location filename="../../src/ui/speedit.ui" line="240"/>
        <location filename="../../src/ui/speedit.ui" line="351"/>
        <location filename="../../src/ui/speedit.ui" line="462"/>
        <source>On</source>
        <translation>Ein</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="51"/>
        <location filename="../../src/ui/speedit.ui" line="162"/>
        <location filename="../../src/ui/speedit.ui" line="273"/>
        <location filename="../../src/ui/speedit.ui" line="384"/>
        <source>Load new texture</source>
        <translation>Neue Textur laden</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="361"/>
        <source>Par.</source>
        <translation>Par.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="576"/>
        <source>Fog</source>
        <translation>Nebel</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="659"/>
        <source>Red fog light</source>
        <translation>Rotes Nebellicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="684"/>
        <source>Green fog light</source>
        <translation>Grünes Nebellicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="709"/>
        <source>Blue fog light</source>
        <translation>Blaues Nebellicht</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="737"/>
        <source>Fog light alpha channel</source>
        <translation>Nebellicht Alpha-Kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="755"/>
        <source>Lock RGB-sliders</source>
        <translation>Sperre RGB-Schieberegler</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="758"/>
        <source>Lock</source>
        <translation>Sperre</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="798"/>
        <source>Fog mode</source>
        <translation>Nebelmodus</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="801"/>
        <source>Mode</source>
        <translation>Modus</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="825"/>
        <source>Exp</source>
        <translation>Exp</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="835"/>
        <source>Exp2</source>
        <translation>Exp2</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="842"/>
        <source>Linear</source>
        <translation>Linear</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="845"/>
        <source>Lin.</source>
        <translation>Lin.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="855"/>
        <source>Fog settings</source>
        <translation>Nebel-Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="858"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="882"/>
        <location filename="../../src/ui/speedit.ui" line="930"/>
        <source>Intensity</source>
        <translation>Intensität</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="898"/>
        <location filename="../../src/ui/speedit.ui" line="950"/>
        <source>Fog end value</source>
        <translation>Nebel Endwert</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="914"/>
        <location filename="../../src/ui/speedit.ui" line="940"/>
        <source>Fog starting value</source>
        <translation>Nebel Startwert</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="933"/>
        <source>Int.</source>
        <translation>Int.</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="943"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="953"/>
        <source>End</source>
        <translation>Ende</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="822"/>
        <source>Exponential</source>
        <translation>Exponentiell</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="832"/>
        <source>Quadratic exponential</source>
        <translation>Quadratisch exponentiell</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="368"/>
        <source>Texture parameter system</source>
        <translation>Textur Parametersystem</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="771"/>
        <source>Sync</source>
        <translation>Sync</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="493"/>
        <source>Span</source>
        <translation>Spannweite</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="532"/>
        <source>Increase/decrease texture span</source>
        <translation>Texturspannweite erhöhen/vermindern</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="612"/>
        <source>Fog colour properties</source>
        <translation>Farbeigenschaften Nebel</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="615"/>
        <source>Colour</source>
        <translation>Farbe</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="768"/>
        <source>Synchronize fog with background colour</source>
        <translation>Nebel mit Hintergrundfarbe synchronisieren</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="79"/>
        <location filename="../../src/ui/speedit.ui" line="190"/>
        <location filename="../../src/ui/speedit.ui" line="301"/>
        <location filename="../../src/ui/speedit.ui" line="412"/>
        <source>Remove texture from file</source>
        <translation>Textur von Datei entfernen</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="984"/>
        <source>Motion blur</source>
        <translation>Bewegungsunschärfe</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1011"/>
        <location filename="../../src/ui/speedit.ui" line="1094"/>
        <source>Translation offset for each iteration</source>
        <translation>Versatz pro Iteration</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1030"/>
        <location filename="../../src/ui/speedit.ui" line="1084"/>
        <source>Iterations calculated per frame</source>
        <translation>Berechnete Iterationen pro Frame</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1052"/>
        <location filename="../../src/ui/speedit.ui" line="1074"/>
        <source>Magnitude of blur effect</source>
        <translation>Ausmaß des Unschärfe-Effekts</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1077"/>
        <source>Magnitude</source>
        <translation>Ausmaß</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1087"/>
        <source>Iterations</source>
        <translation>Iterationen</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="1097"/>
        <source>Offset</source>
        <translation>Versatz</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="28"/>
        <source>F0/I0</source>
        <translation>F0/I0</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="35"/>
        <source>Texture F0/I0</source>
        <translation>Textur F0/I0</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="139"/>
        <source>F1/I1</source>
        <translation>F1/I1</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="146"/>
        <source>Texture F1/I1</source>
        <translation>Textur F1/I1</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="250"/>
        <source>F2/I2</source>
        <translation>F2/I2</translation>
    </message>
    <message>
        <location filename="../../src/ui/speedit.ui" line="257"/>
        <source>Texture F2/I2</source>
        <translation>Textur F2/I2</translation>
    </message>
</context>
<context>
    <name>speWidget</name>
    <message>
        <location filename="../../src/speedit.cpp" line="126"/>
        <location filename="../../src/speedit.cpp" line="158"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="126"/>
        <source>file</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="159"/>
        <source>Error loading file:</source>
        <translation>Fehler beim Laden:</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="38"/>
        <location filename="../../src/speedit.cpp" line="171"/>
        <location filename="../../src/speedit.cpp" line="182"/>
        <location filename="../../src/speedit.cpp" line="195"/>
        <location filename="../../src/speedit.cpp" line="206"/>
        <location filename="../../src/speedit.cpp" line="613"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="172"/>
        <source>Texture width too large</source>
        <translation>Breite der Textur ist zu groß</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="183"/>
        <source>Texture height too large</source>
        <translation>Höhe der Textur ist zu groß</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="196"/>
        <source>Texture width not a power of 2</source>
        <translation>Breite der Textur ist keine Potenz von 2</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="207"/>
        <source>Texture height not a power of 2</source>
        <translation>Höhe der Textur ist keine Potenz von 2</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="223"/>
        <location filename="../../src/speedit.cpp" line="243"/>
        <location filename="../../src/speedit.cpp" line="262"/>
        <location filename="../../src/speedit.cpp" line="286"/>
        <location filename="../../src/speedit.cpp" line="294"/>
        <source>System information</source>
        <translation>Systeminformation</translation>
    </message>
    <message>
        <location filename="../../src/speedit.cpp" line="224"/>
        <location filename="../../src/speedit.cpp" line="244"/>
        <location filename="../../src/speedit.cpp" line="263"/>
        <location filename="../../src/speedit.cpp" line="287"/>
        <location filename="../../src/speedit.cpp" line="295"/>
        <source>Out of memory</source>
        <translation>Kein Speicher mehr</translation>
    </message>
</context>
<context>
    <name>usrWidget</name>
    <message>
        <location filename="../../src/usredit.cpp" line="34"/>
        <location filename="../../src/usredit.cpp" line="220"/>
        <source>User defined items</source>
        <translation>Benutzerdefinierte Einträge</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="93"/>
        <source>Alert</source>
        <translation>Achtung</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="128"/>
        <location filename="../../src/usredit.cpp" line="221"/>
        <source>Item</source>
        <translation>Eintrag</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="149"/>
        <location filename="../../src/usredit.cpp" line="222"/>
        <source>Delete row</source>
        <translation>Zeile löschen</translation>
    </message>
    <message>
        <location filename="../../src/usredit.cpp" line="152"/>
        <location filename="../../src/usredit.cpp" line="223"/>
        <source>Insert row</source>
        <translation>Zeile einfügen</translation>
    </message>
</context>
</TS>
