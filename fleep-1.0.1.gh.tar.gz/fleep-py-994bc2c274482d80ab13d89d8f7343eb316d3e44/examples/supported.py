import fleep

print(fleep.supported_types())
print(fleep.supported_extensions())
print(fleep.supported_mimes())
