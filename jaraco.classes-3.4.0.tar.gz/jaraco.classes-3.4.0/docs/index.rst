Welcome to |project| documentation!
===================================

.. sidebar-links::
   :home:
   :pypi:

.. toctree::
   :maxdepth: 1

   history


.. tidelift-referral-banner::

.. automodule:: jaraco.classes.ancestry
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: jaraco.classes.meta
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: jaraco.classes.properties
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
