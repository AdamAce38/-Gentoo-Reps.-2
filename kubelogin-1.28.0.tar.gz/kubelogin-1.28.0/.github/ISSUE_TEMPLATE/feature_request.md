---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

## Purpose of the feature (why)
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]
A clear and concise description of what you want to happen.

## Your idea (how)
A clear and concise description of any alternative solutions or features you've considered.
