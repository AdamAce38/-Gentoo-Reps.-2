v0.0.2 2017-07-16 Zagreb
------------------------

- Safe-string support. Thanks to Jacques-Pascal Deplaix for
  the help.
- Remove Uchar.dump. It's no longer part of the API since
  4.05. See MPR7500 and GPR1081.


v0.0.1 2015-12-01 Cambridge (UK)
--------------------------------

First release.
