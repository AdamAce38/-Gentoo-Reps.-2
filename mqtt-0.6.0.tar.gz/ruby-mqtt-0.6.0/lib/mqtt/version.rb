module MQTT
  # The version number of the MQTT gem
  VERSION = '0.6.0'
end
