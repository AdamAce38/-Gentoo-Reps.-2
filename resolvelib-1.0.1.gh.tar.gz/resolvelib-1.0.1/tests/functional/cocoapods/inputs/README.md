Inputs in this directory are borrowed from https://github.com/CocoaPods/Resolver-Integration-Specs
