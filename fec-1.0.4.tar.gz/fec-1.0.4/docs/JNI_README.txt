JNI_README


The Java code uses JNI to call the native FEC C routines. It should be noted that while Java passes parameters (using JNI) to the C-code, in fact the parameters are accessed using the same memory space. (actually the JVM decides...the programmer has no control over this.)  
To ensure proper "clean up" after native code execution, surround the JNI code with the following statements. This lets the Java garbage collector know that the memory is free.

PushLocalFrame
<jni code>
PopLocalFrame

These JNI statements are implemented similarly to database transactions "begin transaction" and "commit transaction".




Additional Information can be found at the source: http://java.sun.com/docs/books/tutorial/native1.1/index.html




--------------------------------------------------------------------------------
This file created: March 21, 2001 for OpenCola by Todd Hiltz (todd@opencola.com)