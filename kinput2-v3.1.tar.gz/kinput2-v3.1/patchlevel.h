#define KINPUT2_VERSION "version 3.1"
#define DATE "$Date: 2002/10/03 09:31:24 $"
#define PATCHLEVEL 0
