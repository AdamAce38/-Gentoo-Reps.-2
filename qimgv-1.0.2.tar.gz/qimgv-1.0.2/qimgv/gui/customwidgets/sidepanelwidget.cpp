#include "sidepanelwidget.h"

SidePanelWidget::SidePanelWidget(QWidget *parent) : QWidget(parent) {

}
