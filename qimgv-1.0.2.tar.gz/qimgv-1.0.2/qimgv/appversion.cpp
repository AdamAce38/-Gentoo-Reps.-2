#include "appversion.h"

QVersionNumber appVersion(1,0,2);
