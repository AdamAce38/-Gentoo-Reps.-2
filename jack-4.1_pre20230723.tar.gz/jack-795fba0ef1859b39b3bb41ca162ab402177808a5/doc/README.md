This is the unaltered, outdated documentation as found on http://www.home.unix-ag.org/arne/jack/
