/*
20140319
Jan Mojzis
Public domain.
*/

#include <unistd.h>

int main(void) {

    _exit(0);
}
