/*
20140417
Jan Mojzis
Public domain.
*/

#include <unistd.h>
#include "e.h"

#ifndef EPROTO
error!
#endif

int main(void) {

    _exit(0);
}
