#ifndef _NUMTOSTR_H____
#define _NUMTOSTR_H____

#define NUMTOSTR_LEN 41

extern char *numtostr(char *, long long);

#endif
