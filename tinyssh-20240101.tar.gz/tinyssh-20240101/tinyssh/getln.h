#ifndef _GETLN_H____
#define _GETLN_H____

extern int getln(int, void *, long long);

#endif
