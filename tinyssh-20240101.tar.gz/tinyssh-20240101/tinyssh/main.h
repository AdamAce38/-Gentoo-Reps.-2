#ifndef _MAIN_H____
#define _MAIN_H____

extern int main_tinysshd(int, char **, const char *);
extern int main_tinysshd_printkey(int, char **);
extern int main_tinysshd_makekey(int, char **);

#endif
