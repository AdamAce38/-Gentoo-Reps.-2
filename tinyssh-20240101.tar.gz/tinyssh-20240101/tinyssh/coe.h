#ifndef _COE_H____
#define _COE_H____

extern void coe_enable(int);
extern void coe_disable(int);

#endif
