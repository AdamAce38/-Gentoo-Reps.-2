#ifndef _TRYMLOCK_H____
#define _TRYMLOCK_H____

extern void trymlock(void *, long long);
extern void trymunlock(void *, long long);

#endif
