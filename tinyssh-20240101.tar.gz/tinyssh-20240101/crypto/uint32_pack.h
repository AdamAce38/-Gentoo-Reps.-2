#ifndef _UINT32_PACK_H____
#define _UINT32_PACK_H____

#include "crypto_uint32.h"

extern void uint32_pack(unsigned char *, crypto_uint32);

#endif
