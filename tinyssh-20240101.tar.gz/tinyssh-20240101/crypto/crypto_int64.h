#ifndef crypto_int64_h
#define crypto_int64_h

#include <stdint.h>

typedef int64_t crypto_int64;

#endif
