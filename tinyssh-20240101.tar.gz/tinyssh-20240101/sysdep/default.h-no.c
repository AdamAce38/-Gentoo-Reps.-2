/* Public domain. */
int main(void) {
    return 0;
}
