/* Public domain. */
#include <libutil.h>

int main(void) {
    return 0;
}
