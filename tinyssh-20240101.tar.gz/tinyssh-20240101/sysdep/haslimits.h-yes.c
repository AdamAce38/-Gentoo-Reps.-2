/* Public domain. */
#include <limits.h>

int main(void) {
    return 0;
}
