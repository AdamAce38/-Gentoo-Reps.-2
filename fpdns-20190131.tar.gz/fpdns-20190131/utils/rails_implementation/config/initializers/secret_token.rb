# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
FpdnsRails::Application.config.secret_token = '4f5cb0f255d27cd56fe64b565ad3a697b9a56b854941c0d3eb603f972d2d75326a91cc4df951242d5b7b5ffa4cd1b66da768ffeef06cc218d20aaf0d9f953e10'
