#ifndef __DESCR_H__
#define __DESCR_H__


#include "widgets.h"


void showDescription(Area *parentArea);


#endif

