#! /bin/sh

../mkres/mkres --source resources.descr --output einstein.res

