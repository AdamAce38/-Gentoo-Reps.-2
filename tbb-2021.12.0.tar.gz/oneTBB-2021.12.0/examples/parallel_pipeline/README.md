# Code Samples of oneAPI Threading Building Blocks (oneTBB)
Examples using `parallel_pipeline` algorithm.

| Code sample name | Description
|:--- |:---
| square | Another string transformation example that squares numbers read from a file.
