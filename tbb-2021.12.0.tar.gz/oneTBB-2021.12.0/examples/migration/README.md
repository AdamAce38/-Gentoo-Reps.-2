# Code Samples of oneAPI Threading Building Blocks (oneTBB)
Examples of migrating from TBB APIs to the oneTBB APIs.

| Code sample name | Description
|:--- |:---
| recursive_fibonacci | Compute Fibonacci number in recursive way.
