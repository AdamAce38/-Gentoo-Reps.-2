#ifndef __DATETIME_H
#define __DATETIME_H

__BEGIN_DECLS
time_t xep82_datetime(const char *);
__END_DECLS

#endif
