#ifndef __XEP_H
#define __XEP_H

__BEGIN_DECLS
void	xep_init(void);
void	xep_deinit(void);
__END_DECLS

#endif
