#ifndef __COMPOSING_H
#define __COMPOSING_H

__BEGIN_DECLS
void composing_init(void);
void composing_deinit(void);
__END_DECLS

#endif
