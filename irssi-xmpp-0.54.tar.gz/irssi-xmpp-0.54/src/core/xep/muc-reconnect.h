#ifndef __MUC_RECONNECT_H
#define __MUC_RECONNECT_H

__BEGIN_DECLS
void muc_reconnect_init(void);
void muc_reconnect_deinit(void);
__END_DECLS

#endif
