#ifndef __VCARD_H
#define __VCARD_H

__BEGIN_DECLS
void vcard_init(void);
void vcard_deinit(void);
__END_DECLS

#endif
