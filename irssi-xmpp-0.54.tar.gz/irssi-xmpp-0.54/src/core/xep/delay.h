#ifndef __DELAY_H
#define __DELAY_H

__BEGIN_DECLS
void delay_init(void);
void delay_deinit(void);
__END_DECLS

#endif
