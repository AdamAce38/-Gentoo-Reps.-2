#ifndef __CHATSTATES_H
#define __CHATSTATES_H

__BEGIN_DECLS
void chatstates_init(void);
void chatstates_deinit(void);
__END_DECLS

#endif
