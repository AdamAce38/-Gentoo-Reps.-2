#ifndef __VERSION_H
#define __VERSION_H

__BEGIN_DECLS
void version_init(void);
void version_deinit(void);
__END_DECLS

#endif
