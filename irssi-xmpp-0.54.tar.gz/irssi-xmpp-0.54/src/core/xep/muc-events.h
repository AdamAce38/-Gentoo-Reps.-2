#ifndef __MUC_EVENTS_H
#define __MUC_EVENTS_H

__BEGIN_DECLS
void muc_events_init(void);
void muc_events_deinit(void);
__END_DECLS

#endif
