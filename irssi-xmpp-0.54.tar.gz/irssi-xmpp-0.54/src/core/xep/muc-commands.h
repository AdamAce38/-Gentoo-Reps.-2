#ifndef __MUC_COMMANDS_H
#define __MUC_COMMANDS_H

__BEGIN_DECLS
void muc_commands_init(void);
void muc_commands_deinit(void);
__END_DECLS

#endif
