#ifndef __OOB_H
#define __OOB_H

__BEGIN_DECLS
void oob_init(void);
void oob_deinit(void);
__END_DECLS

#endif
