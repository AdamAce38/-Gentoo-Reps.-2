#ifndef __STANZAS_H
#define __STANZAS_H

__BEGIN_DECLS
void	stanzas_init(void);
void	stanzas_deinit(void);
__END_DECLS

#endif
