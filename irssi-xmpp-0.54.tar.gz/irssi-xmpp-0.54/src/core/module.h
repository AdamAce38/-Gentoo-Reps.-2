#define MODULE_NAME "xmpp/core"

#include "irssi-config.h"
#include "common.h"
#include "xmpp.h"
