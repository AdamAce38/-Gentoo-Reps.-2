#ifndef __XMPP_SERVERS_RECONNECT_H
#define __XMPP_SERVERS_RECONNECT_H

__BEGIN_DECLS
void	xmpp_servers_reconnect_init(void);
void	xmpp_servers_reconnect_deinit(void);
__END_DECLS

#endif
