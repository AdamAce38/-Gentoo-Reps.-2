#ifndef __XMPP_SETTINGS_H
#define __XMPP_SETTINGS_H

__BEGIN_DECLS
void xmpp_settings_init(void);
void xmpp_settings_deinit(void);
__END_DECLS

#endif
