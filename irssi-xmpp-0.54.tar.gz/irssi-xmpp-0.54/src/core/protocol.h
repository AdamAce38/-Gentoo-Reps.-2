#ifndef __PROTOCOL_H
#define __PROTOCOL_H

#include "xmpp-servers.h"

__BEGIN_DECLS
void	protocol_init(void);
void	protocol_deinit(void);
__END_DECLS

#endif
