#ifndef __LOUDMOUTH_TOOLS_H
#define __LOUDMOUTH_TOOLS_H

__BEGIN_DECLS
LmMessageNode	*lm_find_node(LmMessageNode *, const char *,
		     const char *, const char *);
__END_DECLS

#endif
