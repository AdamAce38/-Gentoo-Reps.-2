#ifndef __TEXT_MUC_H
#define __TEXT_MUC_H

__BEGIN_DECLS
void text_muc_init(void);
void text_muc_deinit(void);
__END_DECLS

#endif
