#ifndef __TEXT_COMPOSING_H
#define __TEXT_COMPOSING_H

__BEGIN_DECLS
void text_composing_init(void);
void text_composing_deinit(void);
__END_DECLS

#endif
