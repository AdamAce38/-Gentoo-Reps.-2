#ifndef __TEXT_XEP_H
#define __TEXT_XEP_H

__BEGIN_DECLS
void	text_xep_init(void);
void	text_xep_deinit(void);
__END_DECLS

#endif
