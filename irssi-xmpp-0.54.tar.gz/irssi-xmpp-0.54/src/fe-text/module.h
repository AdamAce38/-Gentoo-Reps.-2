#define MODULE_NAME "xmpp/text"

#include "irssi-config.h"
#include "common.h"
#include "xmpp.h"
