#ifndef __FE_XMPP_QUERIES_H
#define __FE_XMPP_QUERIES_H

__BEGIN_DECLS
void fe_xmpp_queries_init(void);
void fe_xmpp_queries_deinit(void);
__END_DECLS

#endif
