#ifndef __FE_XMPP_WINDOWS_H
#define __FE_XMPP_WINDOWS_H

__BEGIN_DECLS
void fe_xmpp_windows_init(void);
void fe_xmpp_windows_deinit(void);
__END_DECLS

#endif
