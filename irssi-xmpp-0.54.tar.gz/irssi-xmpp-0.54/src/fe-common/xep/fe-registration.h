#ifndef __FE_REGISTRATION_H
#define __FE_REGISTRATION_H

__BEGIN_DECLS
void fe_registration_init(void);
void fe_registration_deinit(void);
__END_DECLS

#endif
