#ifndef __FE_XEP_H
#define __FE_XEP_H

__BEGIN_DECLS
void	fe_xep_init(void);
void	fe_xep_deinit(void);
__END_DECLS

#endif
