#ifndef __FE_PING_H
#define __FE_PING_H

__BEGIN_DECLS
void fe_ping_init(void);
void fe_ping_deinit(void);
__END_DECLS

#endif
