#ifndef __FE_VCARD_H
#define __FE_VCARD_H

__BEGIN_DECLS
void fe_vcard_init(void);
void fe_vcard_deinit(void);
__END_DECLS

#endif
