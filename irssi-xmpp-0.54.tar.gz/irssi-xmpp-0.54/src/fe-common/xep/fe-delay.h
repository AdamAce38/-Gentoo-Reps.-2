#ifndef __FE_DELAY_H
#define __FE_DELAY_H

__BEGIN_DECLS
void fe_delay_init(void);
void fe_delay_deinit(void);
__END_DECLS

#endif
