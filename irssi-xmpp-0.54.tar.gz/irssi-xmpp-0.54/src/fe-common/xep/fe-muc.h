#ifndef __FE_MUC_H
#define __FE_MUC_H

__BEGIN_DECLS
void fe_muc_init(void);
void fe_muc_deinit(void);
__END_DECLS

#endif
