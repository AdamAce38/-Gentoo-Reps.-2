#ifndef __FE_COMPOSING_H
#define __FE_COMPOSING_H

__BEGIN_DECLS
void	fe_composing_init(void);
void	fe_composing_deinit(void);
__END_DECLS

#endif
