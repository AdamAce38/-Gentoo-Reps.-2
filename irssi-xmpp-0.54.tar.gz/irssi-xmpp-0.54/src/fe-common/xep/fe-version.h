#ifndef __FE_VERSION_H
#define __FE_VERSION_H

__BEGIN_DECLS
void fe_version_init(void);
void fe_version_deinit(void);
__END_DECLS

#endif
