#ifndef __FE_XMPP_MESSAGES_H
#define __FE_XMPP_MESSAGES_H

__BEGIN_DECLS
void fe_xmpp_messages_init(void);
void fe_xmpp_messages_deinit(void);
__END_DECLS

#endif
