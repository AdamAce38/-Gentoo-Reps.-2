#ifndef __XMPP_FORMATS_H
#define __XMPP_FORMATS_H

__BEGIN_DECLS
void xmpp_formats_init(void);
void xmpp_formats_deinit(void);
__END_DECLS

#endif
