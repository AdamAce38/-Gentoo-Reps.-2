#ifndef __FE_STANZAS_H
#define __FE_STANZAS_H

__BEGIN_DECLS
void fe_stanzas_init(void);
void fe_stanzas_deinit(void);
__END_DECLS

#endif
