#ifndef __FE_ROSTERS_H
#define __FE__ROSTERS_H

__BEGIN_DECLS
void fe_rosters_init(void);
void fe_rosters_deinit(void);
__END_DECLS

#endif
