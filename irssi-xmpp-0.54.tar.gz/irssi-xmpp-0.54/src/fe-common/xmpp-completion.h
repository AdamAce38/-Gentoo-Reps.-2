#ifndef __XMPP_COMPLETION_H
#define __XMPP_COMPLETION_H

__BEGIN_DECLS
void xmpp_completion_init(void);
void xmpp_completion_deinit(void);
__END_DECLS

#endif
