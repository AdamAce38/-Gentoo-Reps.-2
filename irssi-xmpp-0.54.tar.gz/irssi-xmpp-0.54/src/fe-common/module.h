#define MODULE_NAME "fe-common/xmpp"

#define CORE_MODULE_NAME "fe-common/core"
#define IRC_MODULE_NAME "fe-common/irc"

#include "irssi-config.h"
#include "common.h"
#include "xmpp.h"
