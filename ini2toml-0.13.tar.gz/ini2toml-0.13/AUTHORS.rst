============
Contributors
============

* Anderson Bravalheri <andersonbravalheri@gmail.com>
* Michał Górny <mgorny@gentoo.org>
