# Bigbuffer_blocking

A single-module library extending `Core_kernel.Bigbuffer` with
functions for blocking I/O on a bigbuffer.
