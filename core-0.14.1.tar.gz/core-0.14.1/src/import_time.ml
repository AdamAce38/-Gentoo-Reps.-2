(* to be used by modules within Core that want to see the same unified view of Time that
   modules outside of Core see.  *)
module Time = Core_time_float
