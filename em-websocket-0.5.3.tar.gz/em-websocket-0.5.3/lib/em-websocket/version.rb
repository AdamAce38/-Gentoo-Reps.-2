module EventMachine
  module Websocket
    VERSION = "0.5.3"
  end
end
