Want to help make this information more accurate? If you have a meter not listed here, or you've verified that your meter has a different ERT Type than listed, submit your info and I'll update it.

Submit your meter: https://docs.google.com/forms/d/1WPhliiE7tnbTKa-WDQ9Bf7UIf27qPMqX0IarxFGWGKY/viewform?usp=send_form

 * Electric: 04, 05, 07, 08
 * Gas: 02, 09, 12
 * Water: 11, 13

The compatible meter table has moved to a csv file: [ERT Compatible Meters](https://github.com/bemasher/rtlamr/blob/master/meters.csv)