"""Constant variables for tmuxp workspace functionality."""
VALID_WORKSPACE_DIR_FILE_EXTENSIONS = [".yaml", ".yml", ".json"]
