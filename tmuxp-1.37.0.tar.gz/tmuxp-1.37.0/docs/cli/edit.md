(edit-config)=

(cli-edit)=

# tmuxp edit

```{eval-rst}
.. argparse::
    :module: tmuxp.cli
    :func: create_parser
    :prog: tmuxp
    :path: edit
```
