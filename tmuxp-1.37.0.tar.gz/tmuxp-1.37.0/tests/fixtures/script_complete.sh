#!/bin/sh

echo hello
echo $?    # Exit status 0 returned because command executed successfully.
