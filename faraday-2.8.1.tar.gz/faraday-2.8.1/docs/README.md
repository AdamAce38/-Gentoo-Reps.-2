# Faraday Docs

Faraday Docs are powered by [Docsify](https://docsify.js.org/#/).

## Development

### Setup

From the Faraday project root, run the following:

```bash
npm install # this will install the necessary dependencies
```

### Running the Docs Locally

To preview your changes locally, run the following:

```bash
npm run docs
```
