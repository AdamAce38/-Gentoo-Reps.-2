# frozen_string_literal: true

module Faraday
  VERSION = '2.8.1'
end
