Mamba
=====

**Mamba** is a *Behaviour-Driven Development* tool for Python developers.

Is heavily influenced from RSpec, Mocha, Jasmine or Ginkgo.

This is the official documentation site for Mamba.

Contents
--------

.. toctree::
   :maxdepth: 2

   getting-started
   example-groups
   hooks
   filtering
   formatters
   integration
   other-features
