# -*- coding: utf-8 -*-


class HelperClass(object):
    pass
