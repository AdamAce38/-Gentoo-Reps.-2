from mamba import description, it

with description('Fixture#without_inner_contexts'):
    with it('first example'):
        pass

    with it('second example'):
        pass

    with it('third example'):
        pass
