# -*- coding: utf-8 -*-

from mamba import description

from .helpers import HelperClass


with description(HelperClass):
    pass
