#ifndef __H5_FCMP_H
#define __H5_FCMP_H

h5_int64_t
h5priv_fcmp (
	h5_float64_t A,
	h5_float64_t B,
	h5_int32_t maxUlps );

#endif
