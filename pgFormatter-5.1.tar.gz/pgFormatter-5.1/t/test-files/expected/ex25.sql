CREATE TABLE demo.test (
    foo text,
    bar timestamp with time zone,
    baz text
)
WITH (
    OIDS = FALSE
);

