CREATE TABLE demo.test (
	    foo text,
	    bar timestamp WITH time zone, baz text
) WITH (OIDS = FALSE);
