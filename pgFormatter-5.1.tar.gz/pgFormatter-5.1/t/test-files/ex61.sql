SELECT
    myfunction (123, 'ertez', col1),
    pg_sleep(12)
FROM
    mytbl1;

CREATE OR REPLACE FUNCTION f() RETURNS BOOL AS '/foo','bar' LANGUAGE C;

SELECT
  lives_ok ('INSERT INTO "order".v_order (status, order_id, name)
    VALUES (''complete'', ''' || get_order_id () || ''', '' caleb ''', 'with all parameters');

INSERT INTO table1
  (id, name)
VALUES
-- 5 min <= duration < 15 min
  (10, 'duration');

INSERT INTO table1
  (id, name)
VALUES
-- name
  (10, 'duration')

