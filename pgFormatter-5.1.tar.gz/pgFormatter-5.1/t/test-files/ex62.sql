-- test placeholder: perl pg_format samples/ex62.sql -w 60 -C -p 'https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)'

-- This code simply contains a long url in a comment. https://github.com/aubertc/pgFormatter/blob/master/t/test-files/ex62.sql
