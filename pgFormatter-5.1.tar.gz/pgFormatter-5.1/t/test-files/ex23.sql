INSERT INTO task_item (task_item_id, task_item_description, priority, on_hold, task_type) VALUES (1, 'a desc', 'low', 't', 'an item');
