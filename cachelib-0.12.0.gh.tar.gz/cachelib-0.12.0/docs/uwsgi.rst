uWSGI Backend
=============

.. automodule:: cachelib.uwsgi
   :members:
   :undoc-members:
   :show-inheritance:
