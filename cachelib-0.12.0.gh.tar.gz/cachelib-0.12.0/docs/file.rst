File Backend
============

.. automodule:: cachelib.file
   :members:
   :undoc-members:
   :show-inheritance:
