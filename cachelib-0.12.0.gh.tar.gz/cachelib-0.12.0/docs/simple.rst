Simple Memory Backend
=====================

.. automodule:: cachelib.simple
   :members:
   :undoc-members:
   :show-inheritance:
