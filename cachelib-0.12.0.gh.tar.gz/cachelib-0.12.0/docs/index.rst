CacheLib
========

A collection of cache libraries in the same API interface. Extracted
from Werkzeug.

.. toctree::
    :maxdepth: 2

    base
    simple
    file
    redis
    memcached
    uwsgi
    dynamodb
    mongodb

.. toctree::
    :maxdepth: 2

    license
    changes
