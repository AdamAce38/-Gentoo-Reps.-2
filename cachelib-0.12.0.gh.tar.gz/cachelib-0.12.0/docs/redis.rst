Redis Backend
=============

.. automodule:: cachelib.redis
   :members:
   :undoc-members:
   :show-inheritance:
