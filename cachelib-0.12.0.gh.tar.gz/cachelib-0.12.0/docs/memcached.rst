Memcached Backend
=================

.. automodule:: cachelib.memcached
   :members:
   :undoc-members:
   :show-inheritance:
